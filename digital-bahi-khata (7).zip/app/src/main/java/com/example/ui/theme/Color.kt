package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kisan / Agriculture themed vibrant colors
val EmeraldDark = Color(0xFF1B5E20)
val EmeraldPrimary = Color(0xFF2E7D32)
val EmeraldLight = Color(0xFF4CAF50)
val EmeraldContainer = Color(0xFFE8F5E9)

val WaterBlue = Color(0xFF0288D1)
val WaterBlueLight = Color(0xFFE1F5FE)

val GoldAccent = Color(0xFFF57F17)
val GoldContainer = Color(0xFFFFF9C4)

val AlertRed = Color(0xFFD32F2F)
val AlertRedLight = Color(0xFFFFEBEE)

val SurfaceLight = Color(0xFFF9FBF8)
val SurfaceCard = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1E293B)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)
val DividerColor = Color(0xFFE2E8F0)
