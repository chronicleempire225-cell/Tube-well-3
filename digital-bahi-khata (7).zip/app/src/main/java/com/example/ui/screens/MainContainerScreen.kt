package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.components.AddCustomerDialog
import com.example.ui.components.AddSessionDialog
import com.example.ui.components.AppHeader
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.RecordPaymentDialog
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.KisanLedgerViewModel

@Composable
fun MainContainerScreen(
    viewModel: KisanLedgerViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val isHindi by viewModel.isHindi.collectAsState()
    val timerState by viewModel.timerState.collectAsState()
    val customers by viewModel.customers.collectAsState()

    val showAddCustomer by viewModel.showAddCustomerDialog.collectAsState()
    val showAddSession by viewModel.showAddSessionDialog.collectAsState()
    val showPayment by viewModel.showPaymentDialog.collectAsState()
    val receiptSession by viewModel.showReceiptDialog.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            AppHeader(
                isHindi = isHindi,
                activePumpRunning = timerState.isRunning,
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceCard,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == AppTab.HOME,
                    onClick = {
                        viewModel.selectCustomer(null)
                        viewModel.setTab(AppTab.HOME)
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == AppTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = {
                        Text(
                            text = if (isHindi) "होम" else "Home",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == AppTab.HOME) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = EmeraldDark,
                        indicatorColor = EmeraldContainer,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_home")
                )

                NavigationBarItem(
                    selected = currentTab == AppTab.CUSTOMERS,
                    onClick = {
                        viewModel.selectCustomer(null)
                        viewModel.setTab(AppTab.CUSTOMERS)
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == AppTab.CUSTOMERS) Icons.Filled.Groups else Icons.Outlined.Groups,
                            contentDescription = "Farmers"
                        )
                    },
                    label = {
                        Text(
                            text = if (isHindi) "किसान" else "Farmers",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == AppTab.CUSTOMERS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = EmeraldDark,
                        indicatorColor = EmeraldContainer,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_customers")
                )

                NavigationBarItem(
                    selected = currentTab == AppTab.SESSIONS,
                    onClick = {
                        viewModel.selectCustomer(null)
                        viewModel.setTab(AppTab.SESSIONS)
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == AppTab.SESSIONS) Icons.Filled.WaterDrop else Icons.Outlined.WaterDrop,
                            contentDescription = "Sessions"
                        )
                    },
                    label = {
                        Text(
                            text = if (isHindi) "सिंचाई" else "Sessions",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == AppTab.SESSIONS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = EmeraldDark,
                        indicatorColor = EmeraldContainer,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_sessions")
                )

                NavigationBarItem(
                    selected = currentTab == AppTab.REPORTS,
                    onClick = {
                        viewModel.selectCustomer(null)
                        viewModel.setTab(AppTab.REPORTS)
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == AppTab.REPORTS) Icons.Filled.Assessment else Icons.Outlined.Assessment,
                            contentDescription = "Reports"
                        )
                    },
                    label = {
                        Text(
                            text = if (isHindi) "रिपोर्ट" else "Reports",
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == AppTab.REPORTS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldDark,
                        selectedTextColor = EmeraldDark,
                        indicatorColor = EmeraldContainer,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_tab_reports")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.HOME -> HomeScreen(viewModel = viewModel)
                AppTab.CUSTOMERS -> CustomersScreen(viewModel = viewModel)
                AppTab.SESSIONS -> SessionsScreen(viewModel = viewModel)
                AppTab.REPORTS -> ReportsScreen(viewModel = viewModel)
            }
        }
    }

    // Global Dialogs
    if (showAddCustomer) {
        AddCustomerDialog(
            isHindi = isHindi,
            onDismiss = { viewModel.showAddCustomerDialog.value = false },
            onConfirm = { name, phone, village, rate, due ->
                viewModel.addCustomer(name, phone, village, rate, due)
            }
        )
    }

    if (showAddSession) {
        AddSessionDialog(
            customers = customers,
            isHindi = isHindi,
            onDismiss = { viewModel.showAddSessionDialog.value = false },
            onConfirm = { custId, duration, rate, notes ->
                viewModel.addSession(custId, duration, rate, notes)
            }
        )
    }

    if (showPayment) {
        RecordPaymentDialog(
            customers = customers,
            isHindi = isHindi,
            onDismiss = { viewModel.showPaymentDialog.value = false },
            onConfirm = { custId, amount, mode, notes ->
                viewModel.recordPayment(custId, amount, mode, notes)
            }
        )
    }

    if (receiptSession != null) {
        val session = receiptSession!!
        ReceiptDialog(
            session = session,
            receiptText = viewModel.getReceiptText(session),
            isHindi = isHindi,
            onDismiss = { viewModel.showReceiptDialog.value = null }
        )
    }
}
