package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.PumpSession
import com.example.ui.components.LivePumpTimerCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterBlue
import com.example.ui.theme.WaterBlueLight
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.KisanLedgerViewModel

@Composable
fun HomeScreen(
    viewModel: KisanLedgerViewModel,
    modifier: Modifier = Modifier
) {
    val summary by viewModel.summary.collectAsState()
    val timerState by viewModel.timerState.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val sessions by viewModel.sessions.collectAsState()
    val isHindi by viewModel.isHindi.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Live Pump Widget
        item {
            LivePumpTimerCard(
                timerState = timerState,
                customers = customers,
                isHindi = isHindi,
                onStartTimer = { custId, rate -> viewModel.startPumpTimer(custId, rate) },
                onStopTimer = { viewModel.stopPumpTimer() }
            )
        }

        // 2. Summary Dashboard Metrics Grid
        item {
            Text(
                text = if (isHindi) "खाता सारांश (Account Overview)" else "Account Overview",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryMetricCard(
                    title = if (isHindi) "कुल बकाया" else "Total Due",
                    amount = "₹${summary.totalPendingDue.toInt()}",
                    subtitle = if (isHindi) "किसानों से लेना है" else "Receivable",
                    icon = Icons.Default.CurrencyRupee,
                    cardColor = AlertRedLight,
                    accentColor = AlertRed,
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    title = if (isHindi) "कुल वसूली" else "Collected",
                    amount = "₹${summary.totalCollected.toInt()}",
                    subtitle = if (isHindi) "जमा प्राप्त राशि" else "Total Received",
                    icon = Icons.Default.AccountBalanceWallet,
                    cardColor = EmeraldContainer,
                    accentColor = EmeraldDark,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryMetricCard(
                    title = if (isHindi) "कुल सिंचाई" else "Total Irrigation",
                    amount = "${summary.totalHoursIrrigated} घंटे",
                    subtitle = if (isHindi) "ट्यूबवेल चला" else "Hours Run",
                    icon = Icons.Default.Opacity,
                    cardColor = WaterBlueLight,
                    accentColor = WaterBlue,
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    title = if (isHindi) "कुल किसान" else "Total Farmers",
                    amount = "${summary.totalFarmers} किसान",
                    subtitle = if (isHindi) "सक्रिय खाते" else "Active Accounts",
                    icon = Icons.Default.Groups,
                    cardColor = GoldContainer,
                    accentColor = GoldAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Quick Action Buttons
        item {
            Text(
                text = if (isHindi) "त्वरित कार्य (Quick Actions)" else "Quick Actions",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.showAddCustomerDialog.value = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_customer_button"),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isHindi) "+ नया किसान" else "+ Farmer", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.showAddSessionDialog.value = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WaterBlue),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_session_button"),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.WaterDrop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isHindi) "+ सिंचाई" else "+ Session", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.showPaymentDialog.value = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_payment_button"),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isHindi) "+ जमा राशि" else "+ Payment", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 4. Recent Irrigation Sessions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isHindi) "हाल की सिंचाई (Recent Sessions)" else "Recent Sessions",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = if (isHindi) "सभी देखें >" else "View All >",
                    color = EmeraldDark,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { viewModel.setTab(AppTab.SESSIONS) }
                )
            }
        }

        items(sessions.take(4)) { session ->
            RecentSessionRowItem(
                session = session,
                isHindi = isHindi,
                onViewReceipt = { viewModel.showReceiptDialog.value = session },
                onSelectCustomer = {
                    viewModel.selectCustomer(session.customerId)
                    viewModel.setTab(AppTab.CUSTOMERS)
                }
            )
        }
    }
}

@Composable
fun SummaryMetricCard(
    title: String,
    amount: String,
    subtitle: String,
    icon: ImageVector,
    cardColor: Color,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = accentColor
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = amount,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun RecentSessionRowItem(
    session: PumpSession,
    isHindi: Boolean,
    onViewReceipt: () -> Unit,
    onSelectCustomer: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectCustomer() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(WaterBlueLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = null,
                        tint = WaterBlue,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = session.customerName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "${session.dateText} • ${session.durationHours} घंटे",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    if (session.notes.isNotBlank()) {
                        Text(
                            text = session.notes,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "₹${session.totalAmount.toInt()}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = EmeraldDark
                )
                Surface(
                    color = if (session.isPaid) EmeraldContainer else AlertRedLight,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (session.isPaid) (if (isHindi) "जमा" else "Paid") else (if (isHindi) "बकाया" else "Due"),
                        color = if (session.isPaid) EmeraldDark else AlertRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
