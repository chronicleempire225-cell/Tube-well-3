package com.example.data.localization

import java.util.concurrent.ConcurrentHashMap

enum class AppLanguage(val code: String, val nativeName: String, val englishName: String, val region: String) {
    HINDI("hi", "हिंदी", "Hindi", "भारत (India)"),
    ENGLISH("en", "English", "English", "International"),
    PUNJABI("pa", "ਪੰਜਾਬੀ", "Punjabi", "ਪੰਜਾਬ (Punjab)"),
    GUJARATI("gu", "ગુજરાતી", "Gujarati", "ગુજરાત (Gujarat)"),
    MARATHI("mr", "मराठी", "Marathi", "महाराष्ट्र (Maharashtra)"),
    BENGALI("bn", "বাংলা", "Bengali", "পশ্চিমবঙ্গ (Bengal)"),
    TELUGU("te", "తెలుగు", "Telugu", "ఆంధ్ర / తెలంగాణ"),
    TAMIL("ta", "தமிழ்", "Tamil", "தமிழ்நாடு (Tamil Nadu)"),
    KANNADA("kn", "ಕನ್ನಡ", "Kannada", "ಕರ್ನಾಟಕ (Karnataka)"),
    URDU("ur", "اردو", "Urdu", "پاکستان / بھارت"),
    SPANISH("es", "Español", "Spanish", "América Latina / España"),
    ARABIC("ar", "العربية", "Arabic", "الشرق الأوسط")
}

/**
 * Universal Dynamic Translation & Localization Engine
 * Provides instant string lookup, dynamic phrase translation across all 12 languages,
 * and smart token/pattern translation for runtime content.
 */
object LanguageManager {

    private val translationCache = ConcurrentHashMap<String, String>()

    fun getAllLanguages(): List<AppLanguage> = AppLanguage.values().toList()

    fun getString(key: String, language: AppLanguage): String {
        val map = STRINGS[key]
        if (map != null) {
            val res = map[language] ?: map[AppLanguage.ENGLISH] ?: map[AppLanguage.HINDI]
            if (res != null) return res
        }
        return translate(key, language)
    }

    /**
     * Translates ANY string dynamically to the target language.
     * Uses fast cache -> dictionary -> token/phrase pattern replacement -> fallback.
     */
    fun translate(text: String, language: AppLanguage): String {
        if (text.isBlank()) return text
        if (language == AppLanguage.HINDI && isPrimarilyHindi(text)) return text
        if (language == AppLanguage.ENGLISH && isPrimarilyEnglish(text)) return text

        val cacheKey = "${language.code}::${text.trim()}"
        translationCache[cacheKey]?.let { return it }

        val trimmed = text.trim()

        // 1. Direct dictionary check on STRINGS
        STRINGS[trimmed]?.let { map ->
            map[language]?.let {
                translationCache[cacheKey] = it
                return it
            }
        }

        // 2. Direct lookup in extensive PHRASES dictionary
        PHRASES[trimmed]?.let { map ->
            map[language]?.let {
                translationCache[cacheKey] = it
                return it
            }
        }

        // 3. Normalized lookup (ignoring emoji prefixes or symbols)
        val cleanKey = normalizePhrase(trimmed)
        if (cleanKey.isNotBlank() && cleanKey != trimmed) {
            PHRASES[cleanKey]?.let { map ->
                val translated = map[language]
                if (translated != null) {
                    val prefix = trimmed.takeWhile { !it.isLetterOrDigit() }
                    val suffix = trimmed.takeLastWhile { !it.isLetterOrDigit() }
                    val result = "$prefix$translated$suffix"
                    translationCache[cacheKey] = result
                    return result
                }
            }
        }

        // 4. Pattern / dynamic token replacements
        var result = trimmed

        // Rate pattern: e.g. "₹160/घंटा" or "₹160/hr"
        if (result.contains("/घंटा") || result.contains("/hr")) {
            val unit = when (language) {
                AppLanguage.HINDI -> "/घंटा"
                AppLanguage.ENGLISH -> "/hr"
                AppLanguage.PUNJABI -> "/ਘੰਟਾ"
                AppLanguage.GUJARATI -> "/કલાક"
                AppLanguage.MARATHI -> "/तास"
                AppLanguage.BENGALI -> "/ঘণ্টা"
                AppLanguage.TELUGU -> "/గంట"
                AppLanguage.TAMIL -> "/மணி"
                AppLanguage.KANNADA -> "/ಗಂಟೆ"
                AppLanguage.URDU -> "/گھنٹہ"
                AppLanguage.SPANISH -> "/hora"
                AppLanguage.ARABIC -> "/ساعة"
            }
            result = result.replace("/घंटा", unit).replace("/hr", unit)
        }

        // Hours pattern: e.g. "3.5 घंटे" or "3.5 hrs"
        val hoursWord = when (language) {
            AppLanguage.HINDI -> "घंटे"
            AppLanguage.ENGLISH -> "hrs"
            AppLanguage.PUNJABI -> "ਘੰਟੇ"
            AppLanguage.GUJARATI -> "કલાકો"
            AppLanguage.MARATHI -> "तास"
            AppLanguage.BENGALI -> "ঘণ্টা"
            AppLanguage.TELUGU -> "గంటలు"
            AppLanguage.TAMIL -> "மணி"
            AppLanguage.KANNADA -> "ಗಂಟೆಗಳು"
            AppLanguage.URDU -> "گھنٹے"
            AppLanguage.SPANISH -> "horas"
            AppLanguage.ARABIC -> "ساعات"
        }
        result = result.replace(Regex("(\\d+(?:\\.\\d+)?)\\s*(?:घंटे|hrs|hours)"), "$1 $hoursWord")

        // Days left pattern: e.g. "30 दिन शेष" or "30 days left"
        val daysWord = when (language) {
            AppLanguage.HINDI -> "दिन शेष"
            AppLanguage.ENGLISH -> "days left"
            AppLanguage.PUNJABI -> "ਦਿਨ ਬਾਕੀ"
            AppLanguage.GUJARATI -> "દિવસ બાકી"
            AppLanguage.MARATHI -> "दिवस शिल्लक"
            AppLanguage.BENGALI -> "দিন বাকি"
            AppLanguage.TELUGU -> "రోజులు మిగిలి ఉన్నాయి"
            AppLanguage.TAMIL -> "நாட்கள் மீதம்"
            AppLanguage.KANNADA -> "ದಿನಗಳು ಬಾಕಿ"
            AppLanguage.URDU -> "دن باقی"
            AppLanguage.SPANISH -> "días restantes"
            AppLanguage.ARABIC -> "أيام متبقية"
        }
        result = result.replace(Regex("(\\d+)\\s*(?:दिन शेष|दिन शेष बचे हैं|days left)"), "$1 $daysWord")

        // Replace common terms
        for ((hiTerm, termMap) in COMMON_TERMS) {
            if (result.contains(hiTerm)) {
                val targetTerm = termMap[language] ?: termMap[AppLanguage.ENGLISH] ?: hiTerm
                result = result.replace(hiTerm, targetTerm)
            }
        }

        translationCache[cacheKey] = result
        return result
    }

    private fun isPrimarilyHindi(str: String): Boolean {
        return str.any { it in '\u0900'..'\u097F' }
    }

    private fun isPrimarilyEnglish(str: String): Boolean {
        return str.all { it.isWhitespace() || it in 'a'..'z' || it in 'A'..'Z' || it.isDigit() || !it.isLetter() }
    }

    private fun normalizePhrase(text: String): String {
        return text.trim()
            .replace(Regex("^[🔴🟢⚡👑💡✓⏳📍📢🎧📜🚪🌾⭐]+\\s*"), "")
            .replace(Regex("\\s*[🔒👑💥⭐✓←→]+$"), "")
            .trim()
    }

    private val COMMON_TERMS: Map<String, Map<AppLanguage, String>> = mapOf(
        "सक्रिय" to mapOf(
            AppLanguage.HINDI to "सक्रिय", AppLanguage.ENGLISH to "Active", AppLanguage.PUNJABI to "ਸਰਗਰਮ",
            AppLanguage.GUJARATI to "સક્રિય", AppLanguage.MARATHI to "सक्रिय", AppLanguage.BENGALI to "সক্রিয়",
            AppLanguage.TELUGU to "యాక్టివ్", AppLanguage.TAMIL to "செயலில்", AppLanguage.KANNADA to "ಸಕ್ರಿಯ",
            AppLanguage.URDU to "فعال", AppLanguage.SPANISH to "Activo", AppLanguage.ARABIC to "نشط"
        ),
        "निष्क्रिय" to mapOf(
            AppLanguage.HINDI to "निष्क्रिय", AppLanguage.ENGLISH to "Inactive", AppLanguage.PUNJABI to "ਅਕਿਰਿਆਸ਼ੀਲ",
            AppLanguage.GUJARATI to "નિષ્ક્રિય", AppLanguage.MARATHI to "निष्क्रिय", AppLanguage.BENGALI to "নিষ্ক্রিয়",
            AppLanguage.TELUGU to "నిష్క్రియం", AppLanguage.TAMIL to "செயலற்றது", AppLanguage.KANNADA to "ನಿಷ್ಕ್ರಿಯ",
            AppLanguage.URDU to "غیر فعال", AppLanguage.SPANISH to "Inactivo", AppLanguage.ARABIC to "غير نشط"
        ),
        "सत्यापित" to mapOf(
            AppLanguage.HINDI to "सत्यापित", AppLanguage.ENGLISH to "Verified", AppLanguage.PUNJABI to "ਪ੍ਰਮਾਣਿਤ",
            AppLanguage.GUJARATI to "ચકાસાયેલ", AppLanguage.MARATHI to "सत्यापित", AppLanguage.BENGALI to "যাচাইকৃত",
            AppLanguage.TELUGU to "ధృవీకరించబడింది", AppLanguage.TAMIL to "சரிபார்க்கப்பட்டது", AppLanguage.KANNADA to "ಪರಿಶೀಲಿಸಲಾಗಿದೆ",
            AppLanguage.URDU to "تصدیق شدہ", AppLanguage.SPANISH to "Verificado", AppLanguage.ARABIC to "تم التحقق"
        ),
        "कुल" to mapOf(
            AppLanguage.HINDI to "कुल", AppLanguage.ENGLISH to "Total", AppLanguage.PUNJABI to "ਕੁੱਲ",
            AppLanguage.GUJARATI to "કુલ", AppLanguage.MARATHI to "एकूण", AppLanguage.BENGALI to "মোট",
            AppLanguage.TELUGU to "మొత్తం", AppLanguage.TAMIL to "மொத்தம்", AppLanguage.KANNADA to "ಒಟ್ಟು",
            AppLanguage.URDU to "کل", AppLanguage.SPANISH to "Total", AppLanguage.ARABIC to "المجموع"
        ),
        "बाकी" to mapOf(
            AppLanguage.HINDI to "बाकी", AppLanguage.ENGLISH to "Due", AppLanguage.PUNJABI to "ਬਾਕੀ",
            AppLanguage.GUJARATI to "બાકી", AppLanguage.MARATHI to "बाकी", AppLanguage.BENGALI to "বাকি",
            AppLanguage.TELUGU to "బాకీ", AppLanguage.TAMIL to "நிலுவை", AppLanguage.KANNADA to "ಬಾಕಿ",
            AppLanguage.URDU to "باقی", AppLanguage.SPANISH to "Saldo", AppLanguage.ARABIC to "متبقي"
        ),
        "जमा" to mapOf(
            AppLanguage.HINDI to "जमा", AppLanguage.ENGLISH to "Paid", AppLanguage.PUNJABI to "ਜਮ੍ਹਾ",
            AppLanguage.GUJARATI to "જમા", AppLanguage.MARATHI to "जमा", AppLanguage.BENGALI to "জমা",
            AppLanguage.TELUGU to "చెల్లించిన", AppLanguage.TAMIL to "செலுத்திய", AppLanguage.KANNADA to "ಜಮೆ",
            AppLanguage.URDU to "جمع", AppLanguage.SPANISH to "Pagado", AppLanguage.ARABIC to "مدفوع"
        )
    )

    private val PHRASES: Map<String, Map<AppLanguage, String>> = mapOf(
        // Home Screen Phrases
        "सिंचाई सेवा खाता" to mapOf(
            AppLanguage.HINDI to "सिंचाई सेवा खाता",
            AppLanguage.ENGLISH to "Irrigation Service Account",
            AppLanguage.PUNJABI to "ਸਿੰਚਾਈ ਸੇਵਾ ਖਾਤਾ",
            AppLanguage.GUJARATI to "સિંચાઈ સેવા ખાતું",
            AppLanguage.MARATHI to "सिंचन सेवा खाते",
            AppLanguage.BENGALI to "সেচ সেবা হিসাব",
            AppLanguage.TELUGU to "సాగునీటి సేవా ఖాతా",
            AppLanguage.TAMIL to "பாசன சேவை கணக்கு",
            AppLanguage.KANNADA to "ನೀರಾವರಿ ಸೇವಾ ಖಾತೆ",
            AppLanguage.URDU to "آبپاشی سروس کھاتہ",
            AppLanguage.SPANISH to "Cuenta de Servicio de Riego",
            AppLanguage.ARABIC to "حساب خدمة الري"
        ),
        "व्यक्ति चुनें और सत्र शुरू करें" to mapOf(
            AppLanguage.HINDI to "व्यक्ति चुनें और सत्र शुरू करें",
            AppLanguage.ENGLISH to "Select Farmer & Start Session",
            AppLanguage.PUNJABI to "ਕਿਸਾਨ ਚੁਣੋ ਅਤੇ ਸੈਸ਼ਨ ਸ਼ੁਰੂ ਕਰੋ",
            AppLanguage.GUJARATI to "ખેડૂત પસંદ કરો અને સત્ર શરૂ કરો",
            AppLanguage.MARATHI to "शेतकरी निवडा आणि सत्र सुरू करा",
            AppLanguage.BENGALI to "কৃষক নির্বাচন করুন ও সেশন শুরু করুন",
            AppLanguage.TELUGU to "రైతును ఎంచుకుని సెషన్ ప్రారంభించండి",
            AppLanguage.TAMIL to "விவசாயியை தேர்வு செய்து அமர்வை தொடங்கவும்",
            AppLanguage.KANNADA to "ರೈತರನ್ನು ಆರಿಸಿ ಮತ್ತು ಸೆಷನ್ ಪ್ರಾರಂಭಿಸಿ",
            AppLanguage.URDU to "کسان منتخب کریں اور سیشن شروع کریں",
            AppLanguage.SPANISH to "Seleccionar Agricultor e Iniciar Sesión",
            AppLanguage.ARABIC to "اختر المزارع وابدأ الجلسة"
        ),
        "लाइव टाइमर, शुरू-समाप्त समय या सीधे घंटे" to mapOf(
            AppLanguage.HINDI to "लाइव टाइमर, शुरू-समाप्त समय या सीधे घंटे",
            AppLanguage.ENGLISH to "Live Timer, Start-End Time or Direct Hours",
            AppLanguage.PUNJABI to "ਲਾਈਵ ਟਾਈਮਰ, ਸ਼ੁਰੂ-ਅੰਤ ਸਮਾਂ ਜਾਂ ਸਿੱਧੇ ਘੰਟੇ",
            AppLanguage.GUJARATI to "લાઈવ ટાઈમર, શરૂ-સમાપ્ત સમય અથવા કલાકો",
            AppLanguage.MARATHI to "थेट टाइमर, सुरू-समाप्ती वेळ किंवा थेट तास",
            AppLanguage.BENGALI to "লাইভ টাইমার, শুরু-শেষ সময় বা সরাসরি ঘণ্টা",
            AppLanguage.TELUGU to "లైవ్ టైమర్, ప్రారంభ-ముగింపు సమయం లేదా గంటలు",
            AppLanguage.TAMIL to "நேரடி கடிகாரம், தொடக்க-முடிவு நேரம் அல்லது நேரடி மணி",
            AppLanguage.KANNADA to "ಲೈವ್ ಟೈಮರ್, ಪ್ರಾರಂಭ-ಮುಕ್ತಾಯ ಸಮಯ ಅಥವಾ ನೇರ ಗಂಟೆಗಳು",
            AppLanguage.URDU to "لائیو ٹائمر، شروع اور ختم وقت یا گھنٹے",
            AppLanguage.SPANISH to "Temporizador en vivo, inicio-fin o total de horas",
            AppLanguage.ARABIC to "عداد مباشر، وقت البدء والانتهاء أو ساعات مباشرة"
        ),
        "🔴 लाइव चल रहा सत्र (ACTIVE RUNNING SESSION)" to mapOf(
            AppLanguage.HINDI to "🔴 लाइव चल रहा सत्र (सक्रिय सत्र)",
            AppLanguage.ENGLISH to "🔴 Active Running Session (Live Timer)",
            AppLanguage.PUNJABI to "🔴 ਚੱਲ ਰਿਹਾ ਸੈਸ਼ਨ (ਲਾਈਵ ਟਾਈਮਰ)",
            AppLanguage.GUJARATI to "🔴 લાઈવ ચાલતું સત્ર (સક્રિય સત્ર)",
            AppLanguage.MARATHI to "🔴 चालू असलेले सत्र (थेट टाइमर)",
            AppLanguage.BENGALI to "🔴 চলমান সেশন (লাইভ টাইমার)",
            AppLanguage.TELUGU to "🔴 రన్నింగ్ సెషన్ (లైవ్ టైమర్)",
            AppLanguage.TAMIL to "🔴 நேரடி பாசன அமர்வு (செயலில்)",
            AppLanguage.KANNADA to "🔴 ನಡೆಯುತ್ತಿರುವ ಸೆಷನ್ (ಲೈವ್ ಟೈಮರ್)",
            AppLanguage.URDU to "🔴 جاری لائیو سیشن",
            AppLanguage.SPANISH to "🔴 Sesión de Riego en Curso (En Vivo)",
            AppLanguage.ARABIC to "🔴 جلسة ري جارية ومباشرة"
        ),
        "कुल चार्ज (₹)" to mapOf(
            AppLanguage.HINDI to "कुल चार्ज (₹)",
            AppLanguage.ENGLISH to "Total Charge (₹)",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਖ਼ਰਚਾ (₹)",
            AppLanguage.GUJARATI to "કુલ ચાર્જ (₹)",
            AppLanguage.MARATHI to "एकूण आकार (₹)",
            AppLanguage.BENGALI to "মোট চার্জ (₹)",
            AppLanguage.TELUGU to "మొత్తం ఛార్జ్ (₹)",
            AppLanguage.TAMIL to "மொத்த கட்டணம் (₹)",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಶುಲ್ಕ (₹)",
            AppLanguage.URDU to "کل خرچہ (₹)",
            AppLanguage.SPANISH to "Cargo Total (₹)",
            AppLanguage.ARABIC to "إجمالي التكلفة (₹)"
        ),
        "आज जमा नकद राशि (Paid Amount)" to mapOf(
            AppLanguage.HINDI to "आज जमा नकद राशि (Paid Amount)",
            AppLanguage.ENGLISH to "Cash Paid Today (Paid Amount)",
            AppLanguage.PUNJABI to "ਅੱਜ ਜਮ੍ਹਾ ਨਕਦੀ",
            AppLanguage.GUJARATI to "આજે રોકડ જમા",
            AppLanguage.MARATHI to "आज रोख जमा रक्कम",
            AppLanguage.BENGALI to "আজকের নগদ জমা",
            AppLanguage.TELUGU to "ఈ రోజు నగదు చెల్లింపు",
            AppLanguage.TAMIL to "இன்று செலுத்திய ரொக்கம்",
            AppLanguage.KANNADA to "ಇಂದು ನಗದು ಪಾವತಿ",
            AppLanguage.URDU to "آج نقد جمع شدہ رقم",
            AppLanguage.SPANISH to "Efectivo Pagado Hoy",
            AppLanguage.ARABIC to "المبلغ النقدي المدفوع اليوم"
        ),
        "आज का बाकी बकाया:" to mapOf(
            AppLanguage.HINDI to "आज का बाकी बकाया:",
            AppLanguage.ENGLISH to "Today's Pending Due:",
            AppLanguage.PUNJABI to "ਅੱਜ ਦਾ ਬਾਕੀ ਬਕਾਇਆ:",
            AppLanguage.GUJARATI to "આજનું બાકી લેણું:",
            AppLanguage.MARATHI to "आजची उर्वरित बाकी:",
            AppLanguage.BENGALI to "আজকের বকেয়া বাকি:",
            AppLanguage.TELUGU to "ఈ రోజు మిగిలిన బకాయి:",
            AppLanguage.TAMIL to "இன்றைய மீதமுள்ள நிலுவை:",
            AppLanguage.KANNADA to "ಇಂದಿನ ಬಾಕಿ ಮೊತ್ತ:",
            AppLanguage.URDU to "آج کی باقی رقم:",
            AppLanguage.SPANISH to "Saldo Pendiente de Hoy:",
            AppLanguage.ARABIC to "المتبقي المستحق اليوم:"
        ),
        "✓ सत्र समाप्त करें एवं बही-खाता में जोड़ें" to mapOf(
            AppLanguage.HINDI to "✓ सत्र समाप्त करें एवं बही-खाता में जोड़ें",
            AppLanguage.ENGLISH to "✓ Complete Session & Save to Ledger",
            AppLanguage.PUNJABI to "✓ ਸੈਸ਼ਨ ਖ਼ਤਮ ਕਰੋ ਅਤੇ ਬਹੀ-ਖਾਤੇ ਵਿੱਚ ਜੋੜੋ",
            AppLanguage.GUJARATI to "✓ સત્ર પૂર્ણ કરો અને ખાતામાં ઉમેરો",
            AppLanguage.MARATHI to "✓ सत्र पूर्ण करा आणि वही-खात्यात नोंदवा",
            AppLanguage.BENGALI to "✓ সেশন সমাপ্ত করুন ও খাতায় যুক্ত করুন",
            AppLanguage.TELUGU to "✓ సెషన్ ముగించి ఖాతాలో సేవ్ చేయండి",
            AppLanguage.TAMIL to "✓ அமர்வை முடித்து கணக்கில் சேமிக்கவும்",
            AppLanguage.KANNADA to "✓ ಸೆಷನ್ ಪೂರ್ಣಗೊಳಿಸಿ ಮತ್ತು ಖಾತೆಗೆ ಸೇರಿಸಿ",
            AppLanguage.URDU to "✓ سیشن ختم کریں اور کھاتے میں شامل کریں",
            AppLanguage.SPANISH to "✓ Finalizar Sesión y Guardar en Libro",
            AppLanguage.ARABIC to "✓ إنهاء الجلسة وحفظها في الدفتر"
        ),
        "होमस्क्रीन पर लाइव टाइमर देखें" to mapOf(
            AppLanguage.HINDI to "होमस्क्रीन पर लाइव टाइमर देखें",
            AppLanguage.ENGLISH to "View Live Timer on Home Screen",
            AppLanguage.PUNJABI to "ਹੋਮਸਕ੍ਰੀਨ 'ਤੇ ਲਾਈਵ ਟਾਈਮਰ ਦੇਖੋ",
            AppLanguage.GUJARATI to "હોમસ્ક્રીન પર લાઈવ ટાઈમર જુઓ",
            AppLanguage.MARATHI to "मुख्यपृष्ठावर थेट टाइमर पहा",
            AppLanguage.BENGALI to "হোমস্ক্রিনে লাইভ টাইমার দেখুন",
            AppLanguage.TELUGU to "హోమ్‌స్క్రీన్‌లో లైవ్ టైమర్ చూడండి",
            AppLanguage.TAMIL to "முகப்பு திரையில் நேரடி கடிகாரத்தை பார்க்கவும்",
            AppLanguage.KANNADA to "ಮುಖಪುಟದಲ್ಲಿ ಲೈವ್ ಟೈಮರ್ ವೀಕ್ಷಿಸಿ",
            AppLanguage.URDU to "ہوم اسکرین پر لائیو ٹائمر دیکھیں",
            AppLanguage.SPANISH to "Ver Temporizador en Pantalla Principal",
            AppLanguage.ARABIC to "عرض العداد المباشر في الشاشة الرئيسية"
        ),
        "नया किसान जोड़ें" to mapOf(
            AppLanguage.HINDI to "नया किसान जोड़ें",
            AppLanguage.ENGLISH to "Add New Farmer",
            AppLanguage.PUNJABI to "ਨਵਾਂ ਕਿਸਾਨ ਜੋੜੋ",
            AppLanguage.GUJARATI to "નવા ખેડૂત ઉમેરો",
            AppLanguage.MARATHI to "नवीन शेतकरी जोडा",
            AppLanguage.BENGALI to "নতুন কৃষক যোগ করুন",
            AppLanguage.TELUGU to "కొత్త రైతును చేర్చండి",
            AppLanguage.TAMIL to "புதிய விவசாயியை சேர்க்கவும்",
            AppLanguage.KANNADA to "ಹೊಸ ರೈತರನ್ನು ಸೇರಿಸಿ",
            AppLanguage.URDU to "نیا کسان شامل کریں",
            AppLanguage.SPANISH to "Agregar Agricultor",
            AppLanguage.ARABIC to "إضافة مزارع جديد"
        ),
        "आज का समय" to mapOf(
            AppLanguage.HINDI to "आज का समय",
            AppLanguage.ENGLISH to "Today's Runtime",
            AppLanguage.PUNJABI to "ਅੱਜ ਦਾ ਸਮਾਂ",
            AppLanguage.GUJARATI to "આજનો સમય",
            AppLanguage.MARATHI to "आजची वेळ",
            AppLanguage.BENGALI to "আজকের সময়",
            AppLanguage.TELUGU to "ఈ రోజు సమయం",
            AppLanguage.TAMIL to "இன்றைய நேரம்",
            AppLanguage.KANNADA to "ಇಂದಿನ ಸಮಯ",
            AppLanguage.URDU to "آج کا وقت",
            AppLanguage.SPANISH to "Tiempo de Hoy",
            AppLanguage.ARABIC to "تشغيل اليوم"
        ),
        "कुल बकाया" to mapOf(
            AppLanguage.HINDI to "कुल बकाया",
            AppLanguage.ENGLISH to "Total Due",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਬਾਕੀ",
            AppLanguage.GUJARATI to "કુલ બાકી",
            AppLanguage.MARATHI to "एकूण बाकी",
            AppLanguage.BENGALI to "মোট বকেয়া",
            AppLanguage.TELUGU to "మొత్తం బకాయి",
            AppLanguage.TAMIL to "மொத்த நிலுவை",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಬಾಕಿ",
            AppLanguage.URDU to "کل باقی رقم",
            AppLanguage.SPANISH to "Total Pendiente",
            AppLanguage.ARABIC to "إجمالي المستحق"
        ),
        "किसान सूची / Customers" to mapOf(
            AppLanguage.HINDI to "किसान सूची",
            AppLanguage.ENGLISH to "Customer Directory",
            AppLanguage.PUNJABI to "ਕਿਸਾਨ ਸੂਚੀ",
            AppLanguage.GUJARATI to "ખેડૂત યાદી",
            AppLanguage.MARATHI to "शेतकरी यादी",
            AppLanguage.BENGALI to "কৃষক তালিকা",
            AppLanguage.TELUGU to "రైతుల జాబితా",
            AppLanguage.TAMIL to "விவசாயிகள் பட்டியல்",
            AppLanguage.KANNADA to "ರೈತರ ಪಟ್ಟಿ",
            AppLanguage.URDU to "کسانوں کی فہرست",
            AppLanguage.SPANISH to "Lista de Clientes",
            AppLanguage.ARABIC to "دليل العملاء والمزارعين"
        ),
        "रिपोर्ट एवं बही-खाता / Reports" to mapOf(
            AppLanguage.HINDI to "रिपोर्ट एवं बही-खाता",
            AppLanguage.ENGLISH to "Reports & Master Ledger",
            AppLanguage.PUNJABI to "ਰਿਪੋਰਟਾਂ ਅਤੇ ਬਹੀ-ਖਾਤਾ",
            AppLanguage.GUJARATI to "રિપોર્ટ અને ખાતાવહી",
            AppLanguage.MARATHI to "अहवाल आणि वही-खाते",
            AppLanguage.BENGALI to "প্রতিবেদন ও খাতা",
            AppLanguage.TELUGU to "నివేదికలు & లెడ్జర్",
            AppLanguage.TAMIL to "அறிக்கைகள் & கணக்கு ஏடு",
            AppLanguage.KANNADA to "ವರದಿಗಳು & ಲೆಡ್ಜರ್",
            AppLanguage.URDU to "رپورٹس اور لیجر",
            AppLanguage.SPANISH to "Informes y Libro Mayor",
            AppLanguage.ARABIC to "التقارير ودفتر الحسابات"
        ),
        "समय अवधि (Time Range):" to mapOf(
            AppLanguage.HINDI to "समय अवधि (Time Range):",
            AppLanguage.ENGLISH to "Time Range (Filter):",
            AppLanguage.PUNJABI to "ਸਮਾਂ ਮਿਆਦ (Time Range):",
            AppLanguage.GUJARATI to "સમયગાળો (Time Range):",
            AppLanguage.MARATHI to "कालावधी (Time Range):",
            AppLanguage.BENGALI to "সময়কাল (Time Range):",
            AppLanguage.TELUGU to "సమయ వ్యవధి (Time Range):",
            AppLanguage.TAMIL to "கால அளவு (Time Range):",
            AppLanguage.KANNADA to "ಸಮಯದ ಅವಧಿ (Time Range):",
            AppLanguage.URDU to "مدت وقت (Time Range):",
            AppLanguage.SPANISH to "Rango de Tiempo (Time Range):",
            AppLanguage.ARABIC to "الفترة الزمنية (Time Range):"
        ),
        "अवधि चुनें (Select Period):" to mapOf(
            AppLanguage.HINDI to "अवधि चुनें (Select Period):",
            AppLanguage.ENGLISH to "Select Period:",
            AppLanguage.PUNJABI to "ਮਿਆਦ ਚੁਣੋ (Select Period):",
            AppLanguage.GUJARATI to "સમયગાળો પસંદ કરો (Select Period):",
            AppLanguage.MARATHI to "कालावधी निवडा (Select Period):",
            AppLanguage.BENGALI to "সময় নির্বাচন করুন (Select Period):",
            AppLanguage.TELUGU to "వ్యవధిని ఎంచుకోండి (Select Period):",
            AppLanguage.TAMIL to "கால அளவைத் தேர்ந்தெடுக்கவும்:",
            AppLanguage.KANNADA to "ಅವಧಿಯನ್ನು ಆಯ್ಕೆಮಾಡಿ:",
            AppLanguage.URDU to "مدت منتخب کریں (Select Period):",
            AppLanguage.SPANISH to "Seleccionar Período:",
            AppLanguage.ARABIC to "اختر الفترة الزمنية:"
        ),
        "किसान अनुसार हिसाब" to mapOf(
            AppLanguage.HINDI to "किसान अनुसार हिसाब",
            AppLanguage.ENGLISH to "Farmer-wise Accounts",
            AppLanguage.PUNJABI to "ਕਿਸਾਨ ਅਨੁਸਾਰ ਹਿਸਾਬ",
            AppLanguage.GUJARATI to "ખેડૂત મુજબ હિસાબ",
            AppLanguage.MARATHI to "शेतकऱ्यांनुसार हिशोब",
            AppLanguage.BENGALI to "কৃষক অনুযায়ী হিসাব",
            AppLanguage.TELUGU to "రైతుల వారీగా లెక్కలు",
            AppLanguage.TAMIL to "விவசாயிகள் வாரியாக கணக்கு",
            AppLanguage.KANNADA to "ರೈತರ ಪ್ರಕಾರ ಲೆಕ್ಕಾಚಾರ",
            AppLanguage.URDU to "کسان کے مطابق حساب",
            AppLanguage.SPANISH to "Cuentas por Agricultor",
            AppLanguage.ARABIC to "الحسابات حسب المزارع"
        ),
        "अवधि:" to mapOf(
            AppLanguage.HINDI to "अवधि:",
            AppLanguage.ENGLISH to "Period:",
            AppLanguage.PUNJABI to "ਮਿਆਦ:",
            AppLanguage.GUJARATI to "સમયગાળો:",
            AppLanguage.MARATHI to "कालावधी:",
            AppLanguage.BENGALI to "সময়কাল:",
            AppLanguage.TELUGU to "వ్యవధి:",
            AppLanguage.TAMIL to "கால அளவு:",
            AppLanguage.KANNADA to "ಅವಧಿ:",
            AppLanguage.URDU to "مدت:",
            AppLanguage.SPANISH to "Período:",
            AppLanguage.ARABIC to "الفترة:"
        ),
        "चयनित अवधि:" to mapOf(
            AppLanguage.HINDI to "चयनित अवधि:",
            AppLanguage.ENGLISH to "Selected Period:",
            AppLanguage.PUNJABI to "ਚੁਣੀ ਗਈ ਮਿਆਦ:",
            AppLanguage.GUJARATI to "પસંદ કરેલ સમય:",
            AppLanguage.MARATHI to "निवडलेला कालावधी:",
            AppLanguage.BENGALI to "নির্বাচিত সময়কাল:",
            AppLanguage.TELUGU to "ఎంచుకున్న వ్యవధి:",
            AppLanguage.TAMIL to "தேர்ந்தெடுக்கப்பட்ட கால அளவு:",
            AppLanguage.KANNADA to "ಆಯ್ಕೆಮಾಡಿದ ಅವಧಿ:",
            AppLanguage.URDU to "منتخب مدت:",
            AppLanguage.SPANISH to "Período Seleccionado:",
            AppLanguage.ARABIC to "الفترة المحددة:"
        ),
        "कुल चले घंटे" to mapOf(
            AppLanguage.HINDI to "कुल चले घंटे",
            AppLanguage.ENGLISH to "Total Pumped Hours",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਚੱਲੇ ਘੰਟੇ",
            AppLanguage.GUJARATI to "કુલ ચાલેલા કલાકો",
            AppLanguage.MARATHI to "एकूण चाललेले तास",
            AppLanguage.BENGALI to "মোট চালিত ঘণ্টা",
            AppLanguage.TELUGU to "మొత్తం నడిచిన గంటలు",
            AppLanguage.TAMIL to "மொத்த ஓடிய மணிநேரம்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಚಾಲನೆಯಾದ ಗಂಟೆಗಳು",
            AppLanguage.URDU to "کل چلے ہوئے گھنٹے",
            AppLanguage.SPANISH to "Horas Totales",
            AppLanguage.ARABIC to "إجمالي ساعات التشغيل"
        ),
        "कुल सिंचाई समय" to mapOf(
            AppLanguage.HINDI to "कुल सिंचाई समय",
            AppLanguage.ENGLISH to "Total Irrigation Time",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਸਿੰਚਾਈ ਸਮਾਂ",
            AppLanguage.GUJARATI to "કુલ સિંચાઈ સમય",
            AppLanguage.MARATHI to "एकूण सिंचन वेळ",
            AppLanguage.BENGALI to "মোট সেচ সময়",
            AppLanguage.TELUGU to "మొత్తం సాగునీటి సమయం",
            AppLanguage.TAMIL to "மொத்த பாசன நேரம்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ನೀರಾವರಿ ಸಮಯ",
            AppLanguage.URDU to "کل آبپاشی کا وقت",
            AppLanguage.SPANISH to "Tiempo Total de Riego",
            AppLanguage.ARABIC to "إجمالي وقت الري"
        ),
        "कुल बनी रकम" to mapOf(
            AppLanguage.HINDI to "कुल बनी रकम",
            AppLanguage.ENGLISH to "Total Billed Amount",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਬਣੀ ਰਕਮ",
            AppLanguage.GUJARATI to "કુલ બનેલ રકમ",
            AppLanguage.MARATHI to "एकूण बिल रक्कम",
            AppLanguage.BENGALI to "মোট বিলের পরিমাণ",
            AppLanguage.TELUGU to "మొత్తం బిల్లు మొత్తం",
            AppLanguage.TAMIL to "மொத்த பில் தொகை",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಬಿಲ್ ಮೊತ್ತ",
            AppLanguage.URDU to "کل بل کی رقم",
            AppLanguage.SPANISH to "Monto Total Facturado",
            AppLanguage.ARABIC to "إجمالي مبلغ الفاتورة"
        ),
        "कुल बिल राशि" to mapOf(
            AppLanguage.HINDI to "कुल बिल राशि",
            AppLanguage.ENGLISH to "Total Billed Value",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਬਿੱਲ ਰਾਸ਼ੀ",
            AppLanguage.GUJARATI to "કુલ બિલ રકમ",
            AppLanguage.MARATHI to "एकूण बिल रक्कम",
            AppLanguage.BENGALI to "মোট বিলের রাশি",
            AppLanguage.TELUGU to "మొత్తం బిల్లు విలువ",
            AppLanguage.TAMIL to "மொத்த பில் மதிப்பு",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಬಿಲ್ ಮೌಲ್ಯ",
            AppLanguage.URDU to "کل بل رقم",
            AppLanguage.SPANISH to "Valor Total Facturado",
            AppLanguage.ARABIC to "القيمة الإجمالية للفاتورة"
        ),
        "कुल जमा राशि" to mapOf(
            AppLanguage.HINDI to "कुल जमा राशि",
            AppLanguage.ENGLISH to "Total Cash Received",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਜਮ੍ਹਾ ਰਕਮ",
            AppLanguage.GUJARATI to "કુલ જમા રકમ",
            AppLanguage.MARATHI to "एकूण जमा रक्कम",
            AppLanguage.BENGALI to "মোট জমা রাশি",
            AppLanguage.TELUGU to "మొత్తం జమ చేసిన మొత్తం",
            AppLanguage.TAMIL to "மொத்த வரவுத் தொகை",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಜಮಾ ಮೊತ್ತ",
            AppLanguage.URDU to "کل جمع شدہ رقم",
            AppLanguage.SPANISH to "Total Recibido",
            AppLanguage.ARABIC to "إجمالي المبلغ المحصل"
        ),
        "नकद / प्राप्त राशि" to mapOf(
            AppLanguage.HINDI to "नकद / प्राप्त राशि",
            AppLanguage.ENGLISH to "Cash / Received Amount",
            AppLanguage.PUNJABI to "ਨਕਦ / ਪ੍ਰਾਪਤ ਰਕਮ",
            AppLanguage.GUJARATI to "રોકડ / મળેલ રકમ",
            AppLanguage.MARATHI to "रोख / मिळालेली रक्कम",
            AppLanguage.BENGALI to "নগদ / প্রাপ্ত রাশি",
            AppLanguage.TELUGU to "నగదు / స్వీకరించిన మొత్తం",
            AppLanguage.TAMIL to "ரொக்கம் / பெறப்பட்ட தொகை",
            AppLanguage.KANNADA to "ನಗದು / ಸ್ವೀಕರಿಸಿದ ಮೊತ್ತ",
            AppLanguage.URDU to "نقد / وصول شدہ رقم",
            AppLanguage.SPANISH to "Efectivo / Cobrado",
            AppLanguage.ARABIC to "النقد / المبلغ المستلم"
        ),
        "किसानों से लेना शेष" to mapOf(
            AppLanguage.HINDI to "किसानों से लेना शेष",
            AppLanguage.ENGLISH to "Pending Balance to Collect",
            AppLanguage.PUNJABI to "ਕਿਸਾਨਾਂ ਤੋਂ ਲੈਣਾ ਬਾਕੀ",
            AppLanguage.GUJARATI to "ખેડૂતો પાસેથી લેવાના બાકી",
            AppLanguage.MARATHI to "शेतकऱ्यांकडून येणे बाकी",
            AppLanguage.BENGALI to "কৃষকদের থেকে বকেয়া",
            AppLanguage.TELUGU to "రైతుల నుండి రావలసిన బకాయి",
            AppLanguage.TAMIL to "விவசாயிகளிடமிருந்து வர வேண்டியவை",
            AppLanguage.KANNADA to "ರೈತರಿಂದ ಬರಬೇಕಾದ ಬಾಕಿ",
            AppLanguage.URDU to "کسانوں سے وصولی باقی",
            AppLanguage.SPANISH to "Saldo por Cobrar de Agricultores",
            AppLanguage.ARABIC to "المتبقي للتحصيل من المزارعين"
        ),
        "अवधि चुनें / PDF खोलें" to mapOf(
            AppLanguage.HINDI to "अवधि चुनें / PDF खोलें",
            AppLanguage.ENGLISH to "Select Period / View PDF",
            AppLanguage.PUNJABI to "ਮਿਆਦ ਚੁਣੋ / PDF ਖੋਲ੍ਹੋ",
            AppLanguage.GUJARATI to "સમય પસંદ કરો / PDF ખોલો",
            AppLanguage.MARATHI to "कालावधी निवडा / PDF उघडा",
            AppLanguage.BENGALI to "সময় বেছে নিন / PDF দেখুন",
            AppLanguage.TELUGU to "వ్యవధిని ఎంచుకోండి / PDF తెరవండి",
            AppLanguage.TAMIL to "காலத்தை தேர்வு செய் / PDF திறக்க",
            AppLanguage.KANNADA to "ಅವಧಿ ಆಯ್ಕೆಮಾಡಿ / PDF ತೆರೆಯಿರಿ",
            AppLanguage.URDU to "مدت چنیں / PDF کھولیں",
            AppLanguage.SPANISH to "Elegir Período / Ver PDF",
            AppLanguage.ARABIC to "اختر الفترة / فتح PDF"
        ),
        "PDF शेयर करें" to mapOf(
            AppLanguage.HINDI to "PDF शेयर करें",
            AppLanguage.ENGLISH to "Share PDF",
            AppLanguage.PUNJABI to "PDF ਸ਼ੇਅਰ ਕਰੋ",
            AppLanguage.GUJARATI to "PDF શેર કરો",
            AppLanguage.MARATHI to "PDF शेअर करा",
            AppLanguage.BENGALI to "PDF শেয়ার করুন",
            AppLanguage.TELUGU to "PDF షేర్ చేయండి",
            AppLanguage.TAMIL to "PDF பகிரவும்",
            AppLanguage.KANNADA to "PDF ಹಂಚಿಕೊಳ್ಳಿ",
            AppLanguage.URDU to "PDF شیئر کریں",
            AppLanguage.SPANISH to "Compartir PDF",
            AppLanguage.ARABIC to "مشاركة PDF"
        ),
        "📄 मास्टर PDF रिपोर्ट (PDF खाता)" to mapOf(
            AppLanguage.HINDI to "📄 मास्टर PDF रिपोर्ट (PDF खाता)",
            AppLanguage.ENGLISH to "📄 Master PDF Ledger Report",
            AppLanguage.PUNJABI to "📄 ਮਾਸਟਰ PDF ਰਿਪੋਰਟ",
            AppLanguage.GUJARATI to "📄 માસ્ટર PDF રિપોર્ટ",
            AppLanguage.MARATHI to "📄 मास्टर PDF अहवाल",
            AppLanguage.BENGALI to "📄 মাস্টার PDF রিপোর্ট",
            AppLanguage.TELUGU to "📄 మాస్టర్ PDF నివేదిక",
            AppLanguage.TAMIL to "📄 முழு PDF அறிக்கை",
            AppLanguage.KANNADA to "📄 ಮಾಸ್ಟರ್ PDF ವರದಿ",
            AppLanguage.URDU to "📄 ماسٹر PDF رپورٹ",
            AppLanguage.SPANISH to "📄 Informe Maestro en PDF",
            AppLanguage.ARABIC to "📄 تقرير PDF الشامل للدفتر"
        ),
        "सेटिंग्स व प्रोफाइल" to mapOf(
            AppLanguage.HINDI to "सेटिंग्स व प्रोफाइल",
            AppLanguage.ENGLISH to "Settings & Profile",
            AppLanguage.PUNJABI to "ਸੈਟਿੰਗਾਂ ਅਤੇ ਪ੍ਰੋਫਾਈਲ",
            AppLanguage.GUJARATI to "સેટિંગ્સ અને પ્રોફાઇલ",
            AppLanguage.MARATHI to "सेटिंग्ज आणि प्रोफाइल",
            AppLanguage.BENGALI to "সেটিংস ও প্রোফাইল",
            AppLanguage.TELUGU to "సెట్టింగ్‌లు & ప్రొఫైల్",
            AppLanguage.TAMIL to "அமைப்புகள் & சுயவிவரம்",
            AppLanguage.KANNADA to "ಸೆಟ್ಟಿಂಗ್ಸ್ & ಪ್ರೊಫೈಲ್",
            AppLanguage.URDU to "سیٹنگز اور پروفائل",
            AppLanguage.SPANISH to "Ajustes y Perfil",
            AppLanguage.ARABIC to "الإعدادات والملف الشخصي"
        ),
        "🌐 ऐप की भाषा (App Language)" to mapOf(
            AppLanguage.HINDI to "🌐 ऐप की भाषा",
            AppLanguage.ENGLISH to "🌐 App Language",
            AppLanguage.PUNJABI to "🌐 ਐਪ ਦੀ ਭਾਸ਼ਾ",
            AppLanguage.GUJARATI to "🌐 એપ્લિકેશનની ભાષા",
            AppLanguage.MARATHI to "🌐 ॲपची भाषा",
            AppLanguage.BENGALI to "🌐 অ্যাপের ভাষা",
            AppLanguage.TELUGU to "🌐 యాప్ భాష",
            AppLanguage.TAMIL to "🌐 பயன்பாட்டு மொழி",
            AppLanguage.KANNADA to "🌐 ಆ್ಯಪ್ ಭಾಷೆ",
            AppLanguage.URDU to "🌐 ایپ کی زبان",
            AppLanguage.SPANISH to "🌐 Idioma de la Aplicación",
            AppLanguage.ARABIC to "🌐 لغة التطبيق"
        ),
        "भाषा बदलें / Select Language" to mapOf(
            AppLanguage.HINDI to "भाषा बदलें",
            AppLanguage.ENGLISH to "Change Language",
            AppLanguage.PUNJABI to "ਭਾਸ਼ਾ ਬਦਲੋ",
            AppLanguage.GUJARATI to "ભાષા બદલો",
            AppLanguage.MARATHI to "भाषा बदला",
            AppLanguage.BENGALI to "ভাষা পরিবর্তন করুন",
            AppLanguage.TELUGU to "భాషను మార్చండి",
            AppLanguage.TAMIL to "மொழியை மாற்றவும்",
            AppLanguage.KANNADA to "ಭಾಷೆಯನ್ನು ಬದಲಾಯಿಸಿ",
            AppLanguage.URDU to "زبان تبدیل کریں",
            AppLanguage.SPANISH to "Cambiar Idioma",
            AppLanguage.ARABIC to "تغيير اللغة"
        ),
        "डेटा अभी सिंक करें" to mapOf(
            AppLanguage.HINDI to "डेटा अभी सिंक करें",
            AppLanguage.ENGLISH to "Sync Cloud Data Now",
            AppLanguage.PUNJABI to "ਡਾਟਾ ਹੁਣੇ ਸਿੰਕ ਕਰੋ",
            AppLanguage.GUJARATI to "ડેટા અત્યારે સિંક કરો",
            AppLanguage.MARATHI to "डेटा आता सिंक करा",
            AppLanguage.BENGALI to "এখনই ডেটা সিঙ্ক করুন",
            AppLanguage.TELUGU to "డేటాను ఇప్పుడే సమకాలీకరించండి",
            AppLanguage.TAMIL to "தரவை இப்போது ஒத்திசைக்கவும்",
            AppLanguage.KANNADA to "ಡೇಟಾವನ್ನು ಈಗ ಸಿಂಕ್ ಮಾಡಿ",
            AppLanguage.URDU to "ڈیٹا ابھی سنک کریں",
            AppLanguage.SPANISH to "Sincronizar Datos Ahora",
            AppLanguage.ARABIC to "مزامنة البيانات الآن"
        ),
        "सुरक्षित करें" to mapOf(
            AppLanguage.HINDI to "सुरक्षित करें",
            AppLanguage.ENGLISH to "Save Changes",
            AppLanguage.PUNJABI to "ਸੰਭਾਲੋ",
            AppLanguage.GUJARATI to "સાચવો",
            AppLanguage.MARATHI to "जतन करा",
            AppLanguage.BENGALI to "সংরক্ষণ করুন",
            AppLanguage.TELUGU to "సేవ్ చేయండి",
            AppLanguage.TAMIL to "சேமிக்கவும்",
            AppLanguage.KANNADA to "ಉಳಿಸಿ",
            AppLanguage.URDU to "محفوظ کریں",
            AppLanguage.SPANISH to "Guardar Cambios",
            AppLanguage.ARABIC to "حفظ التغييرات"
        ),
        "पासवर्ड बदलें" to mapOf(
            AppLanguage.HINDI to "पासवर्ड बदलें",
            AppLanguage.ENGLISH to "Change PIN/Password",
            AppLanguage.PUNJABI to "ਪਾਸਵਰਡ ਬਦਲੋ",
            AppLanguage.GUJARATI to "પાસવર્ડ બદલો",
            AppLanguage.MARATHI to "पासवर्ड बदला",
            AppLanguage.BENGALI to "পাসওয়ার্ড পরিবর্তন করুন",
            AppLanguage.TELUGU to "పాస్‌వర్డ్ మార్చండి",
            AppLanguage.TAMIL to "கடவுச்சொல்லை மாற்றவும்",
            AppLanguage.KANNADA to "ಪಾಸ್‌ವರ್ಡ್ ಬದಲಾಯಿಸಿ",
            AppLanguage.URDU to "پاس ورڈ تبدیل کریں",
            AppLanguage.SPANISH to "Cambiar Contraseña",
            AppLanguage.ARABIC to "تغيير كلمة المرور"
        ),
        "अक्षर का आकार (फ़ॉन्ट साइज)" to mapOf(
            AppLanguage.HINDI to "अक्षर का आकार (फ़ॉन्ट साइज)",
            AppLanguage.ENGLISH to "Display Text Size (Font Scale)",
            AppLanguage.PUNJABI to "ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ (ਫੌਂਟ)",
            AppLanguage.GUJARATI to "અક્ષરોનું કદ (ફોન્ટ સાઇઝ)",
            AppLanguage.MARATHI to "अक्षरांचा आकार (फॉन्ट आकार)",
            AppLanguage.BENGALI to "ফন্ট সাইজ (অক্ষরের আকার)",
            AppLanguage.TELUGU to "టెక్స్ట్ పరిమాణం (ఫాంట్ పరిమాణం)",
            AppLanguage.TAMIL to "எழுத்து அளவு (Font Size)",
            AppLanguage.KANNADA to "ಅಕ್ಷರದ ಗಾತ್ರ (ಫಾಂಟ್ ಸೈಜ್)",
            AppLanguage.URDU to "حروف کا سائز (فونٹ سائز)",
            AppLanguage.SPANISH to "Tamaño del Texto (Escala de Fuente)",
            AppLanguage.ARABIC to "حجم الخط وشاشة العرض"
        ),
        "डेटाबेस सुरक्षा (AES-256)" to mapOf(
            AppLanguage.HINDI to "डेटाबेस सुरक्षा (AES-256)",
            AppLanguage.ENGLISH to "Database Security (AES-256)",
            AppLanguage.PUNJABI to "ਡਾਟਾਬੇਸ ਸੁਰੱਖਿਆ (AES-256)",
            AppLanguage.GUJARATI to "ડેટાબેઝ સુરક્ષા (AES-256)",
            AppLanguage.MARATHI to "डेटाबेस सुरक्षा (AES-256)",
            AppLanguage.BENGALI to "ডাটাবেস সুরক্ষা (AES-256)",
            AppLanguage.TELUGU to "డేటాబేస్ భద్రత (AES-256)",
            AppLanguage.TAMIL to "தரவுத்தள பாதுகாப்பு (AES-256)",
            AppLanguage.KANNADA to "ಡೇಟಾಬೇಸ್ ಭದ್ರತೆ (AES-256)",
            AppLanguage.URDU to "ڈیٹابیس سیکیورٹی (AES-256)",
            AppLanguage.SPANISH to "Seguridad de Base de Datos (AES-256)",
            AppLanguage.ARABIC to "أمان قاعدة البيانات (AES-256)"
        ),
        "लॉगआउट" to mapOf(
            AppLanguage.HINDI to "लॉगआउट",
            AppLanguage.ENGLISH to "Logout",
            AppLanguage.PUNJABI to "ਲਾਗਆਉਟ",
            AppLanguage.GUJARATI to "લૉગ આઉટ",
            AppLanguage.MARATHI to "लॉगआउट",
            AppLanguage.BENGALI to "লগআউট",
            AppLanguage.TELUGU to "లాగ్ అవుట్",
            AppLanguage.TAMIL to "வெளியேறு",
            AppLanguage.KANNADA to "ಲಾಗ್‌ಔಟ್",
            AppLanguage.URDU to "لاگ آؤٹ",
            AppLanguage.SPANISH to "Cerrar Sesión",
            AppLanguage.ARABIC to "تسجيل الخروج"
        )
    )

    private val STRINGS: Map<String, Map<AppLanguage, String>> = mapOf(
        "app_title" to mapOf(
            AppLanguage.HINDI to "डिजिटल बही-खाता",
            AppLanguage.ENGLISH to "Digital Bahi-Khata",
            AppLanguage.PUNJABI to "ਡਿਜੀਟਲ ਬਹੀ-ਖਾਤਾ",
            AppLanguage.GUJARATI to "ડિજિટલ બહી-ખાતા",
            AppLanguage.MARATHI to "डिजिटल वही-खाते",
            AppLanguage.BENGALI to "ডিজিটাল খাতা",
            AppLanguage.TELUGU to "డిజిటల్ బహి-ఖాతా",
            AppLanguage.TAMIL to "டிஜிட்டல் கணக்கு புத்தகம்",
            AppLanguage.KANNADA to "ಡಿಜಿಟಲ್ ಬಹಿ-ಖಾತಾ",
            AppLanguage.URDU to "ڈیجیٹل بہی کھاتہ",
            AppLanguage.SPANISH to "Libro Contable Digital",
            AppLanguage.ARABIC to "دفتر الحسابات الرقمي"
        ),
        "splash_slogan" to mapOf(
            AppLanguage.HINDI to "जय जवान, जय किसान",
            AppLanguage.ENGLISH to "Jai Jawan, Jai Kisan",
            AppLanguage.PUNJABI to "ਜੈ ਜਵਾਨ, ਜੈ ਕਿਸਾਨ",
            AppLanguage.GUJARATI to "જય જવાન, જય કિસાન",
            AppLanguage.MARATHI to "जय जवान, जय किसान",
            AppLanguage.BENGALI to "জয় জওয়ান, জয় কিষান",
            AppLanguage.TELUGU to "జై జవాన్, జై కిసాన్",
            AppLanguage.TAMIL to "ஜெய் ஜவான், ஜெய் கிசான்",
            AppLanguage.KANNADA to "ಜೈ ಜವಾನ್, ಜೈ ಕಿಸಾನ್",
            AppLanguage.URDU to "جے جوان، جے کسان",
            AppLanguage.SPANISH to "Honor al Agricultor",
            AppLanguage.ARABIC to "تحية للمزارع والفلاح"
        ),
        "splash_subtext" to mapOf(
            AppLanguage.HINDI to "अब ट्यूबवेल हिसाब करना हुआ बेहद आसान!",
            AppLanguage.ENGLISH to "Now Tubewell & Irrigation accounting made super easy!",
            AppLanguage.PUNJABI to "ਹੁਣ ਟਿਊਬਵੈੱਲ ਹਿਸਾਬ ਕਰਨਾ ਹੋਇਆ ਆਸਾਨ!",
            AppLanguage.GUJARATI to "હવે ટ્યુબવેલ હિસાબ કરવો થયો સરળ!",
            AppLanguage.MARATHI to "आता कूपनलिका हिशोब झाला अतिशय सोपा!",
            AppLanguage.BENGALI to "এখন টিউবওয়েল হিসাব করা আরও সহজ!",
            AppLanguage.TELUGU to "ఇప్పుడు బోరుబావి లెక్కలు చాలా సులభం!",
            AppLanguage.TAMIL to "இப்போது பாசன கணக்கு மிகவும் எளிது!",
            AppLanguage.KANNADA to "ಈಗ ಕೊಳವೆಬಾವಿ ಲೆಕ್ಕಾಚಾರ ತುಂಬಾ ಸುಲಭ!",
            AppLanguage.URDU to "اب ٹیوب ویل کا حساب رکھنا ہوا انتہائی آسان!",
            AppLanguage.SPANISH to "¡Gestión de riego y bombeo fácil y rápida!",
            AppLanguage.ARABIC to "حسابات الري وتشغيل الآبار أصبحت أسهل بكثير!"
        ),
        "choose_language" to mapOf(
            AppLanguage.HINDI to "भाषा चुनें / Choose Language",
            AppLanguage.ENGLISH to "Choose Language / भाषा चुनें",
            AppLanguage.PUNJABI to "ਭਾਸ਼ਾ ਚੁਣੋ / Choose Language",
            AppLanguage.GUJARATI to "ભાષા પસંદ કરો / Choose Language",
            AppLanguage.MARATHI to "भाषा निवडा / Choose Language",
            AppLanguage.BENGALI to "ভাষা নির্বাচন করুন / Choose Language",
            AppLanguage.TELUGU to "భాషను ఎంచుకోండి / Choose Language",
            AppLanguage.TAMIL to "மொழியைத் தேர்ந்தெடுக்கவும் / Choose Language",
            AppLanguage.KANNADA to "ಭಾಷೆಯನ್ನು ಆರಿಸಿ / Choose Language",
            AppLanguage.URDU to "زبان منتخب کریں / Choose Language",
            AppLanguage.SPANISH to "Seleccionar Idioma / Choose Language",
            AppLanguage.ARABIC to "اختر اللغة / Choose Language"
        ),
        "continue_btn" to mapOf(
            AppLanguage.HINDI to "आगे बढ़ें →",
            AppLanguage.ENGLISH to "Continue →",
            AppLanguage.PUNJABI to "ਅੱਗੇ ਵਧੋ →",
            AppLanguage.GUJARATI to "આગળ વધો →",
            AppLanguage.MARATHI to "पुढे जा →",
            AppLanguage.BENGALI to "এগিয়ে যান →",
            AppLanguage.TELUGU to "ముందుకు సాగండి →",
            AppLanguage.TAMIL to "தொடரவும் →",
            AppLanguage.KANNADA to "ಮುಂದುವರಿಯಿರಿ →",
            AppLanguage.URDU to "آگے بڑھیں →",
            AppLanguage.SPANISH to "Continuar →",
            AppLanguage.ARABIC to "متابعة ←"
        ),
        "auth_welcome_title" to mapOf(
            AppLanguage.HINDI to "किसान बही-खाता में आपका स्वागत है",
            AppLanguage.ENGLISH to "Welcome to Digital Bahi-Khata",
            AppLanguage.PUNJABI to "ਕਿਸਾਨ ਬਹੀ-ਖਾਤਾ ਵਿੱਚ ਜੀ ਆਇਆਂ ਨੂੰ",
            AppLanguage.GUJARATI to "કિસાન બહી-ખાતા માં આપનું સ્વાગત છે",
            AppLanguage.MARATHI to "शेतकरी वही-खात्यामध्ये आपले स्वागत आहे",
            AppLanguage.BENGALI to "কৃষক খাতা অ্যাপে স্বাগতম",
            AppLanguage.TELUGU to "రైతు బహి-ఖాతాకు స్వాగతం",
            AppLanguage.TAMIL to "விவசாய கணக்கு ஏட்டிற்கு நல்வரவு",
            AppLanguage.KANNADA to "ರೈತ ಬಹಿ-ಖಾತಾಗೆ ಸುಸ್ವಾಗತ",
            AppLanguage.URDU to "کسان بہی کھاتہ میں خوش آمدید",
            AppLanguage.SPANISH to "Bienvenido al Gestor de Riego",
            AppLanguage.ARABIC to "مرحباً بك في دفتر حسابات الري"
        ),
        "create_new_account" to mapOf(
            AppLanguage.HINDI to "नया खाता बनाएं",
            AppLanguage.ENGLISH to "Create New Account",
            AppLanguage.PUNJABI to "ਨਵਾਂ ਖਾਤਾ ਬਣਾਓ",
            AppLanguage.GUJARATI to "નવું ખાતું બનાવો",
            AppLanguage.MARATHI to "नवीन खाते तयार करा",
            AppLanguage.BENGALI to "নতুন একাউন্ট তৈরি করুন",
            AppLanguage.TELUGU to "కొత్త ఖాతాను సృష్టించండి",
            AppLanguage.TAMIL to "புதிய கணக்கை உருவாக்கவும்",
            AppLanguage.KANNADA to "ಹೊಸ ಖಾತೆ ತೆರೆಯಿರಿ",
            AppLanguage.URDU to "نیا اکاؤنٹ بنائیں",
            AppLanguage.SPANISH to "Crear Nueva Cuenta",
            AppLanguage.ARABIC to "إنشاء حساب جديد"
        ),
        "already_have_account" to mapOf(
            AppLanguage.HINDI to "मेरे पास पहले से खाता है (लॉग इन)",
            AppLanguage.ENGLISH to "I already have an account (Login)",
            AppLanguage.PUNJABI to "ਮੇਰੇ ਕੋਲ ਪਹਿਲਾਂ ਤੋਂ ਖਾਤਾ ਹੈ (ਲਾਗਇਨ)",
            AppLanguage.GUJARATI to "મારી પાસે પહેલેથી ખાતું છે (લૉગિન)",
            AppLanguage.MARATHI to "माझं आधीच खाते आहे (लॉग इन)",
            AppLanguage.BENGALI to "আমার ইতিমধ্যে একাউন্ট আছে (লগইন)",
            AppLanguage.TELUGU to "నాకు ఇప్పటికే ఖాతా ఉంది (లాగిన్)",
            AppLanguage.TAMIL to "ஏற்கனவே கணக்கு உள்ளது (உள்நுழையவும்)",
            AppLanguage.KANNADA to "ನನಗೆ ಈಗಾಗಲೇ ಖಾತೆ ಇದೆ (ಲಾಗಿನ್)",
            AppLanguage.URDU to "میرے پاس پہلے سے اکاؤنٹ ہے (لاگ ان)",
            AppLanguage.SPANISH to "Ya tengo una cuenta (Iniciar sesión)",
            AppLanguage.ARABIC to "لدي حساب بالفعل (تسجيل الدخول)"
        ),
        "owner_name" to mapOf(
            AppLanguage.HINDI to "मालिक का नाम (Owner Name)",
            AppLanguage.ENGLISH to "Owner Name",
            AppLanguage.PUNJABI to "ਮਾਲਕ ਦਾ ਨਾਮ",
            AppLanguage.GUJARATI to "માલિકનું નામ",
            AppLanguage.MARATHI to "मालकाचे नाव",
            AppLanguage.BENGALI to "মালিকের নাম",
            AppLanguage.TELUGU to "యజమాని పేరు",
            AppLanguage.TAMIL to "உரிமையாளர் பெயர்",
            AppLanguage.KANNADA to "ಮಾಲೀಕರ ಹೆಸರು",
            AppLanguage.URDU to "مالک کا نام",
            AppLanguage.SPANISH to "Nombre del Propietario",
            AppLanguage.ARABIC to "اسم المالك"
        ),
        "agency_name" to mapOf(
            AppLanguage.HINDI to "ट्यूबवेल / फार्म / दुकान का नाम",
            AppLanguage.ENGLISH to "Tubewell / Farm / Agency Name",
            AppLanguage.PUNJABI to "ਟਿਊਬਵੈੱਲ / ਫਾਰਮ ਦਾ ਨਾਮ",
            AppLanguage.GUJARATI to "ટ્યુબવેલ / ફાર્મનું નામ",
            AppLanguage.MARATHI to "कूपनलिका / शेतीचे नाव",
            AppLanguage.BENGALI to "টিউবওয়েল / খামারের নাম",
            AppLanguage.TELUGU to "బోరుబావి / ఫారం పేరు",
            AppLanguage.TAMIL to "பண்ணை / பாசன நிலைய பெயர்",
            AppLanguage.KANNADA to "ಕೊಳವೆಬಾವಿ / ಕೃಷಿ ಜಮೀನಿನ ಹೆಸರು",
            AppLanguage.URDU to "ٹیوب ویل / فارم کا نام",
            AppLanguage.SPANISH to "Nombre del Pozo / Finca",
            AppLanguage.ARABIC to "اسم البئر / المزرعة"
        ),
        "mobile_number" to mapOf(
            AppLanguage.HINDI to "मोबाइल नंबर (Mobile No.)",
            AppLanguage.ENGLISH to "Mobile Number",
            AppLanguage.PUNJABI to "ਮੋਬਾਈਲ ਨੰਬਰ",
            AppLanguage.GUJARATI to "મોબાઇલ નંબર",
            AppLanguage.MARATHI to "मोबाईल नंबर",
            AppLanguage.BENGALI to "মোবাইল নম্বর",
            AppLanguage.TELUGU to "మొబైల్ నంబర్",
            AppLanguage.TAMIL to "கைபேசி எண்",
            AppLanguage.KANNADA to "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ",
            AppLanguage.URDU to "موبائل نمبر",
            AppLanguage.SPANISH to "Número de Teléfono",
            AppLanguage.ARABIC to "رقم الهاتف المحمول"
        ),
        "create_pin" to mapOf(
            AppLanguage.HINDI to "4-अंकों का सुरक्षा पिन बनाएं",
            AppLanguage.ENGLISH to "Create 4-Digit Security PIN",
            AppLanguage.PUNJABI to "4-ਅੰਕਾਂ ਦਾ ਸੁਰੱਖਿਆ ਪਿੰਨ ਬਣਾਓ",
            AppLanguage.GUJARATI to "4-અંકનો સુરક્ષા પિન બનાવો",
            AppLanguage.MARATHI to "4-अंकी सुरक्षा पिन तयार करा",
            AppLanguage.BENGALI to "৪-সংখ্যার সুরক্ষা পিন তৈরি করুন",
            AppLanguage.TELUGU to "4-అంకెల సెక్యూరిటీ పిన్ సృష్టించండి",
            AppLanguage.TAMIL to "4-இலக்க பாதுகாப்பு பின்னை உருவாக்கவும்",
            AppLanguage.KANNADA to "4-ಅಂಕಿಯ ಭದ್ರತಾ ಪಿನ್ ರಚಿಸಿ",
            AppLanguage.URDU to "4 ہندسوں کا سیکیورٹی پن بنائیں",
            AppLanguage.SPANISH to "Crear PIN de 4 dígitos",
            AppLanguage.ARABIC to "إنشاء رمز PIN مكون من 4 أرقام"
        ),
        "confirm_pin" to mapOf(
            AppLanguage.HINDI to "पिन दोबारा दर्ज करें (Confirm PIN)",
            AppLanguage.ENGLISH to "Confirm 4-Digit PIN",
            AppLanguage.PUNJABI to "ਪਿੰਨ ਦੁਬਾਰਾ ਦਰਜ ਕਰੋ",
            AppLanguage.GUJARATI to "પિન ફરીથી દાખલ કરો",
            AppLanguage.MARATHI to "पिन पुन्हा प्रविष्ट करा",
            AppLanguage.BENGALI to "পিন পুনরায় লিখুন",
            AppLanguage.TELUGU to "పిన్‌ను నిర్ధారించండి",
            AppLanguage.TAMIL to "பின்னை மீண்டும் உள்ளிடவும்",
            AppLanguage.KANNADA to "ಪಿನ್ ಅನ್ನು ದೃಢೀಕರಿಸಿ",
            AppLanguage.URDU to "پن دوبارہ درج کریں",
            AppLanguage.SPANISH to "Confirmar PIN",
            AppLanguage.ARABIC to "تأكيد رمز PIN"
        ),
        "default_rate" to mapOf(
            AppLanguage.HINDI to "डिफ़ॉल्ट दर (₹ प्रति घंटा)",
            AppLanguage.ENGLISH to "Default Rate (₹ per hour)",
            AppLanguage.PUNJABI to "ਡਿਫੌਲਟ ਰੇਟ (₹ ਪ੍ਰਤੀ ਘੰਟਾ)",
            AppLanguage.GUJARATI to "ડિફૉલ્ટ દર (₹ પ્રતિ કલાક)",
            AppLanguage.MARATHI to "मूळ दर (₹ प्रति तास)",
            AppLanguage.BENGALI to "ডিফল্ট রেট (₹ প্রতি ঘণ্টা)",
            AppLanguage.TELUGU to "డిఫాల్ట్ రేటు (₹ గంటకు)",
            AppLanguage.TAMIL to "வழக்கமான கட்டணம் (₹ மணிக்கு)",
            AppLanguage.KANNADA to "ಸಾಮಾನ್ಯ ದರ (₹ ಗಂಟೆಗೆ)",
            AppLanguage.URDU to "پہلے سے طے شدہ ریٹ (₹ فی گھنٹہ)",
            AppLanguage.SPANISH to "Tarifa Predeterminada ($/hora)",
            AppLanguage.ARABIC to "السعر الافتراضي (لكل ساعة)"
        ),
        "login_screen_title" to mapOf(
            AppLanguage.HINDI to "खाते में लॉग इन करें",
            AppLanguage.ENGLISH to "Login to Account",
            AppLanguage.PUNJABI to "ਖਾਤੇ ਵਿੱਚ ਲੌਗਇਨ ਕਰੋ",
            AppLanguage.GUJARATI to "ખાતામાં લૉગિન કરો",
            AppLanguage.MARATHI to "खात्यात लॉग इन करा",
            AppLanguage.BENGALI to "একাউন্টে লগইন করুন",
            AppLanguage.TELUGU to "ఖాతాలోకి లాగిన్ అవ్వండి",
            AppLanguage.TAMIL to "கணக்கில் உள்நுழையவும்",
            AppLanguage.KANNADA to "ಖಾತೆಗೆ ಲಾಗಿನ್ ಮಾಡಿ",
            AppLanguage.URDU to "اکاؤنٹ میں لاگ ان کریں",
            AppLanguage.SPANISH to "Iniciar Sesión",
            AppLanguage.ARABIC to "تسجيل الدخول إلى الحساب"
        ),
        "login_action_button" to mapOf(
            AppLanguage.HINDI to "लॉग इन करें →",
            AppLanguage.ENGLISH to "Login →",
            AppLanguage.PUNJABI to "ਲਾਗਇਨ ਕਰੋ →",
            AppLanguage.GUJARATI to "લૉગિન કરો →",
            AppLanguage.MARATHI to "लॉग इन करा →",
            AppLanguage.BENGALI to "লগইন করুন →",
            AppLanguage.TELUGU to "లాగిన్ అవ్వండి →",
            AppLanguage.TAMIL to "உள்நுழைக →",
            AppLanguage.KANNADA to "ಲಾಗಿನ್ ಮಾಡಿ →",
            AppLanguage.URDU to "لاگ ان کریں →",
            AppLanguage.SPANISH to "Iniciar Sesión →",
            AppLanguage.ARABIC to "دخول ←"
        ),
        "nav_home" to mapOf(
            AppLanguage.HINDI to "होम",
            AppLanguage.ENGLISH to "Home",
            AppLanguage.PUNJABI to "ਹੋਮ",
            AppLanguage.GUJARATI to "હોમ",
            AppLanguage.MARATHI to "होम",
            AppLanguage.BENGALI to "হোম",
            AppLanguage.TELUGU to "హోమ్",
            AppLanguage.TAMIL to "முகப்பு",
            AppLanguage.KANNADA to "ಮುಖಪುಟ",
            AppLanguage.URDU to "ہوم",
            AppLanguage.SPANISH to "Inicio",
            AppLanguage.ARABIC to "الرئيسية"
        ),
        "nav_customers" to mapOf(
            AppLanguage.HINDI to "ग्राहक सूची",
            AppLanguage.ENGLISH to "Customers",
            AppLanguage.PUNJABI to "ਗਾਹਕ",
            AppLanguage.GUJARATI to "ગ્રાહકો",
            AppLanguage.MARATHI to "ग्राहक",
            AppLanguage.BENGALI to "গ্রাহক",
            AppLanguage.TELUGU to "రైతులు",
            AppLanguage.TAMIL to "வாடிக்கையாளர்",
            AppLanguage.KANNADA to "ಗ್ರಾಹಕರು",
            AppLanguage.URDU to "کسٹمرز",
            AppLanguage.SPANISH to "Clientes",
            AppLanguage.ARABIC to "العملاء"
        ),
        "nav_reports" to mapOf(
            AppLanguage.HINDI to "रिपोर्ट्स",
            AppLanguage.ENGLISH to "Reports",
            AppLanguage.PUNJABI to "ਰਿਪੋਰਟਾਂ",
            AppLanguage.GUJARATI to "રિપોર્ટ્સ",
            AppLanguage.MARATHI to "अहवाल",
            AppLanguage.BENGALI to "রিপোর্ট",
            AppLanguage.TELUGU to "నివేదికలు",
            AppLanguage.TAMIL to "அறிக்கைகள்",
            AppLanguage.KANNADA to "ವರದಿಗಳು",
            AppLanguage.URDU to "رپورٹس",
            AppLanguage.SPANISH to "Informes",
            AppLanguage.ARABIC to "التقارير"
        ),
        "nav_settings" to mapOf(
            AppLanguage.HINDI to "सेटिंग्स",
            AppLanguage.ENGLISH to "Settings",
            AppLanguage.PUNJABI to "ਸੈਟਿੰਗਾਂ",
            AppLanguage.GUJARATI to "સેટિંગ્સ",
            AppLanguage.MARATHI to "सेटिंग्ज",
            AppLanguage.BENGALI to "সেটিংস",
            AppLanguage.TELUGU to "సెట్టింగ్‌లు",
            AppLanguage.TAMIL to "அமைப்புகள்",
            AppLanguage.KANNADA to "ಸೆಟ್ಟಿಂಗ್ಸ್",
            AppLanguage.URDU to "سیٹنگز",
            AppLanguage.SPANISH to "Ajustes",
            AppLanguage.ARABIC to "الإعدادات"
        ),
        "quick_session_entry" to mapOf(
            AppLanguage.HINDI to "⚡ नया ट्यूबवेल एंट्री दर्ज करें",
            AppLanguage.ENGLISH to "⚡ Quick Tubewell Session Entry",
            AppLanguage.PUNJABI to "⚡ ਨਵੀਂ ਐਂਟਰੀ ਦਰਜ ਕਰੋ",
            AppLanguage.GUJARATI to "⚡ નવી એન્ટ્રી નોંધો",
            AppLanguage.MARATHI to "⚡ नवीन नोंद करा",
            AppLanguage.BENGALI to "⚡ নতুন এন্ট্রি যোগ করুন",
            AppLanguage.TELUGU to "⚡ కొత్త ఎంట్రీ నమోదు చేయండి",
            AppLanguage.TAMIL to "⚡ புதிய பதிவு சேர்க்கவும்",
            AppLanguage.KANNADA to "⚡ ಹೊಸ ನಮೂದು ದಾಖಲಿಸಿ",
            AppLanguage.URDU to "⚡ نیا سیشن درج کریں",
            AppLanguage.SPANISH to "⚡ Registrar Sesión de Riego",
            AppLanguage.ARABIC to "⚡ تسجيل جلسة ضخ جديدة"
        ),
        "select_customer" to mapOf(
            AppLanguage.HINDI to "किसान / ग्राहक चुनें",
            AppLanguage.ENGLISH to "Select Farmer / Customer",
            AppLanguage.PUNJABI to "ਕਿਸਾਨ ਚੁਣੋ",
            AppLanguage.GUJARATI to "ખેડૂત પસંદ કરો",
            AppLanguage.MARATHI to "शेतकरी निवडा",
            AppLanguage.BENGALI to "কৃষক নির্বাচন করুন",
            AppLanguage.TELUGU to "రైతును ఎంచుకోండి",
            AppLanguage.TAMIL to "விவசாயியை தேர்வு செய்யவும்",
            AppLanguage.KANNADA to "ರೈತರನ್ನು ಆಯ್ಕೆಮಾಡಿ",
            AppLanguage.URDU to "کسان منتخب کریں",
            AppLanguage.SPANISH to "Seleccionar Agricultor",
            AppLanguage.ARABIC to "اختر المزارع"
        ),
        "hours_count" to mapOf(
            AppLanguage.HINDI to "कुल घंटे (Hours)",
            AppLanguage.ENGLISH to "Total Hours",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਘੰਟੇ",
            AppLanguage.GUJARATI to "કુલ કલાકો",
            AppLanguage.MARATHI to "एकूण तास",
            AppLanguage.BENGALI to "মোট ঘণ্টা",
            AppLanguage.TELUGU to "మొత్తం గంటలు",
            AppLanguage.TAMIL to "மொத்த மணிநேரம்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಗಂಟೆಗಳು",
            AppLanguage.URDU to "کل گھنٹے",
            AppLanguage.SPANISH to "Horas Totales",
            AppLanguage.ARABIC to "إجمالي الساعات"
        ),
        "rate_per_hr" to mapOf(
            AppLanguage.HINDI to "दर (₹ प्रति घंटा)",
            AppLanguage.ENGLISH to "Rate (₹/hr)",
            AppLanguage.PUNJABI to "ਰੇਟ (₹/ਘੰਟਾ)",
            AppLanguage.GUJARATI to "દર (₹/કલાક)",
            AppLanguage.MARATHI to "दर (₹/तास)",
            AppLanguage.BENGALI to "রেট (₹/ঘণ্টা)",
            AppLanguage.TELUGU to "రేటు (₹/గంట)",
            AppLanguage.TAMIL to "கட்டணம் (₹/மணி)",
            AppLanguage.KANNADA to "ದರ (₹/ಗಂಟೆ)",
            AppLanguage.URDU to "ریٹ (₹ فی گھنٹہ)",
            AppLanguage.SPANISH to "Tarifa ($/h)",
            AppLanguage.ARABIC to "السعر (لكل ساعة)"
        ),
        "total_amount" to mapOf(
            AppLanguage.HINDI to "कुल रकम (Total Amount)",
            AppLanguage.ENGLISH to "Total Amount",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਰਕਮ",
            AppLanguage.GUJARATI to "કુલ રકમ",
            AppLanguage.MARATHI to "एकूण रक्कम",
            AppLanguage.BENGALI to "মোট টাকা",
            AppLanguage.TELUGU to "మొత్తం మొత్తం",
            AppLanguage.TAMIL to "மொத்த தொகை",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಮೊತ್ತ",
            AppLanguage.URDU to "کل رقم",
            AppLanguage.SPANISH to "Monto Total",
            AppLanguage.ARABIC to "المبلغ الإجمالي"
        ),
        "paid_amount" to mapOf(
            AppLanguage.HINDI to "नकद जमा (Paid Amount)",
            AppLanguage.ENGLISH to "Paid Amount",
            AppLanguage.PUNJABI to "ਜਮ੍ਹਾ ਰਕਮ",
            AppLanguage.GUJARATI to "જમા રકમ",
            AppLanguage.MARATHI to "जमा रक्कम",
            AppLanguage.BENGALI to "জমা দেওয়া টাকা",
            AppLanguage.TELUGU to "చెల్లించిన మొత్తం",
            AppLanguage.TAMIL to "செலுத்திய தொகை",
            AppLanguage.KANNADA to "ಪಾವತಿಸಿದ ಮೊತ್ತ",
            AppLanguage.URDU to "وصول رقم",
            AppLanguage.SPANISH to "Monto Pagado",
            AppLanguage.ARABIC to "المبلغ المدفوع"
        ),
        "due_amount" to mapOf(
            AppLanguage.HINDI to "बाकी रकम (Balance Due)",
            AppLanguage.ENGLISH to "Balance Due",
            AppLanguage.PUNJABI to "ਬਾਕੀ ਰਕਮ",
            AppLanguage.GUJARATI to "બાકી રકમ",
            AppLanguage.MARATHI to "बाकी रक्कम",
            AppLanguage.BENGALI to "বাকি টাকা",
            AppLanguage.TELUGU to "మిగిలిన బకాయి",
            AppLanguage.TAMIL to "நிலுவைத் தொகை",
            AppLanguage.KANNADA to "ಬಾಕಿ ಮೊತ್ತ",
            AppLanguage.URDU to "باقی واجب الادا",
            AppLanguage.SPANISH to "Saldo Pendiente",
            AppLanguage.ARABIC to "المبلغ المتبقي"
        ),
        "save_session" to mapOf(
            AppLanguage.HINDI to "खाते में दर्ज करें (Save Entry)",
            AppLanguage.ENGLISH to "Save Session Entry",
            AppLanguage.PUNJABI to "ਐਂਟਰੀ ਸੇਵ ਕਰੋ",
            AppLanguage.GUJARATI to "એન્ટ્રી સેવ કરો",
            AppLanguage.MARATHI to "नोंद सेव्ह करा",
            AppLanguage.BENGALI to "এন্ট্রি সংরক্ষণ করুন",
            AppLanguage.TELUGU to "ఎంట్రీ సేవ్ చేయండి",
            AppLanguage.TAMIL to "பதிவை சேமிக்கவும்",
            AppLanguage.KANNADA to "ನಮೂದನ್ನು ಉಳಿಸಿ",
            AppLanguage.URDU to "سیشن محفوظ کریں",
            AppLanguage.SPANISH to "Guardar Sesión",
            AppLanguage.ARABIC to "حفظ الجلسة"
        ),
        "total_due_all" to mapOf(
            AppLanguage.HINDI to "कुल बाकीदार राशि (Total Due)",
            AppLanguage.ENGLISH to "Total Pending Balance",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਬਾਕੀ",
            AppLanguage.GUJARATI to "કુલ બાકી",
            AppLanguage.MARATHI to "एकूण बाकी",
            AppLanguage.BENGALI to "সর্বমোট বাকি",
            AppLanguage.TELUGU to "మొత్తం బకాయిలు",
            AppLanguage.TAMIL to "மொத்த நிலுவை",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಬಾಕಿ",
            AppLanguage.URDU to "کل باقی رقم",
            AppLanguage.SPANISH to "Total por Cobrar",
            AppLanguage.ARABIC to "إجمالي المستحقات"
        ),
        "total_collected" to mapOf(
            AppLanguage.HINDI to "कुल प्राप्त (Collected)",
            AppLanguage.ENGLISH to "Total Collected",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਪ੍ਰਾਪਤ",
            AppLanguage.GUJARATI to "કુલ મળેલ",
            AppLanguage.MARATHI to "एकूण जमा",
            AppLanguage.BENGALI to "মোট সংগৃহীত",
            AppLanguage.TELUGU to "మొత్తం వసూలు",
            AppLanguage.TAMIL to "மொத்த வசூல்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಸಂಗ್ರಹ",
            AppLanguage.URDU to "کل وصولی",
            AppLanguage.SPANISH to "Total Recaudado",
            AppLanguage.ARABIC to "إجمالي المحصل"
        ),
        "total_hours_run" to mapOf(
            AppLanguage.HINDI to "कुल चले घंटे (Total Hours)",
            AppLanguage.ENGLISH to "Total Pumped Hours",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਚੱਲੇ ਘੰਟੇ",
            AppLanguage.GUJARATI to "કુલ ચાલેલા કલાકો",
            AppLanguage.MARATHI to "एकूण चाललेले तास",
            AppLanguage.BENGALI to "মোট পাম্প চালিত ঘণ্টা",
            AppLanguage.TELUGU to "మొత్తం నడిచిన గంటలు",
            AppLanguage.TAMIL to "மொத்த ஓடிய மணிநேரம்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಚಾಲನೆಯಾದ ಗಂಟೆಗಳು",
            AppLanguage.URDU to "کل چلے ہوئے گھنٹے",
            AppLanguage.SPANISH to "Horas Totales de Bombeo",
            AppLanguage.ARABIC to "إجمالي ساعات التشغيل"
        ),
        "deposit_btn" to mapOf(
            AppLanguage.HINDI to "रुपये जमा करें",
            AppLanguage.ENGLISH to "Deposit Payment",
            AppLanguage.PUNJABI to "ਰੁਪਏ ਜਮ੍ਹਾ ਕਰੋ",
            AppLanguage.GUJARATI to "રૂપિયા જમા કરો",
            AppLanguage.MARATHI to "रक्कम जमा करा",
            AppLanguage.BENGALI to "টাকা জমা দিন",
            AppLanguage.TELUGU to "చెల్లింపు స్వీకరించండి",
            AppLanguage.TAMIL to "பணம் பெறவும்",
            AppLanguage.KANNADA to "ಹಣ ಜಮೆ ಮಾಡಿ",
            AppLanguage.URDU to "رقم جمع کریں",
            AppLanguage.SPANISH to "Registrar Cobro",
            AppLanguage.ARABIC to "تسجيل دفعة"
        ),
        "call_btn" to mapOf(
            AppLanguage.HINDI to "कॉल करें",
            AppLanguage.ENGLISH to "Call Now",
            AppLanguage.PUNJABI to "ਕਾਲ ਕਰੋ",
            AppLanguage.GUJARATI to "કૉલ કરો",
            AppLanguage.MARATHI to "कॉल करा",
            AppLanguage.BENGALI to "কল করুন",
            AppLanguage.TELUGU to "కాల్ చేయండి",
            AppLanguage.TAMIL to "அழைக்கவும்",
            AppLanguage.KANNADA to "ಕರೆ ಮಾಡಿ",
            AppLanguage.URDU to "کال کریں",
            AppLanguage.SPANISH to "Llamar",
            AppLanguage.ARABIC to "اتصال"
        ),
        "whatsapp_share" to mapOf(
            AppLanguage.HINDI to "WhatsApp पर्ची भेजें",
            AppLanguage.ENGLISH to "Send WhatsApp Bill",
            AppLanguage.PUNJABI to "WhatsApp ਪਰਚੀ ਭੇਜੋ",
            AppLanguage.GUJARATI to "WhatsApp રસીદ મોકલો",
            AppLanguage.MARATHI to "WhatsApp पावती पाठवा",
            AppLanguage.BENGALI to "WhatsApp এ রসিদ পাঠান",
            AppLanguage.TELUGU to "WhatsApp బిల్లు పంపండి",
            AppLanguage.TAMIL to "WhatsApp ரசீது அனுப்பவும்",
            AppLanguage.KANNADA to "WhatsApp ರಸೀದಿ ಕಳುಹಿಸಿ",
            AppLanguage.URDU to "واٹس ایپ رسید بھیجیں",
            AppLanguage.SPANISH to "Enviar Factura por WhatsApp",
            AppLanguage.ARABIC to "إرسال الفاتورة عبر واتساب"
        ),
        "generate_pdf" to mapOf(
            AppLanguage.HINDI to "📄 मास्टर PDF लेजर डाउनलोड व शेयर करें",
            AppLanguage.ENGLISH to "📄 Generate & Share Master PDF Ledger",
            AppLanguage.PUNJABI to "📄 ਮਾਸਟਰ PDF ਡਾਊਨਲੋਡ ਕਰੋ",
            AppLanguage.GUJARATI to "📄 માસ્ટર PDF ડાઉનલોડ કરો",
            AppLanguage.MARATHI to "📄 मास्टर PDF डाउनलोड करा",
            AppLanguage.BENGALI to "📄 মাস্টার PDF ডাউনলোড করুন",
            AppLanguage.TELUGU to "📄 మాస్టర్ PDF డౌన్‌లోడ్ చేయండి",
            AppLanguage.TAMIL to "📄 முழு PDF கணக்கை பெறவும்",
            AppLanguage.KANNADA to "📄 ಮಾಸ್ಟರ್ PDF ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ",
            AppLanguage.URDU to "📄 ماسٹر PDF لیجر ڈاؤن لوڈ کریں",
            AppLanguage.SPANISH to "📄 Generar y Compartir PDF Maestro",
            AppLanguage.ARABIC to "📄 إنشاء ومشاركة تقرير PDF الشامل"
        ),
        "tab_all" to mapOf(
            AppLanguage.HINDI to "सभी (All)",
            AppLanguage.ENGLISH to "All",
            AppLanguage.PUNJABI to "ਸਾਰੇ (All)",
            AppLanguage.GUJARATI to "બધા (All)",
            AppLanguage.MARATHI to "सर्व (All)",
            AppLanguage.BENGALI to "সব (All)",
            AppLanguage.TELUGU to "అన్నీ (All)",
            AppLanguage.TAMIL to "அனைத்தும் (All)",
            AppLanguage.KANNADA to "ಎಲ್ಲಾ (All)",
            AppLanguage.URDU to "تمام (All)",
            AppLanguage.SPANISH to "Todos",
            AppLanguage.ARABIC to "الكل"
        ),
        "filter_all" to mapOf(
            AppLanguage.HINDI to "सभी (All)",
            AppLanguage.ENGLISH to "All",
            AppLanguage.PUNJABI to "ਸਾਰੇ (All)",
            AppLanguage.GUJARATI to "બધા (All)",
            AppLanguage.MARATHI to "सर्व (All)",
            AppLanguage.BENGALI to "সব (All)",
            AppLanguage.TELUGU to "అన్నీ (All)",
            AppLanguage.TAMIL to "அனைத்தும் (All)",
            AppLanguage.KANNADA to "ಎಲ್ಲಾ (All)",
            AppLanguage.URDU to "تمام (All)",
            AppLanguage.SPANISH to "Todos",
            AppLanguage.ARABIC to "الكل"
        ),
        "filter_today" to mapOf(
            AppLanguage.HINDI to "आज (Today)",
            AppLanguage.ENGLISH to "Today",
            AppLanguage.PUNJABI to "ਅੱਜ (Today)",
            AppLanguage.GUJARATI to "આજે (Today)",
            AppLanguage.MARATHI to "आज (Today)",
            AppLanguage.BENGALI to "আজ (Today)",
            AppLanguage.TELUGU to "ఈ రోజు (Today)",
            AppLanguage.TAMIL to "இன்று (Today)",
            AppLanguage.KANNADA to "ಇಂದು (Today)",
            AppLanguage.URDU to "آج (Today)",
            AppLanguage.SPANISH to "Hoy (Today)",
            AppLanguage.ARABIC to "اليوم (Today)"
        ),
        "filter_weekly" to mapOf(
            AppLanguage.HINDI to "इस सप्ताह (Weekly)",
            AppLanguage.ENGLISH to "Weekly",
            AppLanguage.PUNJABI to "ਇਸ ਹਫ਼ਤੇ (Weekly)",
            AppLanguage.GUJARATI to "આ અઠવાડિયે (Weekly)",
            AppLanguage.MARATHI to "या आठवड्यात (Weekly)",
            AppLanguage.BENGALI to "এই সপ্তাহ (Weekly)",
            AppLanguage.TELUGU to "ఈ వారం (Weekly)",
            AppLanguage.TAMIL to "இந்த வாரம் (Weekly)",
            AppLanguage.KANNADA to "ಈ ವಾರ (Weekly)",
            AppLanguage.URDU to "اس ہفتے (Weekly)",
            AppLanguage.SPANISH to "Semanal (Weekly)",
            AppLanguage.ARABIC to "أسبوعي (Weekly)"
        ),
        "filter_monthly" to mapOf(
            AppLanguage.HINDI to "इस महीने (Monthly)",
            AppLanguage.ENGLISH to "Monthly",
            AppLanguage.PUNJABI to "ਇਸ ਮਹੀਨੇ (Monthly)",
            AppLanguage.GUJARATI to "આ મહિને (Monthly)",
            AppLanguage.MARATHI to "या महिन्यात (Monthly)",
            AppLanguage.BENGALI to "এই মাস (Monthly)",
            AppLanguage.TELUGU to "ఈ నెల (Monthly)",
            AppLanguage.TAMIL to "இந்த மாதம் (Monthly)",
            AppLanguage.KANNADA to "ಈ ತಿಂಗಳು (Monthly)",
            AppLanguage.URDU to "اس مہینے (Monthly)",
            AppLanguage.SPANISH to "Mensual (Monthly)",
            AppLanguage.ARABIC to "شهري (Monthly)"
        ),
        "filter_yearly" to mapOf(
            AppLanguage.HINDI to "1 साल (Yearly)",
            AppLanguage.ENGLISH to "1 Year (Yearly)",
            AppLanguage.PUNJABI to "1 ਸਾਲ (Yearly)",
            AppLanguage.GUJARATI to "1 વર્ષ (Yearly)",
            AppLanguage.MARATHI to "1 वर्ष (Yearly)",
            AppLanguage.BENGALI to "১ বছর (Yearly)",
            AppLanguage.TELUGU to "1 సంవత్సరం (Yearly)",
            AppLanguage.TAMIL to "1 வருடம் (Yearly)",
            AppLanguage.KANNADA to "1 ವರ್ಷ (Yearly)",
            AppLanguage.URDU to "1 سال (Yearly)",
            AppLanguage.SPANISH to "1 Año (Yearly)",
            AppLanguage.ARABIC to "سنة واحدة (Yearly)"
        ),
        "filter_2years" to mapOf(
            AppLanguage.HINDI to "2 साल (2 Years)",
            AppLanguage.ENGLISH to "2 Years",
            AppLanguage.PUNJABI to "2 ਸਾਲ (2 Years)",
            AppLanguage.GUJARATI to "2 વર્ષ (2 Years)",
            AppLanguage.MARATHI to "2 वर्षे (2 Years)",
            AppLanguage.BENGALI to "২ বছর (2 Years)",
            AppLanguage.TELUGU to "2 సంవత్సరాలు (2 Years)",
            AppLanguage.TAMIL to "2 வருடங்கள் (2 Years)",
            AppLanguage.KANNADA to "2 ವರ್ಷಗಳು (2 Years)",
            AppLanguage.URDU to "2 سال (2 Years)",
            AppLanguage.SPANISH to "2 Años (2 Years)",
            AppLanguage.ARABIC to "سنتان (2 Years)"
        ),
        "tab_due" to mapOf(
            AppLanguage.HINDI to "बाकीदार (Due)",
            AppLanguage.ENGLISH to "Due",
            AppLanguage.PUNJABI to "ਬਾਕੀ ਵਾਲੇ",
            AppLanguage.GUJARATI to "બાકીવાળા",
            AppLanguage.MARATHI to "बाकीदार",
            AppLanguage.BENGALI to "বকেয়া",
            AppLanguage.TELUGU to "బకాయిలు",
            AppLanguage.TAMIL to "நிலுவை",
            AppLanguage.KANNADA to "ಬಾಕಿ ಇರುವವರು",
            AppLanguage.URDU to "واجب الادا",
            AppLanguage.SPANISH to "Pendientes",
            AppLanguage.ARABIC to "الآجل / المستحق"
        ),
        "filter_due" to mapOf(
            AppLanguage.HINDI to "बकाया वाले (Due)",
            AppLanguage.ENGLISH to "Pending Due",
            AppLanguage.PUNJABI to "ਬਾਕੀ ਵਾਲੇ (Due)",
            AppLanguage.GUJARATI to "બાકીવાળા (Due)",
            AppLanguage.MARATHI to "बाकीदार (Due)",
            AppLanguage.BENGALI to "বকেয়া (Due)",
            AppLanguage.TELUGU to "బకాయిలు (Due)",
            AppLanguage.TAMIL to "நிலுவை (Due)",
            AppLanguage.KANNADA to "ಬಾಕಿ ಇರುವವರು (Due)",
            AppLanguage.URDU to "واجب الادا (Due)",
            AppLanguage.SPANISH to "Pendientes (Due)",
            AppLanguage.ARABIC to "المستحقات (Due)"
        ),
        "tab_cash" to mapOf(
            AppLanguage.HINDI to "चुक्ता (No Due)",
            AppLanguage.ENGLISH to "Settled (Cash)",
            AppLanguage.PUNJABI to "ਨਿਪਟਾਏ",
            AppLanguage.GUJARATI to "ચૂકતે",
            AppLanguage.MARATHI to "निल बाकी",
            AppLanguage.BENGALI to "পরিশোধিত",
            AppLanguage.TELUGU to "చెల్లించినవి",
            AppLanguage.TAMIL to "முழுதும் செலுத்தியவை",
            AppLanguage.KANNADA to "ಪೂರ್ಣ ಪಾವತಿಸಿದವರು",
            AppLanguage.URDU to "بے باق",
            AppLanguage.SPANISH to "Liquidados",
            AppLanguage.ARABIC to "المسدد بالكامل"
        ),
        "filter_cash" to mapOf(
            AppLanguage.HINDI to "नकद वाले (Cash)",
            AppLanguage.ENGLISH to "Cash / Settled",
            AppLanguage.PUNJABI to "ਨਕਦ ਵਾਲੇ (Cash)",
            AppLanguage.GUJARATI to "રોકડ વાળા (Cash)",
            AppLanguage.MARATHI to "नकद वाले (Cash)",
            AppLanguage.BENGALI to "নগদ / পরিশোধিত (Cash)",
            AppLanguage.TELUGU to "నగదు / చెల్లించినవి (Cash)",
            AppLanguage.TAMIL to "ரொக்கம் / செலுத்தியவை (Cash)",
            AppLanguage.KANNADA to "ನಗದು / ಪಾವತಿಸಿದವರು (Cash)",
            AppLanguage.URDU to "نقد / بے باق (Cash)",
            AppLanguage.SPANISH to "Contado / Al Día (Cash)",
            AppLanguage.ARABIC to "النقدي / المسدد (Cash)"
        ),
        "support_help" to mapOf(
            AppLanguage.HINDI to "सहायता / Support",
            AppLanguage.ENGLISH to "Support / Help",
            AppLanguage.PUNJABI to "ਸਹਾਇਤਾ / Support",
            AppLanguage.GUJARATI to "સહાય / Support",
            AppLanguage.MARATHI to "मदत / Support",
            AppLanguage.BENGALI to "সহায়তা / Support",
            AppLanguage.TELUGU to "సహాయం / Support",
            AppLanguage.TAMIL to "உதவி / Support",
            AppLanguage.KANNADA to "ಸಹಾಯ / Support",
            AppLanguage.URDU to "مدد / Support",
            AppLanguage.SPANISH to "Soporte / Ayuda",
            AppLanguage.ARABIC to "الدعم والمساعدة"
        ),
        "forgot_password" to mapOf(
            AppLanguage.HINDI to "पासवर्ड भूल गए?",
            AppLanguage.ENGLISH to "Forgot Password?",
            AppLanguage.PUNJABI to "ਪਾਸਵਰਡ ਭੁੱਲ ਗਏ?",
            AppLanguage.GUJARATI to "પાસવર્ડ ભૂલી ગયા?",
            AppLanguage.MARATHI to "पासवर्ड विसरलात?",
            AppLanguage.BENGALI to "পাসওয়ার্ড ভুলে গেছেন?",
            AppLanguage.TELUGU to "పాస్‌వర్డ్ మర్చిపోయారా?",
            AppLanguage.TAMIL to "கடவுச்சொல் மறந்துவிட்டதா?",
            AppLanguage.KANNADA to "ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರಾ?",
            AppLanguage.URDU to "پاس ورڈ بھول گئے؟",
            AppLanguage.SPANISH to "¿Olvidaste tu contraseña?",
            AppLanguage.ARABIC to "هل نسيت كلمة المرور؟"
        )
    )
}

/**
 * Convenient string localization extension
 */
fun String.tr(language: AppLanguage): String {
    return LanguageManager.translate(this, language)
}
