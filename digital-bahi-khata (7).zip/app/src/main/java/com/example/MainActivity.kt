package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screens.MainContainerScreen
import com.example.ui.theme.KisanLedgerTheme
import com.example.ui.viewmodel.KisanLedgerViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: KisanLedgerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KisanLedgerTheme {
                MainContainerScreen(viewModel = viewModel)
            }
        }
    }
}
