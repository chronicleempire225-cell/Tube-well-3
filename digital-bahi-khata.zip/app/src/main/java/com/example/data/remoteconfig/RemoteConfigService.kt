package com.example.data.remoteconfig

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.supabase.SupabaseAuthService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Dynamic Remote Config & AdMob Controller.
 * 
 * Allows controlling:
 * 1. Which screens show ads (HOME, CUSTOMERS, HISTORY, etc.)
 * 2. Ad sizes (BANNER, LARGE_BANNER, MEDIUM_RECTANGLE, ADAPTIVE)
 * 3. Position (BOTTOM, TOP)
 * 4. Ad Unit ID (Test ID or production AdMob ID)
 * 5. Premium / Ad-Free user flags (user_subscriptions)
 * 
 * Offline-first: Cached in SharedPreferences so UI never flickers or hangs.
 * Syncs seamlessly with Supabase table 'app_remote_config'.
 */
data class AdSlotConfig(
    val screenName: String,
    val isEnabled: Boolean = true,
    val position: String = "BOTTOM",       // BOTTOM or TOP
    val adSize: String = "BANNER",         // BANNER, LARGE_BANNER, MEDIUM_RECTANGLE, REWARDED
    val adUnitId: String = GOOGLE_TEST_BANNER_ID,
    val requiredWatchSeconds: Int = 0      // 0 means standard Google AdMob reward rules (100% policy compliant)
) {
    companion object {
        const val GOOGLE_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    }
}

/**
 * Dynamic Pricing and Festival/Special Offer Configuration.
 * Fully configurable from Supabase 'app_pricing_offers'.
 */
data class PricingOfferConfig(
    val monthlyPrice: Double = 49.0,              // Offer monthly price
    val monthlyOriginalPrice: Double = 99.0,      // Normal/Base monthly price (when offer is OFF)
    val yearlyPrice: Double = 199.0,              // Offer yearly price
    val yearlyOriginalPrice: Double = 499.0,      // Normal/Base yearly price (when offer is OFF)
    val isOfferActive: Boolean = false,
    val showHomeBanner: Boolean = false,          // Separate control to show/hide home countdown banner
    val isVipEnabled: Boolean = false,            // Master toggle for VIP Subscription (OFF by default for new app)
    val offerTitle: String = "त्योहार महा-धमाका ऑफर! 💥",
    val offerSubtitle: String = "सिर्फ सीमित समय के लिए 60% तक भारी छूट",
    val bannerBadgeText: String = "SALE",       // e.g. "DIWALI", "HOLI", "SALE", "OFFER"
    val bannerTheme: String = "RED_GOLD",       // "RED_GOLD", "SAFFRON", "GREEN", "ROYAL_BLUE", "PURPLE"
    val bannerImageUrl: String = "",            // Custom image URL from Supabase Storage or external CDN!
    val offerStartTimeMs: Long = 0L,            // 0 means start immediately
    val offerEndTimeMs: Long = System.currentTimeMillis() + (72L * 60L * 60L * 1000L), // 3 days default
    val razorpayKeyId: String = "rzp_test_TZA7CyoMjch6gO" // Set real ID in Supabase!
) {
    /**
     * Checks if festival offer countdown is currently live based on clock.
     */
    fun isOfferLiveNow(): Boolean {
        if (!isOfferActive) return false
        val now = System.currentTimeMillis()
        if (offerStartTimeMs > 0 && now < offerStartTimeMs) return false
        if (offerEndTimeMs > 0 && now > offerEndTimeMs) return false
        return true
    }

    /**
     * Checks if the home countdown banner should be shown.
     * Controlled independently by 'show_home_banner' in Supabase.
     */
    fun shouldDisplayHomeBanner(): Boolean {
        return isVipEnabled && showHomeBanner && isOfferLiveNow()
    }

    /**
     * Active monthly price to charge via Razorpay (Discounted if offer is live, else normal)
     */
    fun getEffectiveMonthlyPrice(): Double = if (isOfferLiveNow()) monthlyPrice else monthlyOriginalPrice

    /**
     * Active yearly price to charge via Razorpay (Discounted if offer is live, else normal)
     */
    fun getEffectiveYearlyPrice(): Double = if (isOfferLiveNow()) yearlyPrice else yearlyOriginalPrice

    /**
     * Remaining milliseconds before offer ends.
     */
    fun remainingOfferMillis(): Long {
        val now = System.currentTimeMillis()
        return (offerEndTimeMs - now).coerceAtLeast(0L)
    }
}

object RemoteConfigService {
    private const val TAG = "RemoteConfigService"
    private const val PREFS_NAME = "remote_ad_config_prefs"
    private const val KEY_CONFIG_JSON = "cached_ad_configs"
    private const val KEY_PRICING_JSON = "cached_pricing_offers"
    private const val KEY_IS_PREMIUM_USER = "cached_is_premium"
    private const val KEY_PLAN_TYPE = "cached_plan_type"
    private const val KEY_FEATURE_PASS_EXPIRY = "feature_pass_expiry_timestamp"
    private const val KEY_VIP_EXPIRY = "cached_vip_expiry_timestamp"
    private const val KEY_VIP_DAYS_REMAINING = "cached_vip_days_remaining"

    private val _pricingOffer = MutableStateFlow(PricingOfferConfig())
    val pricingOffer: StateFlow<PricingOfferConfig> = _pricingOffer.asStateFlow()

    // Default configurations with user's verified Live AdMob IDs
    private val DEFAULT_CONFIGS = mapOf(
        "HOME" to AdSlotConfig(screenName = "HOME", isEnabled = true, position = "BOTTOM", adSize = "BANNER", adUnitId = "ca-app-pub-8640508231791309/4794109713"),
        "CUSTOMERS" to AdSlotConfig(screenName = "CUSTOMERS", isEnabled = true, position = "BOTTOM", adSize = "BANNER", adUnitId = "ca-app-pub-8640508231791309/4794109713"),
        "REPORTS" to AdSlotConfig(screenName = "REPORTS", isEnabled = true, position = "BOTTOM", adSize = "BANNER", adUnitId = "ca-app-pub-8640508231791309/4794109713"),
        "HISTORY" to AdSlotConfig(screenName = "HISTORY", isEnabled = true, position = "BOTTOM", adSize = "BANNER", adUnitId = "ca-app-pub-8640508231791309/4794109713"),
        "CALCULATOR" to AdSlotConfig(screenName = "CALCULATOR", isEnabled = false, position = "BOTTOM", adSize = "BANNER", adUnitId = "ca-app-pub-8640508231791309/4794109713"),
        "LIVE_SESSION" to AdSlotConfig(
            screenName = "LIVE_SESSION",
            isEnabled = true,
            position = "INLINE",
            adSize = "MEDIUM_RECTANGLE",
            adUnitId = "ca-app-pub-8640508231791309/9250386161"
        ),
        "APP_OPEN" to AdSlotConfig(
            screenName = "APP_OPEN",
            isEnabled = true,
            position = "FULLSCREEN",
            adSize = "APP_OPEN",
            adUnitId = "ca-app-pub-8640508231791309/7238466340"
        ),
        "REWARDED_FEATURE_UNLOCK" to AdSlotConfig(
            screenName = "REWARDED_FEATURE_UNLOCK",
            isEnabled = true,
            position = "FULLSCREEN",
            adSize = "REWARDED",
            adUnitId = "ca-app-pub-8640508231791309/3942219164"
        ),
        "MUNSHI_PASS_CONFIG" to AdSlotConfig(
            screenName = "MUNSHI_PASS_CONFIG",
            isEnabled = true, // TRUE: Munshi is tied to 24-hr Pass and VIP Pass. FALSE: Separated from passes (free for all)
            position = "TIED_TO_PASS",
            adSize = "GEMINI_AI",
            adUnitId = "5", // Default 5 daily free calls per account
            requiredWatchSeconds = 5 // Default 5 daily free calls per account
        )
    )

    private val _configsFlow = MutableStateFlow<Map<String, AdSlotConfig>>(DEFAULT_CONFIGS)
    val configsFlow: StateFlow<Map<String, AdSlotConfig>> = _configsFlow.asStateFlow()

    private val _isAdFreeUser = MutableStateFlow(false)
    val isAdFreeUser: StateFlow<Boolean> = _isAdFreeUser.asStateFlow()

    private val _planType = MutableStateFlow("FREE")
    val planType: StateFlow<String> = _planType.asStateFlow()

    // 24-hour temporary feature unlock (granted by watching Rewarded Video Ad)
    // NOTE: Banner ads STILL run even when feature pass is active, per business requirement!
    private val _featurePassExpiry = MutableStateFlow(0L)
    val featurePassExpiry: StateFlow<Long> = _featurePassExpiry.asStateFlow()

    // VIP Expiry timestamp (epoch millis) and daily calculated days remaining
    private val _vipExpiryTimestamp = MutableStateFlow(0L)
    val vipExpiryTimestamp: StateFlow<Long> = _vipExpiryTimestamp.asStateFlow()

    private val _vipDaysRemaining = MutableStateFlow(0)
    val vipDaysRemaining: StateFlow<Int> = _vipDaysRemaining.asStateFlow()

    private var isInitialized = false

    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedPlan = prefs.getString(KEY_PLAN_TYPE, "FREE") ?: "FREE"
        if (savedPlan == "LIFETIME_SUPABASE") {
            prefs.edit().putBoolean(KEY_IS_PREMIUM_USER, false).putString(KEY_PLAN_TYPE, "FREE").apply()
            _isAdFreeUser.value = false
            _planType.value = "FREE"
        } else {
            _isAdFreeUser.value = prefs.getBoolean(KEY_IS_PREMIUM_USER, false)
            _planType.value = savedPlan
        }
        _featurePassExpiry.value = prefs.getLong(KEY_FEATURE_PASS_EXPIRY, 0L)
        _vipExpiryTimestamp.value = prefs.getLong(KEY_VIP_EXPIRY, 0L)
        _vipDaysRemaining.value = prefs.getInt(KEY_VIP_DAYS_REMAINING, 0)

        // Automatically recalculate remaining days and refresh VIP active state
        checkAndRefreshVipStatus(context)

        val cachedJson = prefs.getString(KEY_CONFIG_JSON, null)
        if (!cachedJson.isNullOrBlank()) {
            try {
                val parsed = parseConfigsJson(cachedJson)
                if (parsed.isNotEmpty()) {
                    _configsFlow.value = DEFAULT_CONFIGS + parsed
                    val cachedWorker = parsed["CLOUDFLARE_WORKER"] ?: parsed["GEMINI_PROXY"]
                    if (cachedWorker != null && cachedWorker.adUnitId.isNotBlank()) {
                        com.example.data.gemini.GeminiMunshiService.masterCloudflareWorkerUrl = cachedWorker.adUnitId.trim()
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error parsing cached ad configs: ${e.message}")
            }
        }

        val cachedPricingJson = prefs.getString(KEY_PRICING_JSON, null)
        if (!cachedPricingJson.isNullOrBlank()) {
            try {
                val parsedPricing = parsePricingJson(cachedPricingJson)
                if (parsedPricing != null) {
                    _pricingOffer.value = parsedPricing
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error parsing cached pricing offers: ${e.message}")
            }
        }

        // Asynchronously fetch latest remote configs & pricing offers from Supabase
        CoroutineScope(Dispatchers.IO).launch {
            fetchFromSupabase(context)
            fetchPricingOffersFromSupabase(context)
        }
    }

    /**
     * Returns the currently active Pricing & VIP offer configuration.
     */
    fun getPricingConfig(): PricingOfferConfig = _pricingOffer.value

    /**
     * Gets the Ad configuration for a specific screen.
     */
    fun getConfigForScreen(screenName: String): AdSlotConfig? {
        return _configsFlow.value[screenName.uppercase()]
    }

    /**
     * Checks if ads should be rendered for this screen.
     * Returns false if user is Premium/Ad-Free, or if disabled by Admin.
     */
    fun shouldShowAd(screenName: String): Boolean {
        if (_isAdFreeUser.value) return false
        val cfg = getConfigForScreen(screenName)
        return cfg?.isEnabled == true
    }

    /**
     * Sync remote configuration from Supabase table 'app_remote_config'.
     */
    suspend fun fetchFromSupabase(context: Context): Boolean = withContext(Dispatchers.IO) {
        if (!SupabaseAuthService.isConfigured(context)) return@withContext false
        val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
        val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)

        try {
            // 1. Fetch remote ad configs
            val endpoint = "$baseUrl/rest/v1/app_remote_config?select=*"
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                SupabaseAuthService.applyAuthHeaders(this, anonKey)
            }

            if (conn.responseCode in 200..299) {
                val responseStr = conn.inputStream.bufferedReader().use { it.readText() }
                val parsed = parseConfigsJson(responseStr)
                if (parsed.isNotEmpty()) {
                    val updated = DEFAULT_CONFIGS + parsed
                    _configsFlow.value = updated
                    saveConfigsToLocal(context, responseStr)
                    val liveWorker = parsed["CLOUDFLARE_WORKER"] ?: parsed["GEMINI_PROXY"]
                    if (liveWorker != null && liveWorker.adUnitId.isNotBlank()) {
                        com.example.data.gemini.GeminiMunshiService.masterCloudflareWorkerUrl = liveWorker.adUnitId.trim()
                    }
                    Log.d(TAG, "Successfully synced ${parsed.size} remote ad configs from Supabase")
                }
                return@withContext true
            } else {
                Log.w(TAG, "Failed to fetch remote config (HTTP ${conn.responseCode}). Using local defaults.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Remote config fetch error: ${e.message}")
        }
        return@withContext false
    }

    /**
     * Updates an ad configuration locally and syncs to Supabase.
     */
    suspend fun updateConfig(
        context: Context,
        screenName: String,
        isEnabled: Boolean,
        adSize: String = "BANNER",
        position: String = "BOTTOM",
        adUnitId: String = AdSlotConfig.GOOGLE_TEST_BANNER_ID
    ): Boolean = withContext(Dispatchers.IO) {
        val upperKey = screenName.uppercase()
        val current = _configsFlow.value.toMutableMap()
        val newConfig = AdSlotConfig(
            screenName = upperKey,
            isEnabled = isEnabled,
            position = position,
            adSize = adSize,
            adUnitId = adUnitId
        )
        current[upperKey] = newConfig
        _configsFlow.value = current

        // Save locally
        val jsonArray = JSONArray()
        current.values.forEach { cfg ->
            jsonArray.put(JSONObject().apply {
                put("screen_name", cfg.screenName)
                put("is_enabled", cfg.isEnabled)
                put("position", cfg.position)
                put("ad_size", cfg.adSize)
                put("ad_unit_id", cfg.adUnitId)
            })
        }
        saveConfigsToLocal(context, jsonArray.toString())

        // Push to Supabase if configured
        if (SupabaseAuthService.isConfigured(context)) {
            try {
                val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
                val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)
                val endpoint = "$baseUrl/rest/v1/app_remote_config?on_conflict=screen_name"

                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "resolution=merge-duplicates")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }

                val body = JSONObject().apply {
                    put("screen_name", newConfig.screenName)
                    put("is_enabled", newConfig.isEnabled)
                    put("position", newConfig.position)
                    put("ad_size", newConfig.adSize)
                    put("ad_unit_id", newConfig.adUnitId)
                }

                OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
                val code = conn.responseCode
                Log.d(TAG, "Push config to Supabase code: $code")
                return@withContext code in 200..299
            } catch (e: Exception) {
                Log.e(TAG, "Push config to Supabase failed: ${e.message}")
            }
        }
        return@withContext true
    }

    /**
     * Resets local VIP membership state to FREE with 0 days remaining.
     */
    fun resetVipState(context: Context) {
        _isAdFreeUser.value = false
        _planType.value = "FREE"
        _vipExpiryTimestamp.value = 0L
        _vipDaysRemaining.value = 0
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_IS_PREMIUM_USER, false)
            .putString(KEY_PLAN_TYPE, "FREE")
            .putLong(KEY_VIP_EXPIRY, 0L)
            .putInt(KEY_VIP_DAYS_REMAINING, 0)
            .apply()
    }

    /**
     * Recalculates remaining VIP days based on current system time and stored expiry timestamp.
     * Updates local state and preferences. If expired, automatically revokes VIP.
     * Returns remaining days (0 if expired or not VIP).
     */
    fun checkAndRefreshVipStatus(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isPrem = prefs.getBoolean(KEY_IS_PREMIUM_USER, false)
        val expiry = prefs.getLong(KEY_VIP_EXPIRY, 0L)
        val now = System.currentTimeMillis()

        if (!isPrem || expiry <= 0L) {
            resetVipState(context)
            return 0
        }

        if (now >= expiry) {
            // Subscription has expired
            Log.d(TAG, "VIP subscription expired at $expiry (current time: $now). Revoking VIP.")
            resetVipState(context)
            return 0
        } else {
            val remainingDays = Math.ceil((expiry - now) / (1000.0 * 60 * 60 * 24)).toInt().coerceAtLeast(1)
            _isAdFreeUser.value = true
            _vipExpiryTimestamp.value = expiry
            _vipDaysRemaining.value = remainingDays
            prefs.edit().putInt(KEY_VIP_DAYS_REMAINING, remainingDays).apply()
            return remainingDays
        }
    }

    /**
     * Returns the formatted date string (e.g., "15 Oct 2026") when the VIP subscription expires.
     */
    fun getFormattedVipExpiryDate(): String {
        val expiry = _vipExpiryTimestamp.value
        if (expiry <= 0L) return ""
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale("hi", "IN"))
        return sdf.format(Date(expiry))
    }

    /**
     * Adds / Extends VIP subscription.
     * CUMULATIVE DURATION LOGIC:
     * If the user already has an active VIP subscription with remaining days,
     * the new plan days are STACKED (added) onto the existing expiry timestamp.
     * 
     * Returns total days remaining after addition.
     */
    fun addVipSubscription(
        context: Context,
        planType: String,
        daysToAdd: Int? = null,
        phone: String = ""
    ): Int {
        val now = System.currentTimeMillis()
        val currentExpiry = _vipExpiryTimestamp.value
        
        // If current VIP is active and has future expiry, add days onto currentExpiry (cumulative)!
        val baseTime = if (_isAdFreeUser.value && currentExpiry > now) currentExpiry else now

        val addedDays = daysToAdd ?: if (planType.uppercase().contains("YEAR")) 365 else 30
        val addedMillis = addedDays.toLong() * 24L * 60L * 60L * 1000L
        val newExpiry = baseTime + addedMillis
        val newTotalDays = Math.ceil((newExpiry - now) / (1000.0 * 60 * 60 * 24)).toInt().coerceAtLeast(addedDays)

        _isAdFreeUser.value = true
        _planType.value = planType
        _vipExpiryTimestamp.value = newExpiry
        _vipDaysRemaining.value = newTotalDays

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_IS_PREMIUM_USER, true)
            .putString(KEY_PLAN_TYPE, planType)
            .putLong(KEY_VIP_EXPIRY, newExpiry)
            .putInt(KEY_VIP_DAYS_REMAINING, newTotalDays)
            .apply()

        Log.d(TAG, "VIP subscription stacked/added! Added: $addedDays days. Total remaining days: $newTotalDays. Expiry: $newExpiry")

        if (phone.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                syncVipDaysToSupabase(context, phone, newExpiry, newTotalDays, planType)
            }
        }
        return newTotalDays
    }

    /**
     * Syncs calculated remaining VIP days and ISO expiry timestamp to Supabase 'profiles' table.
     */
    suspend fun syncVipDaysToSupabase(
        context: Context,
        phone: String,
        expiryTimestamp: Long,
        daysRemaining: Int,
        planType: String = "PREMIUM"
    ) {
        if (!SupabaseAuthService.isConfigured(context) || phone.isBlank()) return
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").trim()
        if (cleanPhone.length < 6) return

        withContext(Dispatchers.IO) {
            try {
                val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
                val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)
                val encodedPhone = URLEncoder.encode("*$cleanPhone*", "UTF-8")

                // Format ISO 8601 UTC timestamp string for Supabase timestamp column
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val isoExpiry = sdf.format(Date(expiryTimestamp))

                val profileEndpoint = "$baseUrl/rest/v1/profiles?phone=ilike.$encodedPhone"
                val conn = (URL(profileEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "PATCH"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }

                val body = JSONObject().apply {
                    put("vip_member", daysRemaining > 0)
                    put("is_premium", daysRemaining > 0)
                    put("vip_days_remaining", daysRemaining)
                    put("vip_expiry", isoExpiry)
                    put("vip_plan", planType)
                    put("updated_at", System.currentTimeMillis())
                }

                OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
                val code = conn.responseCode
                Log.d(TAG, "Supabase profile VIP days synced: code=$code, days=$daysRemaining, expiry=$isoExpiry")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to sync VIP days to Supabase: ${e.message}")
            }
        }
    }

    /**
     * Syncs VIP membership state from a downloaded Supabase Profile JSON object.
     */
    fun syncFromProfileJson(context: Context, obj: JSONObject) {
        try {
            val isVip = obj.optBoolean("vip_member", false)
            val expiryStr = obj.optString("vip_expiry", "")
            val daysFromDb = obj.optInt("vip_days_remaining", 0)
            val plan = obj.optString("vip_plan", "FREE").ifBlank { "FREE" }
            val phone = obj.optString("phone", obj.optString("mobile", ""))

            var parsedExpiry = 0L
            if (expiryStr.isNotBlank() && expiryStr != "null") {
                try {
                    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                        timeZone = TimeZone.getTimeZone("UTC")
                    }
                    parsedExpiry = sdf.parse(expiryStr.replace("Z", "").substringBefore("."))?.time ?: 0L
                } catch (_: Exception) {
                    try { parsedExpiry = expiryStr.toLong() } catch (_: Exception) {}
                }
            }

            val now = System.currentTimeMillis()
            if (isVip && (parsedExpiry > now || daysFromDb > 0)) {
                val finalDays = when {
                    parsedExpiry > now -> Math.ceil((parsedExpiry - now) / (1000.0 * 60 * 60 * 24)).toInt().coerceAtLeast(1)
                    daysFromDb > 0 -> daysFromDb
                    else -> 0
                }
                if (finalDays > 0) {
                    val finalExpiry = if (parsedExpiry > now) parsedExpiry else (now + finalDays.toLong() * 24L * 60L * 60L * 1000L)

                    _isAdFreeUser.value = true
                    _planType.value = plan
                    _vipExpiryTimestamp.value = finalExpiry
                    _vipDaysRemaining.value = finalDays

                    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                        .putBoolean(KEY_IS_PREMIUM_USER, true)
                        .putString(KEY_PLAN_TYPE, plan)
                        .putLong(KEY_VIP_EXPIRY, finalExpiry)
                        .putInt(KEY_VIP_DAYS_REMAINING, finalDays)
                        .apply()

                    if (phone.isNotBlank()) {
                        CoroutineScope(Dispatchers.IO).launch {
                            syncVipDaysToSupabase(context, phone, finalExpiry, finalDays, plan)
                        }
                    }
                    return
                }
            }

            // User has no active VIP membership -> reset local state to FREE
            resetVipState(context)
        } catch (e: Exception) {
            Log.w(TAG, "Error syncing VIP from profile JSON: ${e.message}")
        }
    }

    /**
     * Toggles Premium / Ad-free status locally for demonstration and admin testing.
     */
    fun setAdFreeLocally(context: Context, isAdFree: Boolean, plan: String = "PREMIUM", days: Int = 30) {
        if (isAdFree) {
            addVipSubscription(context, plan, days)
        } else {
            _isAdFreeUser.value = false
            _planType.value = "FREE"
            _vipExpiryTimestamp.value = 0L
            _vipDaysRemaining.value = 0
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_IS_PREMIUM_USER, false)
                .putString(KEY_PLAN_TYPE, "FREE")
                .putLong(KEY_VIP_EXPIRY, 0L)
                .putInt(KEY_VIP_DAYS_REMAINING, 0)
                .apply()
        }
    }

    /**
     * Checks if Rewarded Video Unlock is enabled in Supabase remote config.
     */
    fun isRewardedAdEnabled(): Boolean {
        val config = _configsFlow.value["REWARDED_FEATURE_UNLOCK"]
        return config?.isEnabled ?: true
    }

    /**
     * Checks if features (PDF, WhatsApp share, etc.) are unlocked.
     * 1. If user is VIP -> 100% unlocked.
     * 2. If Rewarded Video is DISABLED in Supabase by Admin -> 100% unlocked for everyone for free!
     * 3. Else, checks if the 24-hour pass earned via video ad is active.
     */
    fun isFeaturePassActive(): Boolean {
        if (_isAdFreeUser.value) return true
        if (!isRewardedAdEnabled()) return true // Admin disabled rewarded ads -> All features unlocked free!
        return System.currentTimeMillis() < _featurePassExpiry.value
    }

    /**
     * Grants 24-hour temporary feature access (earned via Rewarded Video Ad).
     * IMPORTANT: Per user rule, banner ads will continue to display normally!
     */
    fun grant24HourFeaturePass(context: Context) {
        val expiry = System.currentTimeMillis() + (24L * 60L * 60L * 1000L)
        _featurePassExpiry.value = expiry
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_FEATURE_PASS_EXPIRY, expiry)
            .apply()
        Log.d(TAG, "24-Hour Feature Pass granted! Expires at timestamp: $expiry")
    }

    /**
     * Returns human-readable remaining time for the feature pass.
     */
    fun getRemainingFeaturePassTimeFormatted(): String {
        if (_isAdFreeUser.value) return "असीमित (VIP)"
        val diff = _featurePassExpiry.value - System.currentTimeMillis()
        if (diff <= 0L) return "समाप्त"
        val hours = diff / (1000L * 60L * 60L)
        val minutes = (diff / (1000L * 60L)) % 60L
        return if (hours > 0) "${hours} घंटे ${minutes} मिनट" else "${minutes} मिनट"
    }

    /**
     * Checks if Munshi Gemini AI is gated by 24-hour pass & VIP pass.
     * Controlled directly from Supabase 'app_remote_config' where screen_name='MUNSHI_PASS_CONFIG'.
     * is_enabled = true  -> Gated (Pass / VIP required once daily free limit is reached).
     * is_enabled = false -> Separated from passes (Completely free for everyone without pass/VIP requirements).
     */
    fun isMunshiGatedByPass(): Boolean {
        val config = _configsFlow.value["MUNSHI_PASS_CONFIG"]
        return config?.isEnabled ?: true
    }

    /**
     * Daily free Gemini AI queries allowed per account before requiring a pass or VIP.
     * Default is 5. Configurable from Supabase table 'app_remote_config' ('required_seconds' or 'ad_unit_id').
     */
    fun getMunshiDailyFreeLimit(): Int {
        val config = _configsFlow.value["MUNSHI_PASS_CONFIG"]
        val fromSeconds = config?.requiredWatchSeconds
        if (fromSeconds != null && fromSeconds > 0) return fromSeconds
        val fromUnit = config?.adUnitId?.toIntOrNull()
        if (fromUnit != null && fromUnit > 0) return fromUnit
        return 5
    }

    /**
     * Checks if user has unlimited access to Munshi Gemini AI:
     * - VIP user (Ad-Free / VIP subscription active) OR
     * - Active 24-Hour Feature Pass (earned via Rewarded Video)
     */
    fun hasMunshiUnlimitedPassAccess(): Boolean {
        if (_isAdFreeUser.value || _vipDaysRemaining.value > 0) return true
        if (isFeaturePassActive()) return true
        return false
    }

    private fun saveConfigsToLocal(context: Context, json: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CONFIG_JSON, json)
            .apply()
    }

    private fun savePricingToLocal(context: Context, json: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PRICING_JSON, json)
            .apply()
    }

    /**
     * Sync dynamic pricing & festival offer from Supabase table 'app_pricing_offers'.
     */
    suspend fun fetchPricingOffersFromSupabase(context: Context): Boolean = withContext(Dispatchers.IO) {
        if (!SupabaseAuthService.isConfigured(context)) return@withContext false
        val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
        val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)

        try {
            val endpoint = "$baseUrl/rest/v1/app_pricing_offers?select=*&limit=1"
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                useCaches = false
                defaultUseCaches = false
                setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate")
                setRequestProperty("Pragma", "no-cache")
                connectTimeout = 8000
                readTimeout = 8000
                SupabaseAuthService.applyAuthHeaders(this, anonKey)
            }

            if (conn.responseCode in 200..299) {
                val responseStr = conn.inputStream.bufferedReader().use { it.readText() }
                Log.d(TAG, "Supabase pricing offers raw response: $responseStr")
                val parsed = parsePricingJson(responseStr)
                if (parsed != null) {
                    _pricingOffer.value = parsed
                    savePricingToLocal(context, responseStr)
                    Log.d(TAG, "Successfully synced pricing and festival offers from Supabase: active=${parsed.isOfferActive}, monthly=₹${parsed.monthlyPrice}")
                }
                return@withContext true
            } else {
                Log.w(TAG, "Failed to fetch pricing offers (HTTP ${conn.responseCode}). Using defaults.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Pricing offers fetch error: ${e.message}")
        }
        return@withContext false
    }

    /**
     * Push pricing or offer updates to Supabase (from Admin Dashboard or app).
     */
    suspend fun updatePricingOfferInSupabase(
        context: Context,
        config: PricingOfferConfig
    ): Boolean = withContext(Dispatchers.IO) {
        _pricingOffer.value = config
        
        val json = JSONObject().apply {
            put("id", "default_pricing")
            put("monthly_price", config.monthlyPrice)
            put("monthly_original_price", config.monthlyOriginalPrice)
            put("yearly_price", config.yearlyPrice)
            put("yearly_original_price", config.yearlyOriginalPrice)
            put("is_offer_active", config.isOfferActive)
            put("show_home_banner", config.showHomeBanner)
            put("is_vip_enabled", config.isVipEnabled)
            put("offer_title", config.offerTitle)
            put("offer_subtitle", config.offerSubtitle)
            put("banner_badge_text", config.bannerBadgeText)
            put("banner_theme", config.bannerTheme)
            put("banner_image_url", config.bannerImageUrl)
            put("offer_start_time_ms", config.offerStartTimeMs)
            put("offer_end_time_ms", config.offerEndTimeMs)
            put("razorpay_key_id", config.razorpayKeyId)
        }
        savePricingToLocal(context, JSONArray().put(json).toString())

        if (SupabaseAuthService.isConfigured(context)) {
            try {
                val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
                val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)
                val endpoint = "$baseUrl/rest/v1/app_pricing_offers?on_conflict=id"

                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "resolution=merge-duplicates")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }

                OutputStreamWriter(conn.outputStream).use { it.write(json.toString()) }
                val code = conn.responseCode
                Log.d(TAG, "Push pricing offer to Supabase code: $code")
                return@withContext code in 200..299
            } catch (e: Exception) {
                Log.e(TAG, "Push pricing offer error: ${e.message}")
            }
        }
        return@withContext true
    }

    private fun parsePricingJson(jsonStr: String): PricingOfferConfig? {
        try {
            val arr = JSONArray(jsonStr)
            if (arr.length() == 0) return null
            val obj = arr.getJSONObject(0)
            
            // Robust boolean parser for is_offer_active (handles Boolean, String "false"/"true", Numbers 0/1)
            val activeRaw = obj.opt("is_offer_active")
            val isActive = when (activeRaw) {
                is Boolean -> activeRaw
                is String -> activeRaw.trim().equals("true", ignoreCase = true) || activeRaw.trim() == "1"
                is Number -> activeRaw.toInt() != 0
                else -> obj.optBoolean("is_offer_active", false)
            }

            // Separate toggle for home banner (defaults to isActive if column is absent)
            val bannerRaw = obj.opt("show_home_banner")
            val showHomeBanner = when (bannerRaw) {
                is Boolean -> bannerRaw
                is String -> bannerRaw.trim().equals("true", ignoreCase = true) || bannerRaw.trim() == "1"
                is Number -> bannerRaw.toInt() != 0
                else -> if (obj.has("show_home_banner")) false else isActive
            }

            val normalMonthly = when {
                obj.has("normal_monthly_price") -> obj.optDouble("normal_monthly_price", 99.0)
                obj.has("standard_monthly_price") -> obj.optDouble("standard_monthly_price", 99.0)
                else -> obj.optDouble("monthly_original_price", 99.0)
            }

            val normalYearly = when {
                obj.has("normal_yearly_price") -> obj.optDouble("normal_yearly_price", 499.0)
                obj.has("standard_yearly_price") -> obj.optDouble("standard_yearly_price", 499.0)
                else -> obj.optDouble("yearly_original_price", 499.0)
            }

            val offerMonthly = when {
                obj.has("offer_monthly_price") -> obj.optDouble("offer_monthly_price", 49.0)
                else -> obj.optDouble("monthly_price", 49.0)
            }

            val offerYearly = when {
                obj.has("offer_yearly_price") -> obj.optDouble("offer_yearly_price", 199.0)
                else -> obj.optDouble("yearly_price", 199.0)
            }

            // Master toggle for VIP Subscription from Supabase
            val vipRaw = obj.opt("is_vip_enabled")
            val isVipEnabled = when (vipRaw) {
                is Boolean -> vipRaw
                is String -> vipRaw.trim().equals("true", ignoreCase = true) || vipRaw.trim() == "1"
                is Number -> vipRaw.toInt() != 0
                else -> obj.optBoolean("is_vip_enabled", false)
            }

            return PricingOfferConfig(
                monthlyPrice = offerMonthly,
                monthlyOriginalPrice = normalMonthly,
                yearlyPrice = offerYearly,
                yearlyOriginalPrice = normalYearly,
                isOfferActive = isActive,
                showHomeBanner = showHomeBanner,
                isVipEnabled = isVipEnabled,
                offerTitle = obj.optString("offer_title", "त्योहार महा-धमाका ऑफर! 💥"),
                offerSubtitle = obj.optString("offer_subtitle", "सिर्फ सीमित समय के लिए 60% तक भारी छूट"),
                bannerBadgeText = obj.optString("banner_badge_text", "SALE"),
                bannerTheme = obj.optString("banner_theme", "RED_GOLD"),
                bannerImageUrl = when {
                    obj.has("banner_image_url") -> obj.optString("banner_image_url", "").trim()
                    obj.has("image_url") -> obj.optString("image_url", "").trim()
                    else -> ""
                },
                offerStartTimeMs = obj.optLong("offer_start_time_ms", 0L),
                offerEndTimeMs = obj.optLong("offer_end_time_ms", System.currentTimeMillis() + (72L * 60L * 60L * 1000L)),
                razorpayKeyId = obj.optString("razorpay_key_id", "rzp_test_TZA7CyoMjch6gO")
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing pricing json: ${e.message}")
            return null
        }
    }

    private fun parseConfigsJson(jsonStr: String): Map<String, AdSlotConfig> {
        val result = mutableMapOf<String, AdSlotConfig>()
        val arr = JSONArray(jsonStr)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val screen = obj.optString("screen_name", "").uppercase()
            if (screen.isNotBlank()) {
                val defaultUnitId = when (screen) {
                    "APP_OPEN" -> AppOpenAdManager.DEFAULT_TEST_APP_OPEN_ID
                    "REWARDED_FEATURE_UNLOCK" -> "ca-app-pub-3940256099942544/5224354917"
                    else -> AdSlotConfig.GOOGLE_TEST_BANNER_ID
                }
                val rawUnitId = obj.optString("ad_unit_id", defaultUnitId).trim()
                val isValidAdMobFormat = rawUnitId.matches(Regex("""^ca-app-pub-\d+/\d+$"""))
                val isPlaceholder = rawUnitId.contains("YOUR_AD_ID", ignoreCase = true) ||
                        rawUnitId.contains("PLACEHOLDER", ignoreCase = true) ||
                        rawUnitId.contains("XXX", ignoreCase = true)

                // If ad_unit_id is placeholder, invalid format, or mistakenly set to banner ID for an APP_OPEN slot, safeguard with defaultUnitId
                val finalUnitId = when {
                    rawUnitId.isBlank() || isPlaceholder || !isValidAdMobFormat -> defaultUnitId
                    screen == "APP_OPEN" && (rawUnitId == AdSlotConfig.GOOGLE_TEST_BANNER_ID || rawUnitId.contains("6300978111")) -> AppOpenAdManager.DEFAULT_TEST_APP_OPEN_ID
                    screen == "REWARDED_FEATURE_UNLOCK" && (rawUnitId == AdSlotConfig.GOOGLE_TEST_BANNER_ID || rawUnitId.contains("6300978111")) -> "ca-app-pub-3940256099942544/5224354917"
                    else -> rawUnitId
                }

                result[screen] = AdSlotConfig(
                    screenName = screen,
                    isEnabled = obj.optBoolean("is_enabled", true),
                    position = obj.optString("position", if (screen == "APP_OPEN" || screen == "REWARDED_FEATURE_UNLOCK") "FULLSCREEN" else "BOTTOM"),
                    adSize = obj.optString("ad_size", if (screen == "APP_OPEN") "APP_OPEN" else if (screen == "REWARDED_FEATURE_UNLOCK") "REWARDED" else "BANNER"),
                    adUnitId = finalUnitId,
                    requiredWatchSeconds = obj.optInt("required_seconds", obj.optInt("required_watch_seconds", 8))
                )
            }
        }
        return result
    }

    /**
     * Check Supabase `app_subscriptions` table for active subscription for the given phone number.
     * If found with is_premium=true and is_active=true, it unlocks VIP status for the user!
     * This allows admin to manually enable VIP from Supabase Dashboard if user paid but app had an issue.
     */
    suspend fun checkAndRestorePremiumFromSupabase(
        context: Context,
        rawPhone: String,
        isManualTrigger: Boolean = false,
        onResult: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        val cleanPhone = rawPhone.replace("+91", "").replace("[^0-9]".toRegex(), "").trim()
        if (cleanPhone.length < 6) {
            if (isManualTrigger) {
                onResult(false, "कृपया वैध फ़ोन नंबर दर्ज करें!")
            }
            return
        }

        withContext(Dispatchers.IO) {
            try {
                if (!SupabaseAuthService.isConfigured(context)) return@withContext
                val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
                val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)

                val encodedPhone = URLEncoder.encode("*$cleanPhone*", "UTF-8")
                
                // 1. First check profiles table for vip_member = true or positive vip_days_remaining
                try {
                    val profileUrl = URL("$baseUrl/rest/v1/profiles?phone=ilike.$encodedPhone&limit=1&select=id,name,phone,vip_member,is_premium,vip_days_remaining,vip_expiry,vip_plan")
                    val profConn = (profileUrl.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        SupabaseAuthService.applyAuthHeaders(this, anonKey)
                        connectTimeout = 6000
                        readTimeout = 6000
                    }
                    if (profConn.responseCode == 200) {
                        val pResp = profConn.inputStream.bufferedReader().use { it.readText() }
                        val pArr = JSONArray(pResp)
                        if (pArr.length() > 0) {
                            val prof = pArr.getJSONObject(0)
                            val isVip = prof.optBoolean("vip_member", false)
                            val daysFromDb = prof.optInt("vip_days_remaining", 0)
                            val expiryStr = prof.optString("vip_expiry", "")
                            val plan = prof.optString("vip_plan", "FREE").ifBlank { "FREE" }

                            var parsedExpiry = 0L
                            if (expiryStr.isNotBlank() && expiryStr != "null") {
                                try {
                                    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                                        timeZone = TimeZone.getTimeZone("UTC")
                                    }
                                    parsedExpiry = sdf.parse(expiryStr.replace("Z", "").substringBefore("."))?.time ?: 0L
                                } catch (_: Exception) {
                                    try { parsedExpiry = expiryStr.toLong() } catch (_: Exception) {}
                                }
                            }

                            val now = System.currentTimeMillis()
                            if (isVip && (parsedExpiry > now || daysFromDb > 0)) {
                                val finalDays = when {
                                    parsedExpiry > now -> Math.ceil((parsedExpiry - now) / (1000.0 * 60 * 60 * 24)).toInt().coerceAtLeast(1)
                                    daysFromDb > 0 -> daysFromDb
                                    else -> 0
                                }
                                if (finalDays > 0) {
                                    val finalExpiry = if (parsedExpiry > now) parsedExpiry else (now + finalDays.toLong() * 24L * 60L * 60L * 1000L)

                                    _isAdFreeUser.value = true
                                    _planType.value = plan
                                    _vipExpiryTimestamp.value = finalExpiry
                                    _vipDaysRemaining.value = finalDays

                                    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                                        .putBoolean(KEY_IS_PREMIUM_USER, true)
                                        .putString(KEY_PLAN_TYPE, plan)
                                        .putLong(KEY_VIP_EXPIRY, finalExpiry)
                                        .putInt(KEY_VIP_DAYS_REMAINING, finalDays)
                                        .apply()

                                    // Sync the recalculated days back to Supabase so it's always up to date
                                    syncVipDaysToSupabase(context, cleanPhone, finalExpiry, finalDays, plan)

                                    withContext(Dispatchers.Main) {
                                        onResult(true, "बधाई हो! आपकी VIP सदस्यता सक्रिय है! (शेष दिन: $finalDays दिन) 🎉")
                                    }
                                    return@withContext
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Profile VIP check fallback: ${e.message}")
                }

                // 2. Also check app_subscriptions table if exists
                val urlString = "$baseUrl/rest/v1/app_subscriptions?phone=ilike.$encodedPhone&is_premium=eq.true&is_active=eq.true&order=created_at.desc&limit=1&select=id,phone,plan_type,is_premium,is_active,expires_at,total_days_remaining,days_added"
                val url = URL(urlString)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                    connectTimeout = 7000
                    readTimeout = 7000
                }

                if (conn.responseCode == 200) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val jsonArr = JSONArray(resp)
                    if (jsonArr.length() > 0) {
                        val record = jsonArr.getJSONObject(0)
                        val isPrem = record.optBoolean("is_premium", false)
                        val isAct = record.optBoolean("is_active", false)

                        if (isPrem && isAct) {
                            val planType = record.optString("plan_type", "MONTHLY")
                            val expiryStr = record.optString("expires_at", "")
                            val totalDays = record.optInt("total_days_remaining", 0)

                            var parsedExpiry = 0L
                            if (expiryStr.isNotBlank() && expiryStr != "null") {
                                try {
                                    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                                        timeZone = TimeZone.getTimeZone("UTC")
                                    }
                                    parsedExpiry = sdf.parse(expiryStr.replace("Z", "").substringBefore("."))?.time ?: 0L
                                } catch (_: Exception) {
                                    try { parsedExpiry = expiryStr.toLong() } catch (_: Exception) {}
                                }
                            }

                            val now = System.currentTimeMillis()
                            if (parsedExpiry > now || totalDays > 0) {
                                val finalDays = when {
                                    parsedExpiry > now -> Math.ceil((parsedExpiry - now) / (1000.0 * 60 * 60 * 24)).toInt().coerceAtLeast(1)
                                    totalDays > 0 -> totalDays
                                    else -> 0
                                }
                                if (finalDays > 0) {
                                    val finalExpiry = if (parsedExpiry > now) parsedExpiry else (now + finalDays.toLong() * 24L * 60L * 60L * 1000L)

                                    _isAdFreeUser.value = true
                                    _planType.value = planType
                                    _vipExpiryTimestamp.value = finalExpiry
                                    _vipDaysRemaining.value = finalDays

                                    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                                        .putBoolean(KEY_IS_PREMIUM_USER, true)
                                        .putString(KEY_PLAN_TYPE, planType)
                                        .putLong(KEY_VIP_EXPIRY, finalExpiry)
                                        .putInt(KEY_VIP_DAYS_REMAINING, finalDays)
                                        .apply()

                                    syncVipDaysToSupabase(context, cleanPhone, finalExpiry, finalDays, planType)

                                    withContext(Dispatchers.Main) {
                                        onResult(true, "बधाई हो! आपकी $planType VIP सदस्यता सफलतापूर्वक एक्टिवेट हो गई है! (शेष दिन: $finalDays दिन) 🎉")
                                    }
                                    return@withContext
                                }
                            }
                        }
                    }
                }

                // If no active VIP found in profiles or subscriptions, reset local state to FREE
                resetVipState(context)

                withContext(Dispatchers.Main) {
                    if (isManualTrigger) {
                        onResult(false, "इस नंबर के लिए कोई एक्टिव VIP सदस्यता नहीं मिली। यदि पैसे कट गए हैं तो एडमिन से संपर्क करें।")
                    } else {
                        onResult(false, "")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "checkAndRestorePremium error: ${e.message}")
                withContext(Dispatchers.Main) {
                    if (isManualTrigger) {
                        onResult(false, "नेटवर्क त्रुटि: कृपया इंटरनेट कनेक्शन जांचें।")
                    }
                }
            }
        }
    }
}
