package com.example.data.payment

import android.app.Activity
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.supabase.SupabaseAuthService
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Result of a Razorpay Payment.
 */
sealed class PaymentEvent {
    data class Success(val paymentId: String, val planType: String, val amount: Double) : PaymentEvent()
    data class Error(val code: Int, val message: String) : PaymentEvent()
}

/**
 * Razorpay Payment Manager.
 * Handles checkout initialization, preloading, and status synchronization with Supabase.
 */
object RazorpayManager : PaymentResultListener {
    private const val TAG = "RazorpayManager"
    
    // Default Razorpay Test Key ID (Used as safe fallback if Supabase key is blank)
    // Replace anytime in Supabase 'app_pricing_offers' or via Admin Dashboard!
    const val DEFAULT_FALLBACK_KEY_ID = "rzp_test_TZA7CyoMjch6gO"

    private val _paymentEvents = MutableSharedFlow<PaymentEvent>(replay = 0)
    val paymentEvents = _paymentEvents.asSharedFlow()

    private var pendingPlanType: String = "MONTHLY"
    private var pendingAmount: Double = 49.0
    private var lastUserPhone: String = ""
    private var activeAppContext: Context? = null

    /**
     * Preload Razorpay checkout for instant popup without network lag.
     */
    fun preload(context: Context) {
        try {
            Checkout.preload(context.applicationContext)
        } catch (e: Exception) {
            Log.w(TAG, "Checkout preload error: ${e.message}")
        }
    }

    /**
     * Start Razorpay checkout flow.
     * @param activity Hosting ComponentActivity
     * @param planType "MONTHLY" or "YEARLY"
     * @param amountRupees Amount in INR (e.g. 49.0 or 199.0)
     * @param userPhone Optional customer phone
     * @param userEmail Optional customer email
     */
    fun startPayment(
        activity: Activity,
        planType: String,
        amountRupees: Double,
        userPhone: String = "9876543210",
        userEmail: String = "kisan@example.com"
    ) {
        pendingPlanType = planType
        pendingAmount = amountRupees
        lastUserPhone = userPhone
        activeAppContext = activity.applicationContext

        val pricing = RemoteConfigService.pricingOffer.value
        val razorpayKey = pricing.razorpayKeyId.ifBlank { DEFAULT_FALLBACK_KEY_ID }

        val checkout = Checkout()
        checkout.setKeyID(razorpayKey)

        try {
            val options = JSONObject().apply {
                put("name", "किसान ट्यूबवेल व डिजिटल बहीखाता")
                put("description", if (planType == "YEARLY") "VIP वार्षिक सदस्यता (1 साल Ad-Free)" else "VIP मासिक सदस्यता (30 दिन Ad-Free)")
                put("currency", "INR")
                // Amount in Paise (INR * 100)
                val amountInPaise = (amountRupees * 100).toLong()
                put("amount", amountInPaise)
                
                // Color Theme matching Kisan Green
                put("theme.color", "#1B5E20")

                // Prefill user details
                val prefill = JSONObject().apply {
                    put("contact", userPhone)
                    put("email", userEmail)
                }
                put("prefill", prefill)

                // Retry configuration
                val retryObj = JSONObject().apply {
                    put("enabled", true)
                    put("max_count", 2)
                }
                put("retry", retryObj)

                // Additional metadata
                val notes = JSONObject().apply {
                    put("phone", userPhone)
                    put("plan_type", planType)
                    put("app_name", "Kisan Tubewell Digital Bahi Khata")
                }
                put("notes", notes)
            }

            checkout.open(activity, options)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting Razorpay checkout: ${e.message}", e)
            Toast.makeText(activity, "पेमेंट शुरू करने में त्रुटि: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String?) {
        val paymentId = razorpayPaymentID ?: "PAY_SUCCESS_${System.currentTimeMillis()}"
        Log.d(TAG, "Razorpay payment SUCCESS: $paymentId for plan: $pendingPlanType")
        
        val context = activeAppContext
        if (context != null) {
            val daysToAdd = if (pendingPlanType.contains("YEAR", ignoreCase = true)) 365 else 30
            // Cumulative addition: extends existing days if active
            val newTotalDays = RemoteConfigService.addVipSubscription(
                context = context,
                planType = pendingPlanType,
                daysToAdd = daysToAdd,
                phone = lastUserPhone
            )
            val expiryTimestamp = RemoteConfigService.vipExpiryTimestamp.value

            // 2. Persist subscription record to Supabase profiles & app_subscriptions
            val phoneToSync = lastUserPhone
            CoroutineScope(Dispatchers.IO).launch {
                syncSubscriptionToSupabase(
                    context = context,
                    paymentId = paymentId,
                    planType = pendingPlanType,
                    amount = pendingAmount,
                    phone = phoneToSync,
                    daysAdded = daysToAdd,
                    totalDaysRemaining = newTotalDays,
                    expiryTimestamp = expiryTimestamp
                )
            }
        }

        CoroutineScope(Dispatchers.Main).launch {
            _paymentEvents.emit(PaymentEvent.Success(paymentId, pendingPlanType, pendingAmount))
        }
    }

    override fun onPaymentError(errorCode: Int, responseDescription: String?) {
        val desc = responseDescription ?: "पेमेंट रद्द किया गया या नेटवर्क समस्या"
        Log.w(TAG, "Razorpay payment ERROR: $errorCode - $desc")

        CoroutineScope(Dispatchers.Main).launch {
            _paymentEvents.emit(PaymentEvent.Error(errorCode, desc))
        }
    }

    /**
     * Uploads the payment record to Supabase profiles & app_subscriptions / user_subscriptions.
     */
    private suspend fun syncSubscriptionToSupabase(
        context: Context,
        paymentId: String,
        planType: String,
        amount: Double,
        phone: String,
        daysAdded: Int,
        totalDaysRemaining: Int,
        expiryTimestamp: Long
    ) {
        if (!SupabaseAuthService.isConfigured(context)) return
        val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
        val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)

        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val isoExpiry = sdf.format(Date(expiryTimestamp))

        // 1. Update profiles table: set is_premium, vip_member, vip_days_remaining, vip_expiry, vip_plan
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").trim()
        if (cleanPhone.length >= 6) {
            try {
                val encodedPhone = java.net.URLEncoder.encode("*$cleanPhone*", "UTF-8")
                val profileEndpoint = "$baseUrl/rest/v1/profiles?phone=ilike.$encodedPhone"
                val profileConn = (URL(profileEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "PATCH"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }
                val profileBody = JSONObject().apply {
                    put("vip_member", true)
                    put("is_premium", true)
                    put("vip_plan", planType)
                    put("vip_days_remaining", totalDaysRemaining)
                    put("vip_expiry", isoExpiry)
                    put("updated_at", System.currentTimeMillis())
                }
                OutputStreamWriter(profileConn.outputStream).use { it.write(profileBody.toString()) }
                val pCode = profileConn.responseCode
                Log.d(TAG, "Supabase profiles VIP days updated with code: $pCode, days: $totalDaysRemaining, for $phone")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to update profiles VIP columns: ${e.message}")
            }
        }

        // 2. Insert into app_subscriptions / user_subscriptions table
        val targetTables = listOf("app_subscriptions", "user_subscriptions")
        for (tbl in targetTables) {
            try {
                val endpoint = "$baseUrl/rest/v1/$tbl"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }

                val body = JSONObject().apply {
                    put("payment_id", paymentId)
                    put("phone", phone)
                    put("plan_type", planType)
                    put("amount", amount)
                    put("days_added", daysAdded)
                    put("total_days_remaining", totalDaysRemaining)
                    put("expires_at", isoExpiry)
                    put("is_premium", true)
                    put("is_active", true)
                    put("payment_status", "SUCCESS")
                    put("platform", "ANDROID_RAZORPAY")
                }

                OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
                val code = conn.responseCode
                Log.d(TAG, "Supabase $tbl sync response code: $code")
                if (code in 200..299) break // First available table succeeded
            } catch (e: Exception) {
                Log.w(TAG, "Failed to insert into $tbl: ${e.message}")
            }
        }
    }
}
