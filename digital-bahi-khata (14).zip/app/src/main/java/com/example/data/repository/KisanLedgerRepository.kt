package com.example.data.repository

import com.example.data.model.ActiveTimerState
import com.example.data.model.Customer
import com.example.data.model.PaymentTransaction
import com.example.data.model.PumpSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class KisanLedgerRepository {

    private val _customers = MutableStateFlow<List<Customer>>(getInitialCustomers())
    val customers: StateFlow<List<Customer>> = _customers.asStateFlow()

    private val _sessions = MutableStateFlow<List<PumpSession>>(getInitialSessions())
    val sessions: StateFlow<List<PumpSession>> = _sessions.asStateFlow()

    private val _transactions = MutableStateFlow<List<PaymentTransaction>>(getInitialTransactions())
    val transactions: StateFlow<List<PaymentTransaction>> = _transactions.asStateFlow()

    private val _timerState = MutableStateFlow(ActiveTimerState())
    val timerState: StateFlow<ActiveTimerState> = _timerState.asStateFlow()

    private val _isHindi = MutableStateFlow(true)
    val isHindi: StateFlow<Boolean> = _isHindi.asStateFlow()

    fun toggleLanguage() {
        _isHindi.value = !_isHindi.value
    }

    fun addCustomer(name: String, phone: String, village: String, rate: Double, initialDue: Double = 0.0) {
        val newCustomer = Customer(
            id = UUID.randomUUID().toString(),
            name = name,
            phone = phone,
            village = village,
            defaultHourlyRate = rate,
            totalHoursIrrigated = 0.0,
            totalBilled = initialDue,
            totalPaid = 0.0,
            balanceDue = initialDue
        )
        _customers.value = listOf(newCustomer) + _customers.value
    }

    fun addSession(
        customerId: String,
        durationHours: Double,
        rate: Double,
        notes: String = ""
    ) {
        val customer = _customers.value.find { it.id == customerId } ?: return
        val totalAmount = durationHours * rate
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        val newSession = PumpSession(
            customerId = customer.id,
            customerName = customer.name,
            dateText = dateFormat.format(now),
            startTime = timeFormat.format(Date(now.time - (durationHours * 3600 * 1000).toLong())),
            endTime = timeFormat.format(now),
            durationHours = durationHours,
            hourlyRate = rate,
            totalAmount = totalAmount,
            isPaid = false,
            notes = notes
        )

        _sessions.value = listOf(newSession) + _sessions.value

        // Update customer balance & totals
        _customers.value = _customers.value.map {
            if (it.id == customerId) {
                val updatedHours = it.totalHoursIrrigated + durationHours
                val updatedBilled = it.totalBilled + totalAmount
                val updatedDue = updatedBilled - it.totalPaid
                it.copy(
                    totalHoursIrrigated = updatedHours,
                    totalBilled = updatedBilled,
                    balanceDue = updatedDue
                )
            } else it
        }
    }

    fun recordPayment(
        customerId: String,
        amount: Double,
        paymentMode: String,
        notes: String = ""
    ) {
        val customer = _customers.value.find { it.id == customerId } ?: return
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val now = Date()

        val transaction = PaymentTransaction(
            customerId = customer.id,
            customerName = customer.name,
            dateText = dateFormat.format(now),
            amount = amount,
            paymentMode = paymentMode,
            notes = notes
        )

        _transactions.value = listOf(transaction) + _transactions.value

        _customers.value = _customers.value.map {
            if (it.id == customerId) {
                val updatedPaid = it.totalPaid + amount
                val updatedDue = it.totalBilled - updatedPaid
                it.copy(
                    totalPaid = updatedPaid,
                    balanceDue = updatedDue
                )
            } else it
        }
    }

    fun startTimer(customerId: String, rate: Double) {
        val customer = _customers.value.find { it.id == customerId } ?: return
        _timerState.value = ActiveTimerState(
            isRunning = true,
            customerId = customer.id,
            customerName = customer.name,
            hourlyRate = rate,
            startTimeMillis = System.currentTimeMillis(),
            elapsedSeconds = 0L
        )
    }

    fun updateTimerTick() {
        val current = _timerState.value
        if (current.isRunning) {
            val seconds = (System.currentTimeMillis() - current.startTimeMillis) / 1000
            _timerState.value = current.copy(elapsedSeconds = seconds)
        }
    }

    fun stopTimer(): PumpSession? {
        val current = _timerState.value
        if (!current.isRunning) return null

        val elapsedSec = (System.currentTimeMillis() - current.startTimeMillis) / 1000
        val durationHours = maxOf(0.1, (elapsedSec / 3600.0 * 10).toInt() / 10.0) // min 0.1 hour
        val rate = current.hourlyRate
        val totalAmount = durationHours * rate

        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()
        val start = Date(current.startTimeMillis)

        val newSession = PumpSession(
            customerId = current.customerId,
            customerName = current.customerName,
            dateText = dateFormat.format(now),
            startTime = timeFormat.format(start),
            endTime = timeFormat.format(now),
            durationHours = durationHours,
            hourlyRate = rate,
            totalAmount = totalAmount,
            isPaid = false,
            notes = "लाइव टाइमर सेशन (${elapsedSec / 60} मिनट)"
        )

        _sessions.value = listOf(newSession) + _sessions.value

        _customers.value = _customers.value.map {
            if (it.id == current.customerId) {
                val updatedHours = it.totalHoursIrrigated + durationHours
                val updatedBilled = it.totalBilled + totalAmount
                val updatedDue = updatedBilled - it.totalPaid
                it.copy(
                    totalHoursIrrigated = updatedHours,
                    totalBilled = updatedBilled,
                    balanceDue = updatedDue
                )
            } else it
        }

        _timerState.value = ActiveTimerState(isRunning = false)
        return newSession
    }

    private fun getInitialCustomers(): List<Customer> {
        return listOf(
            Customer(
                id = "c1",
                name = "रामेश्वर पटेल",
                phone = "9826112345",
                village = "रामपुर",
                defaultHourlyRate = 160.0,
                totalHoursIrrigated = 24.5,
                totalBilled = 3920.0,
                totalPaid = 2000.0,
                balanceDue = 1920.0
            ),
            Customer(
                id = "c2",
                name = "सुरेश कुमार शर्मा",
                phone = "9414223456",
                village = "हरिपुरा",
                defaultHourlyRate = 150.0,
                totalHoursIrrigated = 18.0,
                totalBilled = 2700.0,
                totalPaid = 2700.0,
                balanceDue = 0.0
            ),
            Customer(
                id = "c3",
                name = "महेंद्र यादव",
                phone = "9876543210",
                village = "गोकुलपुर",
                defaultHourlyRate = 180.0,
                totalHoursIrrigated = 32.0,
                totalBilled = 5760.0,
                totalPaid = 3000.0,
                balanceDue = 2760.0
            ),
            Customer(
                id = "c4",
                name = "राजपाल चौधरी",
                phone = "9123456780",
                village = "किशनगढ़",
                defaultHourlyRate = 150.0,
                totalHoursIrrigated = 12.0,
                totalBilled = 1800.0,
                totalPaid = 1000.0,
                balanceDue = 800.0
            )
        )
    }

    private fun getInitialSessions(): List<PumpSession> {
        return listOf(
            PumpSession(
                id = "s1",
                customerId = "c3",
                customerName = "महेंद्र यादव",
                dateText = "28 Sep 2026",
                startTime = "06:00 AM",
                endTime = "10:30 AM",
                durationHours = 4.5,
                hourlyRate = 180.0,
                totalAmount = 810.0,
                isPaid = false,
                notes = "गेहूँ की पहली सिंचाई (पूर्वी खेत)"
            ),
            PumpSession(
                id = "s2",
                customerId = "c1",
                customerName = "रामेश्वर पटेल",
                dateText = "27 Sep 2026",
                startTime = "02:00 PM",
                endTime = "06:00 PM",
                durationHours = 4.0,
                hourlyRate = 160.0,
                totalAmount = 640.0,
                isPaid = false,
                notes = "सरसों की बुवाई सिंचाई"
            ),
            PumpSession(
                id = "s3",
                customerId = "c2",
                customerName = "सुरेश कुमार शर्मा",
                dateText = "26 Sep 2026",
                startTime = "07:00 AM",
                endTime = "11:00 AM",
                durationHours = 4.0,
                hourlyRate = 150.0,
                totalAmount = 600.0,
                isPaid = true,
                notes = "सब्जी बाड़ी फव्वारा सिंचाई"
            ),
            PumpSession(
                id = "s4",
                customerId = "c4",
                customerName = "राजपाल चौधरी",
                dateText = "25 Sep 2026",
                startTime = "03:30 PM",
                endTime = "07:30 PM",
                durationHours = 4.0,
                hourlyRate = 150.0,
                totalAmount = 600.0,
                isPaid = true,
                notes = "चना खेत"
            )
        )
    }

    private fun getInitialTransactions(): List<PaymentTransaction> {
        return listOf(
            PaymentTransaction(
                id = "t1",
                customerId = "c2",
                customerName = "सुरेश कुमार शर्मा",
                dateText = "26 Sep 2026",
                amount = 600.0,
                paymentMode = "UPI PhonePe",
                notes = "सिंचाई पूर्ण भुगतान"
            ),
            PaymentTransaction(
                id = "t2",
                customerId = "c1",
                customerName = "रामेश्वर पटेल",
                dateText = "24 Sep 2026",
                amount = 2000.0,
                paymentMode = "Cash",
                notes = "अग्रिम रोकड़ जमा"
            ),
            PaymentTransaction(
                id = "t3",
                customerId = "c3",
                customerName = "महेंद्र यादव",
                dateText = "22 Sep 2026",
                amount = 3000.0,
                paymentMode = "Cash",
                notes = "खाता जमा"
            )
        )
    }
}
