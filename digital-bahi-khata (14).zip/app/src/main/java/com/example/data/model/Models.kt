package com.example.data.model

import java.util.UUID

data class Customer(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String,
    val village: String,
    val defaultHourlyRate: Double = 150.0,
    val totalHoursIrrigated: Double = 0.0,
    val totalBilled: Double = 0.0,
    val totalPaid: Double = 0.0,
    val balanceDue: Double = 0.0
)

data class PumpSession(
    val id: String = UUID.randomUUID().toString(),
    val customerId: String,
    val customerName: String,
    val dateText: String, // e.g., "28 Sep 2026"
    val startTime: String, // e.g., "06:30 AM"
    val endTime: String, // e.g., "09:30 AM"
    val durationHours: Double, // e.g., 3.0
    val hourlyRate: Double, // e.g., 150.0
    val totalAmount: Double, // e.g., 450.0
    val isPaid: Boolean = false,
    val notes: String = ""
)

data class PaymentTransaction(
    val id: String = UUID.randomUUID().toString(),
    val customerId: String,
    val customerName: String,
    val dateText: String,
    val amount: Double,
    val paymentMode: String = "Cash", // Cash, UPI, Bank
    val notes: String = ""
)

data class ActiveTimerState(
    val isRunning: Boolean = false,
    val customerId: String = "",
    val customerName: String = "",
    val hourlyRate: Double = 150.0,
    val startTimeMillis: Long = 0L,
    val elapsedSeconds: Long = 0L
)
