package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.ui.components.openDialer
import com.example.ui.components.shareText
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterBlue
import com.example.ui.viewmodel.KisanLedgerViewModel

@Composable
fun CustomersScreen(
    viewModel: KisanLedgerViewModel,
    modifier: Modifier = Modifier
) {
    val customers by viewModel.customers.collectAsState()
    val isHindi by viewModel.isHindi.collectAsState()
    val selectedCustomerId by viewModel.selectedCustomerId.collectAsState()

    if (selectedCustomerId != null) {
        CustomerDetailScreen(
            customerId = selectedCustomerId!!,
            viewModel = viewModel,
            onBack = { viewModel.selectCustomer(null) },
            modifier = modifier
        )
        return
    }

    var searchQuery by remember { mutableStateOf("") }
    var filterOnlyDue by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val filteredList = customers.filter { cust ->
        val matchesQuery = cust.name.contains(searchQuery, ignoreCase = true) ||
                cust.village.contains(searchQuery, ignoreCase = true) ||
                cust.phone.contains(searchQuery)
        val matchesDue = !filterOnlyDue || cust.balanceDue > 0
        matchesQuery && matchesDue
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_farmer_input"),
                placeholder = { Text(if (isHindi) "किसान का नाम, गाँव या मोबाइल खोजें..." else "Search by name, village, phone...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextSecondary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !filterOnlyDue,
                    onClick = { filterOnlyDue = false },
                    label = { Text(if (isHindi) "सभी किसान (${customers.size})" else "All (${customers.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldContainer,
                        selectedLabelColor = EmeraldDark
                    )
                )
                val dueCount = customers.count { it.balanceDue > 0 }
                FilterChip(
                    selected = filterOnlyDue,
                    onClick = { filterOnlyDue = true },
                    label = { Text(if (isHindi) "केवल बकायादार ($dueCount)" else "With Due ($dueCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AlertRedLight,
                        selectedLabelColor = AlertRed
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isHindi) "कोई किसान नहीं मिला" else "No farmers found",
                        color = TextSecondary
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredList) { customer ->
                        CustomerCardItem(
                            customer = customer,
                            isHindi = isHindi,
                            onCardClick = { viewModel.selectCustomer(customer.id) },
                            onCallClick = { openDialer(context, customer.phone) },
                            onShareReminder = {
                                val msg = """
                                    नमस्ते ${customer.name} जी,
                                    आपके ट्यूबवेल सिंचाई सेवा का कुल बकाया हिसाब ₹${customer.balanceDue.toInt()} है।
                                    कृपया सुविधानुसार भुगतान जमा करें।
                                    - धन्यवाद (किसान बही खाता)
                                """.trimIndent()
                                shareText(context, msg)
                            }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { viewModel.showAddCustomerDialog.value = true },
            containerColor = EmeraldPrimary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_farmer_fab")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Farmer")
        }
    }
}

@Composable
fun CustomerCardItem(
    customer: Customer,
    isHindi: Boolean,
    onCardClick: () -> Unit,
    onCallClick: () -> Unit,
    onShareReminder: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("customer_card_${customer.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(EmeraldContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "${customer.village} • ${customer.phone}",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                // Balance due pill
                Surface(
                    color = if (customer.balanceDue > 0) AlertRedLight else EmeraldContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (customer.balanceDue > 0) (if (isHindi) "बकाया" else "Due") else (if (isHindi) "पूर्ण जमा" else "Settled"),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (customer.balanceDue > 0) AlertRed else EmeraldDark
                        )
                        Text(
                            text = "₹${customer.balanceDue.toInt()}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (customer.balanceDue > 0) AlertRed else EmeraldDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details and Quick Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "कुल सिंचाई: ${customer.totalHoursIrrigated} घंटे (₹${customer.defaultHourlyRate.toInt()}/घंटा)",
                    fontSize = 12.sp,
                    color = TextMuted
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (customer.phone.isNotBlank()) {
                        IconButton(
                            onClick = onCallClick,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Call",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    if (customer.balanceDue > 0) {
                        IconButton(
                            onClick = onShareReminder,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "WhatsApp reminder",
                                tint = WaterBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
