package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveTimerState
import com.example.data.model.Customer
import com.example.data.model.PumpSession
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AlertRedLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaterBlue
import com.example.ui.theme.WaterBlueLight

@Composable
fun AppHeader(
    isHindi: Boolean,
    activePumpRunning: Boolean,
    onToggleLanguage: () -> Unit
) {
    Surface(
        color = EmeraldDark,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = "Tubewell Icon",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (isHindi) "किसान बही खाता" else "Kisan Ledger",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (isHindi) "ट्यूबवेल सिंचाई सेवा" else "Tubewell Irrigation Service",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (activePumpRunning) {
                    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                    val scale by infiniteTransition.animateFloat(
                        initialValue = 0.85f,
                        targetValue = 1.15f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(600),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "scale"
                    )
                    Box(
                        modifier = Modifier
                            .scale(scale)
                            .clip(RoundedCornerShape(12.dp))
                            .background(WaterBlue)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isHindi) "पंप चालू 💧" else "PUMP ON 💧",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                // Language toggle button
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.25f),
                    modifier = Modifier.clickable { onToggleLanguage() }
                ) {
                    Text(
                        text = if (isHindi) "हिन्दी | EN" else "EN | हिन्दी",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LivePumpTimerCard(
    timerState: ActiveTimerState,
    customers: List<Customer>,
    isHindi: Boolean,
    onStartTimer: (customerId: String, rate: Double) -> Unit,
    onStopTimer: () -> Unit
) {
    var expandedCustomerSelect by remember { mutableStateOf(false) }
    var selectedCustomer by remember { mutableStateOf<Customer?>(customers.firstOrNull()) }
    var hourlyRateText by remember { mutableStateOf("150") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("live_pump_timer_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (timerState.isRunning) WaterBlueLight else EmeraldContainer
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (timerState.isRunning) Icons.Default.WaterDrop else Icons.Default.HourglassTop,
                        contentDescription = "Timer Status",
                        tint = if (timerState.isRunning) WaterBlue else EmeraldDark,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (timerState.isRunning) {
                            if (isHindi) "लाइव सिंचाई पंप चालू है" else "Live Pump Running"
                        } else {
                            if (isHindi) "लाइव सिंचाई टाइमर शुरू करें" else "Start Live Pump Timer"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = if (timerState.isRunning) WaterBlue else EmeraldDark
                    )
                }

                if (timerState.isRunning) {
                    val sec = timerState.elapsedSeconds
                    val hrs = sec / 3600
                    val mins = (sec % 3600) / 60
                    val s = sec % 60
                    val timeStr = String.format("%02d:%02d:%02d", hrs, mins, s)
                    Text(
                        text = timeStr,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = WaterBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (timerState.isRunning) {
                // Running info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isHindi) "किसान:" else "Farmer:",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = timerState.customerName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isHindi) "दर / अनुमानित बिल:" else "Rate / Est. Bill:",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        val elapsedHours = timerState.elapsedSeconds / 3600.0
                        val estAmount = (elapsedHours * timerState.hourlyRate).toInt()
                        Text(
                            text = "₹${timerState.hourlyRate.toInt()}/घंटा  |  ₹$estAmount",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onStopTimer,
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stop_pump_button")
                ) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHindi) "पंप बंद करें एवं रसीद बनाएं" else "Stop Pump & Generate Bill",
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                // Config inputs to start pump
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ExposedDropdownMenuBox(
                        expanded = expandedCustomerSelect,
                        onExpandedChange = { expandedCustomerSelect = !expandedCustomerSelect },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = selectedCustomer?.name ?: (if (isHindi) "किसान चुनें" else "Select Farmer"),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (isHindi) "किसान चुनें" else "Farmer") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCustomerSelect) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            singleLine = true
                        )
                        ExposedDropdownMenu(
                            expanded = expandedCustomerSelect,
                            onDismissRequest = { expandedCustomerSelect = false }
                        ) {
                            customers.forEach { cust ->
                                DropdownMenuItem(
                                    text = { Text("${cust.name} (${cust.village})") },
                                    onClick = {
                                        selectedCustomer = cust
                                        hourlyRateText = cust.defaultHourlyRate.toInt().toString()
                                        expandedCustomerSelect = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = hourlyRateText,
                        onValueChange = { hourlyRateText = it },
                        label = { Text(if (isHindi) "दर ₹/घंटा" else "Rate/hr") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(95.dp),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        val cust = selectedCustomer ?: customers.firstOrNull()
                        val rate = hourlyRateText.toDoubleOrNull() ?: 150.0
                        if (cust != null) {
                            onStartTimer(cust.id, rate)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("start_pump_button")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Start")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHindi) "सिंचाई टाइमर शुरू करें" else "Start Irrigation Timer",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// Dialog to Add a New Farmer / Customer
@Composable
fun AddCustomerDialog(
    isHindi: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String, village: String, rate: Double, initialDue: Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var village by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("150") }
    var initialDue by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isHindi) "नया किसान / ग्राहक जोड़ें" else "Add New Farmer",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isHindi) "किसान का नाम *" else "Farmer Name *") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_name_input"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(if (isHindi) "मोबाइल नंबर" else "Mobile Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_phone_input"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = village,
                    onValueChange = { village = it },
                    label = { Text(if (isHindi) "गाँव / पता" else "Village / Address") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = rate,
                        onValueChange = { rate = it },
                        label = { Text(if (isHindi) "दर ₹/घंटा" else "Rate ₹/hr") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = initialDue,
                        onValueChange = { initialDue = it },
                        label = { Text(if (isHindi) "पुराना बकाया ₹" else "Initial Due ₹") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val hourlyRate = rate.toDoubleOrNull() ?: 150.0
                        val due = initialDue.toDoubleOrNull() ?: 0.0
                        onConfirm(name.trim(), phone.trim(), village.trim(), hourlyRate, due)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("save_customer_button")
            ) {
                Text(if (isHindi) "सहेजें (Save)" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isHindi) "रद्द करें" else "Cancel")
            }
        }
    )
}

// Dialog to Add Manual Irrigation Session
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSessionDialog(
    customers: List<Customer>,
    isHindi: Boolean,
    preSelectedCustomerId: String? = null,
    onDismiss: () -> Unit,
    onConfirm: (customerId: String, duration: Double, rate: Double, notes: String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedCust by remember {
        mutableStateOf(customers.find { it.id == preSelectedCustomerId } ?: customers.firstOrNull())
    }
    var hoursText by remember { mutableStateOf("3.0") }
    var rateText by remember { mutableStateOf(selectedCust?.defaultHourlyRate?.toInt()?.toString() ?: "150") }
    var notesText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isHindi) "सिंचाई एंट्री जोड़ें" else "Add Irrigation Session",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedCust?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isHindi) "किसान चुनें" else "Select Farmer") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        customers.forEach { c ->
                            DropdownMenuItem(
                                text = { Text("${c.name} (${c.village})") },
                                onClick = {
                                    selectedCust = c
                                    rateText = c.defaultHourlyRate.toInt().toString()
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = hoursText,
                        onValueChange = { hoursText = it },
                        label = { Text(if (isHindi) "घंटे (Hours)" else "Hours") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = rateText,
                        onValueChange = { rateText = it },
                        label = { Text(if (isHindi) "दर ₹/घंटा" else "Rate ₹/hr") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                val hrs = hoursText.toDoubleOrNull() ?: 0.0
                val r = rateText.toDoubleOrNull() ?: 0.0
                val total = (hrs * r).toInt()

                Surface(
                    color = EmeraldContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isHindi) "कुल देय राशि: ₹$total" else "Total Amount: ₹$total",
                        color = EmeraldDark,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text(if (isHindi) "विवरण (खेत/फसल)" else "Notes (Field/Crop)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cust = selectedCust
                    val h = hoursText.toDoubleOrNull() ?: 0.0
                    val r = rateText.toDoubleOrNull() ?: 150.0
                    if (cust != null && h > 0) {
                        onConfirm(cust.id, h, r, notesText.trim())
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isHindi) "एंट्री जोड़ें" else "Save Session")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isHindi) "रद्द करें" else "Cancel")
            }
        }
    )
}

// Dialog to Record Payment (जमा)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordPaymentDialog(
    customers: List<Customer>,
    isHindi: Boolean,
    preSelectedCustomerId: String? = null,
    onDismiss: () -> Unit,
    onConfirm: (customerId: String, amount: Double, mode: String, notes: String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedCust by remember {
        mutableStateOf(customers.find { it.id == preSelectedCustomerId } ?: customers.firstOrNull())
    }
    var amountText by remember { mutableStateOf(selectedCust?.balanceDue?.toInt()?.toString() ?: "500") }
    var paymentMode by remember { mutableStateOf("Cash") }
    var notesText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isHindi) "भुगतान प्राप्त (जमा करें)" else "Record Payment Received",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedCust?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isHindi) "किसान चुनें" else "Select Farmer") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        customers.forEach { c ->
                            DropdownMenuItem(
                                text = { Text("${c.name} (बकाया: ₹${c.balanceDue.toInt()})") },
                                onClick = {
                                    selectedCust = c
                                    amountText = if (c.balanceDue > 0) c.balanceDue.toInt().toString() else "500"
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text(if (isHindi) "जमा राशि ₹ *" else "Amount Received ₹ *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Mode selector
                Text(
                    text = if (isHindi) "भुगतान माध्यम:" else "Payment Mode:",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Cash", "UPI", "Bank").forEach { mode ->
                        val isSelected = paymentMode == mode
                        OutlinedButton(
                            onClick = { paymentMode = mode },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isSelected) EmeraldContainer else Color.Transparent
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = mode,
                                color = if (isSelected) EmeraldDark else TextPrimary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text(if (isHindi) "टिप्पणी / विवरण" else "Notes / Reference") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cust = selectedCust
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (cust != null && amt > 0) {
                        onConfirm(cust.id, amt, paymentMode, notesText.trim())
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isHindi) "जमा करें" else "Save Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isHindi) "रद्द करें" else "Cancel")
            }
        }
    )
}

// Dialog to display & share receipt
@Composable
fun ReceiptDialog(
    session: PumpSession,
    receiptText: String,
    isHindi: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Receipt,
                    contentDescription = "Receipt",
                    tint = EmeraldDark
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isHindi) "सिंचाई बिल रसीद" else "Irrigation Receipt",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC), shape = RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = receiptText,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = TextPrimary
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    shareText(context, receiptText)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = "Share")
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isHindi) "व्हाट्सएप / शेयर करें" else "Share via WhatsApp")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isHindi) "बंद करें" else "Close")
            }
        }
    )
}

fun shareText(context: Context, text: String) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, text)
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "किसान पर्ची शेयर करें")
    context.startActivity(shareIntent)
}

fun openDialer(context: Context, phone: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$phone")
        }
        context.startActivity(intent)
    } catch (_: Exception) {}
}
