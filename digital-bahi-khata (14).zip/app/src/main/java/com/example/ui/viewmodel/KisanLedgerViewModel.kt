package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.PumpSession
import com.example.data.repository.KisanLedgerRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AppTab {
    HOME,
    CUSTOMERS,
    SESSIONS,
    REPORTS
}

data class DashboardSummary(
    val totalFarmers: Int = 0,
    val totalHoursIrrigated: Double = 0.0,
    val totalRevenue: Double = 0.0,
    val totalCollected: Double = 0.0,
    val totalPendingDue: Double = 0.0,
    val activePumpRunning: Boolean = false
)

class KisanLedgerViewModel(
    private val repository: KisanLedgerRepository = KisanLedgerRepository()
) : ViewModel() {

    val customers = repository.customers
    val sessions = repository.sessions
    val transactions = repository.transactions
    val timerState = repository.timerState
    val isHindi = repository.isHindi

    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _selectedCustomerId = MutableStateFlow<String?>(null)
    val selectedCustomerId: StateFlow<String?> = _selectedCustomerId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Dialog state
    var showAddCustomerDialog = MutableStateFlow(false)
    var showAddSessionDialog = MutableStateFlow(false)
    var showPaymentDialog = MutableStateFlow(false)
    var showReceiptDialog = MutableStateFlow<PumpSession?>(null)

    // Summary calculation
    val summary: StateFlow<DashboardSummary> = combine(
        customers,
        sessions,
        transactions,
        timerState
    ) { custList, sessList, transList, timer ->
        val totalHours = custList.sumOf { it.totalHoursIrrigated }
        val totalRev = custList.sumOf { it.totalBilled }
        val totalPaid = custList.sumOf { it.totalPaid }
        val totalPending = custList.sumOf { it.balanceDue }
        DashboardSummary(
            totalFarmers = custList.size,
            totalHoursIrrigated = totalHours,
            totalRevenue = totalRev,
            totalCollected = totalPaid,
            totalPendingDue = totalPending,
            activePumpRunning = timer.isRunning
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DashboardSummary()
    )

    init {
        // Background ticker for live pump timer
        viewModelScope.launch {
            while (isActive) {
                if (timerState.value.isRunning) {
                    repository.updateTimerTick()
                }
                delay(1000)
            }
        }
    }

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun selectCustomer(customerId: String?) {
        _selectedCustomerId.value = customerId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleLanguage() {
        repository.toggleLanguage()
    }

    fun addCustomer(name: String, phone: String, village: String, rate: Double, initialDue: Double) {
        repository.addCustomer(name, phone, village, rate, initialDue)
    }

    fun addSession(customerId: String, duration: Double, rate: Double, notes: String) {
        repository.addSession(customerId, duration, rate, notes)
    }

    fun recordPayment(customerId: String, amount: Double, paymentMode: String, notes: String) {
        repository.recordPayment(customerId, amount, paymentMode, notes)
    }

    fun startPumpTimer(customerId: String, rate: Double) {
        repository.startTimer(customerId, rate)
    }

    fun stopPumpTimer() {
        val completedSession = repository.stopTimer()
        if (completedSession != null) {
            showReceiptDialog.value = completedSession
        }
    }

    fun getReceiptText(session: PumpSession): String {
        return """
            =========================
             🚜 किसान बही खाता - सिंचाई पर्ची 🚜
            =========================
            किसान का नाम: ${session.customerName}
            दिनांक: ${session.dateText}
            समय: ${session.startTime} से ${session.endTime}
            कुल सिंचाई समय: ${session.durationHours} घंटे
            दर प्रति घंटा: ₹${session.hourlyRate.toInt()}
            -------------------------
            कुल देय राशि: ₹${session.totalAmount.toInt()}
            स्थिति: ${if (session.isPaid) "भुगतान प्राप्त (PAID)" else "बकाया (DUE)"}
            विवरण: ${session.notes.ifEmpty { "ट्यूबवेल सिंचाई" }}
            =========================
            डिजिटल बही खाता द्वारा जनरेटेड
        """.trimIndent()
    }
}
