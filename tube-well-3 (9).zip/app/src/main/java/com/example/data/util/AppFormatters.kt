package com.example.data.util

import com.example.data.localization.AppLanguage
import java.util.Locale
import kotlin.math.roundToLong

object AppFormatters {

    /**
     * Formats session hours into crystal clear, human-readable localized duration:
     * - Less than 1 minute: e.g. "45 सेकंड" / "45 sec"
     * - Less than 60 minutes: e.g. "2 मिनट", "18 मिनट" / "18 min"
     * - 1 hour or more: e.g. "1 घंटा 20 मिनट" / "1 hr 20 min"
     */
    fun formatSessionDuration(hours: Double, lang: AppLanguage = AppLanguage.HINDI, includeHrsBracket: Boolean = false): String {
        val totalSeconds = Math.round(hours * 3600.0).toInt()
        if (totalSeconds <= 0) {
            return when (lang) {
                AppLanguage.ENGLISH -> "0 min"
                AppLanguage.PUNJABI -> "0 ਮਿੰਟ"
                AppLanguage.GUJARATI -> "0 મિનિટ"
                AppLanguage.MARATHI -> "0 मिनिटे"
                AppLanguage.BENGALI -> "0 মিনিট"
                AppLanguage.TELUGU -> "0 నిమిషాలు"
                AppLanguage.TAMIL -> "0 நிமிடம்"
                AppLanguage.KANNADA -> "0 ನಿಮಿಷ"
                AppLanguage.URDU -> "0 منٹ"
                AppLanguage.SPANISH -> "0 min"
                AppLanguage.ARABIC -> "0 دقيقة"
                else -> "0 मिनट"
            }
        }

        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60

        val (hrUnitSingular, hrUnitPlural, minUnit, secUnit) = when (lang) {
            AppLanguage.ENGLISH -> Quad("hr", "hrs", "min", "sec")
            AppLanguage.PUNJABI -> Quad("ਘੰਟਾ", "ਘੰਟੇ", "ਮਿੰਟ", "ਸਕਿੰਟ")
            AppLanguage.GUJARATI -> Quad("કલાક", "કલાક", "મિનિટ", "સેકન્ડ")
            AppLanguage.MARATHI -> Quad("तास", "तास", "मिनिटे", "सेकंद")
            AppLanguage.BENGALI -> Quad("ঘণ্টা", "ঘণ্টা", "মিনিট", "সেকেন্ড")
            AppLanguage.TELUGU -> Quad("గంట", "గంటలు", "నిమిషాలు", "సెకన్లు")
            AppLanguage.TAMIL -> Quad("மணி", "மணிநேரம்", "நிமிடம்", "வினாடி")
            AppLanguage.KANNADA -> Quad("ಗಂಟೆ", "ಗಂಟೆಗಳು", "ನಿಮಿಷ", "ಸೆಕೆಂಡು")
            AppLanguage.URDU -> Quad("گھنٹہ", "گھنٹے", "منٹ", "سیکنڈ")
            AppLanguage.SPANISH -> Quad("hora", "horas", "min", "seg")
            AppLanguage.ARABIC -> Quad("ساعة", "ساعات", "دقيقة", "ثانية")
            else -> Quad("घंटा", "घंटे", "मिनट", "सेकंड")
        }

        return when {
            h > 0 && m > 0 -> {
                val hrText = if (h == 1) "$h $hrUnitSingular" else "$h $hrUnitPlural"
                val base = "$hrText $m $minUnit"
                if (includeHrsBracket) "$base (${String.format(Locale.ROOT, "%.1f", hours)} $hrUnitPlural)" else base
            }
            h > 0 -> {
                val hrText = if (h == 1) "$h $hrUnitSingular" else "$h $hrUnitPlural"
                if (includeHrsBracket) "$hrText (${String.format(Locale.ROOT, "%.1f", hours)} $hrUnitPlural)" else hrText
            }
            m > 0 -> "$m $minUnit"
            else -> "$s $secUnit"
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

    /**
     * Formats hours decimal with localized unit label:
     * e.g. "30.3 घंटे" (Hindi), "30.3 hrs" (English), "30.3 ਕਲਾਕ" (Gujarati)
     */
    fun formatHoursNumber(hours: Double, lang: AppLanguage = AppLanguage.HINDI): String {
        val numStr = String.format(Locale.ROOT, "%.1f", hours)
        val unit = when (lang) {
            AppLanguage.ENGLISH -> "hrs"
            AppLanguage.PUNJABI -> "ਘੰਟੇ"
            AppLanguage.GUJARATI -> "કલાક"
            AppLanguage.MARATHI -> "तास"
            AppLanguage.BENGALI -> "ঘণ্টা"
            AppLanguage.TELUGU -> "గంటలు"
            AppLanguage.TAMIL -> "மணி"
            AppLanguage.KANNADA -> "ಗಂಟೆ"
            AppLanguage.URDU -> "گھنٹے"
            AppLanguage.SPANISH -> "hrs"
            AppLanguage.ARABIC -> "ساعة"
            else -> "घंटे"
        }
        return "$numStr $unit"
    }

    /**
     * Compact duration for chips and small badges:
     * - e.g. "5 min", "1h 20m", "2.5 hrs"
     */
    fun formatCompactDuration(hours: Double): String {
        val totalSeconds = Math.round(hours * 3600.0).toInt()
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h} hrs"
            m > 0 -> "${m} min"
            else -> "${totalSeconds}s"
        }
    }

    /**
     * Formats rupee amounts reliably with Math.round so that:
     * 1. Floating-point precision issues (e.g. 5.9999 or 2.333) never drop ₹1 due to .toInt() truncation.
     * 2. Grand totals and individual row sums always match 100% without ₹1 mismatch.
     */
    fun roundRupees(amount: Double): Long {
        return Math.round(amount)
    }

    /**
     * Formats rupee integer with comma separators: e.g. 10,500
     */
    fun formatRupees(amount: Double): String {
        return String.format(Locale.ROOT, "%,d", Math.round(amount))
    }
}
