const DIRECT_API_KEY = "AQ.Ab8RN6LNSzpzltKJVCyEecIQcyjjuAnNVJ82y08aOTzpwUv5OA";
const MUNSHI_APP_SECRET = "munshi_tubewell_secure_2026";
export default {
async fetch(request, env) {
const cors = {
"Access-Control-Allow-Origin": "*",
"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
"Access-Control-Allow-Headers": "Content-Type, x-munshi-secret, x-goog-api-key"
};
if (request.method === "OPTIONS") return new Response(null, { headers: cors });
const keys = [];
if (DIRECT_API_KEY && DIRECT_API_KEY.length > 5) keys.push(DIRECT_API_KEY.trim());
if (env && typeof env === "object") {
for (const [keyName, val] of Object.entries(env)) {
if (keyName.startsWith("GEMINI_API_KEY") && typeof val === "string" && val.trim().length > 5) {
val.split(/[\n,]+/).forEach(k => {
const clean = k.trim();
if (clean.length > 5 && !keys.includes(clean)) keys.push(clean);
});
}
}
}
const hKey = request.headers.get("x-goog-api-key");
if (hKey && hKey.length > 5 && !keys.includes(hKey.trim())) keys.push(hKey.trim());
if (keys.length === 0) {
return new Response(JSON.stringify({ error: "NO_API_KEY" }), { status: 500, headers: cors });
}
if (request.method === "GET") {
return new Response(JSON.stringify({ status: "ONLINE", model: "gemini-3.8-flash", keysFound: keys.length }, null, 2), { headers: cors });
}
const reqBody = await request.text();
let lastError = "No response";
for (const apiKey of keys) {
for (const model of ["gemini-3.8-flash", "gemini-3.5-flash"]) {
try {
const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
const res = await fetch(url, {
method: "POST",
headers: { "Content-Type": "application/json" },
body: reqBody
});
const data = await res.text();
if (res.ok) {
return new Response(data, { status: 200, headers: { ...cors, "Content-Type": "application/json" } });
}
lastError = data;
} catch (e) {
lastError = e.message;
}
}
}
return new Response(JSON.stringify({ error: "ALL_KEYS_FAILED", details: lastError }), { status: 502, headers: cors });
}};
