package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.*
import com.example.ui.theme.KisanLedgerTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.KisanLedgerViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: KisanLedgerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KisanLedgerTheme {
                AppRootNavigation(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AppRootNavigation(viewModel: BahiKhataViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val selectedCustomerId by viewModel.selectedCustomerId.collectAsState()

    when (currentScreen) {
        AppScreen.SPLASH -> SplashScreen(viewModel = viewModel)
        AppScreen.LANGUAGE_SELECT -> LanguageSelectScreen(viewModel = viewModel)
        AppScreen.AUTH_CHOICE -> AuthChoiceScreen(viewModel = viewModel)
        AppScreen.SIGN_UP -> SignUpScreen(viewModel = viewModel)
        AppScreen.LOGIN -> LoginScreen(viewModel = viewModel)
        AppScreen.FORGOT_PASSWORD -> ForgotPasswordScreen(viewModel = viewModel)
        AppScreen.MAIN_CONTAINER -> {
            if (selectedCustomerId != null) {
                CustomerDetailScreen(
                    customerId = selectedCustomerId!!,
                    viewModel = viewModel,
                    onBack = { viewModel.selectCustomer(null) }
                )
            } else {
                MainContainerScreen(viewModel = viewModel)
            }
        }
    }
}
