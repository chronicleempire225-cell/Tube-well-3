package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.TimerState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LivePumpTimerCard(
    timerState: TimerState,
    customers: List<Customer>,
    isHindi: Boolean,
    onStartTimer: (customerId: String, rate: Double) -> Unit,
    onStopTimer: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCustomerId by remember(timerState.selectedCustomerId) {
        mutableStateOf(timerState.selectedCustomerId ?: customers.firstOrNull()?.id ?: "")
    }
    var rateText by remember(timerState.hourlyRate) {
        mutableStateOf(timerState.hourlyRate.toInt().toString())
    }
    var customerDropdownExpanded by remember { mutableStateOf(false) }

    // Pulsing animation when running
    val infiniteTransition = rememberInfiniteTransition(label = "pump_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_pump_timer_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (timerState.isRunning) EmeraldContainer else SurfaceCard
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Title & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (timerState.isRunning) EmeraldPrimary else WaterBlueLight)
                            .then(if (timerState.isRunning) Modifier.scale(pulseScale) else Modifier),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = null,
                            tint = if (timerState.isRunning) Color.White else WaterBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isHindi) "लाइव पंप टाइमर (Stopwatch)" else "Live Pump Stopwatch",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (timerState.isRunning) {
                                if (isHindi) "● ट्यूबवेल चालू है" else "● Pump Running"
                            } else {
                                if (isHindi) "पंप बंद है" else "Pump Stopped"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (timerState.isRunning) EmeraldDark else TextMuted,
                            fontWeight = if (timerState.isRunning) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Timer Display (HH:MM:SS)
            val hours = timerState.elapsedSeconds / 3600
            val minutes = (timerState.elapsedSeconds % 3600) / 60
            val seconds = timerState.elapsedSeconds % 60
            val formattedTime = String.format("%02d:%02d:%02d", hours, minutes, seconds)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (timerState.isRunning) Color.White else Color(0xFFF1F5F9))
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = formattedTime,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = if (timerState.isRunning) EmeraldDark else TextPrimary,
                        letterSpacing = 2.sp
                    )
                    if (timerState.isRunning) {
                        val currentRate = rateText.toDoubleOrNull() ?: timerState.hourlyRate
                        val estimatedCost = (timerState.elapsedSeconds / 3600.0) * currentRate
                        Text(
                            text = if (isHindi) "अनुमानित बिल: ₹${String.format("%.1f", estimatedCost)}" else "Est. Cost: ₹${String.format("%.1f", estimatedCost)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Customer Selector & Rate when not running
            if (!timerState.isRunning) {
                // Farmer Picker Dropdown
                ExposedDropdownMenuBox(
                    expanded = customerDropdownExpanded,
                    onExpandedChange = { customerDropdownExpanded = !customerDropdownExpanded }
                ) {
                    val selectedCustomer = customers.find { it.id == selectedCustomerId }
                    OutlinedTextField(
                        value = selectedCustomer?.name ?: if (isHindi) "किसान चुनें" else "Select Farmer",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isHindi) "किसान का नाम" else "Farmer Name") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    ExposedDropdownMenu(
                        expanded = customerDropdownExpanded,
                        onDismissRequest = { customerDropdownExpanded = false }
                    ) {
                        if (customers.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text(if (isHindi) "कोई किसान उपलब्ध नहीं है" else "No farmers available") },
                                onClick = { customerDropdownExpanded = false }
                            )
                        } else {
                            customers.forEach { customer ->
                                DropdownMenuItem(
                                    text = { Text(customer.name) },
                                    onClick = {
                                        selectedCustomerId = customer.id
                                        customerDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Rate per hour input
                OutlinedTextField(
                    value = rateText,
                    onValueChange = { rateText = it.filter { char -> char.isDigit() || char == '.' } },
                    label = { Text(if (isHindi) "सिंचाई दर (₹/घंटा)" else "Rate (₹/hour)") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.CurrencyRupee, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))
            }

            // Start / Stop Buttons
            if (timerState.isRunning) {
                Button(
                    onClick = onStopTimer,
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("stop_pump_button")
                ) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isHindi) "पंप रोकें व हिसाब जोड़ें" else "Stop Pump & Save Session",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            } else {
                Button(
                    onClick = {
                        val rate = rateText.toDoubleOrNull() ?: 150.0
                        onStartTimer(selectedCustomerId, rate)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("start_pump_button")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isHindi) "पंप शुरू करें (Start Timer)" else "Start Pump Timer",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
