package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.KisanLedgerViewModel

@Composable
fun CustomersScreen(
    viewModel: KisanLedgerViewModel,
    modifier: Modifier = Modifier
) {
    CustomerDirectoryScreen(viewModel = viewModel)
}

@Composable
fun SessionsScreen(
    viewModel: KisanLedgerViewModel,
    modifier: Modifier = Modifier
) {
    val sessions by viewModel.sessions.collectAsState()
    val isHindi by viewModel.isHindi.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.showAddSessionDialog.value = true },
                containerColor = WaterBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_session_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Session")
            }
        }
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = if (isHindi) "सिंचाई सत्र इतिहास (Irrigation Records)" else "Irrigation Sessions History",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (sessions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 50.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isHindi) "अभी तक कोई सिंचाई सत्र दर्ज नहीं है" else "No irrigation sessions recorded yet",
                            color = TextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(sessions) { session ->
                        RecentSessionRowItem(
                            session = session,
                            isHindi = isHindi,
                            onViewReceipt = { viewModel.showReceiptDialog.value = session },
                            onSelectCustomer = {
                                viewModel.selectCustomer(session.customerId)
                                viewModel.setTab(AppTab.CUSTOMERS)
                            }
                        )
                    }
                }
            }
        }
    }
}
