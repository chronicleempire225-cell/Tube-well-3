package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.CustomerEntity
import com.example.data.db.TubewellSessionEntity
import com.example.ui.components.LivePumpTimerCard
import com.example.ui.components.LiveTimerDisplayState
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.BahiKhataViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: BahiKhataViewModel,
    modifier: Modifier = Modifier
) {
    val isHindi by viewModel.isHindi.collectAsState()
    val allCustomers by viewModel.allCustomers.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val isTimerRunning by viewModel.isLiveTimerRunning.collectAsState()
    val isTimerPaused by viewModel.isLiveTimerPaused.collectAsState()
    val timerSeconds by viewModel.liveTimerSeconds.collectAsState()
    val activeCustId by viewModel.liveTimerActiveCustomerId.collectAsState()

    val activeCustomer = remember(activeCustId, allCustomers) {
        allCustomers.firstOrNull { it.id == activeCustId }
    }

    val profile by viewModel.profile.collectAsState()

    val totalHours = remember(allSessions) {
        allSessions.sumOf { it.hours }
    }
    val totalBilled = remember(allSessions) {
        allSessions.sumOf { it.totalAmount }
    }
    val totalPaid = remember(allTransactions, allSessions) {
        val directTxn = allTransactions.sumOf { it.amountDeposited }
        val sessionPaid = allSessions.sumOf { it.paidAmount }
        directTxn + sessionPaid
    }
    val totalDue = remember(totalBilled, totalPaid) {
        (totalBilled - totalPaid).coerceAtLeast(0.0)
    }

    val timerDisplayState = LiveTimerDisplayState(
        isRunning = isTimerRunning,
        isPaused = isTimerPaused,
        seconds = timerSeconds,
        customerId = activeCustId,
        customerName = activeCustomer?.name,
        ratePerHour = profile?.ratePerHour ?: 160.0
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Live Pump Widget
        item {
            LivePumpTimerCard(
                timerState = timerDisplayState,
                customers = allCustomers,
                isHindi = isHindi,
                onStartTimer = { custId, rate ->
                    viewModel.startLiveTimer(custId, rate)
                },
                onStopTimer = {
                    viewModel.stopAndSaveLiveTimer()
                }
            )
        }

        // 2. Summary Dashboard Metrics Grid
        item {
            Text(
                text = if (isHindi) "खाता सारांश (Account Overview)" else "Account Overview",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryMetricCard(
                    title = if (isHindi) "कुल बकाया" else "Total Due",
                    amount = "₹${totalDue.toInt()}",
                    subtitle = if (isHindi) "किसानों से लेना है" else "Receivable",
                    icon = Icons.Default.CurrencyRupee,
                    cardColor = AlertRedLight,
                    accentColor = AlertRed,
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    title = if (isHindi) "कुल वसूली" else "Collected",
                    amount = "₹${totalPaid.toInt()}",
                    subtitle = if (isHindi) "जमा प्राप्त राशि" else "Total Received",
                    icon = Icons.Default.AccountBalanceWallet,
                    cardColor = EmeraldContainer,
                    accentColor = EmeraldDark,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryMetricCard(
                    title = if (isHindi) "कुल सिंचाई" else "Total Irrigation",
                    amount = String.format(Locale.getDefault(), "%.1f घंटे", totalHours),
                    subtitle = if (isHindi) "ट्यूबवेल चला" else "Hours Run",
                    icon = Icons.Default.Opacity,
                    cardColor = WaterBlueLight,
                    accentColor = WaterBlue,
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    title = if (isHindi) "कुल किसान" else "Total Farmers",
                    amount = "${allCustomers.size} किसान",
                    subtitle = if (isHindi) "सक्रिय खाते" else "Active Accounts",
                    icon = Icons.Default.Groups,
                    cardColor = GoldContainer,
                    accentColor = GoldAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Quick Action Buttons
        item {
            Text(
                text = if (isHindi) "त्वरित कार्य (Quick Actions)" else "Quick Actions",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.setTab(AppTab.CUSTOMERS) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_customer_button"),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isHindi) "+ नया किसान" else "+ Farmer", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.setTab(AppTab.CUSTOMERS) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WaterBlue),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_session_button"),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.WaterDrop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isHindi) "+ सिंचाई" else "+ Session", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.setTab(AppTab.CUSTOMERS) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalOrange),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_payment_button"),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isHindi) "+ जमा राशि" else "+ Payment", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 4. Recent Irrigation Sessions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isHindi) "हाल की सिंचाई (Recent Sessions)" else "Recent Sessions",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = if (isHindi) "सभी देखें >" else "View All >",
                    color = AgriGreenDark,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { viewModel.setTab(AppTab.REPORTS) }
                )
            }
        }

        items(allSessions.take(5)) { session ->
            val customer = allCustomers.firstOrNull { it.id == session.customerId }
            RecentSessionRowItem(
                session = session,
                customerName = customer?.name ?: (if (isHindi) "किसान" else "Farmer"),
                isHindi = isHindi,
                onSelectCustomer = {
                    viewModel.selectCustomerForDetail(session.customerId)
                }
            )
        }
    }
}

@Composable
fun SummaryMetricCard(
    title: String,
    amount: String,
    subtitle: String,
    icon: ImageVector,
    cardColor: Color,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = accentColor
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = amount,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun RecentSessionRowItem(
    session: TubewellSessionEntity,
    customerName: String,
    isHindi: Boolean,
    onSelectCustomer: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM, yyyy", Locale.getDefault()) }
    val dateText = remember(session.sessionDate) { dateFormat.format(Date(session.sessionDate)) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectCustomer() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(WaterBlueLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = null,
                        tint = WaterBlue,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = customerName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "$dateText • ${session.hours} घंटे",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    if (session.note.isNotBlank()) {
                        Text(
                            text = session.note,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "₹${session.totalAmount.toInt()}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = EmeraldDark
                )
                val isPaid = session.paidAmount >= session.totalAmount
                Surface(
                    color = if (isPaid) EmeraldContainer else AlertRedLight,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (isPaid) (if (isHindi) "जमा" else "Paid") else (if (isHindi) "बकाया" else "Due"),
                        color = if (isPaid) EmeraldDark else AlertRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
