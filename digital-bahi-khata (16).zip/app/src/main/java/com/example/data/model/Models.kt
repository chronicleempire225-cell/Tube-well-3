package com.example.data.model

data class Customer(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val village: String = "",
    val ratePerHour: Double = 150.0,
    val initialDue: Double = 0.0,
    val totalPendingDue: Double = 0.0
)

data class PumpSession(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val dateText: String = "",
    val durationHours: Double = 0.0,
    val hourlyRate: Double = 150.0,
    val totalAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val isPaid: Boolean = false,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class SummaryData(
    val totalPendingDue: Double = 0.0,
    val totalCollected: Double = 0.0,
    val totalHoursIrrigated: Double = 0.0,
    val totalFarmers: Int = 0
)

data class TimerState(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val elapsedSeconds: Long = 0L,
    val selectedCustomerId: String? = null,
    val selectedCustomerName: String? = null,
    val hourlyRate: Double = 150.0
)
