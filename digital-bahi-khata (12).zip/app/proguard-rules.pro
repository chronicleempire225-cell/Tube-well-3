# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Room & SQLite / SQLCipher
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
-keep class net.sqlcipher.** { *; }
-keep class net.sqlcipher.database.** { *; }

# Moshi & Retrofit
-keepclassmembers class * {
    @com.squareup.moshi.* <fields>;
    @com.squareup.moshi.* <methods>;
}
-keep class com.squareup.moshi.** { *; }
-dontwarn com.squareup.moshi.**
-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod
-keepclassmembers enum * { *; }
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**

# Razorpay Checkout
-keep class com.razorpay.** {*;}
-dontwarn com.razorpay.**
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Coroutines
-dontwarn kotlinx.coroutines.**
-keep class kotlinx.coroutines.** { *; }

# Models / Data classes
-keep class com.example.data.models.** { *; }
-keep class com.example.data.local.** { *; }
-keep class com.example.data.remoteconfig.** { *; }
-keep class com.example.data.security.** { *; }

