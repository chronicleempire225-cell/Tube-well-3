package com.example.data.gemini

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.data.db.CustomerEntity
import com.example.data.db.TubewellSessionEntity
import com.example.data.repository.BahiKhataRepository
import com.example.ui.viewmodel.CustomerWithStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GeminiMunshiService {
    private const val TAG = "GeminiMunshiService"
    const val MODEL_NAME = "gemini-2.5-flash"
    const val FALLBACK_MODEL_NAME = "gemini-2.5-flash-lite"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"
    const val MUNSHI_APP_SECRET = "munshi_tubewell_secure_2026"

    /**
     * Master Cloudflare Worker URL for centralized multi-key failover.
     * When configured, the entire app routes AI requests through Cloudflare with zero client-side configuration.
     */
    var masterCloudflareWorkerUrl: String = "https://dawn-star-ae04.chronicleempire225.workers.dev"

    fun getEffectiveProxyUrl(context: Context, repository: BahiKhataRepository): String {
        val customProxy = repository.getCloudflareProxyUrl().trim()
        if (customProxy.isNotBlank()) return customProxy.removeSuffix("/")
        if (masterCloudflareWorkerUrl.isNotBlank()) return masterCloudflareWorkerUrl.trim().removeSuffix("/")
        return ""
    }

    /**
     * Represents a single turn of conversation with Munshi AI.
     */
    data class MunshiChatMessage(
        val role: String, // "user" or "model"
        val text: String,
        val timestamp: Long = System.currentTimeMillis()
    )

    /**
     * Smart built-in Ledger Engine: Answers directly from customer ledger without requiring an external API key.
     * Can answer customer balances, total dues, irrigation hours, VIP ad-removal, time-based queries, and app guidance.
     */
    fun answerDirectlyFromLedger(
        query: String,
        customersWithStats: List<CustomerWithStats>,
        defaultRate: Double,
        sessions: List<com.example.data.db.TubewellSessionEntity> = emptyList(),
        profile: com.example.data.db.ProfileEntity? = null,
        isVipActive: Boolean = false,
        vipDaysRemaining: Int = 0,
        vipPlan: String = "FREE"
    ): String {
        val smartAnswer = MunshiSmartLocalEngine.tryAnswerFromAppLogic(
            query = query,
            customersWithStats = customersWithStats,
            sessions = sessions,
            profile = profile,
            isVipActive = isVipActive,
            vipDaysRemaining = vipDaysRemaining,
            vipPlan = vipPlan
        )
        return smartAnswer ?: MunshiSmartLocalEngine.generateFallbackSummary(query, customersWithStats)
    }

    /**
     * Attempts to query live data directly from Supabase PostgREST for the active profile.
     * Returns a formatted context string if successful, or null to fallback to local Room data.
     */
    suspend fun fetchLiveSupabaseLedgerContext(
        context: Context,
        profileId: String,
        userName: String,
        defaultRate: Double
    ): String? = withContext(Dispatchers.IO) {
        try {
            if (!com.example.data.supabase.SupabaseAuthService.isNetworkAvailable(context)) return@withContext null
            val url = com.example.data.supabase.SupabaseAuthService.getSupabaseUrl(context)
            val key = com.example.data.supabase.SupabaseAuthService.getSupabaseAnonKey(context)
            if (url.isBlank() || key.isBlank() || !url.startsWith("http")) return@withContext null

            // 1. Fetch live Customers from Supabase
            val (custCode, custJson) = com.example.data.supabase.SupabaseAuthService.getFromSupabase(
                "$url/rest/v1/customers?profile_id=eq.$profileId&select=*", key
            )
            if (custCode !in 200..299 || custJson == null) return@withContext null

            // 2. Fetch live Sessions from Supabase
            val (_, sessJson) = com.example.data.supabase.SupabaseAuthService.getFromSupabase(
                "$url/rest/v1/sessions?profile_id=eq.$profileId&select=*", key
            )

            // 3. Fetch live Transactions from Supabase
            val (_, txJson) = com.example.data.supabase.SupabaseAuthService.getFromSupabase(
                "$url/rest/v1/transactions?profile_id=eq.$profileId&select=*", key
            )

            val custArr = JSONArray(custJson)
            val sessArr = if (sessJson != null) JSONArray(sessJson) else JSONArray()
            val txArr = if (txJson != null) JSONArray(txJson) else JSONArray()

            data class LiveCust(
                val name: String,
                val phone: String,
                var hours: Double = 0.0,
                var billed: Double = 0.0,
                var paid: Double = 0.0,
                var due: Double = 0.0,
                var sessionCount: Int = 0
            )

            val map = mutableMapOf<String, LiveCust>()
            for (i in 0 until custArr.length()) {
                val obj = custArr.getJSONObject(i)
                val id = obj.getString("id")
                val name = obj.getString("name")
                val phone = obj.optString("phone", obj.optString("mobile", ""))
                val initBal = obj.optDouble("initial_balance", obj.optDouble("total_due", 0.0))
                map[id] = LiveCust(name = name, phone = phone, due = initBal, billed = initBal)
            }

            for (i in 0 until sessArr.length()) {
                val obj = sessArr.getJSONObject(i)
                val cId = if (obj.has("customerId")) obj.getString("customerId") else obj.optString("customer_id", "")
                val h = obj.optDouble("hours", 0.0)
                val amt = if (obj.has("totalAmount")) obj.getDouble("totalAmount") else obj.optDouble("total_amount", 0.0)
                val paid = if (obj.has("paidAmount")) obj.getDouble("paidAmount") else obj.optDouble("paid_amount", 0.0)
                val due = if (obj.has("dueAmount")) obj.getDouble("dueAmount") else obj.optDouble("due_amount", amt - paid)

                map[cId]?.let {
                    it.hours += h
                    it.billed += amt
                    it.paid += paid
                    it.due += due
                    it.sessionCount += 1
                }
            }

            for (i in 0 until txArr.length()) {
                val obj = txArr.getJSONObject(i)
                val cId = if (obj.has("customerId")) obj.getString("customerId") else obj.optString("customer_id", "")
                val amt = if (obj.has("amountDeposited")) obj.getDouble("amountDeposited") else obj.optDouble("amount_deposited", 0.0)
                map[cId]?.let {
                    it.paid += amt
                    it.due = (it.due - amt).coerceAtLeast(0.0)
                }
            }

            val totalDue = map.values.sumOf { it.due }
            val totalHours = map.values.sumOf { it.hours }
            val totalPaid = map.values.sumOf { it.paid }

            val sb = StringBuilder()
            sb.append("=== किसान ट्यूबवेल बही-खाता लाइव Supabase क्लाउड डेटा ===\n")
            sb.append("ऑपरेटर/किसान का नाम: ${userName.ifBlank { "किसान भाई" }}\n")
            sb.append("वर्तमान सामान्य सिंचाई दर: ₹$defaultRate प्रति घंटा\n\n")

            sb.append("--- वित्तीय सारांश (लाइव Supabase डेटा) ---\n")
            sb.append("कुल ग्राहक संख्या: ${map.size}\n")
            sb.append("कुल सिंचाई घंटे: ${"%.1f".format(totalHours)} घंटे\n")
            sb.append("कुल जमा राशि: ₹${"%.0f".format(totalPaid)}\n")
            sb.append("कुल बकाया राशि (मार्केट में बाकी): ₹${"%.0f".format(totalDue)}\n\n")

            sb.append("--- ग्राहकों की लाइव स्थिति (Supabase से) ---\n")
            if (map.isEmpty()) {
                sb.append("क्लाउड में कोई ग्राहक डेटा नहीं है।\n")
            } else {
                map.values.forEachIndexed { idx, c ->
                    sb.append("${idx + 1}. नाम: ${c.name}, ")
                    if (c.phone.isNotBlank()) sb.append("मोबाइल: ${c.phone}, ")
                    sb.append("कुल घंटे: ${"%.1f".format(c.hours)}, ")
                    sb.append("कुल बिल: ₹${"%.0f".format(c.billed)}, ")
                    sb.append("जमा: ₹${"%.0f".format(c.paid)}, ")
                    sb.append("बकाया: ₹${"%.0f".format(c.due)}, ")
                    sb.append("सिंचाई सत्र: ${c.sessionCount} बार\n")
                }
            }

            sb.append("\n--- संपूर्ण 'ट्यूबवेल बही-खाता' ऐप मार्गदर्शिका (App Help & Navigation) ---\n")
            sb.append("1. नया ग्राहक जोड़ना: नीचे 'ग्राहक' टैब में जाएं या होम स्क्रीन पर नीचे दाएँ कोने में बने हरे '+' बटन को दबाएं। नाम, मोबाइल नंबर और सिंचाई दर (जैसे ₹150) दर्ज करके 'सुरक्षित करें' दबाएं।\n")
            sb.append("2. सिंचाई / सत्र दर्ज करना: मुख्य स्क्रीन पर 'सत्र जोड़ें' दबाएं। 3 आसान तरीके उपलब्ध हैं:\n")
            sb.append("   - 'लाइव टाइमर': ट्यूबवेल चालू करते ही 'स्टार्ट' दबाएं, बंद करने पर 'स्टॉप' दबाएं; घंटे और बिल खुद जुड़ेंगे।\n")
            sb.append("   - 'समय दर्ज करें': शुरू समय (जैसे सुबह 08:00 AM) और खत्म समय (जैसे 11:30 AM) दर्ज करें।\n")
            sb.append("   - 'सीधे घंटे': सीधे घंटे (जैसे 3.5 घंटे) लिखकर 'सत्र सुरक्षित करें' दबाएं।\n")
            sb.append("3. पैसे जमा करना / भुगतान: 'ग्राहक' टैब में संबंधित किसान के नाम पर टैप करें। ऊपर हरे रंग का '+ जमा करें' बटन दबाएं, प्राप्त राशि (रुपये) दर्ज करके 'रसीद सुरक्षित करें' दबाएं।\n")
            sb.append("4. व्हाट्सएप पर्ची व रसीद भेजना: ग्राहक के खाते में जाएं और 'शेयर पर्ची' बटन दबाएं। तुरंत सुंदर व्हाट्सएप संदेश तैयार हो जाएगा जिसमें कुल घंटे, कुल बिल, जमा और बाकी बकाया लिखा होगा।\n")
            sb.append("5. पक्की पीडीएफ रसीद: ग्राहक के खाते में 'पीडीएफ' बटन दबाकर रसीद या पूरा खाता विवरण डाउनलोड व प्रिंट कर सकते हैं।\n")
            sb.append("6. सिंचाई दर (घंटे का रेट) बदलना: 'सेटिंग्स' टैब में जाएं, 'सामान्य सिंचाई दर' पर क्लिक करें और नई दर दर्ज करके सेव करें।\n")
            sb.append("7. सुपरबेस क्लाउड बैकअप / डेटा सिंक: 'सेटिंग्स' टैब में 'डेटा सिंक करें' बटन दबाएं। सारा बही-खाता Supabase क्लाउड में सुरक्षित हो जाएगा।\n")
            sb.append("8. नाइट मोड / डार्क थीम: 'सेटिंग्स' टैब में 'डार्क थीम' स्विच ऑन करें।\n")
            sb.append("9. ग्राहक खोजना / फिल्टर: 'ग्राहक' टैब में ऊपर सर्च बार में नाम या मोबाइल नंबर लिखकर तुरंत ढूंढ सकते हैं, और 'बाकी वाले' या 'चुकता' फिल्टर लगा सकते हैं।\n")

            sb.toString()
        } catch (e: Exception) {
            Log.w(TAG, "fetchLiveSupabaseLedgerContext error: ${e.message}")
            null
        }
    }

    /**
     * Cleans text for pleasant, natural Text-to-Speech audio output.
     */
    fun cleanTextForSpeech(text: String): String {
        return text
            .replace(Regex("[*#_~`>]"), "")
            // Handle number ranges with hyphens/en-dashes (e.g., 10-15 -> "10, 15" with comma for natural pause)
            .replace(Regex("(\\d+)\\s*[-–—]\\s*(\\d+)"), "$1, $2")
            // Replace lingering hyphens or dashes with comma and space for pleasant pause
            .replace(Regex("[-–—]"), ", ")
            .replace(Regex("₹\\s*([0-9,.]+)"), "$1 रुपये")
            .replace("₹", " रुपये ")
            .replace(Regex("(\\d+)/घंटा"), "$1 रुपये प्रति घंटा")
            .replace("/", " प्रति ")
            .replace("%", " प्रतिशत ")
            .replace(Regex("[\uD83C-\uDBFF\uDC00-\uDFFF]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * Default Master Project API Key.
     * Kept empty by default for security. Users can enter their key in Settings,
     * or it will be served via the secure Cloudflare proxy.
     */
    const val DEFAULT_PROJECT_GEMINI_KEY = ""

    /**
     * Resolves the Gemini API Key:
     * 1. If farmer/user configured their own key in Settings, use it!
     * 2. If BuildConfig.GEMINI_API_KEY is available and valid, use it.
     * 3. Otherwise, return empty so the built-in local ledger engine handles the request.
     */
    fun getEffectiveApiKey(context: Context, repository: BahiKhataRepository): String {
        val customKey = repository.getGeminiApiKey().trim()
        if (customKey.isNotBlank()) {
            return customKey
        }
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY.trim()
        } catch (_: Throwable) {
            ""
        }
        if (buildKey.isNotBlank() && buildKey != "null") {
            return buildKey
        }
        return DEFAULT_PROJECT_GEMINI_KEY
    }

    /**
     * Prepares structured context containing all current customer balances, hours, sessions and app help.
     */
    fun buildFarmerContext(
        userName: String,
        defaultRate: Double,
        customersWithStats: List<CustomerWithStats>,
        recentSessions: List<TubewellSessionEntity>
    ): String {
        val sb = StringBuilder()
        sb.append("=== किसान ट्यूबवेल बही-खाता लाइव डेटा ===\n")
        sb.append("ऑपरेटर/किसान का नाम: ${userName.ifBlank { "किसान भाई" }}\n")
        sb.append("वर्तमान सामान्य सिंचाई दर: ₹$defaultRate प्रति घंटा\n\n")

        val totalDue = customersWithStats.sumOf { it.netDue }
        val totalHours = customersWithStats.sumOf { it.totalHours }
        val totalPaid = customersWithStats.sumOf { it.totalPaid }

        sb.append("--- वित्तीय सारांश ---\n")
        sb.append("कुल ग्राहक संख्या: ${customersWithStats.size}\n")
        sb.append("कुल सिंचाई घंटे: ${"%.1f".format(totalHours)} घंटे\n")
        sb.append("कुल जमा राशि: ₹${"%.0f".format(totalPaid)}\n")
        sb.append("कुल बकाया राशि (मार्केट में बाकी): ₹${"%.0f".format(totalDue)}\n\n")

        sb.append("--- ग्राहकों की सूची एवं स्थिति ---\n")
        if (customersWithStats.isEmpty()) {
            sb.append("वर्तमान में कोई ग्राहक नहीं जुड़ा है।\n")
        } else {
            customersWithStats.forEachIndexed { idx, item ->
                val c = item.customer
                sb.append("${idx + 1}. नाम: ${c.name}, ")
                if (c.sO.isNotBlank()) sb.append("पिता: ${c.sO}, ")
                if (c.phone.isNotBlank()) sb.append("मोबाइल: ${c.phone}, ")
                sb.append("कुल घंटे: ${"%.1f".format(item.totalHours)}, ")
                sb.append("कुल बिल: ₹${"%.0f".format(item.totalAmount)}, ")
                sb.append("जमा: ₹${"%.0f".format(item.totalPaid)}, ")
                sb.append("बकाया: ₹${"%.0f".format(item.netDue)}, ")
                sb.append("सिंचाई सत्र: ${item.sessionCount} बार")
                if (item.lastSessionDate != null && item.lastSessionDate > 0) {
                    val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale("hi", "IN")).format(Date(item.lastSessionDate))
                    sb.append(", अंतिम सिंचाई: $dateStr")
                }
                sb.append("\n")
            }
        }

        sb.append("\n--- हाल के सिंचाई सत्र (Session History) ---\n")
        if (recentSessions.isEmpty()) {
            sb.append("कोई हालिया सत्र नहीं है।\n")
        } else {
            recentSessions.take(50).forEachIndexed { idx, s ->
                val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale("hi", "IN")).format(Date(s.sessionDate))
                val isPaid = s.dueAmount <= 0.0 || s.paidAmount >= s.totalAmount
                sb.append("${idx + 1}. दिनांक: $dateStr, घंटे: ${"%.1f".format(s.hours)}, दर: ₹${s.rate}/घंटा, बिल: ₹${"%.0f".format(s.totalAmount)}, भुगतान स्थिति: ${if (isPaid) "जमा" else "बाकी"}\n")
            }
        }

        sb.append("\n--- संपूर्ण 'ट्यूबवेल बही-खाता' ऐप मार्गदर्शिका (App Help & Navigation) ---\n")
        sb.append("1. नया ग्राहक जोड़ना: 'ग्राहक' स्क्रीन (Customers Screen) पर नीचे दाएँ कोने में 'लाल' (Red / Royal Orange) रंग का गोल बटन ('+ नया किसान जोड़ें') है। और होम स्क्रीन (Home Screen) पर जब नया सिंचाई सत्र चालू करते हैं, तो वहाँ बटन 'हरा' (Green) होता है ('▶ नया सत्र')। नाम, मोबाइल नंबर और सिंचाई दर दर्ज करके सुरक्षित करें।\n")
        sb.append("2. सिंचाई / सत्र दर्ज करना: मुख्य स्क्रीन पर हरे रंग का 'नया सत्र' बटन दबाएं। 3 आसान तरीके उपलब्ध हैं:\n")
        sb.append("   - 'लाइव टाइमर': ट्यूबवेल चालू करते ही 'स्टार्ट' दबाएं, बंद करने पर 'स्टॉप' दबाएं; घंटे और बिल खुद जुड़ेंगे।\n")
        sb.append("   - 'समय दर्ज करें': शुरू समय (जैसे सुबह 08:00 AM) और खत्म समय (जैसे 11:30 AM) दर्ज करें।\n")
        sb.append("   - 'सीधे घंटे': सीधे घंटे (जैसे 3.5 घंटे) लिखकर 'सत्र सुरक्षित करें' दबाएं।\n")
        sb.append("3. पैसे जमा करना / भुगतान: 'ग्राहक' टैब में संबंधित किसान के नाम पर टैप करें। ऊपर हरे रंग का '+ जमा करें' बटन दबाएं, प्राप्त राशि दर्ज करके सुरक्षित करें।\n")
        sb.append("4. व्हाट्सएप पर्ची व रसीद भेजना: ग्राहक के खाते में जाएं और हरे रंग का 'शेयर पर्ची' बटन दबाएं। तुरंत सुंदर व्हाट्सएप संदेश तैयार हो जाएगा। पक्की पर्ची के लिए नीले रंग का 'पीडीएफ' बटन दबाएं।\n")
        sb.append("5. विज्ञापन / ऐड पूरी तरह हटाना (VIP Ad-Free): 'सेटिंग्स' में जाएं और '👑 VIP सदस्यता' कार्ड पर टैप करके VIP सदस्यता लें। इससे सभी विज्ञापन 100% बंद हो जाएंगे और सभी फीचर्स बिना वीडियो देखे सक्रिय रहेंगे।\n")
        sb.append("6. सिंचाई दर (घंटे का रेट) बदलना: 'सेटिंग्स' टैब में जाएं, 'सामान्य सिंचाई दर' पर क्लिक करें और नई दर दर्ज करके सेव करें।\n")
        sb.append("7. सुपरबेस क्लाउड बैकअप / डेटा सिंक: 'सेटिंग्स' टैब में 'डेटा सिंक करें' बटन दबाएं। सारा बही-खाता Supabase क्लाउड में सुरक्षित हो जाएगा।\n")
        sb.append("8. नाइट मोड / डार्क थीम: 'सेटिंग्स' टैब में 'डार्क थीम' स्विच ऑन करें।\n")
        sb.append("9. ग्राहक खोजना / फिल्टर: 'ग्राहक' टैब में ऊपर सर्च बार में नाम या मोबाइल नंबर लिखकर तुरंत ढूंढ सकते हैं, और 'बाकी वाले' या 'चुकता' फिल्टर लगा सकते हैं।\n")

        return sb.toString()
    }

    /**
     * Executes a single HTTP POST request to Gemini API or Cloudflare Proxy.
     */
    private fun executeGeminiRequest(
        targetUrl: String,
        apiKey: String,
        isProxy: Boolean,
        requestJson: JSONObject
    ): Result<String> {
        return try {
            val conn = (URL(targetUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                if (!isProxy) {
                    setRequestProperty("x-goog-api-key", apiKey)
                } else {
                    setRequestProperty("x-munshi-secret", MUNSHI_APP_SECRET)
                }
                connectTimeout = 15000
                readTimeout = 20000
                doOutput = true
            }

            OutputStreamWriter(conn.outputStream, "UTF-8").use { writer ->
                writer.write(requestJson.toString())
                writer.flush()
            }

            val responseCode = conn.responseCode
            val responseStream = if (responseCode in 200..299) {
                conn.inputStream
            } else {
                conn.errorStream ?: conn.inputStream
            }

            val responseText = BufferedReader(InputStreamReader(responseStream, "UTF-8")).use {
                it.readText()
            }

            if (responseCode !in 200..299) {
                Log.e(TAG, "Gemini API HTTP Error ($responseCode): $responseText")
                val errorMsg = try {
                    val errObj = JSONObject(responseText)
                    errObj.optJSONObject("error")?.optString("message")
                        ?: errObj.optString("error", "सर्वर कोड: $responseCode")
                } catch (_: Exception) {
                    "सर्वर कोड: $responseCode"
                }
                return Result.failure(Exception(errorMsg))
            }

            val respJson = JSONObject(responseText)
            // Guard against proxy-level custom error JSON like {"error":"All keys or models exhausted"}
            if (respJson.has("error") && !respJson.has("candidates")) {
                val errMsg = respJson.optString("error", "Proxy Error")
                Log.w(TAG, "Proxy returned error json: $errMsg")
                return Result.failure(Exception(errMsg))
            }

            val candidates = respJson.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val replyText = parts.getJSONObject(0).optString("text", "").trim()
                    if (replyText.isNotBlank()) {
                        return Result.success(replyText)
                    }
                }
            }

            Result.failure(Exception("मुंशी जी उत्तर तैयार नहीं कर पाए, कृपया दोबारा पूछें।"))
        } catch (e: Exception) {
            Log.e(TAG, "Exception during executeGeminiRequest: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Calls Gemini API (directly with automatic model failover, or via Cloudflare Worker Proxy)
     * with structured context and multi-turn conversation history.
     */
    suspend fun askMunshi(
        apiKey: String = "",
        proxyUrl: String = "",
        userVoiceQuery: String,
        contextData: String,
        chatHistory: List<MunshiChatMessage> = emptyList(),
        learnedMemory: String = "",
        activeLang: MunshiLang = MunshiLang.HINDI
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() && proxyUrl.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API Key या Cloudflare URL मौजूद नहीं है।")
            )
        }

        try {
            val memorySection = if (learnedMemory.isNotBlank()) "\n[पूर्व बातचीत व किसान भाई की आदतों से सीखी गई बातें (Learned Memory)]:\n$learnedMemory\n" else ""

            val systemInstruction = """
आप 'ट्यूबवेल बही-खाता' ऐप के अत्यंत बुद्धिमान, अनुभवी और मददगार 'मुंशी जी' (Google Gemini AI वॉइस सहायक) हैं।

[अभिवादन व आदर का नियम]:
- अपनी तरफ से धार्मिक संबोधन (जैसे 'राम-राम' या 'सत श्री अकाल') से शुरुआत न करें।
- यदि यह बातचीत का पहला संदेश है, केवल तभी 'नमस्ते किसान भाई' या 'नमस्ते भाई' कहें। यदि बातचीत पहले से जारी है (फॉलो-अप), तो बार-बार नमस्ते या कोई अभिवादन न दोहराएं, सीधे और स्वाभाविक रूप से उत्तर दें।
- यदि किसान भाई खुद आगे से 'राम-राम' या 'सत श्री अकाल' बोलकर सवाल शुरू करे, केवल तभी उसी आदर में उस शब्द का प्रयोग करें।

[भाषा और बोली का नियम - 100% अनिवार्य]:
- वर्तमान भाषा प्राथमिकता: ${activeLang.displayName} (${activeLang.nativeName})।
- किसान भाई जिस भाषा या बोली में सवाल पूछे (जैसे: हिंदी, हरियाणवी, पंजाबी, राजस्थानी/मारवाड़ी, भोजपुरी, इंग्लिश या गुजराती, मराठी), आप शत-प्रतिशत उसी भाषा और बोली में आदरपूर्वक उत्तर दें।
- यदि सवाल पंजाबी में है (ਜਿਵੇਂ ਕਿੰਨਾ ਬਕਾਇਆ ਹੈ?), ਤਾਂ ਜਵਾਬ ਪੰਜਾਬੀ ਵਿੱਚ ਦਿਓ।
- यदि सवाल हरियाणवी में है (कितणा बकाया सै?), तो जवाब ठेठ हरियाणवी में दें।
- यदि सवाल राजस्थानी/मारवाड़ी में है, तो 'सा', 'छै', 'थांके' के साथ राजस्थानी में जवाब दें।
- यदि सवाल भोजपुरी में है, तो 'रउआ', 'बा', 'बानी' के साथ भोजपुरी में जवाब दें।
- यदि सवाल हिंदी में है, तो मधुर व आदरणीय हिंदी में दें।

[बातचीत की लय व संदर्भ (Multi-turn Context)]:
- पुरानी बातचीत के संदर्भ को नए सवाल से जोड़कर रखें ताकि बातचीत की लय बनी रहे।
- यदि किसान भाई 'उसका', 'उन्हें', 'उनका हिसाब', 'पिछला' जैसा सर्वनाम बोले, तो पिछली बातचीत से समझें कि किस ग्राहक या विषय की बात हो रही है।

[बटन के रंग व स्क्रीन की सटीक जानकारी]:
1. ग्राहक जोड़ना: 'ग्राहक' स्क्रीन (Customer Tab) पर नीचे दाएँ कोने में नया ग्राहक जोड़ने वाला बटन 'लाल' (Red / Royal Orange) रंग का गोल बटन ('+ नया किसान जोड़ें') है। इस पर टैप करके किसान का नाम, पिता का नाम और मोबाइल नंबर दर्ज करें।
2. सत्र शुरू करना: होम स्क्रीन पर नया सिंचाई सत्र चालू करने का बटन 'हरा' (Green) रंग का ('▶ नया सत्र' / 'स्टार्ट टाइमर') होता है।
3. पैसे जमा करना: ग्राहक के खाते में '₹ भुगतान जमा करें' या '+ जमा करें' बटन दबाकर जमा राशि भरें।
4. पर्ची व रसीद: ग्राहक के खाते में 'सेंड पर्ची' (WhatsApp) का 'हरा' बटन है जिससे व्हाट्सएप पर पूरी रसीद और बकाया जाता है।
5. वीआईपी प्लान (विज्ञापन बंद): सेटिंग्स में '👑 VIP सदस्यता' कार्ड है (मासिक ₹99, वार्षिक ₹799)।
6. ईमेल व प्रोफाइल: सेटिंग्स में 'प्रोफ़ाइल संपादित करें' में ईमेल व फोन नंबर देख व बदल सकते हैं।
7. ऐप शेयर व सपोर्ट: सेटिंग्स में 'शेयर ऐप' और 'हेल्प एवं सपोर्ट' विकल्प हैं।

[पूरा व स्पष्ट उत्तर देने का नियम]:
- यदि किसान भाई 'डिटेल से बताओ', 'विस्तार से बताओ' या प्रक्रिया पूछे, तो अधूरा उत्तर न दें! चरण दर चरण (Step 1, Step 2, Step 3) पूरा और आसान तरीका बताएं।
- वाक्य कभी बीच में न काटें, बात पूरी करके ही समाप्त करें।
- कुल बकाया पूछते समय अगर बहुत सारे किसान हैं, तो कुल संख्या और कुल बकाया रुपये बताएं और कहें कि किसी का भी नाम लेकर आप उसका अलग से पूरा हिसाब पूछ सकते हैं।

[सत्यता और विश्वसनीयता का नियम - कभी गलत उत्तर न दें]:
- जो भी जानकारी दें वह 100% सत्य, सटीक और तथ्यात्मक होनी चाहिए। कभी भी मनगढ़ंत या गलत जवाब न दें।
- यदि सवाल बही-खाते, ट्यूबवेल, या खेती-किसानी (खाद-बीज, मौसम, रोग-उपचार, दवा, पैदावार) का है, तो सर्वोत्तम और प्रामाणिक सलाह दें।
- यदि सवाल सामान्य ज्ञान या खेती से बाहर का है (जैसे देश-दुनिया, गणित, विज्ञान आदि), तो उसका भी बिल्कुल सही और आदरपूर्ण उत्तर दें।

[कृषि व ट्यूबवेल विशेषज्ञता]:
- ट्यूबवेल, मोटर, बोरवेल, बिजली बिल, सिंचाई, खाद-बीज, फसलों (गेहूं, धान, सरसों, गन्ना आदि) और खेती-बाड़ी से जुड़े सवालों का व्यावहारिक, सच्चा, वैज्ञानिक और किसान-हितैषी उत्तर दें।
$memorySection
दिए गए संदर्भ का उपयोग करें:
$contextData
            """.trimIndent()

            val requestJson = JSONObject().apply {
                // system_instruction
                val sysPart = JSONObject().apply { put("text", systemInstruction) }
                val sysParts = JSONArray().apply { put(sysPart) }
                val sysObj = JSONObject().apply { put("parts", sysParts) }
                put("systemInstruction", sysObj)

                // contents: support multi-turn conversation history
                val contentsArray = JSONArray()
                if (chatHistory.isNotEmpty()) {
                    chatHistory.forEachIndexed { index, msg ->
                        val roleStr = if (msg.role == "model") "model" else "user"
                        val textStr = if (index == 0 && msg.role != "model") {
                            "संदर्भ डेटा:\n$contextData\n\nकिसान भाई का सवाल: ${msg.text}"
                        } else {
                            msg.text
                        }
                        val turnObj = JSONObject().apply {
                            put("role", roleStr)
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply { put("text", textStr) })
                            })
                        }
                        contentsArray.put(turnObj)
                    }
                    // Append current voice query
                    val currentTurn = JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", userVoiceQuery) })
                        })
                    }
                    contentsArray.put(currentTurn)
                } else {
                    val contentObj = JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "संदर्भ डेटा:\n$contextData\n\nकिसान भाई का सवाल: $userVoiceQuery")
                            })
                        })
                    }
                    contentsArray.put(contentObj)
                }
                put("contents", contentsArray)

                // generationConfig (1200 tokens prevents any mid-sentence truncation in Indic scripts)
                val genConfig = JSONObject().apply {
                    put("temperature", 0.35)
                    put("maxOutputTokens", 1200)
                }
                put("generationConfig", genConfig)
            }

            // Strategy 1: If API key is available, call Google Gemini API directly!
            // First attempt with primary model (gemini-3.1-flash-lite-preview)
            if (apiKey.isNotBlank()) {
                val primaryUrl = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"
                val res1 = executeGeminiRequest(primaryUrl, apiKey, isProxy = false, requestJson = requestJson)
                if (res1.isSuccess) {
                    return@withContext res1
                }
                Log.w(TAG, "Primary Gemini model ($MODEL_NAME) failed: ${res1.exceptionOrNull()?.message}, trying fallback model: $FALLBACK_MODEL_NAME")

                // Fallback attempt with fallback model (gemini-flash-latest)
                val fallbackUrl = "https://generativelanguage.googleapis.com/v1beta/models/$FALLBACK_MODEL_NAME:generateContent?key=$apiKey"
                val res2 = executeGeminiRequest(fallbackUrl, apiKey, isProxy = false, requestJson = requestJson)
                if (res2.isSuccess) {
                    return@withContext res2
                }
                Log.w(TAG, "Fallback Gemini model ($FALLBACK_MODEL_NAME) failed: ${res2.exceptionOrNull()?.message}")
            }

            // Strategy 2: If Direct API failed or apiKey was blank, try Cloudflare Worker proxy if available!
            if (proxyUrl.isNotBlank()) {
                val resProxy = executeGeminiRequest(proxyUrl.trim(), "", isProxy = true, requestJson = requestJson)
                if (resProxy.isSuccess) {
                    return@withContext resProxy
                }
                Log.w(TAG, "Proxy URL failed: ${resProxy.exceptionOrNull()?.message}")
            }

            Result.failure(Exception("मुंशी जी उत्तर तैयार नहीं कर पाए, कृपया दोबारा पूछें।"))
        } catch (e: Exception) {
            Log.e(TAG, "Error calling Gemini: ${e.message}", e)
            Result.failure(Exception("कनेक्शन समस्या: ${e.localizedMessage ?: "इंटरनेट की जांच करें"}"))
        }
    }

    /**
     * Identifies questions specifically asking for agronomy, crop care, farming, weather,
     * seed rates, fertilizer doses, disease remedies, or seasonal advice.
     * These MUST bypass the offline ledger engine and consult Gemini AI.
     */
    fun isFarmingOrCropAdviceQuery(query: String): Boolean {
        val q = query.trim().lowercase(Locale.ROOT)
        val farmingKeywords = listOf(
            "फसल", "खेती", "कृषि", "गेहूं", "गेहू", "धान", "सरसों", "गन्ना", "मक्का", "बाजरा",
            "चना", "आलू", "प्याज", "सब्जी", "खाद", "यूरिया", "डीएपी", "dap", "कीट",
            "कीटनाशक", "रोग", "दवा", "कीड़ा", "कीड़े", "स्प्रे", "मौसम", "बारिश", "बुवाई",
            "बोना", "कटाई", "पैदावार", "उपज", "बीज", "खरपतवार", "निराई", "गुड़ाई",
            "ट्रैक्टर", "मिट्टी", "जमीन", "पलेवा", "खाद-बीज", "फर्टिलाइजर",
            "पोटाश", "जिंक", "सल्फर", "फंगस", "सुंडी", "दीमक", "माहू", "इल्ली",
            "कपास", "ज्वार", "मूंग", "उड़द", "मटर", "सोयाबीन", "लहसुन", "टमाटर"
        )
        return farmingKeywords.any { q.contains(it) }
    }

    /**
     * Returns true if query belongs to tubewell, ledger, crops, or farming domain.
     */
    fun isAgricultureOrTubewellQuery(query: String): Boolean {
        return !isOffTopicGeneralQuery(query)
    }

    /**
     * Determines if a query is completely outside the domain of:
     * 1. Tubewell / Irrigation / Electricity / Motor / Fuel
     * 2. Bahi-Khata / Ledger / Accounts / App operations / Customers
     * 3. Agriculture / Farming / Crops / Weather / Fertilizers
     * 4. Basic greetings & voice follow-ups
     */
    /**
     * Intelligent check to filter out queries completely unrelated to:
     * 1. Tubewell / Boring / Motor / Irrigation / Diesel / Electricity
     * 2. Bahi-Khata / Ledger / Accounts / Dues / Aging / Customers / Bills
     * 3. Agriculture / Farming / Crops / Weather / Fertilizers / Pests
     * 4. Basic greetings & voice follow-ups
     */
    fun isOffTopicGeneralQuery(query: String): Boolean {
        // First normalize any phonetic STT issues (e.g. आधार -> उधार)
        val normalized = MunshiSmartLocalEngine.normalizeVoiceQuery(query)
        val q = normalized.trim().lowercase(Locale.ROOT)
        if (q.length < 3) return false

        // 1. App, Ledger, Debt & Tubewell Keywords
        val isAppOrTubewell = q.contains("ट्यूबवेल") || q.contains("नलकूप") || q.contains("सिंचाई") ||
                q.contains("पानी") || q.contains("पटाई") || q.contains("मोटर") || q.contains("बिजली") ||
                q.contains("डीजल") || q.contains("पाइप") || q.contains("मीटर") || q.contains("रीडिंग") ||
                q.contains("घंटे") || q.contains("सत्र") || q.contains("सेशन") || q.contains("sechan") ||
                q.contains("हिसाब") || q.contains("बही") || q.contains("खाता") || q.contains("बकाया") ||
                q.contains("बाकी") || q.contains("उधार") || q.contains("उधारी") || q.contains("कर्ज") ||
                q.contains("लेनदारी") || q.contains("देनदारी") || q.contains("चुकता") || q.contains("बैलेंस") ||
                q.contains("ड्यू") || q.contains("तगादा") || q.contains("वसूली") || q.contains("जमा") ||
                q.contains("रुपये") || q.contains("पैसा") || q.contains("रेट") || q.contains("दर") ||
                q.contains("भाव") || q.contains("ग्राहक") || q.contains("किसान") || q.contains("कस्टमर") ||
                q.contains("पर्ची") || q.contains("रसीद") || q.contains("बिल") || q.contains("व्हाट्सएप") ||
                q.contains("शेयर") || q.contains("रिपोर्ट") || q.contains("पीडीएफ") || q.contains("ऐड") ||
                q.contains("विज्ञापन") || q.contains("वीआईपी") || q.contains("प्लान") || q.contains("सेटिंग") ||
                q.contains("प्रोफाइल") || q.contains("ईमेल") || q.contains("पासवर्ड") || q.contains("पिन") ||
                q.contains("बैकअप") || q.contains("सिंक") || q.contains("लॉगआउट") || q.contains("सपोर्ट") ||
                q.contains("हेल्प") || q.contains("डिलीट") || q.contains("जोड़") || q.contains("ग्रह") ||
                q.contains("किस") || q.contains("बटन") || q.contains("साल") || q.contains("महीने") ||
                q.contains("महीना") || q.contains("दिन") || q.contains("पुराना") || q.contains("पुराने") ||
                q.contains("लोगों") || q.contains("लोग") || q.contains("कितने") || q.contains("कितना") ||
                q.contains("किसका") || q.contains("किनका") || q.contains("कितनों") || q.contains("लेना") ||
                q.contains("देना") || q.contains("कमाई") || q.contains("खर्चा") || q.contains("मुनाफा") ||
                q.contains("बोरिंग") || q.contains("सबमर्सिबल") ||
                q.contains("जनवरी") || q.contains("फरवरी") || q.contains("मार्च") || q.contains("अप्रैल") ||
                q.contains("मई") || q.contains("जून") || q.contains("जुलाई") || q.contains("अगस्त") ||
                q.contains("सितंबर") || q.contains("अक्टूबर") || q.contains("नवंबर") || q.contains("दिसंबर")

        if (isAppOrTubewell) return false

        // 2. Agriculture & Farming Keywords
        val isFarming = q.contains("खेती") || q.contains("फसल") || q.contains("गेहूं") || q.contains("धान") ||
                q.contains("सरसों") || q.contains("गन्ना") || q.contains("मक्का") || q.contains("बाजरा") ||
                q.contains("चना") || q.contains("आलू") || q.contains("प्याज") || q.contains("सब्जी") ||
                q.contains("कपास") || q.contains("सोयाबीन") || q.contains("मूंग") || q.contains("उड़द") ||
                q.contains("मटर") || q.contains("लहसुन") || q.contains("टमाटर") || q.contains("मिर्च") ||
                q.contains("खाद") || q.contains("यूरिया") || q.contains("डीएपी") || q.contains("एनपीके") ||
                q.contains("जिंक") || q.contains("पोटाश") || q.contains("कीट") || q.contains("कीटनाशक") ||
                q.contains("रोग") || q.contains("दवा") || q.contains("मौसम") || q.contains("बारिश") ||
                q.contains("बुवाई") || q.contains("कटाई") || q.contains("जमीन") || q.contains("खेत") ||
                q.contains("मिट्टी") || q.contains("कीड़ा") || q.contains("स्प्रे") || q.contains("ट्रैक्टर") ||
                q.contains("जुताई") || q.contains("बीज") || q.contains("पैदावार") || q.contains("उपज") ||
                q.contains("चारा") || q.contains("पशु") || q.contains("गाय") || q.contains("भैंस")

        if (isFarming) return false

        // 3. Conversational / Greetings / Follow-ups
        val isConversational = q.contains("डिटेल") || q.contains("विस्तार") || q.contains("समझ") ||
                q.contains("फिर से") || q.contains("क्या बोला") || q.contains("नमस्ते") || q.contains("राम राम") ||
                q.contains("प्रणाम") || q.contains("हेलो") || q.contains("सुनो") || q.contains("मुंशी") ||
                q.contains("धन्यवाद") || q.contains("शुक्रिया") || q.contains("का हाल") || q.contains("के हाल") ||
                q.contains("जय जवान") || q.contains("जय किसान")

        if (isConversational) return false

        // If it matches none of the agriculture, ledger or app domains (e.g. "भारत का प्रधानमंत्री कौन है", "क्रिकेट", "फिल्म")
        return true
    }
}
