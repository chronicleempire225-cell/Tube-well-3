package com.example.data.remoteconfig

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Date

/**
 * AppOpenAdManager - Manages Google AdMob App Open Ads following official Google Publisher Policies.
 *
 * Strict Policy & Business Rules:
 * 1. ONE AD PER SCREEN / ZERO OVERLAP: Tracks isAppOpenAdShowing so banner ads stay hidden until App Open Ad is closed.
 * 2. SHOW ONCE PER LAUNCH/SESSION: Displays strictly ONCE per app launch session.
 * 3. VIP ONLY AD-FREE: Only active VIP membership disables App Open Ads and Banner Ads.
 * 4. REMOTE CONFIG & SUPABASE TOGGLE: Can be controlled remotely via Supabase table 'app_remote_config' (screen_name='APP_OPEN').
 * 5. ROBUST PRELOAD & TIMEOUT: If ad is still loading when splash completes, waits up to maxWaitMs to show, then gracefully continues.
 */
object AppOpenAdManager {

    private const val TAG = "AppOpenAdManager"

    // Official Google AdMob Test App Open Ad Unit ID
    const val DEFAULT_TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"

    // Live reference to the current foreground Activity
    var currentActivity: Activity? = null

    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAd = false
    private var loadTime: Long = 0

    // List of pending callbacks waiting for ad load
    private val pendingCallbacks = mutableListOf<(Boolean) -> Unit>()

    // Tracks if an App Open Ad is currently taking up full screen
    private val _isAppOpenAdShowing = MutableStateFlow(false)
    val isAppOpenAdShowing: StateFlow<Boolean> = _isAppOpenAdShowing.asStateFlow()

    // Tracks last status message for transparency/debugging
    private val _lastStatus = MutableStateFlow("आइडल (प्रतीक्षा में)")
    val lastStatus: StateFlow<String> = _lastStatus.asStateFlow()

    private var loadingStartTime = 0L
    private var lastShownTimeMs = 0L

    // Flag: Only show once per app launch/session
    var hasShownInThisSession = false
        private set

    /**
     * Checks if a cached ad exists and was loaded less than 4 hours ago.
     */
    fun isAdAvailable(): Boolean {
        val isNotExpired = (Date().time - loadTime) < (4L * 3600000L)
        return appOpenAd != null && isNotExpired
    }

    /**
     * Preloads an App Open Ad in background on the Main Thread.
     */
    fun loadAd(context: Context, onResult: ((Boolean) -> Unit)? = null) {
        val mainHandler = Handler(Looper.getMainLooper())
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { loadAd(context, onResult) }
            return
        }

        // Do not load if user is VIP
        if (RemoteConfigService.isAdFreeUser.value) {
            Log.d(TAG, "User is VIP - skipping App Open Ad load.")
            _lastStatus.value = "VIP यूजर (ऐड बंद)"
            onResult?.invoke(false)
            return
        }

        // Check if remote config has App Open ads enabled
        val config = RemoteConfigService.configsFlow.value["APP_OPEN"]
        if (config != null && !config.isEnabled) {
            Log.d(TAG, "App Open Ad is disabled by Remote Config (Supabase).")
            _lastStatus.value = "रिमोट कॉन्फ़िग द्वारा बंद"
            onResult?.invoke(false)
            return
        }

        if (isAdAvailable()) {
            _lastStatus.value = "ऐड पहले से लोड है (तैयार)"
            onResult?.invoke(true)
            return
        }

        if (onResult != null) {
            pendingCallbacks.add(onResult)
        }

        // Recovery: If previously stuck loading for > 15 seconds, reset and allow retry
        val now = System.currentTimeMillis()
        if (isLoadingAd && (now - loadingStartTime < 15_000L)) {
            _lastStatus.value = "ऐड लोड हो रहा है..."
            return
        }

        isLoadingAd = true
        loadingStartTime = now
        val rawUnitId = config?.adUnitId?.trim() ?: ""
        val isValidFormat = rawUnitId.matches(Regex("""^ca-app-pub-\d+/\d+$"""))
        val isPlaceholder = rawUnitId.contains("YOUR_AD_ID", ignoreCase = true) ||
                rawUnitId.contains("PLACEHOLDER", ignoreCase = true) ||
                rawUnitId.contains("XXX", ignoreCase = true)

        val adUnitId = if (rawUnitId.isNotBlank() &&
            isValidFormat &&
            !isPlaceholder &&
            !rawUnitId.contains("6300978111") &&
            rawUnitId != AdSlotConfig.GOOGLE_TEST_BANNER_ID
        ) {
            rawUnitId
        } else {
            DEFAULT_TEST_APP_OPEN_ID
        }
        _lastStatus.value = "AdMob अनुरोध भेजा जा रहा है ($adUnitId)..."
        Log.d(TAG, "Loading App Open Ad with Unit ID: $adUnitId (raw was '$rawUnitId')")

        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context.applicationContext,
            adUnitId,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    Log.d(TAG, "✅ App Open Ad loaded successfully.")
                    appOpenAd = ad
                    isLoadingAd = false
                    loadTime = Date().time
                    _lastStatus.value = "✅ विज्ञापन लोड हो गया"

                    val callbacks = ArrayList(pendingCallbacks)
                    pendingCallbacks.clear()
                    callbacks.forEach { it.invoke(true) }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "❌ App Open Ad failed to load: ${loadAdError.message} (code=${loadAdError.code})")
                    isLoadingAd = false
                    appOpenAd = null
                    _lastStatus.value = "❌ लोड विफल (कोड: ${loadAdError.code}): ${loadAdError.message}"

                    val callbacks = ArrayList(pendingCallbacks)
                    pendingCallbacks.clear()
                    callbacks.forEach { it.invoke(false) }
                }
            }
        )
    }

    /**
     * Shows the App Open Ad if available or waits up to maxWaitMs for it to finish loading.
     * If force = true, overrides previous session flag so it will display on Home page.
     */
    fun showAdOrWait(
        activity: Activity? = null,
        maxWaitMs: Long = 5000L,
        force: Boolean = false,
        onDone: () -> Unit
    ) {
        val mainHandler = Handler(Looper.getMainLooper())
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { showAdOrWait(activity, maxWaitMs, force, onDone) }
            return
        }

        val targetActivity = activity ?: currentActivity
        if (targetActivity == null || targetActivity.isFinishing || targetActivity.isDestroyed) {
            Log.d(TAG, "No valid activity available to show App Open Ad.")
            onDone()
            return
        }

        // 1. If user is VIP -> Never show
        if (RemoteConfigService.isAdFreeUser.value) {
            Log.d(TAG, "VIP user - suppressing App Open Ad.")
            onDone()
            return
        }

        // 2. Check Remote Config toggle
        val config = RemoteConfigService.configsFlow.value["APP_OPEN"]
        if (config != null && !config.isEnabled) {
            Log.d(TAG, "App Open Ad disabled via remote config / Supabase.")
            onDone()
            return
        }

        // 3. Rule: Check session / frequency
        if (force) {
            hasShownInThisSession = false
        } else if (hasShownInThisSession) {
            Log.d(TAG, "App Open Ad already shown in this session.")
            onDone()
            return
        }

        // 4. If ad already available, show immediately
        if (isAdAvailable() && appOpenAd != null) {
            displayLoadedAd(targetActivity, onDone)
            return
        }

        // 5. If ad is not ready, trigger load with timeout
        var isHandled = false

        val timeoutRunnable = Runnable {
            if (!isHandled) {
                isHandled = true
                Log.d(TAG, "App Open Ad wait timed out (${maxWaitMs}ms). Proceeding to app.")
                onDone()
            }
        }
        mainHandler.postDelayed(timeoutRunnable, maxWaitMs)

        loadAd(targetActivity) { success ->
            mainHandler.removeCallbacks(timeoutRunnable)
            if (!isHandled) {
                isHandled = true
                if (success && isAdAvailable() && !targetActivity.isFinishing && !targetActivity.isDestroyed) {
                    displayLoadedAd(targetActivity, onDone)
                } else {
                    onDone()
                }
            } else if (success && isAdAvailable() && !targetActivity.isFinishing && !targetActivity.isDestroyed && (!hasShownInThisSession || force)) {
                // Ad arrived shortly after timeout while user is still on screen: Show gracefully
                displayLoadedAd(targetActivity) {}
            }
        }
    }

    /**
     * Internal helper to display loaded ad with callbacks on main thread.
     */
    private fun displayLoadedAd(activity: Activity, onDismissed: () -> Unit) {
        val mainHandler = Handler(Looper.getMainLooper())
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { displayLoadedAd(activity, onDismissed) }
            return
        }

        val ad = appOpenAd
        if (ad == null || activity.isFinishing || activity.isDestroyed) {
            onDismissed()
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "App Open Ad displayed full screen.")
                _isAppOpenAdShowing.value = true
                hasShownInThisSession = true
                lastShownTimeMs = System.currentTimeMillis()
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "App Open Ad dismissed by user.")
                _isAppOpenAdShowing.value = false
                appOpenAd = null
                lastShownTimeMs = System.currentTimeMillis()
                onDismissed()
                // Preload next ad in background so future launches/opens have it ready
                loadAd(activity.applicationContext)
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "App Open Ad failed to show: ${adError.message}")
                _isAppOpenAdShowing.value = false
                appOpenAd = null
                onDismissed()
                // Preload next ad in background
                loadAd(activity.applicationContext)
            }
        }

        _isAppOpenAdShowing.value = true
        hasShownInThisSession = true
        ad.show(activity)
    }

    /**
     * Resets session state (e.g. on manual logout/restart).
     */
    fun resetSessionState() {
        hasShownInThisSession = false
    }
}
