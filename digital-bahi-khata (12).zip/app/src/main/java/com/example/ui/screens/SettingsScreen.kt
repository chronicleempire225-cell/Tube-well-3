package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import kotlinx.coroutines.launch
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.data.localization.AppLanguage
import com.example.data.remoteconfig.AppOpenAdManager
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.security.DatabaseEncryptionManager
import com.example.data.supabase.SupabaseAuthService
import com.example.data.util.EmailVerificationManager
import com.example.data.util.ShareHelper
import com.example.ui.components.AvatarView
import com.example.ui.components.RewardedAdUnlockDialog
import com.example.ui.components.VipSubscriptionDialog
import com.example.ui.components.appTextFieldColors
import com.example.ui.theme.*
import android.app.Activity
import android.content.ContextWrapper
import com.example.ui.viewmodel.BahiKhataViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val profile by viewModel.profile.collectAsState()
    val fontScale by viewModel.fontScale.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()

    val coroutineScope = rememberCoroutineScope()
    var showPinDialog by remember { mutableStateOf(false) }
    var showTipsDialog by remember { mutableStateOf(false) }
    var showEncryptionDetailsDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }
    var unsyncedSummary by remember { mutableStateOf<com.example.data.repository.BahiKhataRepository.UnsyncedDataSummary?>(null) }
    var isCheckingUnsynced by remember { mutableStateOf(false) }
    var isSyncingBeforeLogout by remember { mutableStateOf(false) }
    var logoutSyncError by remember { mutableStateOf<String?>(null) }

    // Form states for Owner & Tubewell profile
    var ownerName by remember(profile) { mutableStateOf(profile?.name ?: "Kisan Ramchandra") }
    var agencyName by remember(profile) { mutableStateOf(profile?.agencyName ?: "Kisan Tubewell & Sinchai Seva") }
    var phone by remember(profile) { mutableStateOf(profile?.phone ?: "9876543210") }
    var email by remember(profile) { mutableStateOf(profile?.email ?: "") }
    var isEmailVerified by remember(profile) { mutableStateOf(profile?.isEmailVerified ?: false) }
    var showEmailOtpDialog by remember { mutableStateOf(false) }
    var emailOtpInput by remember { mutableStateOf("") }
    var emailOtpError by remember { mutableStateOf<String?>(null) }
    var activeEmailVerificationToken by remember { mutableStateOf("") }
    var isSendingEmailOtp by remember { mutableStateOf(false) }
    var isVerifyingEmailOtp by remember { mutableStateOf(false) }
    var isCloudSupabaseOtp by remember { mutableStateOf(false) }
    var isSendingPinEmail by remember { mutableStateOf(false) }
    var isWaitingPinEmailConfirm by remember { mutableStateOf(false) }
    var pinResetEmailToken by remember { mutableStateOf("") }
    var rateText by remember(profile) {
        mutableStateOf(profile?.ratePerHour?.toInt()?.toString() ?: "160")
    }

    val isHindi = currentLang == AppLanguage.HINDI
    val featurePassExpiry by RemoteConfigService.featurePassExpiry.collectAsState()
    val isAdFreeUser by RemoteConfigService.isAdFreeUser.collectAsState()
    val vipDaysRemaining by RemoteConfigService.vipDaysRemaining.collectAsState()
    val vipExpiryTimestamp by RemoteConfigService.vipExpiryTimestamp.collectAsState()
    val vipPlanType by RemoteConfigService.planType.collectAsState()
    val pricingConfig by RemoteConfigService.pricingOffer.collectAsState()
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val isRewardedAdEnabled = RemoteConfigService.isRewardedAdEnabled()

    // Live sync pricing offers, ad configs, and VIP status from Supabase on opening Settings
    LaunchedEffect(profile?.phone, phone) {
        RemoteConfigService.fetchPricingOffersFromSupabase(context)
        RemoteConfigService.fetchFromSupabase(context)
        RemoteConfigService.checkAndRefreshVipStatus(context)
        val userPhone = profile?.phone ?: phone
        if (userPhone.isNotBlank()) {
            RemoteConfigService.checkAndRestorePremiumFromSupabase(context, userPhone, isManualTrigger = false)
        }
    }

    var isCheckingRestore by remember { mutableStateOf(false) }
    var showRewardedUnlockDialog by remember { mutableStateOf(false) }
    var showVipSubscriptionDialog by remember { mutableStateOf(false) }
    var showMunshiInfoDialog by remember { mutableStateOf(false) }

    if (showRewardedUnlockDialog) {
        RewardedAdUnlockDialog(
            featureName = "24-घंटे मैसेजिंग व PDF शेयरिंग",
            onDismiss = { showRewardedUnlockDialog = false },
            onUnlockSuccess = { showRewardedUnlockDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp)
    ) {
        // 1. Top Status Bar Line (Exact match with Image)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: LOCAL ACTIVE · READY
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2E7D32))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LOCAL ACTIVE · READY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                // Right: EN / हिंदी Language Toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFFF1F5F9))
                        .padding(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (!isHindi) Color.White else Color.Transparent,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable { viewModel.setLanguage(AppLanguage.ENGLISH) }
                    ) {
                        Text(
                            text = "EN",
                            fontWeight = if (!isHindi) FontWeight.Bold else FontWeight.Medium,
                            color = if (!isHindi) Color(0xFF1B5E20) else Color(0xFF64748B),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontSize = 11.sp
                        )
                    }

                    Surface(
                        color = if (isHindi) Color.White else Color.Transparent,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable { viewModel.setLanguage(AppLanguage.HINDI) }
                    ) {
                        Text(
                            text = "हिंदी",
                            fontWeight = if (isHindi) FontWeight.Bold else FontWeight.Medium,
                            color = if (isHindi) Color(0xFF1B5E20) else Color(0xFF64748B),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // 2. Green Header Banner (Exact match with Image)
        item {
            val ownerDisplayName = agencyName.ifBlank { "Kisan Tubewell & Sinchai Seva" }
            val currentRateVal = rateText.toIntOrNull() ?: (profile?.ratePerHour?.toInt() ?: 160)

            Surface(
                color = Color(0xFF1B5E20),
                shape = RoundedCornerShape(18.dp),
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Golden Drop in Amber Circle
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFA000)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = "Drop",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Title & Subtitle Column
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "सेटिंग्स व प्रोफाइल" else "Settings & Profile",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "📍 $ownerDisplayName • ₹$currentRateVal/hr Rate",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC8E6C9),
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Right Circular Initials Avatar
                    AvatarView(
                        name = ownerName.ifBlank { "KR" },
                        bgColor = 0xFFE65100,
                        size = 42,
                        shape = CircleShape
                    )
                }
            }
        }

        // 2.5 Card: "🎁 फ़ीचर्स पास / अनलॉक स्थिति" - When user is VIP, hide this completely!
        if (!isAdFreeUser) {
            item {
                val isPassActive = RemoteConfigService.isFeaturePassActive()
            val remainingText = RemoteConfigService.getRemainingFeaturePassTimeFormatted()

            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.5.dp, if (isPassActive) Color(0xFF16A34A) else Color(0xFFF59E0B)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_feature_pass_card")
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isPassActive) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPassActive) Icons.Default.CheckCircle else Icons.Default.PlayCircle,
                                    contentDescription = null,
                                    tint = if (isPassActive) Color(0xFF16A34A) else Color(0xFFD97706),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (!isRewardedAdEnabled) {
                                        if (isHindi) "🎉 सभी फ़ीचर्स अनलॉक" else "🎉 All Features Unlocked"
                                    } else {
                                        if (isHindi) "24 घंटे फ़ीचर्स पास" else "24-Hour Feature Pass"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A),
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = if (!isRewardedAdEnabled) {
                                        "मुफ़्त उपलब्ध (वीडियो देखना अनिवार्य नहीं)"
                                    } else if (isPassActive) {
                                        "मैसेजिंग व PDF अनलॉक है"
                                    } else {
                                        "वीडियो देखकर अनलॉक करें"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isPassActive) Color(0xFF16A34A) else Color(0xFFD97706),
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Surface(
                            color = if (isPassActive) Color(0xFFDCFCE7) else Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (isPassActive) Color(0xFF86EFAC) else Color(0xFFFDE68A))
                        ) {
                            Text(
                                text = if (!isRewardedAdEnabled) "मुफ़्त सक्रिय" else if (isPassActive) "सक्रिय" else "निष्क्रिय",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                color = if (isPassActive) Color(0xFF15803D) else Color(0xFFB45309),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (!isRewardedAdEnabled) {
                        Surface(
                            color = Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF15803D),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "व्यवस्थापक द्वारा रिवॉर्ड वीडियो बंद है। सभी प्रीमियम फ़ीचर्स (WhatsApp रसीद, PDF रिपोर्ट) आपके लिए मुफ़्त अनलॉक हैं!",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D),
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    } else if (isPassActive) {
                        Surface(
                            color = Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    tint = Color(0xFF15803D),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "शेष समय: $remainingText",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D),
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    // Feature List bullets
                    val reqSec = configs["REWARDED_FEATURE_UNLOCK"]?.requiredWatchSeconds ?: 0

                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "✓ WhatsApp व SMS रसीद मैसेजिंग",
                            fontSize = 12.sp,
                            color = Color(0xFF334155),
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "✓ PDF खाता रिपोर्ट निर्माण व शेयरिंग",
                            fontSize = 12.sp,
                            color = Color(0xFF334155),
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "✓ मुंशी AI वॉयस असिस्टेंट (बोलकर खाता व लाइव हिसाब)",
                            fontSize = 12.sp,
                            color = Color(0xFF15803D),
                            fontWeight = FontWeight.SemiBold
                        )
                        if (isRewardedAdEnabled) {
                            Text(
                                text = "🎬 एक छोटा वीडियो विज्ञापन देखना होगा (Google AdMob)",
                                fontSize = 11.5.sp,
                                color = Color(0xFF64748B),
                                fontWeight = FontWeight.Normal
                            )
                            Text(
                                text = "💡 बैनर विज्ञापन सामान्य रूप से चलते रहेंगे",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B),
                                fontWeight = FontWeight.Normal
                            )
                        }
                    }

                    // Watch Video Button (Only if Rewarded Ads are enabled by Admin)
                    if (isRewardedAdEnabled) {
                        Button(
                            onClick = { showRewardedUnlockDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPassActive) Color(0xFF15803D) else Color(0xFFD97706)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("settings_watch_rewarded_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isPassActive) "🎬 समय बढ़ाएं (नया वीडियो देखें)" else "🎬 वीडियो देखें (24 घंटे अनलॉक करें)",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }

        // 2.6 Card: "👑 VIP सदस्यता (Razorpay Ad-Free Plan)"
        item {
            val isOfferLive = pricingConfig.isOfferLiveNow()
            val effectiveMonthly = pricingConfig.getEffectiveMonthlyPrice().toInt()
            val effectiveYearly = pricingConfig.getEffectiveYearlyPrice().toInt()
            val shouldShowVipCard = isAdFreeUser || pricingConfig.isVipEnabled

            if (shouldShowVipCard) {
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.5.dp, if (isAdFreeUser) Color(0xFF16A34A) else if (isOfferLive) Color(0xFFF59E0B) else Color(0xFFCBD5E1)),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_vip_plan_card")
                ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (isAdFreeUser) Color(0xFFDCFCE7) else if (isOfferLive) Color(0xFFFEF3C7) else Color(0xFFF1F5F9)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = if (isAdFreeUser) Color(0xFF15803D) else if (isOfferLive) Color(0xFFD97706) else Color(0xFF475569),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isHindi) "👑 VIP सदस्यता (Ad-Free)" else "👑 VIP Membership (Ad-Free)",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = if (isAdFreeUser) {
                                        "सक्रिय • $vipDaysRemaining दिन शेष बचे हैं"
                                    } else if (isOfferLive) {
                                        "मासिक ₹$effectiveMonthly (ऑफर) | वार्षिक ₹$effectiveYearly (ऑफर)"
                                    } else {
                                        "मासिक ₹$effectiveMonthly | वार्षिक ₹$effectiveYearly"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isAdFreeUser) Color(0xFF15803D) else Color(0xFF64748B),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Surface(
                            color = if (isAdFreeUser) Color(0xFFDCFCE7) else if (isOfferLive) Color(0xFFFEF3C7) else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (isAdFreeUser) Color(0xFF86EFAC) else if (isOfferLive) Color(0xFFFDE68A) else Color(0xFFCBD5E1))
                        ) {
                            Text(
                                text = when {
                                    isAdFreeUser -> "$vipDaysRemaining दिन शेष"
                                    isOfferLive -> if (pricingConfig.bannerBadgeText.isNotBlank()) pricingConfig.bannerBadgeText else "ऑफर चालू 💥"
                                    else -> "मानक प्लान"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                color = if (isAdFreeUser) Color(0xFF15803D) else if (isOfferLive) Color(0xFFB45309) else Color(0xFF475569),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (isAdFreeUser) {
                        Surface(
                            color = Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.5.dp, Color(0xFF86EFAC)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF15803D),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "आप एक सम्मानित VIP सदस्य हैं! 👑",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D),
                                        fontSize = 14.sp
                                    )
                                }

                                // Days Remaining Highlight Box
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFDCFCE7),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "⏳ शेष वैधता (Days Left):",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF166534)
                                        )
                                        Text(
                                            text = "$vipDaysRemaining दिन",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 16.sp,
                                            color = Color(0xFF15803D)
                                        )
                                    }
                                }

                                // Plan & Expiry Details
                                val planLabel = if (vipPlanType.contains("YEAR", ignoreCase = true)) "वार्षिक (Yearly Plan)" else "मासिक (Monthly Plan)"
                                val expiryFormatted = if (vipExpiryTimestamp > 0) {
                                    try {
                                        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN"))
                                        sdf.format(Date(vipExpiryTimestamp))
                                    } catch (_: Exception) {
                                        ""
                                    }
                                } else ""

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "सक्रिय प्लान: $planLabel",
                                        fontSize = 11.5.sp,
                                        color = Color(0xFF475569)
                                    )
                                    if (expiryFormatted.isNotBlank()) {
                                        Text(
                                            text = "समाप्ति: $expiryFormatted",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = Color(0xFF475569)
                                        )
                                    }
                                }

                                Text(
                                    text = "💡 नया प्लान खरीदने पर नए दिन आपके मौजूदा $vipDaysRemaining दिनों में अपने आप जुड़ जाएंगे।",
                                    fontSize = 11.sp,
                                    color = Color(0xFF15803D),
                                    lineHeight = 15.sp
                                )
                            }
                        }

                        // Extend Subscription Button
                        Button(
                            onClick = { showVipSubscriptionDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1B5E20)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("settings_extend_vip_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddCircle,
                                contentDescription = null,
                                tint = Color(0xFFFFEB3B),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "सदस्यता बढ़ाएं / Extend VIP (+दिन जुड़ेंगे)",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }

                        // Refresh VIP Status Button
                        OutlinedButton(
                            onClick = {
                                val userPhone = profile?.phone ?: phone
                                if (userPhone.isBlank()) {
                                    Toast.makeText(context, "कृपया पहले नीचे अपनी प्रोफ़ाइल में फ़ोन नंबर सहेजें!", Toast.LENGTH_LONG).show()
                                    return@OutlinedButton
                                }
                                isCheckingRestore = true
                                coroutineScope.launch {
                                    RemoteConfigService.checkAndRestorePremiumFromSupabase(
                                        context = context,
                                        rawPhone = userPhone,
                                        isManualTrigger = true
                                    ) { _, msg ->
                                        isCheckingRestore = false
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFF94A3B8)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("settings_refresh_vip_btn")
                        ) {
                            if (isCheckingRestore) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = Color(0xFF15803D)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "जांच हो रही है...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF475569)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh",
                                    tint = Color(0xFF475569),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "🔄 स्थिति व बचे हुए दिन रिफ्रेश करें",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF475569)
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "⚡ VIP पास जितने समय का खरीदेंगे उतने समय के लिए सभी फीचर्स पूरी तरह मुक्त हो जाएंगे, कोई वीडियो ऐड नहीं देखना पड़ेगा और सभी विज्ञापन 100% बंद रहेंगे।",
                            fontSize = 12.sp,
                            color = Color(0xFF475569),
                            lineHeight = 16.sp
                        )

                        Button(
                            onClick = { showVipSubscriptionDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1B5E20)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("settings_upgrade_vip_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ElectricBolt,
                                contentDescription = null,
                                tint = Color(0xFFFFEB3B),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "VIP प्लान चुनें (Razorpay UPI/Card)",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }

                        // Restore / Check VIP Button
                        OutlinedButton(
                            onClick = {
                                val userPhone = profile?.phone ?: phone
                                if (userPhone.isBlank()) {
                                    Toast.makeText(context, "कृपया पहले नीचे अपनी प्रोफ़ाइल में फ़ोन नंबर सहेजें!", Toast.LENGTH_LONG).show()
                                    return@OutlinedButton
                                }
                                isCheckingRestore = true
                                coroutineScope.launch {
                                    RemoteConfigService.checkAndRestorePremiumFromSupabase(
                                        context = context,
                                        rawPhone = userPhone,
                                        isManualTrigger = true
                                    ) { success, msg ->
                                        isCheckingRestore = false
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFF94A3B8)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("settings_restore_vip_btn")
                        ) {
                            if (isCheckingRestore) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = Color(0xFF15803D)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "जांच हो रही है...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF475569)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Restore",
                                    tint = Color(0xFF475569),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "🔄 ख़रीदारी रिस्टोर करें (पैसे कटने पर)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF475569)
                                )
                            }
                        }
                    }
                }
            }
        }
        }

        // 3. Card 1: "मालिक व समर प्रोफाइल" (Clean White HD Background with Editable Fields)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Card Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = Color(0xFF1B5E20),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🏪 मालिक व समर प्रोफाइल",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                fontSize = 16.sp
                            )
                        }

                        Surface(
                            color = Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Protected",
                                tint = Color(0xFF64748B),
                                modifier = Modifier
                                    .padding(6.dp)
                                    .size(16.dp)
                            )
                        }
                    }

                    // Field 1: मालिक का नाम
                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text("मालिक का नाम", fontWeight = FontWeight.Bold, color = Color(0xFF475569)) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = Color(0xFF1B5E20))
                        },
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF0F172A)
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_owner_name_input")
                    )

                    // Field 2: समर / ट्यूबवेल नाम
                    OutlinedTextField(
                        value = agencyName,
                        onValueChange = { agencyName = it },
                        label = { Text("समर / ट्यूबवेल नाम", fontWeight = FontWeight.Bold, color = Color(0xFF475569)) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.WaterDrop, contentDescription = null, tint = Color(0xFFFFA000))
                        },
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF0F172A)
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_agency_name_input")
                    )

                    // Field 3: मोबाइल नंबर
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("मोबाइल नंबर", fontWeight = FontWeight.Bold, color = Color(0xFF475569)) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color(0xFF1565C0))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF0F172A)
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_phone_input")
                    )

                    // Field 3.5: ईमेल आईडी (वैकल्पिक) एवं सत्यापन
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(
                            value = email,
                            onValueChange = {
                                email = it.trim()
                                if (it.trim() != (profile?.email ?: "")) {
                                    isEmailVerified = false
                                }
                            },
                            label = {
                                Text(
                                    text = if (isHindi) "ईमेल आईडी (वैकल्पिक / पासवर्ड रीसेट हेतु)" else "Email Address (Optional)",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF475569)
                                )
                            },
                            placeholder = { Text("जैसे: kisan@gmail.com") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = Color(0xFF0284C7))
                            },
                            trailingIcon = {
                                if (isEmailVerified && email.isNotBlank()) {
                                    Surface(
                                        color = Color(0xFFDCFCE7),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.padding(end = 8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Verified", tint = Color(0xFF16A34A), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("सत्यापित", color = Color(0xFF15803D), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                } else if (email.isNotBlank()) {
                                    FilledTonalButton(
                                        onClick = {
                                            if (!EmailVerificationManager.isValidEmail(email)) {
                                                Toast.makeText(context, "कृपया सही ईमेल पता दर्ज करें!", Toast.LENGTH_SHORT).show()
                                                return@FilledTonalButton
                                            }
                                            coroutineScope.launch {
                                                isSendingEmailOtp = true
                                                val res = EmailVerificationManager.sendEmailOtp(
                                                    context = context,
                                                    email = email,
                                                    purpose = "VERIFY_EMAIL",
                                                    farmerName = ownerName
                                                )
                                                isSendingEmailOtp = false
                                                activeEmailVerificationToken = res.token
                                                isCloudSupabaseOtp = res.isCloudSupabase
                                                emailOtpInput = ""
                                                emailOtpError = null
                                                showEmailOtpDialog = true
                                                Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                                            }
                                        },
                                        enabled = !isSendingEmailOtp,
                                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFE0F2FE), contentColor = Color(0xFF0369A1)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.padding(end = 6.dp)
                                    ) {
                                        if (isSendingEmailOtp) {
                                            CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp, color = Color(0xFF0369A1))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "भेज रहे हैं...", fontSize = 10.sp)
                                        } else {
                                            Text(text = "वेरीफाई करें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            textStyle = TextStyle(
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF0F172A)
                            ),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_email_input")
                        )
                        Text(
                            text = "💡 ईमेल जोड़ने से पासवर्ड भूलने पर बिना SMS शुल्क के तुरंत ईमेल OTP से रीसेट हो जाएगा।",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }

                    // Field 4: प्रति घंटा डिफ़ॉल्ट दर (₹) (₹/hr)
                    OutlinedTextField(
                        value = rateText,
                        onValueChange = { rateText = it },
                        label = { Text("प्रति घंटा डिफ़ॉल्ट दर (₹) (₹/hr)", fontWeight = FontWeight.Bold, color = Color(0xFF475569)) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.CurrencyRupee, contentDescription = null, tint = Color(0xFFE65100))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = TextStyle(
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_rate_input")
                    )

                    // Buttons Row: [सुरक्षित करें] & [पासवर्ड बदलें]
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                val rateVal = rateText.toDoubleOrNull() ?: 160.0
                                viewModel.saveOrUpdateProfile(
                                    name = ownerName,
                                    agencyName = agencyName,
                                    phone = phone,
                                    rate = rateVal,
                                    email = email.trim(),
                                    isEmailVerified = isEmailVerified
                                )
                                Toast.makeText(context, "प्रोफाइल सफलतापूर्वक सुरक्षित की गई!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "सुरक्षित करें",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { showPinDialog = true },
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF334155)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("change_pin_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockReset,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "पासवर्ड बदलें",
                                color = Color(0xFF334155),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // 4. Card 2: "🔤 अक्षर का आकार (फ़ॉन्ट साइज)" (Clean White HD Background)
        item {
            val scaleLabel = when {
                fontScale < 0.95f -> "Small (छोटा)"
                fontScale > 1.15f -> "Large (बड़ा)"
                else -> "Medium (मध्यम)"
            }

            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FormatSize,
                                contentDescription = null,
                                tint = Color(0xFF1B5E20),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🔤 अक्षर का आकार (फ़ॉन्ट साइज)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                fontSize = 15.sp
                            )
                        }

                        Surface(
                            color = Color(0xFFFFF3E0),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFFFE082))
                        ) {
                            Text(
                                text = scaleLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Text(
                        text = "Adjust text size for better readability across fields and bright sunlight.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B),
                        fontSize = 12.sp
                    )

                    // Slider Control
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "A",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Slider(
                            value = fontScale,
                            onValueChange = { viewModel.setFontScale(it) },
                            valueRange = 0.85f..1.35f,
                            steps = 4,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFE65100),
                                activeTrackColor = Color(0xFF1B5E20),
                                inactiveTrackColor = Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_font_scale_slider")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "A",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }

                    // Live sample preview box
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🌾 नमूना: ट्यूबवेल चले 3.5 घंटे • दर ₹${rateText}/घंटा • कुल ₹${((rateText.toDoubleOrNull() ?: 160.0) * 3.5).toInt()}",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 5. Card 3: "☁️ Cloud & Local Sync" (Clean White HD Background)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = null,
                                tint = Color(0xFF1B5E20),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "☁️ Cloud & Local Sync",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                fontSize = 15.sp
                            )
                        }

                        Surface(
                            color = Color(0xFFE8F5E9),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFC8E6C9))
                        ) {
                            Text(
                                text = "All Data Synced",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B5E20),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Text(
                        text = "100% सुरक्षित स्थानीय डाटाबेस। इंटरनेट बंद होने पर भी आप बेफिक्र हिसाब रखें, इंटरनेट आते ही सुरक्षित सिंक हो जाएगा।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B),
                        fontSize = 12.sp
                    )

                    Button(
                        onClick = { viewModel.triggerSync() },
                        enabled = !isSyncing,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("manual_sync_button")
                    ) {
                        if (isSyncing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("क्लाउड सिंक हो रहा है...", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Sync,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("डेटा अभी सिंक करें", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // 🌾 मुंशी जी (AI वॉइस सहायक) Card
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        showMunshiInfoDialog = true
                    }
                    .testTag("munshi_gemini_settings_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5E9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🌾", fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "मुंशी जी (AI वॉइस सहायक)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "🟢 सक्रिय (24×7 वॉइस व बही-खाता सहायक)",
                            fontSize = 12.sp,
                            color = Color(0xFF15803D),
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8)
                    )
                }
            }
        }

        // 🛡️ Card: "🔐 डेटाबेस सुरक्षा (AES-256 बिट एन्क्रिप्टेड / Encryption at Rest)"
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showEncryptionDetailsDialog = true }
                    .testTag("database_encryption_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Encrypted Database",
                            tint = Color(0xFF15803D),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "डेटाबेस सुरक्षा (AES-256)",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                style = MaterialTheme.typography.titleSmall,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = Color(0xFFDCFCE7),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "सक्रिय 🔒",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "SQLCipher + KeyStore (फोन मेमोरी में 100% डेटा लॉक)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8)
                    )
                }
            }
        }

        // 7. Card 5: "🌾 ट्यूबवेल व मोटर रखरखाव टिप्स" (Clean White HD Background)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showTipsDialog = true }
                    .testTag("tubewell_tips_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFF3E0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = null,
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🌾 ट्यूबवेल व मोटर रखरखाव टिप्स",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "बिजली वोल्टेज, स्टार्टर व पाइपलाइन सुरक्षा गाइड",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8)
                    )
                }
            }
        }

        // 8. Card: "⭐ ऐप को 5-स्टार रेटिंग दें / Rate App" (Clean White HD Card)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFFEF08A)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { ShareHelper.rateApp(context) }
                    .testTag("settings_rate_app_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEF9C3)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Rate App",
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "⭐ ऐप को 5-स्टार रेटिंग दें" else "⭐ Rate Us 5 Stars",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isHindi) "ऐप स्टोर पर रिव्यू व रेटिंग देकर हमारा मनोबल बढ़ाएं" else "Give your valuable review and rating on App Store",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Open Store",
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 9. Card: "📢 दोस्तों व किसान भाइयों के साथ शेयर करें / Share App" (Clean White HD Card)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { ShareHelper.shareAppWithFriends(context) }
                    .testTag("settings_share_app_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share App",
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "📢 किसान भाइयों के साथ शेयर करें" else "📢 Share App with Friends",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isHindi) "WhatsApp या SMS पर ऐप डाउनलोड लिंक भेजें" else "Share app download link via WhatsApp or SMS",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = Color(0xFF16A34A),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 10. Card: "🎧 सहायता व सपोर्ट / Support & Help" (Clean White HD Card)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { ShareHelper.openSupportEmail(context) }
                    .testTag("settings_support_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5E9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HeadsetMic,
                            contentDescription = "Support",
                            tint = Color(0xFF1B5E20),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "🎧 सहायता व संपर्क / Support & Help" else "🎧 Support & Help",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ईमेल: tubewellsupport@gmail.com • कोई भी समस्या या सुझाव साझा करें",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Mail,
                        contentDescription = "Email Support",
                        tint = Color(0xFF1B5E20),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 9. Card: "📜 नियम एवं गोपनीयता नीति / Terms & Privacy Policy" (Clean White HD Card)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { ShareHelper.openPrivacyPolicy(context) }
                    .testTag("settings_terms_policy_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = "Terms and Privacy Policy",
                            tint = Color(0xFF1D4ED8),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "📜 नियम, शर्तें एवं गोपनीयता नीति" else "📜 Terms & Privacy Policy",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            style = MaterialTheme.typography.titleSmall,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isHindi) "उपयोग के नियम, शर्तें और प्राइवेसी पॉलिसी पढ़ें" else "Read Terms of Service & Privacy Policy",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Open Link",
                        tint = Color(0xFF1D4ED8),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 10. Card: "🚪 लॉगआउट / Logout" (Clean White HD Card with Red Accent)
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFFECACA)),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = {
                        logoutSyncError = null
                        isCheckingUnsynced = true
                        coroutineScope.launch {
                            val summary = viewModel.getUnsyncedSummary()
                            unsyncedSummary = summary
                            isCheckingUnsynced = false
                            showLogoutDialog = true
                        }
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB71C1C)),
                    border = BorderStroke(0.dp, Color.Transparent),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("logout_button")
                ) {
                    if (isCheckingUnsynced) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color(0xFFB71C1C),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "जांच रहे हैं...",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB71C1C),
                            fontSize = 14.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = null,
                            tint = Color(0xFFB71C1C),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "खाता लॉगआउट करें" else "Logout Account",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB71C1C),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // 11. Footer: App Info & Quick Policy Link
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "किसान ट्यूबवेल व डिजिटल बहीखाता v1.0 • Soft Empire",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { ShareHelper.openPrivacyPolicy(context) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Terms of Service & Privacy Policy",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF1B5E20),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = null,
                        tint = Color(0xFF1B5E20),
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }

    // Change PIN Dialog
    if (showPinDialog) {
        var oldPin by remember { mutableStateOf("") }
        var newPin by remember { mutableStateOf("") }
        var isVisible by remember { mutableStateOf(true) }
        var err by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(18.dp),
            title = {
                Text(
                    text = "सुरक्षा पिन बदलें",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(onClick = { isVisible = !isVisible }) {
                        Text(
                            text = if (isVisible) "पिन छिपाएं" else "पिन दिखाएं",
                            color = Color(0xFFE65100),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = oldPin,
                        onValueChange = { if (it.length <= 4) oldPin = it },
                        label = { Text("पुराना पिन (वैकल्पिक)") },
                        visualTransformation = if (isVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { if (it.length <= 4) newPin = it },
                        label = { Text("नया 4-अंकों का पिन") },
                        visualTransformation = if (isVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        colors = appTextFieldColors(containerColor = Color.White, focusedBorderColor = Color(0xFF1B5E20)),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (err != null) {
                        Text("⚠️ $err", color = Color(0xFFB71C1C), style = MaterialTheme.typography.bodySmall)
                    }

                    // Email verification alternative
                    if (email.isNotBlank()) {
                        Surface(
                            color = Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Email,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "आसान तरीका: ईमेल लिंक से सेट करें",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF15803D)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "नया पिन दर्ज कर नीचे क्लिक करें। आपके ईमेल ($email) पर लिंक जाएगा, वहां कन्फर्म करते ही पासवर्ड सेट हो जाएगा!",
                                    fontSize = 11.sp,
                                    color = Color(0xFF334155),
                                    lineHeight = 14.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                if (isWaitingPinEmailConfirm) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color(0xFF16A34A))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("ईमेल में कन्फर्म का इंतज़ार कर रहे हैं...", fontSize = 11.5.sp, color = Color(0xFF15803D), fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    OutlinedButton(
                                        onClick = { EmailVerificationManager.openEmailClient(context) },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(vertical = 2.dp)
                                    ) {
                                        Text("📧 ईमेल ऐप खोलें", fontSize = 11.sp, color = Color(0xFF0284C7))
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = {
                                            if (newPin.length != 4) {
                                                err = "कृपया पहले नया 4-अंकों का पिन दर्ज करें!"
                                                return@OutlinedButton
                                            }
                                            coroutineScope.launch {
                                                isSendingPinEmail = true
                                                val res = EmailVerificationManager.sendEmailOtp(
                                                    context = context,
                                                    email = email,
                                                    purpose = "RESET_PASSWORD",
                                                    newPin = newPin,
                                                    farmerName = ownerName
                                                )
                                                isSendingPinEmail = false
                                                pinResetEmailToken = res.token
                                                isWaitingPinEmailConfirm = true
                                                Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                                            }
                                        },
                                        enabled = !isSendingPinEmail,
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF15803D)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        if (isSendingPinEmail) {
                                            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = Color(0xFF15803D))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("लिंक भेज रहे हैं...", fontSize = 11.5.sp)
                                        } else {
                                            Text("✉️ ईमेल पर कन्फर्मेशन लिंक भेजें", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val currentSavedPin = profile?.pinHash ?: ""
                        if (currentSavedPin.isNotBlank() && oldPin.isNotBlank() && oldPin != currentSavedPin) {
                            err = "पुराना पिन गलत है!"
                        } else if (newPin.length != 4) {
                            err = "नया पिन 4 अंकों का होना चाहिए!"
                        } else {
                            viewModel.updateOwnerPin(newPin)
                            showPinDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("पिन अपडेट करें", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { 
                    showPinDialog = false 
                    isWaitingPinEmailConfirm = false
                }) {
                    Text("रद्द करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                }
            }
        )

        // Live Auto-Detection for Password/Pin confirmation from Email Link
        LaunchedEffect(isWaitingPinEmailConfirm, pinResetEmailToken) {
            if (!isWaitingPinEmailConfirm) return@LaunchedEffect
            while (isWaitingPinEmailConfirm && showPinDialog) {
                kotlinx.coroutines.delay(2500L)
                val isConfirmed = EmailVerificationManager.checkAutoVerificationStatus(
                    context = context,
                    email = email,
                    token = pinResetEmailToken
                )
                if (isConfirmed) {
                    viewModel.updateOwnerPin(newPin)
                    isWaitingPinEmailConfirm = false
                    showPinDialog = false
                    Toast.makeText(context, "🎉 बधाई हो! नया पासवर्ड/पिन ईमेल से कन्फर्म होकर सेट हो गया!", Toast.LENGTH_LONG).show()
                    break
                }
            }
        }
    }

    // Live Auto-Detection for Email Verification confirmation from Email Link or Deep Link
    LaunchedEffect(showEmailOtpDialog, activeEmailVerificationToken, email) {
        if (!showEmailOtpDialog) return@LaunchedEffect
        // Immediate check for deep link confirmation
        if (EmailVerificationManager.isEmailConfirmed(email)) {
            isEmailVerified = true
            viewModel.updateOwnerEmail(email, true)
            showEmailOtpDialog = false
            return@LaunchedEffect
        }
        while (showEmailOtpDialog && !isEmailVerified) {
            kotlinx.coroutines.delay(2000L)
            val isConfirmed = EmailVerificationManager.isEmailConfirmed(email) ||
                EmailVerificationManager.checkAutoVerificationStatus(
                    context = context,
                    email = email,
                    token = activeEmailVerificationToken
                )
            if (isConfirmed) {
                isEmailVerified = true
                viewModel.updateOwnerEmail(email, true)
                showEmailOtpDialog = false
                Toast.makeText(context, "🎉 बधाई हो! ईमेल लिंक से स्वतः सत्यापित हो गया!", Toast.LENGTH_LONG).show()
                break
            }
        }
    }

    // Pure Email Link Verification Dialog (No OTP input needed)
    if (showEmailOtpDialog) {
        AlertDialog(
            onDismissRequest = { showEmailOtpDialog = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MarkEmailRead,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "ईमेल सत्यापन",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "एक क्लिक में पुष्टि करें",
                            fontSize = 11.5.sp,
                            color = Color(0xFF16A34A),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Email address highlight card
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "✉️ हमने इस ईमेल पर पुष्टि लिंक भेजा है:",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = email,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                        }
                    }

                    // Open Email App button (Primary Action)
                    Button(
                        onClick = { EmailVerificationManager.openEmailClient(context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "📧 ईमेल ऐप खोलें (Open Inbox)",
                            fontSize = 13.5.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Real-time live confirmation detector status
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.5.dp,
                                    color = Color(0xFF16A34A)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ईमेल में 'Confirm' का इंतज़ार कर रहे हैं...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ईमेल खोलकर 'Confirm' या 'Sign in' पर क्लिक करते ही यह स्क्रीन अपने आप हट जाएगी और ईमेल सुरक्षित रूप से जुड़ जाएगा!",
                                fontSize = 11.sp,
                                color = Color(0xFF334155),
                                textAlign = TextAlign.Center,
                                lineHeight = 15.sp
                            )
                        }
                    }

                    // Resend link button
                    TextButton(
                        onClick = {
                            coroutineScope.launch {
                                isSendingEmailOtp = true
                                val res = EmailVerificationManager.sendEmailOtp(
                                    context = context,
                                    email = email,
                                    purpose = "VERIFY_EMAIL",
                                    farmerName = ownerName
                                )
                                isSendingEmailOtp = false
                                activeEmailVerificationToken = res.token
                                Toast.makeText(context, "✉️ नया लिंक दोबारा भेज दिया गया है!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = !isSendingEmailOtp
                    ) {
                        Text(
                            text = if (isSendingEmailOtp) "भेज रहे हैं..." else "🔄 ईमेल नहीं आया? दोबारा लिंक भेजें",
                            fontSize = 11.5.sp,
                            color = Color(0xFF0284C7),
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Divider for 2nd phone or alternate OTP entry
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFE2E8F0))
                        Text(
                            text = " या ईमेल का ओटीपी (OTP) यहाँ दर्ज करें ",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            fontWeight = FontWeight.Medium
                        )
                        HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFE2E8F0))
                    }

                    // OTP input option for when email is on another phone/laptop
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ईमेल में आया असली ओटीपी (OTP) दर्ज करें:",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF334155)
                            )
                        }

                        OutlinedTextField(
                            value = emailOtpInput,
                            onValueChange = {
                                val clean = it.filter { ch -> ch.isDigit() }.take(8)
                                emailOtpInput = clean
                                emailOtpError = null
                            },
                            placeholder = { Text("6 या 8 अंकों का ओटीपी (जैसे: 15364960)", fontSize = 13.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC), focusedBorderColor = Color(0xFF16A34A)),
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (emailOtpError != null) {
                            Text(
                                text = "⚠️ $emailOtpError",
                                color = Color(0xFFB71C1C),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isVerifyingEmailOtp = true
                                    val verifyRes = EmailVerificationManager.verifyOtp(context, email, emailOtpInput)
                                    isVerifyingEmailOtp = false
                                    if (verifyRes.isSuccess) {
                                        isEmailVerified = true
                                        viewModel.updateOwnerEmail(email, true)
                                        showEmailOtpDialog = false
                                        Toast.makeText(context, "🎉 ईमेल क्लाउड में सफलतापूर्वक सत्यापित हो गया!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        emailOtpError = verifyRes.message
                                    }
                                }
                            },
                            enabled = !isVerifyingEmailOtp && emailOtpInput.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp)
                        ) {
                            if (isVerifyingEmailOtp) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("जांच रहे हैं...", color = Color.White, fontSize = 13.sp)
                            } else {
                                Text("कोड से सत्यापित करें ✓", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showEmailOtpDialog = false }) {
                    Text("रद्द करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Tubewell Maintenance Tips Dialog
    if (showTipsDialog) {
        AlertDialog(
            onDismissRequest = { showTipsDialog = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(18.dp),
            title = {
                Text(
                    text = "🌾 ट्यूबवेल व मोटर सुरक्षा निर्देश",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "1. ⚡ वोल्टेज जांच: मोटर चलाने से पहले वोल्टेज 380V-420V अवश्य जांचें।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "2. 🔌 स्टार्टर रिले: रिले की ओवरलोड सेटिंग सही एम्पियर पर रखें।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "3. 💧 पानी की धार: यदि मोटर हवा ले रही हो या पानी कम फेंक रही हो, तो तुरंत मोटर बंद करें।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "4. 🛢️ ग्रीसिंग व सर्विस: हर फसल चक्र के बाद मोटर की ग्रीसिंग और सील चेक करें।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "5. 📱 पर्ची तुरंत दें: विवाद से बचने के लिए मोटर बंद होते ही किसान को WhatsApp पर्ची भेजें।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF334155)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showTipsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("ठीक है", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Logout Guard & Unsynced Data Dialog
    if (showLogoutDialog) {
        val hasUnsynced = unsyncedSummary?.hasUnsynced == true

        AlertDialog(
            onDismissRequest = {
                if (!isSyncingBeforeLogout) {
                    showLogoutDialog = false
                    logoutSyncError = null
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            icon = {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (hasUnsynced) Color(0xFFFEF3C7) else Color(0xFFFEE2E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (hasUnsynced) Icons.Default.Warning else Icons.Default.ExitToApp,
                        contentDescription = null,
                        tint = if (hasUnsynced) Color(0xFFD97706) else Color(0xFFDC2626),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = if (hasUnsynced) "⚠️ सिंक नहीं हुआ डेटा मिला!" else "खाता लॉगआउट करें",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (hasUnsynced) {
                        Text(
                            text = unsyncedSummary?.message ?: "आपके फोन में कुछ ऑफलाइन हिसाब अभी क्लाउड पर नहीं भेजा गया है।",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF0F172A)
                        )
                        Surface(
                            color = Color(0xFFFFFBEB),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🛡️ आपका डेटा सुरक्षित है: ऑफलाइन दर्ज किया गया डेटा आपके फोन की मेमोरी में हमेशा सुरक्षित रहेगा। जब आप दोबारा इसी फोन में लॉगिन करेंगे, तो यह वैसा का वैसा मिल जाएगा।",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF92400E),
                                modifier = Modifier.padding(10.dp),
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        Text(
                            text = "आपका सारा डेटा सुरक्षित क्लाउड पर सिंक है। क्या आप वाकई लॉगआउट करना चाहते हैं?",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF475569)
                        )
                    }

                    if (logoutSyncError != null) {
                        Surface(
                            color = Color(0xFFFEF2F2),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFFECACA)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = logoutSyncError!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (isSyncingBeforeLogout) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color(0xFF1B5E20),
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "डेटा क्लाउड पर सुरक्षित सिंक हो रहा है...",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF1B5E20),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (hasUnsynced) {
                        Button(
                            onClick = {
                                logoutSyncError = null
                                viewModel.syncAndLogout(
                                    onProgress = { isSyncingBeforeLogout = it },
                                    onResult = { success, msg ->
                                        if (success) {
                                            showLogoutDialog = false
                                        } else {
                                            logoutSyncError = msg
                                        }
                                    }
                                )
                            },
                            enabled = !isSyncingBeforeLogout,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(46.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "सिंक करें और लॉगआउट करें",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                showLogoutDialog = false
                                viewModel.logout()
                            },
                            enabled = !isSyncingBeforeLogout,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                            border = BorderStroke(1.dp, Color(0xFFFECACA)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp)
                        ) {
                            Text(
                                text = "बिना सिंक के लॉगआउट करें",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                showLogoutDialog = false
                                viewModel.logout()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(46.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "हाँ, लॉगआउट करें",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    TextButton(
                        onClick = {
                            showLogoutDialog = false
                            logoutSyncError = null
                        },
                        enabled = !isSyncingBeforeLogout,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "रद्द करें (वापस जाएं)",
                            color = Color(0xFF64748B),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            },
            dismissButton = null
        )
    }

    // VIP Subscription & Razorpay Payment Dialog
    if (showVipSubscriptionDialog) {
        VipSubscriptionDialog(
            onDismiss = { showVipSubscriptionDialog = false },
            userPhone = profile?.phone ?: phone,
            userEmail = profile?.email ?: email
        )
    }

    // 🌾 मुंशी जी (AI वॉइस सहायक) Info Dialog
    if (showMunshiInfoDialog) {
        AlertDialog(
            onDismissRequest = { showMunshiInfoDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🌾", fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("मुंशी जी (AI वॉइस सहायक)", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "मुंशी जी आपके ट्यूबवेल बही-खाते के समर्पित वॉइस सहायक हैं। वे बिना किसी सेटिंग के आपके किसी भी सवाल का तुरंत बोलकर जवाब देते हैं:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF334155)
                    )

                    Surface(
                        color = Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("• किसी भी किसान का बकाया, बिल व जमा राशि", fontSize = 13.sp, color = Color(0xFF1E293B))
                            Text("• आज, इस हफ्ते या किसी खास महीने का हिसाब", fontSize = 13.sp, color = Color(0xFF1E293B))
                            Text("• कुल मार्केट बकाया व 1-2 साल पुराना हिसाब", fontSize = 13.sp, color = Color(0xFF1E293B))
                            Text("• ऐप के सभी फीचर्स और सेटिंग्स की जानकारी", fontSize = 13.sp, color = Color(0xFF1E293B))
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(text = "🟢", fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "स्थिति: ऑलवेज एक्टिव (100% मुफ़्त)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF16A34A)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showMunshiInfoDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                    modifier = Modifier.testTag("munshi_info_ok_button")
                ) {
                    Text("समझ गया")
                }
            }
        )
    }

    // 🛡️ Database Encryption Security Info Dialog
    if (showEncryptionDetailsDialog) {
        val secInfo = remember { DatabaseEncryptionManager.getSecurityInfo(context) }
        AlertDialog(
            onDismissRequest = { showEncryptionDetailsDialog = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color(0xFF15803D),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "डेटाबेस एन्क्रिप्शन सुरक्षा",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = Color(0xFF0F172A)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF16A34A),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "एन्क्रिप्शन एट रेस्ट (Active 🔒)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF15803D)
                                )
                                Text(
                                    text = "फोन स्टोरेज में आपका सारा डेटा 100% लॉक है",
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF166534)
                                )
                            }
                        }
                    }

                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("एन्क्रिप्शन एल्गोरिथम:", fontSize = 12.sp, color = Color(0xFF64748B))
                                Text("AES-256 Bit (CBC)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                            }
                            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.8.dp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("मास्टर-की सुरक्षा:", fontSize = 12.sp, color = Color(0xFF64748B))
                                Text("Android KeyStore", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                            }
                            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.8.dp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("इंजन लाइब्रेरी:", fontSize = 12.sp, color = Color(0xFF64748B))
                                Text(secInfo.cipherVersion, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                            }
                            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.8.dp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("सुरक्षा ग्रेड:", fontSize = 12.sp, color = Color(0xFF64748B))
                                Text("Fintech / Banking Grade", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                            }
                        }
                    }

                    Text(
                        text = "💡 इसका क्या फायदा है?\nअगर कोई व्यक्ति फोन को कंप्यूटर से जोड़कर ऐप की डेटाबेस फाइल कॉपी करने की कोशिश भी करे, तब भी बिना इस फोन के गुप्त हार्डवेयर की (Key) के कोई भी आपका डेटा नहीं पढ़ सकता।",
                        fontSize = 12.sp,
                        color = Color(0xFF475569),
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showEncryptionDetailsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("encryption_info_ok_button")
                ) {
                    Text("ठीक है (सुरक्षित)", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
