package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.*
import com.example.data.localization.AppLanguage
import com.example.data.localization.LanguageManager
import com.example.data.pdf.CustomerLedgerRow
import com.example.data.pdf.PdfGenerator
import com.example.data.repository.BahiKhataRepository
import com.example.data.service.BackgroundNotificationScheduler
import com.example.data.service.DuePaymentReminderManager
import com.example.data.service.LiveTimerManager
import com.example.data.service.OverdueCustomerItem
import com.example.data.service.OverdueDuration
import com.example.data.supabase.SupabaseAuthService
import com.example.data.util.SearchUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

enum class AppScreen {
    SPLASH,
    LANGUAGE_SELECT,
    AUTH_CHOICE,
    SIGN_UP,
    LOGIN,
    FORGOT_PASSWORD,
    MAIN_CONTAINER
}

enum class MainTab {
    HOME,
    CUSTOMERS,
    REPORTS,
    SETTINGS
}

enum class TimeFilter(val titleKey: String) {
    ALL("tab_all"),
    TODAY("filter_today"),
    WEEKLY("filter_weekly"),
    MONTHLY("filter_monthly"),
    YEARLY("filter_yearly"),
    TWO_YEARS("filter_2years")
}

enum class CustomerFilter {
    ALL,
    DUE,
    CASH
}

enum class SessionInputMode {
    LIVE_TIMER,
    START_END_TIME,
    DIRECT_HOURS
}

data class CustomerWithStats(
    val customer: CustomerEntity,
    val totalHours: Double,
    val totalAmount: Double,
    val totalPaid: Double,
    val netDue: Double,
    val sessionCount: Int,
    val lastSessionDate: Long?
)

class BahiKhataViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = BahiKhataRepository(database, application)

    // Language State
    private val _currentLanguage = MutableStateFlow(repository.getSavedLanguage())
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Font Scale State
    private val _fontScale = MutableStateFlow(repository.getSavedFontScale())
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()

    // Navigation State - Always start at SPLASH on launch so App Open Ads & splash animations execute
    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _selectedCustomerId = MutableStateFlow<String?>(null)
    val selectedCustomerId: StateFlow<String?> = _selectedCustomerId.asStateFlow()

    // Profile & Auth
    val profile = repository.profileFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        null
    )

    // Data Flows
    val allCustomers = repository.allCustomersFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        emptyList()
    )

    val allSessions = repository.allSessionsFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        emptyList()
    )

    val allTransactions = repository.allTransactionsFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        emptyList()
    )

    // Search and Filters
    val customerSearchQuery = MutableStateFlow("")
    val customerFilter = MutableStateFlow(CustomerFilter.ALL)
    val reportTimeFilter = MutableStateFlow(TimeFilter.ALL)
    val customerDetailTimeFilter = MutableStateFlow(TimeFilter.ALL)

    // Quick Entry Session Form State
    val formCustomerId = MutableStateFlow("")
    val sessionInputMode = MutableStateFlow(SessionInputMode.LIVE_TIMER)
    val formHours = MutableStateFlow("2.0")
    val formRate = MutableStateFlow("160")
    val formPaidAmount = MutableStateFlow("")
    val formNote = MutableStateFlow("")

    // 1. Live Stopwatch Timer State
    val isLiveTimerRunning = MutableStateFlow(false)
    val isLiveTimerPaused = MutableStateFlow(false)
    val liveTimerSeconds = MutableStateFlow(0L)
    val liveTimerActiveCustomerId = MutableStateFlow<String?>(null)
    private var liveTimerJob: kotlinx.coroutines.Job? = null

    // 2. Start-End Time State (12-Hour Format, Start defaults to empty/dummy 00, End defaults to Live Time)
    val startHourText = MutableStateFlow<String>("")
    val startMinText = MutableStateFlow<String>("")
    val startAmPmText = MutableStateFlow<String>("AM")

    val endHourText = MutableStateFlow<String>("12")
    val endMinText = MutableStateFlow<String>("00")
    val endAmPmText = MutableStateFlow<String>("AM")

    init {
        resetStartEndTimeDefaults()
    }

    // 3. Direct Hours State
    val directHoursText = MutableStateFlow("2.0")

    val isTimeCalculatorOpen = MutableStateFlow(false)
    val calcStartHour = MutableStateFlow(8)
    val calcStartMin = MutableStateFlow(0)
    val calcEndHour = MutableStateFlow(11)
    val calcEndMin = MutableStateFlow(30)

    // Completed Session Popup State (for WhatsApp / SMS sharing)
    val lastCompletedSession = MutableStateFlow<TubewellSessionEntity?>(null)
    val lastCompletedCustomer = MutableStateFlow<CustomerEntity?>(null)
    val showSessionReceiptDialog = MutableStateFlow(false)

    // Internet Warning Dialog State
    val showInternetWarningDialog = MutableStateFlow(false)
    val isSyncing = MutableStateFlow(false)

    // User Message / Snackbar
    val toastMessage = MutableStateFlow<String?>(null)

    init {
        // Initialize Persistent Live Timer from Storage
        LiveTimerManager.init(getApplication())

        // Synchronize with Foreground LiveTimerManager
        viewModelScope.launch {
            LiveTimerManager.isRunning.collect { running ->
                isLiveTimerRunning.value = running
            }
        }
        viewModelScope.launch {
            LiveTimerManager.isPaused.collect { paused ->
                isLiveTimerPaused.value = paused
            }
        }
        viewModelScope.launch {
            LiveTimerManager.seconds.collect { secs ->
                liveTimerSeconds.value = secs
            }
        }
        viewModelScope.launch {
            LiveTimerManager.customerId.collect { cid ->
                if (!cid.isNullOrBlank()) {
                    liveTimerActiveCustomerId.value = cid
                    formCustomerId.value = cid
                }
            }
        }

        // Persistent Login Check - Updates form rate and syncs without dismissing SPLASH screen prematurely
        viewModelScope.launch {
            repository.profileFlow.collect { prof ->
                val activeId = repository.getActiveProfileId()
                if (prof != null && activeId.isNotBlank()) {
                    formRate.value = prof.ratePerHour.toInt().toString()
                    if (_currentScreen.value != AppScreen.SPLASH) {
                        _currentScreen.value = AppScreen.MAIN_CONTAINER
                    }
                } else if (activeId.isBlank()) {
                    if (_currentScreen.value != AppScreen.SPLASH) {
                        _currentScreen.value = AppScreen.AUTH_CHOICE
                    }
                }
            }
        }
        viewModelScope.launch {
            // Check active session on startup in background
            val activeId = repository.getActiveProfileId()
            if (activeId.isNotBlank()) {
                val existingProfile = repository.getProfileOnce()
                if (existingProfile != null) {
                    formRate.value = existingProfile.ratePerHour.toInt().toString()
                    triggerAutoSyncInBackground()
                }
            }
            // Schedule background WorkManager & Alarm periodic checks
            BackgroundNotificationScheduler.schedulePeriodicWork(getApplication())
        }
    }

    fun loadDemoDataForReview() {
        viewModelScope.launch {
            repository.seedDemoReviewData()
            _currentScreen.value = AppScreen.MAIN_CONTAINER
            toastMessage.value = "🌾 डेमो / रिव्यू खाते का डेटा लोड हो गया!"
        }
    }

    fun getString(key: String): String {
        return LanguageManager.getString(key, _currentLanguage.value)
    }

    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
        repository.setSavedLanguage(lang)
    }

    fun setFontScale(scale: Float) {
        _fontScale.value = scale
        repository.setSavedFontScale(scale)
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun setTab(tab: MainTab) {
        _currentTab.value = tab
        _selectedCustomerId.value = null // clear detail view if returning
    }

    fun selectCustomerForDetail(customerId: String) {
        _selectedCustomerId.value = customerId
        customerDetailTimeFilter.value = TimeFilter.ALL
    }

    fun clearSelectedCustomer() {
        _selectedCustomerId.value = null
    }

    fun onSplashFinished() {
        val activeId = repository.getActiveProfileId()
        if (repository.isFirstLaunch()) {
            _currentScreen.value = AppScreen.LANGUAGE_SELECT
        } else if (activeId.isNotBlank()) {
            _currentScreen.value = AppScreen.MAIN_CONTAINER
        } else {
            _currentScreen.value = AppScreen.AUTH_CHOICE
        }
    }

    fun onLanguageSelectedFromOnboarding(lang: AppLanguage) {
        setLanguage(lang)
        repository.setFirstLaunchComplete()
        _currentScreen.value = AppScreen.AUTH_CHOICE
    }

    // All Customers with Stats (Unfiltered, for accurate totals)
    val allCustomerStatsList: StateFlow<List<CustomerWithStats>> = combine(
        allCustomers,
        allSessions,
        allTransactions
    ) { customers, sessions, txns ->
        customers.map { customer ->
            val cSessions = sessions.filter { it.customerId == customer.id }
            val cTxns = txns.filter { it.customerId == customer.id }

            val totalHours = cSessions.sumOf { it.hours }
            val sessionBilled = cSessions.sumOf { it.totalAmount }
            val sessionDirectPaid = cSessions.sumOf { it.paidAmount }
            val standaloneDeposits = cTxns.sumOf { it.amountDeposited }
            val totalPaid = sessionDirectPaid + standaloneDeposits
            val totalBilled = customer.initialBalance + sessionBilled
            val netDue = (totalBilled - totalPaid).coerceAtLeast(0.0)

            val lastDate = cSessions.maxOfOrNull { it.sessionDate }

            CustomerWithStats(
                customer = customer,
                totalHours = totalHours,
                totalAmount = totalBilled,
                totalPaid = totalPaid,
                netDue = netDue,
                sessionCount = cSessions.size,
                lastSessionDate = lastDate
            )
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Customer Aggregations (with search & filter)
    val customerStatsList: StateFlow<List<CustomerWithStats>> = combine(
        allCustomerStatsList,
        customerSearchQuery,
        customerFilter
    ) { list, query, filter ->
        // Apply search query
        val searched = list.filter {
            SearchUtil.matchesQuery(it.customer.name, it.customer.phone, it.customer.sO, query)
        }

        // Apply filter tab
        when (filter) {
            CustomerFilter.ALL -> searched
            CustomerFilter.DUE -> searched.filter { it.netDue > 0 }
            CustomerFilter.CASH -> searched.filter { it.netDue <= 0 }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Overall KPI Totals
    val overallStats = combine(allCustomers, allSessions, allTransactions) { customers, sessions, txns ->
        val totalHours = sessions.sumOf { it.hours }
        val sessionBilled = sessions.sumOf { it.totalAmount }
        val initialBalances = customers.sumOf { it.initialBalance }
        val grandBilled = initialBalances + sessionBilled

        val directPaid = sessions.sumOf { it.paidAmount }
        val deposits = txns.sumOf { it.amountDeposited }
        val grandPaid = directPaid + deposits

        // Accurate customer-by-customer net due sum matching Customer List & Reports exactly
        val grandDue = customers.sumOf { customer ->
            val cSessions = sessions.filter { it.customerId == customer.id }
            val cTxns = txns.filter { it.customerId == customer.id }
            val cBilled = customer.initialBalance + cSessions.sumOf { it.totalAmount }
            val cPaid = cSessions.sumOf { it.paidAmount } + cTxns.sumOf { it.amountDeposited }
            (cBilled - cPaid).coerceAtLeast(0.0)
        }

        // Today's stats
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfToday = cal.timeInMillis

        val todaySessions = sessions.filter { it.sessionDate >= startOfToday }
        val todayTxns = txns.filter { it.depositDate >= startOfToday }

        val todayHours = todaySessions.sumOf { it.hours }
        val todayBilled = todaySessions.sumOf { it.totalAmount }
        val todayPaid = todaySessions.sumOf { it.paidAmount } + todayTxns.sumOf { it.amountDeposited }
        val todayDue = (todayBilled - todayPaid).coerceAtLeast(0.0)

        mapOf(
            "totalHours" to totalHours,
            "grandBilled" to grandBilled,
            "grandPaid" to grandPaid,
            "grandDue" to grandDue,
            "todayHours" to todayHours,
            "todayBilled" to todayBilled,
            "todayPaid" to todayPaid,
            "todayDue" to todayDue,
            "totalCustomers" to customers.size.toDouble(),
            "totalSessions" to sessions.size.toDouble()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Overdue / Due Payment Notification Manager State
    val overdueDurationFilter = MutableStateFlow(DuePaymentReminderManager.getSelectedDuration(getApplication()))
    val isAutoDueReminderEnabled = MutableStateFlow(DuePaymentReminderManager.isAutoReminderEnabled(getApplication()))

    val overdueCustomers: StateFlow<List<OverdueCustomerItem>> = combine(
        allCustomers,
        allSessions,
        allTransactions,
        overdueDurationFilter
    ) { customers, sessions, txns, filter ->
        val now = System.currentTimeMillis()
        val list = mutableListOf<OverdueCustomerItem>()

        for (customer in customers) {
            val cSessions = sessions.filter { it.customerId == customer.id }
            val cTxns = txns.filter { it.customerId == customer.id }

            val sessionBilled = cSessions.sumOf { it.totalAmount }
            val directPaid = cSessions.sumOf { it.paidAmount }
            val deposits = cTxns.sumOf { it.amountDeposited }

            val totalBilled = customer.initialBalance + sessionBilled
            val totalPaid = directPaid + deposits
            val netDue = (totalBilled - totalPaid).coerceAtLeast(0.0)

            if (netDue > 1.0) {
                val earliestDate = if (cSessions.isNotEmpty()) {
                    cSessions.minOf { it.sessionDate }
                } else {
                    customer.createdAt
                }
                val daysDiff = ((now - earliestDate) / (1000 * 60 * 60 * 24L)).toInt().coerceAtLeast(1)

                val category = when {
                    daysDiff >= 365 -> OverdueDuration.YEAR_1
                    daysDiff >= 180 -> OverdueDuration.MONTH_6
                    daysDiff >= 90 -> OverdueDuration.MONTH_3
                    daysDiff >= 60 -> OverdueDuration.MONTH_2
                    daysDiff >= 30 -> OverdueDuration.MONTH_1
                    daysDiff >= 15 -> OverdueDuration.DAYS_15
                    else -> OverdueDuration.ALL
                }

                val durationText = when {
                    daysDiff >= 365 -> {
                        val years = daysDiff / 365
                        val remainingMonths = (daysDiff % 365) / 30
                        if (remainingMonths > 0) "$years साल $remainingMonths महीने" else "$years साल"
                    }
                    daysDiff >= 30 -> {
                        val months = daysDiff / 30
                        val remainingDays = daysDiff % 30
                        if (remainingDays > 0) "$months महीने $remainingDays दिन" else "$months महीने"
                    }
                    else -> "$daysDiff दिन"
                }

                list.add(
                    OverdueCustomerItem(
                        customer = customer,
                        dueAmount = netDue,
                        oldestUnpaidDate = earliestDate,
                        daysOverdue = daysDiff,
                        durationCategory = category,
                        formattedDurationText = durationText
                    )
                )
            }
        }

        val sorted = list.sortedWith(compareByDescending<OverdueCustomerItem> { it.daysOverdue }.thenByDescending { it.dueAmount })
        if (filter == OverdueDuration.ALL) {
            sorted
        } else {
            sorted.filter { it.daysOverdue >= filter.minDays }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setOverdueDurationFilter(duration: OverdueDuration) {
        overdueDurationFilter.value = duration
        DuePaymentReminderManager.setSelectedDuration(getApplication(), duration)
    }

    fun setAutoDueReminderEnabled(enabled: Boolean) {
        isAutoDueReminderEnabled.value = enabled
        DuePaymentReminderManager.setAutoReminderEnabled(getApplication(), enabled)
        if (enabled) {
            BackgroundNotificationScheduler.schedulePeriodicWork(getApplication())
            toastMessage.value = "स्वतः बैकग्राउंड उधारी रिमाइंडर सक्रिय हैं"
        } else {
            BackgroundNotificationScheduler.cancelAll(getApplication())
            toastMessage.value = "स्वतः बैकग्राउंड उधारी रिमाइंडर बंद कर दिए गए हैं"
        }
    }

    fun sendDueNotificationsNow(duration: OverdueDuration = overdueDurationFilter.value) {
        viewModelScope.launch {
            val count = DuePaymentReminderManager.checkAndPostDueNotifications(
                context = getApplication(),
                minDuration = duration,
                isManualTrigger = true
            )
            if (count > 0) {
                toastMessage.value = "🔔 $count ग्राहकों के उधारी नोटिफिकेशन भेज दिए गए हैं!"
            } else {
                toastMessage.value = "✅ चुनी हुई अवधि (${duration.labelHindi}) में कोई उधारी बकाया नहीं है"
            }
        }
    }

    // Filtered Report Rows based on Time Filter
    fun getFilteredReportRows(timeFilter: TimeFilter): List<CustomerLedgerRow> {
        val minTime = getMinTimeForFilter(timeFilter)
        val customers = allCustomers.value
        val sessions = if (timeFilter == TimeFilter.ALL) allSessions.value else allSessions.value.filter { it.sessionDate >= minTime }
        val txns = if (timeFilter == TimeFilter.ALL) allTransactions.value else allTransactions.value.filter { it.depositDate >= minTime }

        return customers.map { customer ->
            val cSessions = sessions.filter { it.customerId == customer.id }
            val cTxns = txns.filter { it.customerId == customer.id }

            val totalHours = cSessions.sumOf { it.hours }
            val initialBalance = if (timeFilter == TimeFilter.ALL || customer.createdAt >= minTime) customer.initialBalance else 0.0
            val sessionBilled = cSessions.sumOf { it.totalAmount }
            val totalAmount = initialBalance + sessionBilled
            val totalPaid = cSessions.sumOf { it.paidAmount } + cTxns.sumOf { it.amountDeposited }
            val totalDue = (totalAmount - totalPaid).coerceAtLeast(0.0)

            CustomerLedgerRow(
                customer = customer,
                totalHours = totalHours,
                totalAmount = totalAmount,
                totalPaid = totalPaid,
                totalDue = totalDue,
                sessionCount = cSessions.size
            )
        }.filter { it.sessionCount > 0 || it.totalPaid > 0 || it.totalDue > 0 || (timeFilter == TimeFilter.ALL && it.totalAmount > 0) }
    }

    private fun getMinTimeForFilter(filter: TimeFilter): Long {
        val cal = Calendar.getInstance()
        return when (filter) {
            TimeFilter.ALL -> 0L
            TimeFilter.TODAY -> {
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.timeInMillis
            }
            TimeFilter.WEEKLY -> {
                cal.add(Calendar.DAY_OF_YEAR, -7)
                cal.timeInMillis
            }
            TimeFilter.MONTHLY -> {
                cal.add(Calendar.DAY_OF_YEAR, -30)
                cal.timeInMillis
            }
            TimeFilter.YEARLY -> {
                cal.add(Calendar.DAY_OF_YEAR, -365)
                cal.timeInMillis
            }
            TimeFilter.TWO_YEARS -> {
                cal.add(Calendar.DAY_OF_YEAR, -730)
                cal.timeInMillis
            }
        }
    }

    // Rate default when customer is chosen for quick entry
    fun onSelectCustomerForQuickEntry(customerId: String) {
        formCustomerId.value = customerId
        val defaultRate = profile.value?.ratePerHour ?: 160.0
        formRate.value = defaultRate.toInt().toString()
    }

    fun updateDefaultRate(newRateStr: String) {
        formRate.value = newRateStr
        val newRate = newRateStr.toDoubleOrNull()
        if (newRate != null && newRate > 0) {
            viewModelScope.launch {
                val prof = repository.getProfileOnce()
                if (prof != null) {
                    if (prof.ratePerHour != newRate) {
                        repository.updateRate(prof.id, newRate)
                    }
                } else {
                    val defaultProf = ProfileEntity(
                        id = "default_owner_profile",
                        name = "Kisan Ramchandra",
                        agencyName = "Kisan Tubewell & Sinchai Seva",
                        phone = "9876543210",
                        ratePerHour = newRate,
                        pinHash = "1234"
                    )
                    repository.saveProfile(defaultProf)
                }
            }
        }
    }

    fun openSessionReceipt(session: TubewellSessionEntity, customer: CustomerEntity) {
        lastCompletedSession.value = session
        lastCompletedCustomer.value = customer
        showSessionReceiptDialog.value = true
    }

    // Live Stopwatch Timer Controls (Foreground Service & Sticky Notification Supported)
    fun startLiveTimer(customerId: String? = null) {
        val targetId = customerId ?: liveTimerActiveCustomerId.value ?: formCustomerId.value.ifBlank { allCustomers.value.firstOrNull()?.id ?: "" }
        if (targetId.isNotBlank()) {
            liveTimerActiveCustomerId.value = targetId
            formCustomerId.value = targetId
        }
        val targetCustomer = allCustomers.value.firstOrNull { it.id == targetId }
        val custName = targetCustomer?.name ?: "किसान"
        val rate = formRate.value.toDoubleOrNull() ?: (profile.value?.ratePerHour ?: 160.0)

        LiveTimerManager.start(
            context = getApplication(),
            custId = targetId,
            custName = custName,
            rate = rate,
            initialSecs = liveTimerSeconds.value
        )
    }

    fun pauseLiveTimer() {
        LiveTimerManager.pause(getApplication())
    }

    fun resumeLiveTimer() {
        LiveTimerManager.resume(getApplication())
    }

    fun resetLiveTimer() {
        LiveTimerManager.stop(getApplication())
        liveTimerSeconds.value = 0L
    }

    fun adjustLiveTimerHours(hours: Double) {
        val totalSecs = (hours * 3600).toLong().coerceAtLeast(0L)
        LiveTimerManager.setSeconds(getApplication(), totalSecs)
        liveTimerSeconds.value = totalSecs
    }

    fun adjustLiveTimerSeconds(deltaSecs: Long) {
        LiveTimerManager.adjustSeconds(getApplication(), deltaSecs)
    }

    // Direct Hours Quick Add
    fun addDirectHours(delta: Double) {
        val current = directHoursText.value.toDoubleOrNull() ?: 0.0
        val updated = (current + delta).coerceAtLeast(0.0)
        directHoursText.value = String.format(java.util.Locale.ROOT, "%.1f", updated)
    }

    fun clearDirectHours() {
        directHoursText.value = "0.0"
    }

    // Start-End Time Quick Shortcuts & 12-Hour Calculation
    fun resetStartEndTimeDefaults() {
        startHourText.value = ""
        startMinText.value = ""
        startAmPmText.value = getCurrentAmPmString()
        setEndTimeToLiveCurrentTime()
    }

    private fun getCurrent12HourString(): String {
        val cal = java.util.Calendar.getInstance()
        val hour12 = cal.get(java.util.Calendar.HOUR)
        val h = if (hour12 == 0) 12 else hour12
        return String.format(java.util.Locale.ROOT, "%02d", h)
    }

    private fun getCurrentMinuteString(): String {
        val cal = java.util.Calendar.getInstance()
        return String.format(java.util.Locale.ROOT, "%02d", cal.get(java.util.Calendar.MINUTE))
    }

    private fun getCurrentAmPmString(): String {
        val cal = java.util.Calendar.getInstance()
        return if (cal.get(java.util.Calendar.AM_PM) == java.util.Calendar.AM) "AM" else "PM"
    }

    fun setEndTimeToLiveCurrentTime() {
        endHourText.value = getCurrent12HourString()
        endMinText.value = getCurrentMinuteString()
        endAmPmText.value = getCurrentAmPmString()
    }

    fun setStartMinuteQuick(min: Int) {
        startMinText.value = String.format(java.util.Locale.ROOT, "%02d", min)
    }

    fun setEndMinuteQuick(min: Int) {
        endMinText.value = String.format(java.util.Locale.ROOT, "%02d", min)
    }

    fun parse12HourTo24Minutes(hourStr: String, minStr: String, amPm: String): Int {
        val hour = hourStr.trim().toIntOrNull() ?: 0
        val min = (minStr.trim().toIntOrNull() ?: 0).coerceIn(0, 59)
        val h24 = when {
            hour == 12 && amPm.equals("AM", ignoreCase = true) -> 0
            hour == 12 && amPm.equals("PM", ignoreCase = true) -> 12
            amPm.equals("PM", ignoreCase = true) -> (hour % 12) + 12
            else -> hour % 12
        }
        return (h24 * 60) + min
    }

    fun getStartEndCalculatedHours(): Double {
        val sHStr = startHourText.value.trim()
        val sMStr = startMinText.value.trim()
        val eHStr = endHourText.value.trim()
        val eMStr = endMinText.value.trim()

        // If start hour is not entered, treat duration as 0 until user inputs start time
        if (sHStr.isEmpty() && sMStr.isEmpty()) return 0.0

        val startTotalMins = parse12HourTo24Minutes(sHStr, sMStr, startAmPmText.value)
        var endTotalMins = parse12HourTo24Minutes(eHStr, eMStr, endAmPmText.value)

        if (endTotalMins < startTotalMins) {
            endTotalMins += 24 * 60 // next day overnight session
        }
        val diffMins = endTotalMins - startTotalMins
        return (diffMins / 60.0).coerceAtLeast(0.0)
    }

    fun calculate12HourDurationInHours(
        sHStr: String,
        sMStr: String,
        sAmPm: String,
        eHStr: String,
        eMStr: String,
        eAmPm: String
    ): Double {
        if (sHStr.trim().isEmpty() && sMStr.trim().isEmpty()) return 0.0
        val startTotalMins = parse12HourTo24Minutes(sHStr, sMStr, sAmPm)
        var endTotalMins = parse12HourTo24Minutes(eHStr, eMStr, eAmPm)
        if (endTotalMins < startTotalMins) {
            endTotalMins += 24 * 60
        }
        val diffMins = endTotalMins - startTotalMins
        return (diffMins / 60.0).coerceAtLeast(0.0)
    }

    fun calculateHoursFromTimes() {
        val hrs = getStartEndCalculatedHours()
        formHours.value = String.format(java.util.Locale.ROOT, "%.2f", hrs)
        isTimeCalculatorOpen.value = false
    }

    // Save Tubewell Session (supporting all 3 modes with 1, 2, 4 Bot & Flood Protection)
    fun saveSessionFromActiveMode(
        customerId: String,
        customHours: Double? = null,
        customRate: Double? = null,
        customPaid: Double? = null,
        customNote: String = "",
        honeypotText: String = "",
        openedAtMillis: Long = 0L,
        onBotDetected: (() -> Unit)? = null
    ): Boolean {
        val custId = if (customerId.isNotBlank()) customerId else formCustomerId.value
        if (custId.isBlank()) {
            toastMessage.value = "कृपया पहले किसान / ग्राहक चुनें!"
            return false
        }

        // 🛡️ Invisible Bot Shield & Rapid-Spam Protection (1, 2, 4)
        val isLiveTimer = (sessionInputMode.value == SessionInputMode.LIVE_TIMER && customHours == null)
        val (isBot, botReason) = com.example.data.security.AppSecurityService.isSessionBotDetected(
            honeypotText = honeypotText,
            openedAtMillis = openedAtMillis,
            isLiveTimer = isLiveTimer
        )

        if (isBot) {
            android.util.Log.w("BahiKhataVM", "Bot attempt detected in saveSession! reason=$botReason, honeypot='$honeypotText'")
            toastMessage.value = "⛔ सुरक्षा चेतावनी: स्वचालित बॉट (Bot) या स्पैम गतिविधि पहचानी गई! सत्र निरस्त कर दिया गया।"
            onBotDetected?.invoke()

            // 4. Cloud Silent Report to Supabase blocked_users table
            viewModelScope.launch(Dispatchers.IO) {
                val currentProfile = profile.value ?: repository.getProfileOnce()
                val currentProfileId = currentProfile?.id ?: "unknown_owner"
                val ownerPhone = currentProfile?.phone ?: ""
                val targetCust = allCustomers.value.firstOrNull { it.id == custId }
                val targetCustName = targetCust?.name ?: "Unknown"

                com.example.data.security.AppSecurityService.reportBotActivitySilently(
                    context = getApplication(),
                    profileId = currentProfileId,
                    action = "FAKE_SESSION_BOT_BLOCKED",
                    details = "Reason: $botReason, TargetCustomer='$targetCustName' ($custId), honeypot='$honeypotText'",
                    phone = ownerPhone
                )
            }
            return false
        }

        // Calculate hours based on active tab or custom
        val hrs = customHours ?: when (sessionInputMode.value) {
            SessionInputMode.LIVE_TIMER -> (liveTimerSeconds.value / 3600.0)
            SessionInputMode.START_END_TIME -> getStartEndCalculatedHours()
            SessionInputMode.DIRECT_HOURS -> (directHoursText.value.toDoubleOrNull() ?: 0.0)
        }

        if (hrs <= 0.0) {
            toastMessage.value = "सत्र की अवधि शून्य नहीं हो सकती! कृपया घंटे दर्ज करें।"
            return false
        }

        val rate = customRate ?: (formRate.value.toDoubleOrNull() ?: (profile.value?.ratePerHour ?: 160.0))
        val totalAmt = Math.round(hrs * rate).toDouble()
        val paidAmt = customPaid ?: (formPaidAmount.value.toDoubleOrNull() ?: 0.0)
        val dueAmt = (totalAmt - paidAmt).coerceAtLeast(0.0)

        viewModelScope.launch {
            val session = TubewellSessionEntity(
                customerId = custId,
                hours = hrs,
                rate = rate,
                totalAmount = totalAmt,
                paidAmount = paidAmt,
                dueAmount = dueAmt,
                note = customNote.ifBlank { formNote.value.trim() },
                sessionDate = System.currentTimeMillis()
            )
            repository.insertSession(session)

            // If user used a specific rate, update owner's profile rate so it becomes the default for future sessions
            if (rate > 0) {
                val currentProfile = repository.getProfileOnce()
                if (currentProfile != null && currentProfile.ratePerHour != rate) {
                    repository.updateRate(currentProfile.id, rate)
                }
            }

            val customer = allCustomers.value.firstOrNull { it.id == custId }
            lastCompletedSession.value = session
            lastCompletedCustomer.value = customer
            showSessionReceiptDialog.value = true

            // If it was live timer, reset it
            if (sessionInputMode.value == SessionInputMode.LIVE_TIMER) {
                resetLiveTimer()
                liveTimerActiveCustomerId.value = null
            }

            // Reset form fields
            formPaidAmount.value = ""
            formNote.value = ""
            toastMessage.value = "✅ ट्यूबवेल सत्र सफलतापूर्वक बही-खाते में दर्ज हुआ!"
            triggerAutoSyncInBackground()
        }
        return true
    }

    // Legacy / direct save
    fun saveQuickSession() {
        saveSessionFromActiveMode(formCustomerId.value)
    }

    // Add New Customer (with invisible Bot Protection & Honeypot validation)
    fun addNewCustomer(
        name: String,
        fatherName: String,
        phone: String,
        initialBal: Double,
        avatarColor: Long,
        honeypotText: String = "",
        openedAtMillis: Long = 0L,
        onCustomerCreated: ((CustomerEntity) -> Unit)? = null
    ) {
        if (name.isBlank()) {
            toastMessage.value = "कृपया किसान का नाम दर्ज करें!"
            return
        }

        // 🛡️ Invisible Bot Shield Validation
        // 1. Honeypot check: Bots auto-fill hidden input fields
        // 2. Timing check: Bots submit instantaneously (< 1.2s)
        if (com.example.data.security.AppSecurityService.isBotDetected(honeypotText, openedAtMillis)) {
            android.util.Log.w("BahiKhataVM", "Bot attempt detected in addNewCustomer! honeypot='$honeypotText', timing=${System.currentTimeMillis() - openedAtMillis}ms")
            // Silently report bot attempt to cloud security log
            viewModelScope.launch(Dispatchers.IO) {
                val currentProfileId = profile.value?.id ?: repository.getProfileOnce()?.id ?: "unknown"
                com.example.data.security.AppSecurityService.reportBotActivitySilently(
                    context = getApplication(),
                    profileId = currentProfileId,
                    action = "ADD_CUSTOMER_BOT_TRAP",
                    details = "name=$name, phone=$phone, honeypot=$honeypotText"
                )
            }
            // Discard fake data injection silently without crashing app
            return
        }

        viewModelScope.launch {
            val newCustomer = CustomerEntity(
                name = name.trim(),
                sO = fatherName.trim(),
                phone = phone.trim(),
                initialBalance = initialBal,
                avatarBgColor = avatarColor
            )
            repository.insertCustomer(newCustomer)
            toastMessage.value = "✅ नया किसान खाता सफलतापूर्वक बना!"
            onCustomerCreated?.invoke(newCustomer)
            triggerAutoSyncInBackground()
        }
    }

    // Update Customer
    fun updateCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.updateCustomer(customer)
            toastMessage.value = "✅ किसान जानकारी अपडेट की गई!"
            triggerAutoSyncInBackground()
        }
    }

    // Deposit Payment
    fun depositPayment(customerId: String, amount: Double, paymentMode: String, note: String) {
        if (amount <= 0) {
            toastMessage.value = "कृपया सही जमा राशि दर्ज करें!"
            return
        }
        viewModelScope.launch {
            val txn = TransactionEntity(
                customerId = customerId,
                amountDeposited = amount,
                paymentMode = paymentMode,
                note = note.trim(),
                depositDate = System.currentTimeMillis()
            )
            repository.insertTransaction(txn)
            toastMessage.value = "✅ ₹${amount.toInt()} जमा दर्ज हो गई!"
            triggerAutoSyncInBackground()
        }
    }

    // Edit Session (Correction Policy: Allowed within 48 hours)
    fun isSessionEditable(session: TubewellSessionEntity): Boolean {
        val now = System.currentTimeMillis()
        val twoDaysMillis = 2 * 24 * 60 * 60 * 1000L
        return (now - session.sessionDate) <= twoDaysMillis
    }

    fun updateSession(
        session: TubewellSessionEntity,
        honeypotText: String = "",
        openedAtMillis: Long = 0L
    ): Boolean {
        if (com.example.data.security.AppSecurityService.isBotDetected(honeypotText, openedAtMillis)) {
            android.util.Log.w("BahiKhataVM", "Bot detected in updateSession! honeypot='$honeypotText'")
            toastMessage.value = "⛔ सुरक्षा चेतावनी: बॉट गतिविधि पकड़ी गई! बदलाव निरस्त किया गया।"
            viewModelScope.launch(Dispatchers.IO) {
                val pId = profile.value?.id ?: repository.getProfileOnce()?.id ?: "unknown"
                val pPhone = profile.value?.phone ?: ""
                com.example.data.security.AppSecurityService.reportBotActivitySilently(
                    context = getApplication(),
                    profileId = pId,
                    action = "UPDATE_SESSION_BOT_BLOCKED",
                    details = "sessionId=${session.id}, honeypot='$honeypotText'",
                    phone = pPhone
                )
            }
            return false
        }
        if (!isSessionEditable(session)) {
            toastMessage.value = "⚠️ यह एंट्री 2 दिन से पुरानी है और सुरक्षित रूप से लॉक है!"
            return false
        }
        viewModelScope.launch {
            repository.updateSession(session)
            toastMessage.value = "✅ एंट्री में सुधार कर दिया गया!"
            triggerAutoSyncInBackground()
        }
        return true
    }

    // Account Creation & Profile Save with real-time cloud verification
    fun createOwnerProfile(
        name: String,
        agencyName: String,
        phone: String,
        pin: String,
        defaultRate: Double,
        email: String = "",
        isEmailVerified: Boolean = false,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val profile = ProfileEntity(
                name = name.trim(),
                agencyName = agencyName.trim(),
                phone = phone.trim(),
                email = email.trim().lowercase(),
                isEmailVerified = isEmailVerified,
                ratePerHour = defaultRate,
                pinHash = pin.trim()
            )
            val result = SupabaseAuthService.signUp(profile, getApplication(), repository)
            when (result) {
                is SupabaseAuthService.AuthResult.Success -> {
                    formRate.value = defaultRate.toInt().toString()
                    _currentScreen.value = AppScreen.MAIN_CONTAINER
                    toastMessage.value = "☁️ क्लाउड में खाता सफलतापूर्वक पंजीकृत हुआ!"
                    onSuccess()
                    triggerAutoSyncInBackground()
                }
                is SupabaseAuthService.AuthResult.Error -> {
                    toastMessage.value = "⚠️ ${result.message}"
                    onError(result.message)
                }
            }
        }
    }

    fun updateDefaultRate(newRate: Double) {
        if (newRate <= 0) return
        formRate.value = newRate.toInt().toString()
        viewModelScope.launch {
            val p = repository.getProfileOnce()
            if (p != null) {
                repository.updateRate(p.id, newRate)
            } else {
                val newProf = ProfileEntity(
                    id = "default_owner_profile",
                    name = "Kisan Ramchandra",
                    agencyName = "Kisan Tubewell & Sinchai Seva",
                    phone = "9876543210",
                    ratePerHour = newRate,
                    pinHash = "1234"
                )
                repository.saveProfile(newProf)
            }
            toastMessage.value = "✅ नई दर ₹${newRate.toInt()}/घंटा सेट हो गई!"
            triggerAutoSyncInBackground()
        }
    }

    fun saveOrUpdateProfile(
        name: String,
        agencyName: String,
        phone: String,
        rate: Double,
        email: String = "",
        isEmailVerified: Boolean? = null
    ) {
        viewModelScope.launch {
            val current = repository.getProfileOnce()
            val cleanEmail = email.trim().lowercase()
            val updatedVerified = isEmailVerified ?: (if (cleanEmail.equals(current?.email, ignoreCase = true)) (current?.isEmailVerified ?: false) else false)
            val updated = if (current != null) {
                current.copy(
                    name = name.trim(),
                    agencyName = agencyName.trim(),
                    phone = phone.trim(),
                    email = cleanEmail,
                    isEmailVerified = updatedVerified,
                    ratePerHour = rate,
                    updatedAt = System.currentTimeMillis()
                )
            } else {
                ProfileEntity(
                    id = "default_owner_profile",
                    name = name.trim(),
                    agencyName = agencyName.trim(),
                    phone = phone.trim(),
                    email = cleanEmail,
                    isEmailVerified = updatedVerified,
                    ratePerHour = rate,
                    pinHash = "1234"
                )
            }
            repository.saveProfile(updated)
            formRate.value = rate.toInt().toString()
            val app = getApplication<Application>()
            withContext(Dispatchers.IO) {
                SupabaseAuthService.updateProfileInSupabase(app, updated)
            }
            toastMessage.value = "✅ प्रोफाइल व दर सुरक्षित हो गई!"
            triggerAutoSyncInBackground()
        }
    }

    fun updateOwnerEmail(email: String, isVerified: Boolean) {
        viewModelScope.launch {
            val p = profile.value ?: repository.getProfileOnce()
            if (p != null) {
                val cleanEmail = email.trim().lowercase()
                val updated = p.copy(
                    email = cleanEmail,
                    isEmailVerified = isVerified,
                    updatedAt = System.currentTimeMillis()
                )
                repository.saveProfile(updated)

                val app = getApplication<Application>()
                val cloudSynced = withContext(Dispatchers.IO) {
                    SupabaseAuthService.updateProfileEmailInSupabase(
                        context = app,
                        profileId = updated.id,
                        phone = updated.phone,
                        email = cleanEmail,
                        isEmailVerified = isVerified
                    )
                }

                toastMessage.value = if (isVerified) {
                    if (cloudSynced) "✅ ईमेल क्लाउड में सुरक्षित व सत्यापित हो गया!"
                    else "✅ ईमेल सफलतापूर्वक सत्यापित हो गया!"
                } else {
                    "✅ ईमेल सुरक्षित हो गया!"
                }
                triggerAutoSyncInBackground()
            }
        }
    }

    fun updateOwnerPin(newPin: String) {
        viewModelScope.launch {
            val p = profile.value
            if (p != null) {
                repository.updatePin(p.id, newPin)
                toastMessage.value = "✅ नया सुरक्षा पिन सेट हो गया!"
                triggerAutoSyncInBackground()
            }
        }
    }

    fun loginWithMobileAndPassword(
        mobile: String,
        passwordOrPin: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = SupabaseAuthService.loginWithMobileAndPassword(
                mobile = mobile,
                passwordOrPin = passwordOrPin,
                repository = repository,
                context = getApplication()
            )
            when (result) {
                is SupabaseAuthService.AuthResult.Success -> {
                    formRate.value = result.profile.ratePerHour.toInt().toString()
                    if (result.profile.id == "demo_reviewer_profile") {
                        val custs = repository.allCustomersFlow.first()
                        if (custs.isEmpty()) {
                            repository.seedDemoReviewData()
                        }
                    }
                    _currentScreen.value = AppScreen.MAIN_CONTAINER
                    val prefix = if (result.source == "Supabase Cloud") "☁️ क्लाउड से" else if (result.source.contains("ऑफ़लाइन")) "🌾 ऑफ़लाइन (फ़ोन मेमोरी से)" else "🌾"
                    toastMessage.value = "$prefix लॉगिन सफल! स्वागत है, ${result.profile.name}"
                    onSuccess()
                    triggerAutoSyncInBackground()
                }
                is SupabaseAuthService.AuthResult.Error -> {
                    onError(result.message)
                }
            }
        }
    }

    fun resetPasswordAndLogin(
        mobile: String,
        newPinOrPassword: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val cleanMobile = mobile.trim()
        val cleanPass = newPinOrPassword.trim()
        if (cleanMobile.length != 10) {
            onError("कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें!")
            return
        }
        if (cleanPass.isEmpty()) {
            onError("कृपया नया पासवर्ड या 4-अंकों का पिन दर्ज करें!")
            return
        }
        viewModelScope.launch {
            val result = SupabaseAuthService.resetPassword(
                phone = cleanMobile,
                newPinOrPassword = cleanPass,
                repository = repository,
                context = getApplication()
            )
            when (result) {
                is SupabaseAuthService.AuthResult.Success -> {
                    formRate.value = result.profile.ratePerHour.toInt().toString()
                    _currentScreen.value = AppScreen.MAIN_CONTAINER
                    toastMessage.value = "✅ नया पासवर्ड सुरक्षित हो गया! स्वागत है, ${result.profile.name}"
                    onSuccess()
                }
                is SupabaseAuthService.AuthResult.Error -> {
                    onError(result.message)
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            _selectedCustomerId.value = null
            _currentTab.value = MainTab.HOME
            repository.logout()
            com.example.data.remoteconfig.RemoteConfigService.resetVipState(getApplication())
            _currentScreen.value = AppScreen.AUTH_CHOICE
            toastMessage.value = "लॉगआउट हो गया"
        }
    }

    suspend fun getUnsyncedSummary(): BahiKhataRepository.UnsyncedDataSummary {
        return repository.getUnsyncedSummary()
    }

    fun syncAndLogout(
        onProgress: (Boolean) -> Unit,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val isOnline = isNetworkConnected(getApplication())
            if (!isOnline) {
                onResult(false, "⚠️ इंटरनेट बंद है! कृपया सिंक करने के लिए इंटरनेट चालू करें, या 'बिना सिंक के लॉगआउट करें' चुनें।")
                return@launch
            }
            onProgress(true)
            val syncRes = repository.performSync()
            onProgress(false)
            if (syncRes.success) {
                _selectedCustomerId.value = null
                _currentTab.value = MainTab.HOME
                repository.logout()
                com.example.data.remoteconfig.RemoteConfigService.resetVipState(getApplication())
                _currentScreen.value = AppScreen.AUTH_CHOICE
                toastMessage.value = "✅ डेटा सुरक्षित सिंक हुआ और लॉगआउट हो गया!"
                onResult(true, "सफल")
            } else {
                onResult(false, syncRes.message)
            }
        }
    }

    // Auto-sync in background without blocking UI
    fun triggerAutoSyncInBackground() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<android.app.Application>()
            if (isNetworkConnected(app) && SupabaseAuthService.isConfigured(app)) {
                try {
                    repository.performSync()
                } catch (e: Exception) {
                    android.util.Log.d("BahiKhataVM", "Auto-sync error: ${e.message}")
                }
            }
        }
    }

    // Pull-to-refresh / Supabase sync handler
    fun triggerSync() {
        viewModelScope.launch {
            isSyncing.value = true
            val isOnline = isNetworkConnected(getApplication())
            if (!isOnline) {
                if (repository.shouldShowInternetWarning()) {
                    showInternetWarningDialog.value = true
                }
                toastMessage.value = "⚠️ आप ऑफ़लाइन हैं। इंटरनेट जुड़ते ही डेटा सिंक हो जाएगा।"
            } else {
                val res = repository.performSync()
                toastMessage.value = res.message
            }
            isSyncing.value = false
        }
    }

    // Supabase Configuration Helpers
    fun saveSupabaseConfig(url: String, anonKey: String) {
        SupabaseAuthService.saveSupabaseConfig(getApplication(), url, anonKey)
        toastMessage.value = "✅ क्लाउड सेटिंग्स सुरक्षित हो गईं!"
    }

    fun getSupabaseUrl(): String = SupabaseAuthService.getSupabaseUrl(getApplication())
    fun getSupabaseAnonKey(): String = SupabaseAuthService.getSupabaseAnonKey(getApplication())
    fun isSupabaseConfigured(): Boolean = SupabaseAuthService.isConfigured(getApplication())

    fun testSupabaseConnection(
        url: String? = null,
        key: String? = null,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val res = SupabaseAuthService.testConnection(
                context = getApplication(),
                testUrl = url,
                testKey = key
            )
            res.fold(
                onSuccess = { msg -> onResult(true, msg) },
                onFailure = { err -> onResult(false, err.message ?: "कनेक्शन विफल") }
            )
        }
    }

    fun getSupabaseSqlScript(): String = SupabaseAuthService.getSqlSetupScript()

    private fun isNetworkConnected(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val net = cm.activeNetworkInfo
            net != null && net.isConnected
        } catch (e: Exception) {
            false
        }
    }

    fun generateMasterPdf(context: Context, filter: TimeFilter = reportTimeFilter.value): File? {
        val rows = getFilteredReportRows(filter)
        val filterTitle = getString(filter.titleKey)
        return PdfGenerator.generateMasterReportPdf(context, profile.value, rows, filterTitle)
    }

    // 🌾 मुंशी जी (Gemini Voice Assistant) State & Operations
    val showMunshiDialog = mutableStateOf(false)
    val showMunshiPassUnlockDialog = mutableStateOf(false)
    val isMunshiThinking = mutableStateOf(false)
    val munshiLastQuery = mutableStateOf<String?>(null)
    val munshiLastResponse = mutableStateOf<String?>(null)
    val munshiErrorMessage = mutableStateOf<String?>(null)
    val munshiChatHistory = mutableStateListOf<com.example.data.gemini.GeminiMunshiService.MunshiChatMessage>()
    val munshiActiveLanguage = mutableStateOf(repository.getSavedMunshiLanguage())

    fun getMunshiRemainingDailyCalls(): Int {
        val prof = profile.value
        val accountKey = prof?.phone?.takeIf { it.isNotBlank() } ?: prof?.id ?: "default_account"
        val limit = com.example.data.remoteconfig.RemoteConfigService.getMunshiDailyFreeLimit()
        return repository.getGeminiRemainingCallsToday(accountKey, limit)
    }

    fun hasUnlimitedMunshiAccess(): Boolean {
        if (!com.example.data.remoteconfig.RemoteConfigService.isMunshiGatedByPass()) return true
        return com.example.data.remoteconfig.RemoteConfigService.hasMunshiUnlimitedPassAccess()
    }

    fun setMunshiLanguage(lang: com.example.data.gemini.MunshiLang) {
        munshiActiveLanguage.value = lang
        repository.setSavedMunshiLanguage(lang)
    }

    fun openMunshiAssistant() {
        munshiErrorMessage.value = null
        showMunshiDialog.value = true
    }

    fun closeMunshiAssistant() {
        showMunshiDialog.value = false
        isMunshiThinking.value = false
    }

    fun clearMunshiHistory() {
        munshiChatHistory.clear()
        munshiLastQuery.value = null
        munshiLastResponse.value = null
    }

    private fun updateMunshiLearnedMemory(query: String, reply: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.getMunshiLearnedMemory()
            val lines = existing.split("\n").filter { it.isNotBlank() }.toMutableList()

            // 1. Detect if a customer was discussed
            val statsList = allCustomerStatsList.value
            val discussedCustomer = statsList.firstOrNull {
                query.contains(it.customer.name, ignoreCase = true)
            }?.customer?.name

            if (discussedCustomer != null) {
                val customerNote = "किसान भाई अक्सर '${discussedCustomer}' का हिसाब पूछते हैं।"
                if (!lines.contains(customerNote)) {
                    lines.add(customerNote)
                }
            }

            // 2. Detect language/dialect preference
            if (query.contains("ਕਿੰਨਾ") || query.contains("ਕਿਵੇਂ") || query.contains("ਰਹਿੰਦਾ") || query.contains("ਦੱਸੋ")) {
                val langNote = "किसान भाई पंजाबी बोली में बात करना पसंद करते हैं।"
                if (!lines.contains(langNote)) lines.add(langNote)
            } else if (query.contains("कितणा") || query.contains("सै") || query.contains("घणा") || query.contains("कुकर")) {
                val langNote = "किसान भाई हरियाणवी बोली में बात करना पसंद करते हैं।"
                if (!lines.contains(langNote)) lines.add(langNote)
            } else if (query.contains("घणी") || query.contains("खम्मा") || query.contains("कांई")) {
                val langNote = "किसान भाई राजस्थानी बोली में बात करना पसंद करते हैं।"
                if (!lines.contains(langNote)) lines.add(langNote)
            }

            // 3. Keep memory concise and relevant (max 6 key insights)
            val updated = lines.takeLast(6).joinToString("\n")
            repository.saveMunshiLearnedMemory(updated)
        }
    }

    fun askMunshiVoice(
        query: String,
        onSuccess: (String) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val cleanQuery = com.example.data.gemini.MunshiSmartLocalEngine.normalizeVoiceQuery(query.trim())
        if (cleanQuery.isBlank()) return

        munshiLastQuery.value = cleanQuery
        munshiErrorMessage.value = null
        isMunshiThinking.value = true

        viewModelScope.launch {
            val app = getApplication<Application>()
            val apiKey = com.example.data.gemini.GeminiMunshiService.getEffectiveApiKey(app, repository)
            val currentProf = profile.value
            val farmerName = currentProf?.name ?: "किसान भाई"
            val defaultRate = currentProf?.ratePerHour ?: 160.0
            var statsList = allCustomerStatsList.value
            var sessionsList = allSessions.value

            // Robust fallback: Always query Room DB directly if in-memory state is empty
            if (statsList.isEmpty()) {
                val activeProfileId = repository.getActiveProfileId().ifBlank { currentProf?.id ?: "default" }
                val dbCustomers = repository.getCustomersByProfileOnce(activeProfileId)
                val dbSessions = repository.getSessionsByProfileOnce(activeProfileId)
                val dbTxns = repository.getTransactionsByProfileOnce(activeProfileId)

                if (dbCustomers.isNotEmpty()) {
                    sessionsList = dbSessions
                    statsList = dbCustomers.map { customer ->
                        val cSessions = dbSessions.filter { it.customerId == customer.id }
                        val cTxns = dbTxns.filter { it.customerId == customer.id }

                        val totalHours = cSessions.sumOf { it.hours }
                        val sessionBilled = cSessions.sumOf { it.totalAmount }
                        val sessionDirectPaid = cSessions.sumOf { it.paidAmount }
                        val standaloneDeposits = cTxns.sumOf { it.amountDeposited }
                        val totalPaid = sessionDirectPaid + standaloneDeposits
                        val totalBilled = customer.initialBalance + sessionBilled
                        val netDue = (totalBilled - totalPaid).coerceAtLeast(0.0)
                        val lastDate = cSessions.maxOfOrNull { it.sessionDate }

                        CustomerWithStats(
                            customer = customer,
                            totalHours = totalHours,
                            totalAmount = totalBilled,
                            totalPaid = totalPaid,
                            netDue = netDue,
                            sessionCount = cSessions.size,
                            lastSessionDate = lastDate
                        )
                    }
                }
            }

            val isVip = com.example.data.remoteconfig.RemoteConfigService.isAdFreeUser.value
            val vipDays = com.example.data.remoteconfig.RemoteConfigService.vipDaysRemaining.value
            val vipPlan = com.example.data.remoteconfig.RemoteConfigService.planType.value
            val hasPriorChat = munshiChatHistory.isNotEmpty()

            // Check if user requested an explicit language switch (e.g., "हरियाणवी में बात करो", "इंग्लिश बोलो")
            val requestedLang = com.example.data.gemini.MunshiSmartLocalEngine.detectLanguageSwitchRequest(cleanQuery)
            if (requestedLang != null) {
                setMunshiLanguage(requestedLang)
            } else {
                // If user didn't explicitly request a language switch, auto-adopt the language/dialect they started speaking in
                val detectedLang = com.example.data.gemini.MunshiSmartLocalEngine.detectDialectFromQuery(cleanQuery, munshiActiveLanguage.value)
                if (detectedLang != munshiActiveLanguage.value) {
                    setMunshiLanguage(detectedLang)
                }
            }
            val activeLang = munshiActiveLanguage.value

            // 1. Try In-App Smart Local Engine FIRST (instant, 0 quota, covers 90%+ queries)
            val localAnswer = com.example.data.gemini.MunshiSmartLocalEngine.tryAnswerFromAppLogic(
                query = cleanQuery,
                customersWithStats = statsList,
                sessions = sessionsList,
                profile = currentProf,
                isVipActive = isVip,
                vipDaysRemaining = vipDays,
                vipPlan = vipPlan,
                hasPriorChat = hasPriorChat,
                activeLang = activeLang
            )

            if (localAnswer != null) {
                isMunshiThinking.value = false
                munshiLastResponse.value = localAnswer
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", localAnswer))
                updateMunshiLearnedMemory(cleanQuery, localAnswer)
                onSuccess(localAnswer)
                return@launch
            }

            // 2. Check Device-Local Learned Q&A Knowledge Cache
            val cachedAnswer = repository.findLearnedAnswer(cleanQuery)
            if (cachedAnswer != null) {
                isMunshiThinking.value = false
                munshiLastResponse.value = cachedAnswer
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", cachedAnswer))
                onSuccess(cachedAnswer)
                return@launch
            }

            // 3. Off-Topic Guardrails Check (Max 2 non-farming questions allowed per 24 hours)
            val isOffTopic = com.example.data.gemini.GeminiMunshiService.isOffTopicGeneralQuery(cleanQuery)
            if (isOffTopic) {
                val offTopicCount = repository.getOffTopicCount()
                if (offTopicCount >= 2) {
                    val guardrailMsg = when (activeLang) {
                        com.example.data.gemini.MunshiLang.HARYANVI -> "भाई, 24 घंटे में 2 आम सवाल पूछण की छूट थी जो पूरी हो ली। मुंशी जी मुख्य रूप तै थारे ट्यूबवेल के हिसाब-किताब अर खेती-बाड़ी खातर सैं। इब ट्यूबवेल या खेती का सवाल पूछो भाई!"
                        com.example.data.gemini.MunshiLang.BHOJPURI -> "भाई जी, 24 घंटा में 2 गो आम सवाल पूछे के छूट रहे जे पूरा हो गइल। मुंशी जी मुख्य रूप से रउआ ट्यूबवेल के हिसाब आ खेती-बारी खातिर बाड़ीं। अब ट्यूबवेल भा खेती से जुड़ल सवाल पूछीं।"
                        com.example.data.gemini.MunshiLang.RAJASTHANI -> "भाई सा, 24 घंटा मांय 2 आम सवाल पूछण री सीमा पूरी हो चुकी छै। मुंशी जी मुख्य रूप सूं आपरे ट्यूबवेल हिसाब-किताब अर खेती-बाड़ी वास्ते छै। अब ट्यूबवेल या खेती रो सवाल ही पूछजो सा!"
                        com.example.data.gemini.MunshiLang.PUNJABI -> "ਵੀਰ ਜੀ, 24 ਘੰਟਿਆਂ ਵਿੱਚ 2 ਆਮ ਸਵਾਲ ਪੁੱਛਣ ਦੀ ਹੱਦ ਪੂਰੀ ਹੋ ਚੁੱਕੀ ਹੈ। ਮੁਨਸ਼ੀ ਜੀ ਮੁੱਖ ਤੌਰ 'ਤੇ ਤੁਹਾਡੇ ਟਿਊਬਵੈੱਲ ਦੇ ਹਿਸਾਬ-ਕਿਤਾਬ ਅਤੇ ਖੇਤੀ ਲਈ ਹਨ। ਹੁਣ ਟਿਊਬਵੈੱਲ ਜਾਂ ਖੇਤੀ ਬਾਰੇ ਸਵਾਲ ਪੁੱਛੋ ਜੀ।"
                        com.example.data.gemini.MunshiLang.GUJARATI -> "ભાઈ, 24 કલાકમાં 2 સામાન્ય પ્રશ્નો પૂછવાની મર્યાદા પૂર્ણ થઈ ગઈ છે. મુનશી જી મુખ્યત્વે તમારા ટ્યુબવેલના હિસાબ અને ખેતી માટે છે. કૃપા કરીને હવે ટ્યુબવેલ કે ખેતી સંબંધિત સવાલ પૂછો."
                        com.example.data.gemini.MunshiLang.MARATHI -> "भाऊ, 24 तासांत 2 सामान्य प्रश्न विचारण्याची मर्यादा संपली आहे. मुन्शी जी मुख्यत्वे तुमच्या ट्यूबवेलचा हिशोब आणि शेतीसाठी आहेत. कृपया आता ट्यूबवेल किंवा शेतीविषयक प्रश्न विचारा."
                        com.example.data.gemini.MunshiLang.ENGLISH -> "Brother, the limit of 2 general questions per 24 hours is completed. Munshi is primarily for your tubewell ledger and farming. Please ask tubewell or agriculture questions now."
                        else -> "भाई जी, 24 घंटे में 2 सामान्य सवाल पूछने की सीमा पूरी हो चुकी है। मुंशी जी मुख्य रूप से आपके ट्यूबवेल हिसाब-किताब और खेती-किसानी के लिए हैं। कृपया आगे से ट्यूबवेल या खेती से जुड़े सवाल ही पूछें।"
                    }
                    isMunshiThinking.value = false
                    munshiLastResponse.value = guardrailMsg
                    munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                    munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", guardrailMsg))
                    onSuccess(guardrailMsg)
                    return@launch
                }
            }

            // 4. Query is complex/generative: Prepare cloud context for Gemini / Cloudflare Worker
            val profId = currentProf?.id ?: "default"
            val accountKey = currentProf?.phone?.takeIf { it.isNotBlank() } ?: profId
            val isGated = com.example.data.remoteconfig.RemoteConfigService.isMunshiGatedByPass()
            val hasPass = com.example.data.remoteconfig.RemoteConfigService.hasMunshiUnlimitedPassAccess()
            val dailyLimit = com.example.data.remoteconfig.RemoteConfigService.getMunshiDailyFreeLimit()

            // 1. Pass Requirement: Munshi usage itself is tied to 24-Hour Feature Pass or VIP Pass
            if (isGated && !hasPass) {
                isMunshiThinking.value = false
                val passReqMsg = when (activeLang) {
                    com.example.data.gemini.MunshiLang.HARYANVI -> "भाई, मुंशी जी का उपयोग करन खातर 24 घंटे का पास (छोटा वीडियो देखकै) अनलॉक कर या VIP पास ले ले!"
                    com.example.data.gemini.MunshiLang.BHOJPURI -> "भाई जी, मुंशी जी के उपयोग करे खातिर 24 घंटा के पास (छोट वीडियो देख के) अनलॉक करीं भा VIP पास लीहीं!"
                    com.example.data.gemini.MunshiLang.RAJASTHANI -> "भाई सा, मुंशी जी रो प्रयोग करण खातर 24 घंटा रो पास (छोटो वीडियो देख'र) अनलॉक करो सा या VIP पास लेवो!"
                    com.example.data.gemini.MunshiLang.PUNJABI -> "ਵੀਰ ਜੀ, ਮੁਨਸ਼ੀ ਜੀ ਦੀ ਵਰਤੋਂ ਕਰਨ ਲਈ 24 ਘੰਟੇ ਦਾ ਪਾਸ (ਵੀਡੀਓ ਵੇਖ ਕੇ) ਅਨਲੌਕ ਕਰੋ ਜਾਂ VIP ਪਾਸ ਲਵੋ!"
                    com.example.data.gemini.MunshiLang.GUJARATI -> "ભાઈ, મુનશી જીનો ઉપયોગ કરવા માટે 24 કલાકનો પાસ (વીડિયો જોઈને) અનલૉક કરો અથવા VIP પાસ લો!"
                    com.example.data.gemini.MunshiLang.MARATHI -> "भाऊ, मुंशी जी वापरण्यासाठी 24 तासांचा पास (व्हिडिओ पाहून) अनलॉक करा किंवा VIP पास घ्या!"
                    com.example.data.gemini.MunshiLang.ENGLISH -> "Please unlock the 24-hour pass (by watching a short video) or get a VIP pass to use Munshi!"
                    else -> "मुंशी जी का उपयोग करने के लिए 24 घंटे का पास (छोटा वीडियो देखकर) अनलॉक करें या VIP पास लें!"
                }
                munshiLastResponse.value = passReqMsg
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", passReqMsg))
                showMunshiPassUnlockDialog.value = true
                onSuccess(passReqMsg)
                return@launch
            }

            // 2. Daily Gemini API Quota: Max 5 API calls per day per account for EVERYONE
            val canCall = repository.canMakeGeminiCallToday(accountKey, dailyLimit)
            if (!canCall) {
                isMunshiThinking.value = false
                val limitMsg = when (activeLang) {
                    com.example.data.gemini.MunshiLang.HARYANVI -> "भाई, आज के विशेष सवाल पूरे होगे सैं। अपणे बहीखाते का हिसाब इब भी पूछ सकै सै, बाकी सवाल काल फेर चालू हो ज्यांगे।"
                    com.example.data.gemini.MunshiLang.BHOJPURI -> "भाई जी, आज के विशेष सवाल पूरा हो गइल बा। रउआ आपन बहीखाता के हिसाब अबहियों पूछ सकीं ले, बाकी सवाल काल्ह फेर चालू हो जाई।"
                    com.example.data.gemini.MunshiLang.RAJASTHANI -> "भाई सा, आज रा विशेष सवाल पूरा हो गया सा। आप आपरे बहीखाते रो हिसाब अबे भी पूछ सको सा, बाकी सवाल काल फेर चालू हो जासी।"
                    com.example.data.gemini.MunshiLang.PUNJABI -> "ਵੀਰ ਜੀ, ਅੱਜ ਦੇ ਵਿਸ਼ੇਸ਼ ਸਵਾਲ ਪੂਰੇ ਹੋ ਚੁੱਕੇ ਹਨ। ਤੁਸੀਂ ਆਪਣੇ ਵਹੀ-ਖਾਤੇ ਦਾ ਹਿਸਾਬ ਹੁਣ ਵੀ ਪੁੱਛ ਸਕਦੇ ਹੋ, ਬਾਕੀ ਸਵਾਲ ਕੱਲ੍ਹ ਫਿਰ ਚਾਲੂ ਹੋ ਜਾਣਗੇ।"
                    com.example.data.gemini.MunshiLang.GUJARATI -> "ભાઈ, આજના વિશેષ પ્રશ્નો પૂર્ણ થઈ ગયા છે. તમે તમારા વહીખાતાનો હિસાબ હજુ પણ પૂછી શકો છો, બાકીના પ્રશ્નો આવતીકાલે ફરી ચાલુ થઈ જશે."
                    com.example.data.gemini.MunshiLang.MARATHI -> "भाऊ, आजचे विशेष प्रश्न संपले आहेत. तुम्ही तुमच्या वहिवाटीचा हिशोब अजूनही विचारू शकता, बाकीचे प्रश्न उद्या पुन्हा सुरू होतील."
                    com.example.data.gemini.MunshiLang.ENGLISH -> "Brother, today's special queries are completed. You can still ask your ledger accounts anytime, remaining queries will resume tomorrow."
                    else -> "भाईजी, आज के विशेष सवाल पूरे हो चुके हैं। आप अपने बहीखाते का हिसाब अभी भी पूछ सकते हैं, बाकी सवाल कल फिर चालू हो जाएंगे।"
                }
                munshiLastResponse.value = limitMsg
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", limitMsg))
                onSuccess(limitMsg)
                return@launch
            }

            val liveCloudContext = com.example.data.gemini.GeminiMunshiService.fetchLiveSupabaseLedgerContext(
                context = app,
                profileId = profId,
                userName = farmerName,
                defaultRate = defaultRate
            )

            val contextData = liveCloudContext ?: com.example.data.gemini.GeminiMunshiService.buildFarmerContext(
                userName = farmerName,
                defaultRate = defaultRate,
                customersWithStats = statsList,
                recentSessions = sessionsList
            )

            val learnedMemory = repository.getMunshiLearnedMemory()
            val historySnapshot = munshiChatHistory.takeLast(8).toList()
            val proxyUrl = com.example.data.gemini.GeminiMunshiService.getEffectiveProxyUrl(app, repository)

            if (apiKey.isBlank() && proxyUrl.isBlank()) {
                val fallback = com.example.data.gemini.MunshiSmartLocalEngine.generateFallbackSummary(
                    query = cleanQuery,
                    customersWithStats = statsList,
                    hasPriorChat = hasPriorChat,
                    activeLang = activeLang
                )
                isMunshiThinking.value = false
                munshiLastResponse.value = fallback
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", fallback))
                updateMunshiLearnedMemory(cleanQuery, fallback)
                onSuccess(fallback)
                return@launch
            }

            val result = com.example.data.gemini.GeminiMunshiService.askMunshi(
                apiKey = apiKey,
                proxyUrl = proxyUrl,
                userVoiceQuery = cleanQuery,
                contextData = contextData,
                chatHistory = historySnapshot,
                learnedMemory = learnedMemory,
                activeLang = activeLang
            )

            isMunshiThinking.value = false

            result.fold(
                onSuccess = { reply ->
                    repository.incrementGeminiDailyCallsCount(accountKey)
                    if (isOffTopic) {
                        repository.incrementOffTopicCount()
                    }
                    munshiLastResponse.value = reply
                    munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                    munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", reply))
                    updateMunshiLearnedMemory(cleanQuery, reply)
                    if (!reply.contains("समस्या") && !reply.contains("त्रुटि") && !reply.contains("समझ नहीं")) {
                        repository.saveLearnedQA(cleanQuery, reply)
                    }
                    onSuccess(reply)
                },
                onFailure = { err ->
                    val isAgri = com.example.data.gemini.GeminiMunshiService.isAgricultureOrTubewellQuery(cleanQuery)
                    val fallback = if (isAgri) {
                        when (activeLang) {
                            com.example.data.gemini.MunshiLang.HARYANVI -> "भाई, इंटरनेट या नेटवर्क में दिक्कत आण लागरही सै। इंटरनेट चालू करकै दुबारा पूछ ले, म्हैं थारी खेती अर ट्यूबवेल की पूरी जानकारी दे द्यूंगा।"
                            com.example.data.gemini.MunshiLang.BHOJPURI -> "भाई जी, इंटरनेट भा नेटवर्क में परेशानी आवत बा। इंटरनेट चालू क के फेर से पूछीं, हम रउआ खेती आ ट्यूबवेल के पूरा जानकारी दे देब।"
                            com.example.data.gemini.MunshiLang.RAJASTHANI -> "भाई सा, इंटरनेट या नेटवर्क मांय कोई समस्या आ रही छै। इंटरनेट चालू कर'र पाछो पूछो सा, म्हूं खेती-बाड़ी अर ट्यूबवेल री पूरी जाणकारी दे देस्यूं।"
                            com.example.data.gemini.MunshiLang.PUNJABI -> "ਵੀਰ ਜੀ, ਇੰਟਰਨੈੱਟ ਜਾਂ ਨੈੱਟਵਰਕ ਵਿੱਚ ਸਮੱਸਿਆ ਆ ਰਹੀ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਇੰਟਰਨੈੱਟ ਚਾਲੂ ਕਰਕੇ ਦੁਬਾਰਾ ਪੁੱਛੋ, ਮੈਂ ਖੇਤੀ ਅਤੇ ਟਿਊਬਵੈੱਲ ਦੀ ਪੂਰੀ ਜਾਣਕਾਰੀ ਦੇਵਾਂਗਾ।"
                            com.example.data.gemini.MunshiLang.GUJARATI -> "ભાઈ, ઈન્ટરનેટ કે નેટવર્કમાં સમસ્યા આવી રહી છે. કૃપા કરીને ઈન્ટરનેટ ચાલુ કરીને ફરીથી પૂછો, હું ખેતી અને ટ્યુબવેલની સંપૂર્ણ માહિતી આપીશ."
                            com.example.data.gemini.MunshiLang.MARATHI -> "भाऊ, इंटरनेट किंवा नेटवर्कमध्ये अडचण येत आहे. कृपया इंटरनेट सुरू करून पुन्हा विचारा, मी शेती आणि ट्यूबवेलची संपूर्ण माहिती देईन."
                            com.example.data.gemini.MunshiLang.ENGLISH -> "Brother, there seems to be a network connection issue. Please check your internet and ask again; I will provide complete agricultural and tubewell guidance."
                            else -> "किसान भाई, इंटरनेट या नेटवर्क में समस्या आ रही है। कृपया इंटरनेट कनेक्शन जांच कर दोबारा पूछें, मुंशी जी खेती-बाड़ी और ट्यूबवेल की पूरी जानकारी देंगे।"
                        }
                    } else {
                        com.example.data.gemini.MunshiSmartLocalEngine.generateFallbackSummary(
                            query = cleanQuery,
                            customersWithStats = statsList,
                            hasPriorChat = hasPriorChat,
                            activeLang = activeLang
                        )
                    }
                    munshiLastResponse.value = fallback
                    munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("user", cleanQuery))
                    munshiChatHistory.add(com.example.data.gemini.GeminiMunshiService.MunshiChatMessage("model", fallback))
                    updateMunshiLearnedMemory(cleanQuery, fallback)
                    onSuccess(fallback)
                }
            )
        }
    }

    fun getGeminiApiKey(): String = repository.getGeminiApiKey()

    fun getCloudflareProxyUrl(): String = repository.getCloudflareProxyUrl()

    fun saveCloudflareProxyUrl(url: String) {
        val cleanUrl = url.trim()
        repository.setCloudflareProxyUrl(cleanUrl)
        toastMessage.value = "✅ Cloudflare Worker लिंक सुरक्षित हो गया!"
    }

    fun saveGeminiApiKey(key: String) {
        val cleanKey = key.trim()
        repository.setGeminiApiKey(cleanKey)
        toastMessage.value = "✅ Gemini API Key सुरक्षित हो गई!"

        // Sync to user profile in Supabase cloud so it persists across logouts and devices
        viewModelScope.launch(Dispatchers.IO) {
            val prof = profile.value ?: repository.getProfileOnce()
            if (prof != null) {
                SupabaseAuthService.updateProfileGeminiApiKeyInSupabase(
                    context = getApplication(),
                    profileId = prof.id,
                    phone = prof.phone,
                    apiKey = cleanKey
                )
            }
        }
    }
}
