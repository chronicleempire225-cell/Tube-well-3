package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.CustomerEntity
import com.example.data.db.TubewellSessionEntity
import com.example.data.localization.AppLanguage
import com.example.data.remoteconfig.AppOpenAdManager
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.service.OverdueCustomerItem
import com.example.data.service.OverdueDuration
import com.example.data.util.AppFormatters
import com.example.data.util.SearchUtil
import com.example.data.util.ShareHelper
import com.example.ui.components.AddCustomerDialog
import com.example.ui.components.AvatarView
import com.example.ui.components.FestivalOfferCountdownBanner
import com.example.ui.components.LiveSessionMediumRectangleAd
import com.example.ui.components.RemoteAdBanner
import com.example.ui.components.SessionEntryBottomSheet
import com.example.ui.components.VipSubscriptionDialog
import com.example.ui.components.appTextFieldColors
import com.example.ui.components.getAvatarColor
import com.example.ui.theme.*
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.MainTab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val profile by viewModel.profile.collectAsState()
    val allCustomers by viewModel.allCustomers.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val overallStats by viewModel.overallStats.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()

    val formCustomerId by viewModel.formCustomerId.collectAsState()
    val formHours by viewModel.formHours.collectAsState()
    val formRate by viewModel.formRate.collectAsState()
    val formPaidAmount by viewModel.formPaidAmount.collectAsState()
    val formNote by viewModel.formNote.collectAsState()

    val isLiveTimerRunning by viewModel.isLiveTimerRunning.collectAsState()
    val isLiveTimerPaused by viewModel.isLiveTimerPaused.collectAsState()
    val liveTimerSeconds by viewModel.liveTimerSeconds.collectAsState()
    val liveTimerActiveCustId by viewModel.liveTimerActiveCustomerId.collectAsState()

    var showSessionModal by remember { mutableStateOf(false) }
    var showFarmerPickerBottomSheet by remember { mutableStateOf(false) }
    var showCustomerSearchDialog by remember { mutableStateOf(false) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showCalculatorDialog by remember { mutableStateOf(false) }
    var showVipSubscriptionDialog by remember { mutableStateOf(false) }

    // Sync remote pricing & remote ad config in background, and show App Open Ad immediately on Home
    LaunchedEffect(Unit) {
        // Run remote config & pricing sync in parallel background jobs so they do NOT delay ad display
        launch(Dispatchers.IO) {
            RemoteConfigService.fetchPricingOffersFromSupabase(context)
            RemoteConfigService.fetchFromSupabase(context)
        }

        // Show App Open Ad immediately on Home Screen (strictly follows AdMob guidelines: banners are auto-suppressed while showing)
        val currentActivity = activity ?: context.findActivity() ?: AppOpenAdManager.currentActivity
        AppOpenAdManager.showAdOrWait(currentActivity, maxWaitMs = 5000L, force = true) {
            // Callback when App Open Ad is dismissed or finished waiting
        }
    }

    val activeLiveCustomer = allCustomers.firstOrNull { it.id == liveTimerActiveCustId }
    val selectedCustomer = allCustomers.firstOrNull { it.id == formCustomerId } ?: activeLiveCustomer

    val hoursVal = formHours.toDoubleOrNull() ?: 0.0
    val rateVal = formRate.toDoubleOrNull() ?: (profile?.ratePerHour ?: 160.0)
    val totalCalculated = hoursVal * rateVal
    val paidVal = formPaidAmount.toDoubleOrNull() ?: 0.0
    val dueCalculated = (totalCalculated - paidVal).coerceAtLeast(0.0)

    // Find the latest completed session (or fallback to first)
    val latestSession = allSessions.maxByOrNull { it.sessionDate }
    val latestCustomer = if (latestSession != null) {
        allCustomers.firstOrNull { it.id == latestSession.customerId }
    } else null

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
    ) {
        // 1. Top Status Bar Line (Exact match with Image)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: LOCAL ACTIVE · READY
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2E7D32))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LOCAL ACTIVE · READY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        letterSpacing = 0.8.sp
                    )
                }

                // Right: Language Switcher Pills [EN] [हिंदी]
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val isHindi = currentLang == AppLanguage.HINDI
                    val isEnglish = currentLang == AppLanguage.ENGLISH

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isEnglish) Color(0xFFE8F5E9) else Color(0xFFF1F5F9),
                        border = BorderStroke(1.dp, if (isEnglish) Color(0xFF2E7D32) else Color(0xFFCBD5E1)),
                        modifier = Modifier
                            .clickable { viewModel.setLanguage(AppLanguage.ENGLISH) }
                            .testTag("lang_pill_en")
                    ) {
                        Text(
                            text = "EN",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isEnglish) Color(0xFF1B5E20) else Color(0xFF64748B),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontSize = 11.sp
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isHindi) Color(0xFFE8F5E9) else Color(0xFFF1F5F9),
                        border = BorderStroke(1.dp, if (isHindi) Color(0xFF2E7D32) else Color(0xFFCBD5E1)),
                        modifier = Modifier
                            .clickable { viewModel.setLanguage(AppLanguage.HINDI) }
                            .testTag("lang_pill_hi")
                    ) {
                        Text(
                            text = "हिंदी",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isHindi) Color(0xFF1B5E20) else Color(0xFF64748B),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // 1.5 Top Festival / Flash Sale Countdown Offer Banner (Flipkart Style)
        item {
            FestivalOfferCountdownBanner(
                onBannerClick = { showVipSubscriptionDialog = true }
            )
        }

        // 2. Owner Green Header Banner (Exact match with Image)
        item {
            val ownerDisplayName = profile?.agencyName?.takeIf { it.isNotBlank() }
                ?: profile?.name?.takeIf { it.isNotBlank() }
                ?: "Kisan Tubewell & Sinchai Seva"
            val ownerRate = profile?.ratePerHour?.toInt() ?: (formRate.toDoubleOrNull()?.toInt() ?: 160)

            Surface(
                color = Color(0xFF1B5E20),
                shape = RoundedCornerShape(18.dp),
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Golden Drop in Amber Circle
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFA000)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = "Drop",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Title & Subtitle Column
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = ownerDisplayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "📍 $ownerDisplayName • ₹$ownerRate/hr Rate",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC8E6C9),
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Right Circular Initials Avatar (Dynamic Initial profile)
                    AvatarView(
                        name = profile?.name ?: "KR",
                        bgColor = 0xFFE65100,
                        size = 42,
                        shape = CircleShape
                    )
                }
            }
        }

        // 3. "सिंचाई सेवा खाता" Action Card (Exact match with Image)
        item {
            val agencyName = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "Kisan Tubewell & Sinchai Seva"
            val currentRate = profile?.ratePerHour?.toInt() ?: (formRate.toDoubleOrNull()?.toInt() ?: 160)

            Surface(
                color = Color.White,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.5.dp, Color(0xFF2E7D32)),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = "Drop",
                            tint = Color(0xFF1B5E20),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "सिंचाई सेवा खाता",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                fontSize = 17.sp
                            )
                            Text(
                                text = agencyName,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B),
                                fontSize = 13.sp
                            )
                        }

                        Surface(
                            color = Color(0xFFFFF3E0),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Color(0xFFFFE082))
                        ) {
                            Text(
                                text = "₹$currentRate/घंटा",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Big Prominent Green Button: "व्यक्ति चुनें और सत्र शुरू करें"
                    Surface(
                        color = Color(0xFF1B5E20),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showFarmerPickerBottomSheet = true }
                            .testTag("start_session_main_action")
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 14.dp, horizontal = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "व्यक्ति चुनें और सत्र शुरू करें",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 16.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "लाइव टाइमर, शुरू-समाप्त समय या सीधे घंटे",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFC8E6C9),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // 4 & 5. Section: Live Running Session OR Last Completed Session
        val isLiveSessionActive = isLiveTimerRunning || liveTimerSeconds > 0L

        if (isLiveSessionActive) {
            // Section Title for Active Live Session
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🔴 लाइव चल रहा सत्र (ACTIVE RUNNING SESSION)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFC62828),
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Active Running Live Timer Banner (Ultra HD High-Contrast White Background for Village & Elder Users)
            item {
                val isLiveTimerActiveRunning = isLiveTimerRunning && !isLiveTimerPaused
                val liveHrs = liveTimerSeconds / 3600
                val liveMins = (liveTimerSeconds % 3600) / 60
                val liveSecs = liveTimerSeconds % 60
                val timeStr = String.format(Locale.ROOT, "%02d:%02d:%02d", liveHrs, liveMins, liveSecs)
                val decimalHrs = liveTimerSeconds / 3600.0
                val rate = profile?.ratePerHour ?: 160.0
                val currentCost = decimalHrs * rate

                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(2.dp, if (isLiveTimerActiveRunning) Color(0xFF16A34A) else Color(0xFFD97706)),
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Top Header: Status Indicator + Customer Badge
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (isLiveTimerActiveRunning) Color(0xFFDCFCE7) else Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, if (isLiveTimerActiveRunning) Color(0xFF86EFAC) else Color(0xFFFDE68A))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(if (isLiveTimerActiveRunning) Color(0xFF16A34A) else Color(0xFFD97706))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isLiveTimerActiveRunning) "🔴 मोटर चल रही है (LIVE)" else "⏸️ सत्र रुका हुआ है (PAUSED)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Black,
                                        color = if (isLiveTimerActiveRunning) Color(0xFF166534) else Color(0xFF92400E),
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            if (activeLiveCustomer != null) {
                                Surface(
                                    color = Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = null,
                                            tint = Color(0xFF1B5E20),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = activeLiveCustomer.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Black,
                                            color = Color(0xFF0F172A),
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        // Middle Section: Large HD Monospace Stopwatch + Prominent Cost (Rupees with Paise)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "कुल बीता समय",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF334155),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = timeStr,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF0F172A),
                                    fontSize = 32.sp,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "अब तक बना रुपया",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF334155),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                // Rupees & Paise Display with 2 Decimal Digits (HD Dark Green)
                                Text(
                                    text = "₹${Math.round(currentCost)}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF15803D),
                                    fontSize = 26.sp
                                )
                                Text(
                                    text = "${AppFormatters.formatSessionDuration(decimalHrs)} @ ₹${rate.toInt()}/घंटा",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF475569),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Bottom Action Controls (Large, Easy to press for villagers)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Pause / Resume Button
                            Button(
                                onClick = {
                                    if (isLiveTimerActiveRunning) viewModel.pauseLiveTimer()
                                    else viewModel.resumeLiveTimer()
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isLiveTimerActiveRunning) Color(0xFFD97706) else Color(0xFF16A34A)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isLiveTimerActiveRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isLiveTimerActiveRunning) "रोकें (Pause)" else "पुनः चालू करें (Play)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            // Complete Session Button
                            Button(
                                onClick = { showSessionModal = true },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                                modifier = Modifier
                                    .weight(1.3f)
                                    .height(46.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "सत्र समाप्त करें",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // High-eCPM Medium Rectangle Ad (300x250) in the empty space below Live Session
            item {
                LiveSessionMediumRectangleAd(
                    modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)
                )
            }
        } else {
            // Section Title: "✅ अंतिम संपन्न सत्र (LAST COMPLETED SESSION)"
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 0.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✅ अंतिम संपन्न सत्र (LAST COMPLETED SESSION)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF334155),
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Last Completed Session Card
            item {
                if (latestSession != null && latestCustomer != null) {
                    val session = latestSession
                    val customer = latestCustomer
                    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                    val sessionDateStr = sdf.format(Date(session.sessionDate))

                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Top Header Row - Session Date & Status
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = Color(0xFFE8F5E9),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF16A34A),
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "सत्र विवरण",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF1B5E20),
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Text(
                                    text = sessionDateStr,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF64748B),
                                    fontSize = 12.sp
                                )
                            }

                            // Customer Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectCustomerForDetail(customer.id) },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Initial Avatar
                                AvatarView(
                                    name = customer.name,
                                    bgColor = customer.avatarBgColor,
                                    size = 46,
                                    shape = CircleShape
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = customer.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A),
                                        fontSize = 17.sp
                                    )
                                    val details = buildString {
                                        if (customer.sO.isNotBlank()) append("पिता: ${customer.sO} • ")
                                        if (customer.phone.isNotBlank()) append("📞 ${customer.phone}")
                                    }
                                    Text(
                                        text = details,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF64748B),
                                        fontSize = 13.sp
                                    )
                                }

                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = "View",
                                    tint = Color(0xFF94A3B8)
                                )
                            }

                            // Two Metric Boxes: [कुल समय चला] & [कुल बना रुपया]
                            val hoursInt = session.hours.toInt()
                            val minsInt = ((session.hours - hoursInt) * 60).toInt()
                            val timeFormatted = String.format(Locale.ROOT, "%02d:%02d:00", hoursInt, minsInt)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Left Box
                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "कुल समय चला",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF64748B),
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "$hoursInt घंटे $minsInt मिनट 0 सेकंड",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A),
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "($timeFormatted)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF64748B),
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                // Right Box
                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "कुल बना रुपया",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF64748B),
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "₹${Math.round(session.totalAmount)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB71C1C),
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = "(${Math.round(session.totalAmount)} रुपये)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF64748B),
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            // Balance Status Line
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🔴 शेष बाकी: ₹${Math.round(session.dueAmount)} (जमा: ₹${Math.round(session.paidAmount)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (session.dueAmount > 0) Color(0xFFB71C1C) else Color(0xFF2E7D32),
                                    fontSize = 12.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "दर: ₹${session.rate.toInt()}/घंटा",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF64748B),
                                    fontSize = 12.sp
                                )
                            }

                            // 3 Action Buttons in a Single Clean Row: [🗂️ बही-खाता] [▶ नया सत्र] [📤 सेंड पर्ची]
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.selectCustomerForDetail(customer.id) },
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF0F172A)),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "🗂️ बही-खाता",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFF0F172A),
                                        maxLines = 1
                                    )
                                }

                                Button(
                                    onClick = {
                                        viewModel.formCustomerId.value = customer.id
                                        showSessionModal = true
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = "▶ नया सत्र",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color.White,
                                        maxLines = 1
                                    )
                                }

                                Button(
                                    onClick = {
                                        viewModel.openSessionReceipt(session, customer)
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Send,
                                            contentDescription = "Send",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = "सेंड पर्ची",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = Color.White,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE8F5E9)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = Color(0xFF1B5E20),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Text(
                                text = "अभी कोई पिछला सत्र दर्ज नहीं है",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "नया ट्यूबवेल सत्र शुरू करने के लिए नीचे '⏱️ नया ट्यूबवेल सत्र शुरू करें' बटन दबाएं।",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }

    // 3-Mode Session Entry Bottom Sheet (Live Timer, Start-End Time, Direct Hours)
    if (showSessionModal) {
        val targetCustomer = selectedCustomer ?: allCustomers.firstOrNull()
        SessionEntryBottomSheet(
            customer = targetCustomer,
            viewModel = viewModel,
            onDismiss = { showSessionModal = false },
            onViewLiveTimerOnHome = { showSessionModal = false }
        )
    }

    // Farmer Selection Modal Bottom Sheet (Matching IMG_20260827_125758.jpg)
    if (showFarmerPickerBottomSheet) {
        var pickerSearchQuery by remember { mutableStateOf("") }
        val filteredList = allCustomers.filter {
            SearchUtil.matchesQuery(it.name, it.phone, it.sO, pickerSearchQuery)
        }

        ModalBottomSheet(
            onDismissRequest = { showFarmerPickerBottomSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(top = 12.dp, bottom = 8.dp)
                        .width(44.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFCBD5E1))
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "किसान का चयन करें",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            fontSize = 18.sp
                        )
                        Text(
                            text = "सत्र शुरू करने या घंटे दर्ज करने के लिए किसान चुनें",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }

                    // + नया किसान Button
                    Surface(
                        color = Color(0xFF1B5E20),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clickable {
                                showAddCustomerDialog = true
                            }
                            .testTag("picker_add_new_customer")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "+ नया किसान",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                // Phonetic & Realtime Search Bar
                OutlinedTextField(
                    value = pickerSearchQuery,
                    onValueChange = { pickerSearchQuery = it },
                    placeholder = {
                        Text(
                            text = "नाम या नंबर खोजें (उदा. रमेश, Ramesh, 98765)...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF94A3B8),
                            fontSize = 14.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    trailingIcon = {
                        if (pickerSearchQuery.isNotEmpty()) {
                            IconButton(onClick = { pickerSearchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = Color(0xFF64748B)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("picker_search_input")
                )

                // Subtitle: "N किसान उपलब्ध हैं"
                Text(
                    text = "${filteredList.size} किसान उपलब्ध हैं",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF475569),
                    fontSize = 12.sp
                )

                // List of Farmers
                if (filteredList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "कोई किसान नहीं मिला",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF64748B)
                            )
                            Button(
                                onClick = { showAddCustomerDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PersonAdd,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "नया किसान जोड़ें",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 440.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredList, key = { it.id }) { cust ->
                            // Calculate net due for this customer
                            val custSessions = allSessions.filter { it.customerId == cust.id }
                            val custTxns = allTransactions.filter { it.customerId == cust.id }
                            val billed = cust.initialBalance + custSessions.sumOf { it.totalAmount }
                            val paid = custSessions.sumOf { it.paidAmount } + custTxns.sumOf { it.amountDeposited }
                            val due = (billed - paid).coerceAtLeast(0.0)

                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Color.White,
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                shadowElevation = 1.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.onSelectCustomerForQuickEntry(cust.id)
                                        showFarmerPickerBottomSheet = false
                                        showSessionModal = true
                                    }
                                    .testTag("picker_customer_item_${cust.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Initial Avatar
                                    AvatarView(
                                        name = cust.name,
                                        bgColor = cust.avatarBgColor,
                                        size = 42,
                                        shape = RoundedCornerShape(10.dp)
                                    )

                                    Spacer(modifier = Modifier.width(12.dp))

                                    // Name & Father/Phone details
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = cust.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A),
                                            fontSize = 15.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        val details = buildString {
                                            if (cust.sO.isNotBlank()) append("पिता: ${cust.sO} • ")
                                            if (cust.phone.isNotBlank()) {
                                                val p = cust.phone
                                                if (p.length >= 6) append("📞 ${p.take(6)}...")
                                                else append("📞 $p")
                                            }
                                        }
                                        Text(
                                            text = details,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF64748B),
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // Right section: Due balance & Start button
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "₹${String.format(Locale.ROOT, "%,d", Math.round(due))}",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = if (due > 0) Color(0xFFB71C1C) else Color(0xFF2E7D32),
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = if (due > 0) "बकाया" else "चुकता",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (due > 0) Color(0xFFB71C1C) else Color(0xFF2E7D32),
                                                fontSize = 10.sp
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                viewModel.onSelectCustomerForQuickEntry(cust.id)
                                                showFarmerPickerBottomSheet = false
                                                showSessionModal = true
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text(
                                                    text = "शुरू करें",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Customer Selection Dialog (Fallback/Alternative)
    if (showCustomerSearchDialog) {
        var searchQuery by remember { mutableStateOf("") }
        val filteredList = allCustomers.filter {
            SearchUtil.matchesQuery(it.name, it.phone, it.sO, searchQuery)
        }

        AlertDialog(
            onDismissRequest = { showCustomerSearchDialog = false },
            title = {
                Text(
                    text = "किसान / ग्राहक चुनें",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("नाम या फोन नंबर से खोजें...") },
                        leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color(0xFF1B5E20)) },
                        singleLine = true,
                        colors = appTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (filteredList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("कोई किसान नहीं मिला", color = Color(0xFF64748B))
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        showCustomerSearchDialog = false
                                        showAddCustomerDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100))
                                ) {
                                    Text("+ नया किसान जोड़ें")
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredList) { cust ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFF8FAFC),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.onSelectCustomerForQuickEntry(cust.id)
                                            showCustomerSearchDialog = false
                                        }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(10.dp)
                                    ) {
                                        AvatarView(name = cust.name, size = 38)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(cust.name, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                            if (cust.sO.isNotBlank()) {
                                                Text("सुपुत्र: श्री ${cust.sO}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                                            }
                                        }
                                        if (cust.phone.isNotBlank()) {
                                            Text(cust.phone, style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCustomerSearchDialog = false }) {
                    Text("बंद करें", color = Color(0xFF1B5E20))
                }
            }
        )
    }

    // Time Calculator Dialog
    if (showCalculatorDialog) {
        var startH by remember { mutableStateOf("08") }
        var startM by remember { mutableStateOf("00") }
        var endH by remember { mutableStateOf("12") }
        var endM by remember { mutableStateOf("30") }

        AlertDialog(
            onDismissRequest = { showCalculatorDialog = false },
            title = {
                Text(
                    text = "मोटर चालू व बंद समय कैलकुलेटर",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B5E20)
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("मोटर चालू करने का समय (Start Time):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = startH,
                            onValueChange = { if (it.length <= 2) startH = it },
                            label = { Text("घंटा (0-23)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = appTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = startM,
                            onValueChange = { if (it.length <= 2) startM = it },
                            label = { Text("मिनट (0-59)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = appTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text("मोटर बंद करने का समय (Stop Time):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = endH,
                            onValueChange = { if (it.length <= 2) endH = it },
                            label = { Text("घंटा (0-23)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = appTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = endM,
                            onValueChange = { if (it.length <= 2) endM = it },
                            label = { Text("मिनट (0-59)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = appTextFieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sH = startH.toIntOrNull() ?: 0
                        val sM = startM.toIntOrNull() ?: 0
                        val eH = endH.toIntOrNull() ?: 0
                        val eM = endM.toIntOrNull() ?: 0

                        val startMins = sH * 60 + sM
                        var endMins = eH * 60 + eM
                        if (endMins < startMins) endMins += 24 * 60
                        val diff = endMins - startMins
                        val calculatedHours = diff / 60.0
                        viewModel.formHours.value = String.format(Locale.ROOT, "%.1f", calculatedHours)
                        showCalculatorDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20))
                ) {
                    Text("घंटे सेट करें", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCalculatorDialog = false }) {
                    Text("रद्द करें", color = Color(0xFF64748B))
                }
            }
        )
    }

    // Add Customer Modal Dialog
    if (showAddCustomerDialog) {
        AddCustomerDialog(
            viewModel = viewModel,
            onDismiss = { showAddCustomerDialog = false },
            onCustomerAdded = { newCust ->
                showFarmerPickerBottomSheet = false
                viewModel.onSelectCustomerForQuickEntry(newCust.id)
                showSessionModal = true
            }
        )
    }

    // VIP Subscription & Razorpay Payment Dialog
    if (showVipSubscriptionDialog) {
        VipSubscriptionDialog(
            onDismiss = { showVipSubscriptionDialog = false },
            userPhone = profile?.phone ?: "",
            userEmail = profile?.email ?: ""
        )
    }
}
