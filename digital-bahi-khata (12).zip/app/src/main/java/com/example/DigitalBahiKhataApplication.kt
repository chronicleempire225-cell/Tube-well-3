package com.example

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import com.example.data.remoteconfig.AppOpenAdManager
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.remoteconfig.RewardedAdManager
import com.example.data.service.BackgroundNotificationScheduler
import com.example.data.service.DuePaymentReminderManager
import com.example.data.service.LiveTimerManager
import com.google.android.gms.ads.MobileAds

/**
 * Main Application class for Digital Bahi Khata.
 * Initializes background notification scheduling (WorkManager + AlarmManager)
 * and notification channels so notifications work seamlessly in the background
 * even when the app is closed.
 */
class DigitalBahiKhataApplication : Application(), Application.ActivityLifecycleCallbacks {

    companion object {
        private const val TAG = "BahiKhataApp"
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "DigitalBahiKhataApplication initialized.")

        registerActivityLifecycleCallbacks(this)

        try {
            // Ensure WebView Code Cache directories exist so Chromium doesn't fail with opendir errors on first run
            try {
                val codeCacheDir = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache")
                java.io.File(codeCacheDir, "js").mkdirs()
                java.io.File(codeCacheDir, "wasm").mkdirs()
            } catch (ignored: Throwable) {}

            // 1. Initialize notification channels
            DuePaymentReminderManager.createNotificationChannel(this)

            // 2. Initialize live timer state from disk
            LiveTimerManager.init(this)

            // 3. Schedule WorkManager Periodic Worker & Alarms for background calculations & notifications
            BackgroundNotificationScheduler.schedulePeriodicWork(this)
            Log.d(TAG, "WorkManager periodic due check & background scheduling registered.")

            // 4. Initialize Dynamic Remote Config & Feature Flags
            RemoteConfigService.init(this)

            // 5. Initialize Google Mobile Ads SDK on Main Thread
            try {
                val reqConfig = com.google.android.gms.ads.RequestConfiguration.Builder()
                    .setTestDeviceIds(listOf(com.google.android.gms.ads.AdRequest.DEVICE_ID_EMULATOR))
                    .build()
                MobileAds.setRequestConfiguration(reqConfig)
                MobileAds.initialize(this) { initStatus ->
                    Log.d(TAG, "Google Mobile Ads SDK initialized successfully: $initStatus")
                    AppOpenAdManager.loadAd(this)
                }
            } catch (e: Exception) {
                Log.w(TAG, "MobileAds initialization error: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed during Application initialization: ${e.message}", e)
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        AppOpenAdManager.currentActivity = activity
    }

    override fun onActivityStarted(activity: Activity) {
        AppOpenAdManager.currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        AppOpenAdManager.currentActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {
        if (AppOpenAdManager.currentActivity == activity) {
            AppOpenAdManager.currentActivity = null
        }
    }
}
