-- ==============================================================================
-- 🛡️ KISAN TUBEWELL BAHI KHATA - SUPABASE SECURITY & BLOCKED USERS TABLE MIGRATION
-- ==============================================================================
-- यह SQL स्क्रिप्ट Supabase में सुरक्षा ब्लॉक (Brute-force lockout & blocked users) 
-- के लिए समर्पित टेबल `blocked_users` बनाती है तथा `profiles` टेबल में सुरक्षा 
-- कॉलम्स (`is_blocked`, `device_id`, `bot_trap`, `client_version`) सुनिश्चित करती है।
-- ==============================================================================

-- 1. profiles टेबल में सुरक्षा कॉलम्स सुनिश्चित करें (यदि पहले से नहीं हैं)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_blocked BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS device_id TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bot_trap TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS client_version TEXT DEFAULT 'android_v1.0';

-- 2. समर्पित ब्लॉक टेबल: `blocked_users` बनाएं
CREATE TABLE IF NOT EXISTS public.blocked_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone TEXT NOT NULL,
    profile_id TEXT DEFAULT '',
    reason TEXT NOT NULL DEFAULT 'BRUTE_FORCE_FAILED_ATTEMPTS',
    failed_attempts INTEGER DEFAULT 5,
    device_id TEXT DEFAULT '',
    client_version TEXT DEFAULT 'android_v1.0',
    is_blocked BOOLEAN NOT NULL DEFAULT TRUE,
    blocked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    unblock_at TIMESTAMP WITH TIME ZONE,
    ip_address TEXT DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. फ़ास्ट लुकअप के लिए इंडेक्स बनाएं
CREATE INDEX IF NOT EXISTS idx_blocked_users_phone ON public.blocked_users (phone);
CREATE INDEX IF NOT EXISTS idx_blocked_users_is_blocked ON public.blocked_users (is_blocked);
CREATE INDEX IF NOT EXISTS idx_blocked_users_created_at ON public.blocked_users (created_at DESC);

-- 4. Row Level Security (RLS) परमिशन्स सक्षम करें (App व Anon Access के लिए)
ALTER TABLE public.blocked_users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow anon read blocked_users" ON public.blocked_users;
CREATE POLICY "Allow anon read blocked_users" ON public.blocked_users 
    FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "Allow anon insert blocked_users" ON public.blocked_users;
CREATE POLICY "Allow anon insert blocked_users" ON public.blocked_users 
    FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "Allow anon update blocked_users" ON public.blocked_users;
CREATE POLICY "Allow anon update blocked_users" ON public.blocked_users 
    FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow anon delete blocked_users" ON public.blocked_users;
CREATE POLICY "Allow anon delete blocked_users" ON public.blocked_users 
    FOR DELETE TO anon, authenticated USING (true);

-- 5. वैकल्पिक एलियास व्यू (यदि कोई क्वेरी 'blocks' नाम से ढूंढे)
CREATE OR REPLACE VIEW public.blocks AS SELECT * FROM public.blocked_users;
