-- ==============================================================================
-- 🚀 KISAN TUBEWELL BAHI KHATA - SUPABASE VIP SUBSCRIPTION & DAYS SCHEMA MIGRATION
-- ==============================================================================
-- यह SQL स्क्रिप्ट profiles टेबल में VIP सदस्यता के दिन (vip_days_remaining), 
-- एक्सपायरी (vip_expiry), और प्लान (vip_plan) के कॉलम जोड़ती है, 
-- तथा रोज़ाना बचे हुए दिन ऑटो-अपडेट करने के लिए ट्रिगर बनाती है।
-- ==============================================================================

-- 1. profiles टेबल में VIP कॉलम्स जोड़ें (यदि पहले से नहीं हैं)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_member BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_days_remaining INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_expiry TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_plan TEXT DEFAULT 'VIP_MEMBERSHIP';

-- 2. VIP सब्सक्रिप्शन व पेमेंट हिस्ट्री टेबल बनाएं
CREATE TABLE IF NOT EXISTS public.app_subscriptions (
    id BIGSERIAL PRIMARY KEY,
    payment_id TEXT NOT NULL,
    phone TEXT DEFAULT '',
    plan_type TEXT DEFAULT 'MONTHLY',
    amount NUMERIC DEFAULT 0.0,
    days_added INTEGER DEFAULT 30,
    total_days_remaining INTEGER DEFAULT 30,
    expires_at TIMESTAMP WITH TIME ZONE,
    is_premium BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    payment_status TEXT DEFAULT 'SUCCESS',
    platform TEXT DEFAULT 'ANDROID_RAZORPAY',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. ऑटो-सिंक ट्रिगर: जब भी vip_expiry या vip_days_remaining अपडेट हो, 
-- तो बाकी बचे दिन (vip_days_remaining) अपने आप सही गणना होकर सेव हो जाएं
CREATE OR REPLACE FUNCTION public.sync_profile_vip_status()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.vip_expiry IS NOT NULL THEN
        NEW.vip_days_remaining := GREATEST(0, CEIL(EXTRACT(EPOCH FROM (NEW.vip_expiry - NOW())) / 86400)::INTEGER);
        IF NEW.vip_expiry > NOW() THEN
            NEW.vip_member := TRUE;
            NEW.is_premium := TRUE;
        ELSE
            NEW.vip_member := FALSE;
            NEW.vip_days_remaining := 0;
        END IF;
    ELSIF NEW.vip_days_remaining IS NOT NULL AND NEW.vip_days_remaining > 0 THEN
        IF NEW.vip_expiry IS NULL THEN
            NEW.vip_expiry := NOW() + (NEW.vip_days_remaining || ' days')::INTERVAL;
        END IF;
        NEW.vip_member := TRUE;
        NEW.is_premium := TRUE;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_profile_vip_status ON public.profiles;
CREATE TRIGGER trg_sync_profile_vip_status
BEFORE INSERT OR UPDATE OF vip_expiry, vip_days_remaining ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.sync_profile_vip_status();

-- 4. रोज़ाना शेष दिनों को अपडेट करने के लिए फंक्शन (Periodic Cron or Manual Trigger)
CREATE OR REPLACE FUNCTION public.refresh_all_vip_days()
RETURNS void AS $$
BEGIN
    UPDATE public.profiles
    SET vip_days_remaining = GREATEST(0, CEIL(EXTRACT(EPOCH FROM (vip_expiry - NOW())) / 86400)::INTEGER),
        vip_member = CASE WHEN vip_expiry > NOW() THEN TRUE ELSE FALSE END,
        is_premium = CASE WHEN vip_expiry > NOW() THEN TRUE ELSE FALSE END
    WHERE vip_expiry IS NOT NULL;
END;
$$ LANGUAGE plpgsql;

-- 5. Row Level Security (RLS) परमिशन्स
ALTER TABLE public.app_subscriptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow app access to app_subscriptions" ON public.app_subscriptions;
CREATE POLICY "Allow app access to app_subscriptions" ON public.app_subscriptions 
    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- 6. ईमेल सत्यापन व पासवर्ड रीसेट टोकन टेबल (Edge Functions के लिए)
CREATE TABLE IF NOT EXISTS public.email_verifications (
    id BIGSERIAL PRIMARY KEY,
    email TEXT NOT NULL,
    token TEXT NOT NULL UNIQUE,
    otp TEXT NOT NULL,
    purpose TEXT DEFAULT 'VERIFY_EMAIL',
    new_pin TEXT DEFAULT '',
    status TEXT DEFAULT 'PENDING',
    is_used BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_verifications_token ON public.email_verifications (token);
CREATE INDEX IF NOT EXISTS idx_email_verifications_email_status ON public.email_verifications (email, status);

ALTER TABLE public.email_verifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow app access to email_verifications" ON public.email_verifications;
CREATE POLICY "Allow app access to email_verifications" ON public.email_verifications 
    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- 8. सुरक्षा व ब्लॉक टेबल (Brute-force protection and user block management)
CREATE TABLE IF NOT EXISTS public.blocked_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone TEXT NOT NULL,
    profile_id TEXT DEFAULT '',
    reason TEXT NOT NULL DEFAULT 'BRUTE_FORCE_FAILED_ATTEMPTS',
    failed_attempts INTEGER DEFAULT 5,
    device_id TEXT DEFAULT '',
    client_version TEXT DEFAULT 'android_v1.0',
    is_blocked BOOLEAN NOT NULL DEFAULT TRUE,
    blocked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    unblock_at TIMESTAMP WITH TIME ZONE,
    ip_address TEXT DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_blocked_users_phone ON public.blocked_users (phone);
CREATE INDEX IF NOT EXISTS idx_blocked_users_is_blocked ON public.blocked_users (is_blocked);

ALTER TABLE public.blocked_users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow app access to blocked_users" ON public.blocked_users;
CREATE POLICY "Allow app access to blocked_users" ON public.blocked_users 
    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_blocked BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS device_id TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bot_trap TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS client_version TEXT DEFAULT 'android_v1.0';


