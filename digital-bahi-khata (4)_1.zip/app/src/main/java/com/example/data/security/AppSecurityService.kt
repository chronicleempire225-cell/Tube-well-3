package com.example.data.security

import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.example.data.supabase.SupabaseAuthService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * AppSecurityService
 * Handles:
 * 1. Brute-force protection: Tracks failed login attempts and locks accounts after limit.
 * 2. Supabase Block Table integration:
 *    - Records blocks directly in Supabase `blocked_users` table
 *    - Updates `is_blocked = true` in Supabase `profiles` table
 *    - Queries Supabase block tables before permitting authentication
 *    - Provides live Supabase block table records for admin/user security inspection
 * 3. Bot-trap & Honeypot detection
 * 4. Device ID and client version telemetry
 */
object AppSecurityService {
    private const val TAG = "AppSecurityService"
    private const val PREFS_NAME = "bahi_khata_security_prefs"

    const val MAX_FAILED_ATTEMPTS = 5
    const val LOCKOUT_DURATION_MS = 15 * 60 * 1000L // 15 minutes cooldown

    private const val KEY_ATTEMPTS_PREFIX = "failed_attempts_"
    private const val KEY_LOCKOUT_PREFIX = "lockout_until_"
    private const val KEY_BLOCK_REASON_PREFIX = "block_reason_"
    private const val KEY_IS_BLOCKED_PREFIX = "is_blocked_"

    data class BlockedUserRecord(
        val id: String,
        val phone: String,
        val profileId: String = "",
        val name: String = "",
        val reason: String,
        val failedAttempts: Int = 5,
        val deviceId: String = "",
        val clientVersion: String = "android_v1.0",
        val isBlocked: Boolean = true,
        val blockedAt: String = "",
        val unblockAt: String = "",
        val sourceTable: String = "blocked_users"
    )

    data class SecurityStatus(
        val isBlocked: Boolean,
        val reason: String,
        val remainingMinutes: Long = 0,
        val isCloudBlocked: Boolean = false
    )

    fun getClientVersion(): String = "android_v1.0"

    fun getDeviceId(context: Context): String {
        return try {
            val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            if (!androidId.isNullOrBlank()) androidId else "device_${Build.MODEL.replace(" ", "_")}"
        } catch (_: Exception) {
            "device_${Build.MODEL.replace(" ", "_")}"
        }
    }

    fun getDeviceInfo(): String {
        return "${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, SDK ${Build.VERSION.SDK_INT})"
    }

    private fun getIsoTimestamp(millis: Long = System.currentTimeMillis()): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        return sdf.format(Date(millis))
    }

    // ==========================================
    // FAILED ATTEMPTS & LOCAL BRUTE FORCE SHIELD
    // ==========================================

    fun getFailedAttempts(context: Context, phone: String): Int {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) return 0
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_ATTEMPTS_PREFIX + cleanPhone, 0)
    }

    fun recordFailedAttempt(context: Context, phone: String): Int {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) return MAX_FAILED_ATTEMPTS
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val current = prefs.getInt(KEY_ATTEMPTS_PREFIX + cleanPhone, 0) + 1
        prefs.edit().putInt(KEY_ATTEMPTS_PREFIX + cleanPhone, current).apply()
        return (MAX_FAILED_ATTEMPTS - current).coerceAtLeast(0)
    }

    fun resetFailedAttempts(context: Context, phone: String) {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .remove(KEY_ATTEMPTS_PREFIX + cleanPhone)
            .remove(KEY_LOCKOUT_PREFIX + cleanPhone)
            .remove(KEY_BLOCK_REASON_PREFIX + cleanPhone)
            .remove(KEY_IS_BLOCKED_PREFIX + cleanPhone)
            .apply()
    }

    fun isAccountLockedOutLocally(context: Context, phone: String): Pair<Boolean, Long> {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) return Pair(false, 0L)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isExplicitlyBlocked = prefs.getBoolean(KEY_IS_BLOCKED_PREFIX + cleanPhone, false)
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_PREFIX + cleanPhone, 0L)
        val now = System.currentTimeMillis()

        if (isExplicitlyBlocked) {
            val remMillis = (lockoutUntil - now).coerceAtLeast(0L)
            val remMinutes = (remMillis / 60000L).coerceAtLeast(1L)
            return Pair(true, remMinutes)
        }

        if (lockoutUntil > now) {
            val remMinutes = ((lockoutUntil - now) / 60000L).coerceAtLeast(1L)
            return Pair(true, remMinutes)
        }

        return Pair(false, 0L)
    }

    // ==========================================
    // SUPABASE CLOUD BLOCK CHECK & SYNC
    // ==========================================

    /**
     * Checks whether this phone/account is blocked in:
     * 1. Local device storage (lockout timer or security flag)
     * 2. Supabase `profiles` table (`is_blocked` = true)
     * 3. Supabase `blocked_users` table (or fallback `blocks` table)
     */
    suspend fun checkSecurityStatus(context: Context, phone: String): SecurityStatus = withContext(Dispatchers.IO) {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) {
            return@withContext SecurityStatus(false, "")
        }

        // 1. Local Lockout Check
        val (isLocallyLocked, remainingMin) = isAccountLockedOutLocally(context, cleanPhone)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val localReason = prefs.getString(KEY_BLOCK_REASON_PREFIX + cleanPhone, "बार-बार गलत पासवर्ड डालने के कारण सुरक्षा लॉक") ?: ""

        if (isLocallyLocked && remainingMin > 0) {
            return@withContext SecurityStatus(
                isBlocked = true,
                reason = localReason,
                remainingMinutes = remainingMin,
                isCloudBlocked = false
            )
        }

        // 2. Supabase Cloud Check if online
        val isOnline = SupabaseAuthService.isNetworkAvailable(context)
        val isConfigured = SupabaseAuthService.isConfigured(context)
        if (!isOnline || !isConfigured) {
            return@withContext SecurityStatus(isLocallyLocked, localReason, remainingMin)
        }

        val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
        val key = SupabaseAuthService.getSupabaseAnonKey(context)

        // Check Supabase profiles table
        try {
            val endpoints = listOf(
                "$url/rest/v1/profiles?phone=eq.$cleanPhone&select=id,name,is_blocked",
                "$url/rest/v1/profiles?mobile=eq.$cleanPhone&select=id,name,is_blocked"
            )
            for (ep in endpoints) {
                val (code, resp) = SupabaseAuthService.getFromSupabase(ep, key)
                if (code in 200..299 && !resp.isNullOrBlank()) {
                    val arr = JSONArray(resp)
                    if (arr.length() > 0) {
                        val obj = arr.getJSONObject(0)
                        val isBlocked = obj.optBoolean("is_blocked", false)
                        if (isBlocked) {
                            Log.w(TAG, "User $cleanPhone is BLOCKED in Supabase profiles table!")
                            // Save to local cache so offline also preserves block
                            prefs.edit()
                                .putBoolean(KEY_IS_BLOCKED_PREFIX + cleanPhone, true)
                                .putString(KEY_BLOCK_REASON_PREFIX + cleanPhone, "खाता एडमिन या सुरक्षा कारणों से ब्लॉक है")
                                .putLong(KEY_LOCKOUT_PREFIX + cleanPhone, System.currentTimeMillis() + LOCKOUT_DURATION_MS)
                                .apply()

                            return@withContext SecurityStatus(
                                isBlocked = true,
                                reason = "⛔ आपका खाता Supabase में एडमिन/सुरक्षा कारणों से ब्लॉक कर दिया गया है।",
                                remainingMinutes = 15,
                                isCloudBlocked = true
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error checking profiles is_blocked: ${e.message}")
        }

        // Check dedicated Supabase block tables: `blocked_users` and `blocks`
        val blockTableEndpoints = listOf(
            "$url/rest/v1/blocked_users?phone=eq.$cleanPhone&is_blocked=eq.true&select=*&limit=1",
            "$url/rest/v1/blocks?phone=eq.$cleanPhone&is_blocked=eq.true&select=*&limit=1"
        )
        for (ep in blockTableEndpoints) {
            try {
                val (code, resp) = SupabaseAuthService.getFromSupabase(ep, key)
                if (code in 200..299 && !resp.isNullOrBlank()) {
                    val arr = JSONArray(resp)
                    if (arr.length() > 0) {
                        val obj = arr.getJSONObject(0)
                        val reason = obj.optString("reason", "सुरक्षा प्रतिबंध")
                        Log.w(TAG, "User $cleanPhone found in Supabase block table ($ep): $reason")

                        prefs.edit()
                            .putBoolean(KEY_IS_BLOCKED_PREFIX + cleanPhone, true)
                            .putString(KEY_BLOCK_REASON_PREFIX + cleanPhone, reason)
                            .putLong(KEY_LOCKOUT_PREFIX + cleanPhone, System.currentTimeMillis() + LOCKOUT_DURATION_MS)
                            .apply()

                        return@withContext SecurityStatus(
                            isBlocked = true,
                            reason = "⛔ सुरक्षा प्रतिबंध: $reason",
                            remainingMinutes = 15,
                            isCloudBlocked = true
                        )
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Error checking block table: ${e.message}")
            }
        }

        SecurityStatus(false, "")
    }

    /**
     * Blocks user locally and pushes the block entry to Supabase:
     * 1. Updates `is_blocked = true` in Supabase `profiles`
     * 2. Inserts block record in Supabase `blocked_users` (and fallback `blocks`)
     */
    suspend fun blockAccount(
        context: Context,
        phone: String,
        reason: String,
        profileId: String? = null,
        failedAttempts: Int = MAX_FAILED_ATTEMPTS
    ): Boolean = withContext(Dispatchers.IO) {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) return@withContext false

        val now = System.currentTimeMillis()
        val lockoutUntil = now + LOCKOUT_DURATION_MS

        // 1. Local lock
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_BLOCKED_PREFIX + cleanPhone, true)
            .putLong(KEY_LOCKOUT_PREFIX + cleanPhone, lockoutUntil)
            .putString(KEY_BLOCK_REASON_PREFIX + cleanPhone, reason)
            .putInt(KEY_ATTEMPTS_PREFIX + cleanPhone, failedAttempts)
            .apply()

        Log.i(TAG, "Locally blocked phone $cleanPhone: $reason")

        // 2. Cloud Supabase Sync
        val isOnline = SupabaseAuthService.isNetworkAvailable(context)
        val isConfigured = SupabaseAuthService.isConfigured(context)
        if (!isOnline || !isConfigured) {
            return@withContext true
        }

        val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
        val key = SupabaseAuthService.getSupabaseAnonKey(context)

        // A. Update profiles table: is_blocked = true
        try {
            val patchPayload = JSONObject().apply {
                put("is_blocked", true)
                put("updated_at", now)
            }.toString()

            val patchEndpoints = listOf(
                "$url/rest/v1/profiles?phone=eq.$cleanPhone",
                "$url/rest/v1/profiles?mobile=eq.$cleanPhone"
            )
            for (ep in patchEndpoints) {
                try {
                    val conn = (URL(ep).openConnection() as HttpURLConnection).apply {
                        requestMethod = "PATCH"
                        SupabaseAuthService.applyAuthHeaders(this, key)
                        setRequestProperty("Content-Type", "application/json")
                        doOutput = true
                        connectTimeout = 4000
                        readTimeout = 4000
                    }
                    OutputStreamWriter(conn.outputStream).use { it.write(patchPayload) }
                    val code = conn.responseCode
                    Log.i(TAG, "PATCH profiles is_blocked code [$code] for $cleanPhone")
                    if (code in 200..299) break
                } catch (e: Exception) {
                    Log.w(TAG, "PATCH profiles failed: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating is_blocked in profiles: ${e.message}")
        }

        // B. Insert into dedicated block table: `blocked_users` (and fallback `blocks`)
        val blockPayload = JSONObject().apply {
            put("id", UUID.randomUUID().toString())
            put("phone", cleanPhone)
            if (!profileId.isNullOrBlank()) put("profile_id", profileId)
            put("reason", reason)
            put("failed_attempts", failedAttempts)
            put("device_id", getDeviceId(context))
            put("client_version", getClientVersion())
            put("is_blocked", true)
            put("blocked_at", getIsoTimestamp(now))
            put("unblock_at", getIsoTimestamp(lockoutUntil))
            put("created_at", getIsoTimestamp(now))
        }.toString()

        val tableCandidates = listOf(
            "$url/rest/v1/blocked_users",
            "$url/rest/v1/blocks",
            "$url/rest/v1/app_blocks"
        )

        var insertedInBlockTable = false
        for (ep in tableCandidates) {
            try {
                val conn = (URL(ep).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    SupabaseAuthService.applyAuthHeaders(this, key)
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    doOutput = true
                    connectTimeout = 4000
                    readTimeout = 4000
                }
                OutputStreamWriter(conn.outputStream).use { it.write(blockPayload) }
                val code = conn.responseCode
                Log.i(TAG, "POST to $ep returned code: $code")
                if (code in 200..299) {
                    insertedInBlockTable = true
                    break
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed inserting to $ep: ${e.message}")
            }
        }

        true
    }

    /**
     * Unblocks account locally and in Supabase
     */
    suspend fun unblockAccount(
        context: Context,
        phone: String,
        profileId: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val cleanPhone = phone.trim()
        if (cleanPhone.isEmpty()) return@withContext false

        // 1. Reset local state
        resetFailedAttempts(context, cleanPhone)
        Log.i(TAG, "Locally unblocked phone: $cleanPhone")

        // 2. Supabase Cloud Sync
        val isOnline = SupabaseAuthService.isNetworkAvailable(context)
        val isConfigured = SupabaseAuthService.isConfigured(context)
        if (!isOnline || !isConfigured) return@withContext true

        val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
        val key = SupabaseAuthService.getSupabaseAnonKey(context)

        // Update profiles table: is_blocked = false
        try {
            val patchPayload = JSONObject().apply {
                put("is_blocked", false)
                put("updated_at", System.currentTimeMillis())
            }.toString()

            val patchEndpoints = listOf(
                "$url/rest/v1/profiles?phone=eq.$cleanPhone",
                "$url/rest/v1/profiles?mobile=eq.$cleanPhone"
            )
            for (ep in patchEndpoints) {
                try {
                    val conn = (URL(ep).openConnection() as HttpURLConnection).apply {
                        requestMethod = "PATCH"
                        SupabaseAuthService.applyAuthHeaders(this, key)
                        setRequestProperty("Content-Type", "application/json")
                        doOutput = true
                    }
                    OutputStreamWriter(conn.outputStream).use { it.write(patchPayload) }
                    conn.responseCode
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error unblocking in profiles: ${e.message}")
        }

        // Update block table: is_blocked = false
        val blockEndpoints = listOf(
            "$url/rest/v1/blocked_users?phone=eq.$cleanPhone",
            "$url/rest/v1/blocks?phone=eq.$cleanPhone"
        )
        for (ep in blockEndpoints) {
            try {
                val conn = (URL(ep).openConnection() as HttpURLConnection).apply {
                    requestMethod = "PATCH"
                    SupabaseAuthService.applyAuthHeaders(this, key)
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                }
                OutputStreamWriter(conn.outputStream).use { it.write("{\"is_blocked\":false}") }
                conn.responseCode
            } catch (_: Exception) {}
        }

        true
    }

    /**
     * Fetches live block records from Supabase:
     * Queries `blocked_users`, `blocks`, and `profiles` where is_blocked = true.
     * Merges and deduplicates so all blocked users are returned to display in the UI.
     */
    suspend fun fetchSupabaseBlockRecords(context: Context): List<BlockedUserRecord> = withContext(Dispatchers.IO) {
        val resultList = mutableListOf<BlockedUserRecord>()
        val isOnline = SupabaseAuthService.isNetworkAvailable(context)
        val isConfigured = SupabaseAuthService.isConfigured(context)

        if (!isOnline || !isConfigured) {
            // Return local blocks from SharedPreferences if offline
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val allEntries = prefs.all
            for ((key, value) in allEntries) {
                if (key.startsWith(KEY_IS_BLOCKED_PREFIX) && value == true) {
                    val phone = key.removePrefix(KEY_IS_BLOCKED_PREFIX)
                    val reason = prefs.getString(KEY_BLOCK_REASON_PREFIX + phone, "सुरक्षा कारणों से ब्लॉक") ?: ""
                    resultList.add(
                        BlockedUserRecord(
                            id = "local_$phone",
                            phone = phone,
                            reason = reason,
                            failedAttempts = prefs.getInt(KEY_ATTEMPTS_PREFIX + phone, 5),
                            deviceId = getDeviceId(context),
                            isBlocked = true,
                            blockedAt = "ऑफ़लाइन रिकॉर्ड",
                            sourceTable = "फोन मेमोरी (ऑफ़लाइन)"
                        )
                    )
                }
            }
            return@withContext resultList
        }

        val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
        val key = SupabaseAuthService.getSupabaseAnonKey(context)
        val seenPhones = mutableSetOf<String>()

        // 1. Fetch from `blocked_users` table
        val blockTableEndpoints = listOf(
            "$url/rest/v1/blocked_users?select=*&order=created_at.desc&limit=50",
            "$url/rest/v1/blocks?select=*&order=created_at.desc&limit=50"
        )
        for (ep in blockTableEndpoints) {
            try {
                val (code, resp) = SupabaseAuthService.getFromSupabase(ep, key)
                if (code in 200..299 && !resp.isNullOrBlank()) {
                    val arr = JSONArray(resp)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val phone = obj.optString("phone", "")
                        if (phone.isNotBlank() && !seenPhones.contains(phone)) {
                            seenPhones.add(phone)
                            resultList.add(
                                BlockedUserRecord(
                                    id = obj.optString("id", UUID.randomUUID().toString()),
                                    phone = phone,
                                    profileId = obj.optString("profile_id", ""),
                                    reason = obj.optString("reason", "5 बार गलत पिन (सुरक्षा ब्लॉक)"),
                                    failedAttempts = obj.optInt("failed_attempts", 5),
                                    deviceId = obj.optString("device_id", ""),
                                    clientVersion = obj.optString("client_version", "android_v1.0"),
                                    isBlocked = obj.optBoolean("is_blocked", true),
                                    blockedAt = obj.optString("blocked_at", obj.optString("created_at", "")),
                                    unblockAt = obj.optString("unblock_at", ""),
                                    sourceTable = if (ep.contains("blocked_users")) "blocked_users" else "blocks"
                                )
                            )
                        }
                    }
                    if (resultList.isNotEmpty()) break
                }
            } catch (e: Exception) {
                Log.d(TAG, "Error fetching from $ep: ${e.message}")
            }
        }

        // 2. Fetch from `profiles` table where is_blocked = true
        try {
            val profileEp = "$url/rest/v1/profiles?is_blocked=eq.true&select=id,name,agency_name,phone,mobile,updated_at,device_id"
            val (code, resp) = SupabaseAuthService.getFromSupabase(profileEp, key)
            if (code in 200..299 && !resp.isNullOrBlank()) {
                val arr = JSONArray(resp)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val phone = obj.optString("phone", obj.optString("mobile", ""))
                    if (phone.isNotBlank() && !seenPhones.contains(phone)) {
                        seenPhones.add(phone)
                        val name = obj.optString("name", "उपयोगकर्ता")
                        resultList.add(
                            BlockedUserRecord(
                                id = obj.optString("id", UUID.randomUUID().toString()),
                                phone = phone,
                                profileId = obj.optString("id", ""),
                                name = name,
                                reason = "खाता Supabase profiles में सुरक्षा ब्लॉक है",
                                failedAttempts = 5,
                                deviceId = obj.optString("device_id", ""),
                                isBlocked = true,
                                blockedAt = "Supabase Profiles",
                                sourceTable = "profiles"
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error fetching blocked profiles: ${e.message}")
        }

        resultList
    }

    /**
     * Checks if a bot filled the honeypot field
     */
    fun isBotTrapTriggered(honeypotText: String): Boolean {
        return honeypotText.trim().isNotEmpty()
    }

    /**
     * Minimum human interaction time for filling and submitting customer form.
     * Bots typically submit within under 800ms.
     */
    const val MIN_HUMAN_INTERACTION_TIME_MS = 1200L

    /**
     * Validates submission timing to detect instant automated bot submissions.
     */
    fun isSubmissionTooFast(openedAtMillis: Long, minAllowedMs: Long = MIN_HUMAN_INTERACTION_TIME_MS): Boolean {
        if (openedAtMillis <= 0L) return false
        val duration = System.currentTimeMillis() - openedAtMillis
        return duration < minAllowedMs
    }

    /**
     * Checks honeypot and time-based bot traps together.
     * Returns true if bot behavior is detected.
     */
    fun isBotDetected(honeypotText: String, openedAtMillis: Long, minAllowedMs: Long = MIN_HUMAN_INTERACTION_TIME_MS): Boolean {
        if (isBotTrapTriggered(honeypotText)) {
            Log.w(TAG, "Bot detected via Honeypot trap: '$honeypotText'")
            return true
        }
        if (isSubmissionTooFast(openedAtMillis, minAllowedMs)) {
            Log.w(TAG, "Bot detected via ultra-fast submission time: ${System.currentTimeMillis() - openedAtMillis} ms (threshold: $minAllowedMs ms)")
            return true
        }
        return false
    }

    // 🛡️ Rapid-Fire Session Flood Protection (Rate Limiting)
    private val sessionSubmissionTimestamps = java.util.concurrent.ConcurrentLinkedQueue<Long>()
    private const val SESSION_FLOOD_WINDOW_MS = 6000L // 6 seconds window
    private const val MAX_SESSIONS_IN_WINDOW = 3 // Max 3 sessions in 6 seconds

    /**
     * Checks whether session submissions are happening too rapidly (flood / bot spam).
     * Returns true if rate limit is exceeded.
     */
    @Synchronized
    fun isSessionFloodDetected(): Boolean {
        val now = System.currentTimeMillis()
        while (sessionSubmissionTimestamps.isNotEmpty() && (now - (sessionSubmissionTimestamps.peek() ?: 0L)) > SESSION_FLOOD_WINDOW_MS) {
            sessionSubmissionTimestamps.poll()
        }
        if (sessionSubmissionTimestamps.size >= MAX_SESSIONS_IN_WINDOW) {
            Log.w(TAG, "Bot flood detected: ${sessionSubmissionTimestamps.size} sessions created within $SESSION_FLOOD_WINDOW_MS ms")
            return true
        }
        sessionSubmissionTimestamps.add(now)
        return false
    }

    /**
     * Complete Bot validation for session recording:
     * 1. Honeypot check (hidden field filled by bots)
     * 2. Timing check (superhuman fast click < minAllowedMs, except when using live timer)
     * 3. Flood rate check (rapid fire session injection)
     */
    fun isSessionBotDetected(
        honeypotText: String,
        openedAtMillis: Long,
        isLiveTimer: Boolean = false,
        minAllowedMs: Long = 900L
    ): Pair<Boolean, String> {
        if (isBotTrapTriggered(honeypotText)) {
            return Pair(true, "अदृश्य हनीपॉट ट्रैप सक्रिय हुआ (Honeypot Triggered: '$honeypotText')")
        }
        if (!isLiveTimer && isSubmissionTooFast(openedAtMillis, minAllowedMs)) {
            val elapsed = System.currentTimeMillis() - openedAtMillis
            return Pair(true, "अति-तीव्र गति ($elapsed ms) - स्वचालित बॉट सबमिशन")
        }
        if (isSessionFloodDetected()) {
            return Pair(true, "रैपिड-स्पैम बाढ़ पकड़ी गई (लगातार बहुत तेज़ गति से सत्र दर्ज करने का प्रयास)")
        }
        return Pair(false, "")
    }

    /**
     * Invisible cloud report of bot activity:
     * When a bot attempts to inject fake data or register with a bot, silently log it to Supabase security audit.
     */
    suspend fun reportBotActivitySilently(
        context: Context,
        profileId: String,
        action: String,
        details: String,
        phone: String = "BOT_TRAP_TRIGGERED"
    ) = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseAuthService.isConfigured(context) || !SupabaseAuthService.isNetworkAvailable(context)) {
                return@withContext
            }
            val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
            val key = SupabaseAuthService.getSupabaseAnonKey(context)
            val devId = getDeviceId(context)

            val payload = JSONObject().apply {
                put("phone", if (phone.isNotBlank()) phone else "BOT_TRAP_TRIGGERED")
                put("profile_id", profileId)
                put("reason", "BOT_PREVENTED: $action - $details")
                put("failed_attempts", 999)
                put("device_id", devId)
                put("client_version", getClientVersion())
                put("is_blocked", true)
                put("blocked_at", getIsoTimestamp())
            }

            val conn = (URL("$url/rest/v1/blocked_users").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                SupabaseAuthService.applyAuthHeaders(this, key)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Prefer", "return=minimal")
                doOutput = true
                connectTimeout = 4000
                readTimeout = 4000
            }
            OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
            conn.responseCode
        } catch (_: Exception) {}
    }
}
