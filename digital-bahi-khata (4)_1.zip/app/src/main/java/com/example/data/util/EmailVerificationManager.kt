package com.example.data.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import com.example.data.supabase.SupabaseAuthService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * EmailVerificationManager
 * Directly connects to Supabase Auth API (`POST /auth/v1/otp` and `POST /auth/v1/verify`)
 * to deliver real email OTP verification without any SMS costs.
 * Also supports direct email link confirmation with automatic real-time detection.
 */
object EmailVerificationManager {
    private const val TAG = "EmailVerification"
    private const val PREFS_NAME = "bahi_khata_email_otp_prefs"
    private const val KEY_OTP = "last_email_otp"
    private const val KEY_EMAIL = "last_otp_email"
    private const val KEY_TOKEN = "last_email_token"
    private const val KEY_TIMESTAMP = "last_otp_timestamp"
    private const val KEY_IS_SUPABASE = "last_otp_is_supabase"
    private const val OTP_EXPIRY_MS = 15 * 60 * 1000L // 15 minutes

    // In-memory real-time state when deep link or auto-verification succeeds
    private val _confirmedEmailFlow = MutableStateFlow<String?>(null)
    val confirmedEmailFlow: StateFlow<String?> = _confirmedEmailFlow.asStateFlow()

    fun notifyEmailConfirmedViaDeepLink(email: String) {
        val clean = email.trim().lowercase(Locale.ROOT)
        Log.i(TAG, "Notifying email confirmed via deep link / action: $clean")
        _confirmedEmailFlow.value = clean.ifBlank { "*" }
    }

    fun isEmailConfirmed(email: String): Boolean {
        val clean = email.trim().lowercase(Locale.ROOT)
        val confirmed = _confirmedEmailFlow.value
        return !confirmed.isNullOrBlank() && (confirmed == clean || confirmed == "*" || clean.isBlank())
    }

    fun clearConfirmedEmail() {
        _confirmedEmailFlow.value = null
    }

    fun getLastOtpEmail(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_EMAIL, "") ?: ""
    }

    data class OtpSendResult(
        val success: Boolean,
        val otp: String,
        val token: String = "",
        val maskedEmail: String,
        val message: String,
        val isCloudSupabase: Boolean = false,
        val confirmUrl: String = ""
    )

    data class VerifyResult(
        val isSuccess: Boolean,
        val message: String,
        val isCloudVerified: Boolean = false
    )

    fun isValidEmail(email: String): Boolean {
        val clean = email.trim()
        return clean.isNotBlank() && Patterns.EMAIL_ADDRESS.matcher(clean).matches()
    }

    fun maskEmail(email: String): String {
        val clean = email.trim()
        if (!clean.contains("@")) return clean
        val parts = clean.split("@")
        val name = parts[0]
        val domain = parts.getOrNull(1) ?: ""
        val maskedName = when {
            name.length <= 2 -> "${name.first()}***"
            name.length <= 4 -> "${name.first()}***${name.last()}"
            else -> "${name.take(2)}***${name.takeLast(2)}"
        }
        return "$maskedName@$domain"
    }

    /**
     * Sends verification email with direct confirmation link + OTP via Supabase.
     * Real OTP is sent directly to the user's email inbox.
     */
    suspend fun sendEmailOtp(
        context: Context,
        email: String,
        purpose: String = "VERIFY_EMAIL",
        newPin: String = "",
        farmerName: String = "किसान भाई"
    ): OtpSendResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase(Locale.ROOT)
        if (!isValidEmail(cleanEmail)) {
            return@withContext OtpSendResult(
                success = false,
                otp = "",
                token = "",
                maskedEmail = cleanEmail,
                message = "कृपया सही ईमेल पता (Email ID) दर्ज करें!",
                isCloudSupabase = false
            )
        }

        val masked = maskEmail(cleanEmail)
        val isConfigured = SupabaseAuthService.isConfigured(context)
        val isOnline = SupabaseAuthService.isNetworkAvailable(context)

        if (!isConfigured || !isOnline) {
            return@withContext OtpSendResult(
                success = false,
                otp = "",
                token = "",
                maskedEmail = masked,
                message = if (!isOnline) "⚠️ इंटरनेट कनेक्शन बंद है। ईमेल पर ओटीपी भेजने के लिए इंटरनेट चालू करें।"
                          else "⚠️ Supabase कॉन्फ़िगर नहीं है। कृपया सेटिंग्स में Supabase सेटिंग्स जांचें।",
                isCloudSupabase = false
            )
        }

        val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
        val key = SupabaseAuthService.getSupabaseAnonKey(context)

        // 1. Try Supabase Edge Function if deployed
        try {
            val edgeEndpoint = "$url/functions/v1/send-email-verify"
            val conn = (URL(edgeEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                SupabaseAuthService.applyAuthHeaders(this, key)
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 6000
                readTimeout = 6000
            }

            val payload = JSONObject().apply {
                put("email", cleanEmail)
                put("name", farmerName)
                put("type", purpose)
                if (newPin.isNotBlank()) put("newPin", newPin)
            }

            OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
            val code = conn.responseCode
            if (code in 200..299) {
                val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                val obj = JSONObject(responseText)
                val token = obj.optString("token")
                val confirmUrl = obj.optString("confirmUrl")

                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                prefs.edit()
                    .putString(KEY_EMAIL, cleanEmail)
                    .putString(KEY_TOKEN, token)
                    .putBoolean(KEY_IS_SUPABASE, true)
                    .putLong(KEY_TIMESTAMP, System.currentTimeMillis())
                    .apply()

                val actionName = if (purpose.contains("PASSWORD", ignoreCase = true)) "पासवर्ड रीसेट" else "ईमेल सत्यापन"
                return@withContext OtpSendResult(
                    success = true,
                    otp = "",
                    token = token,
                    confirmUrl = confirmUrl,
                    maskedEmail = masked,
                    message = "✉️ आपके ईमेल ($masked) पर $actionName कोड भेज दिया गया है! कृपया इनबॉक्स या स्पैम फ़ोल्डर चेक करें।",
                    isCloudSupabase = true
                )
            }
        } catch (e: Exception) {
            Log.d(TAG, "Edge function not available, using Auth API: ${e.message}")
        }

        // 2. Supabase Auth API: /auth/v1/otp
        val otpEndpoint = "$url/auth/v1/otp"
        try {
            val conn = (URL(otpEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                SupabaseAuthService.applyAuthHeaders(this, key)
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }

            val payload = JSONObject().apply {
                put("email", cleanEmail)
                put("create_user", true)
                put("redirect_to", "tubewell://verify?email=$cleanEmail")
                val options = JSONObject().apply {
                    put("email_redirect_to", "tubewell://verify?email=$cleanEmail")
                }
                put("options", options)
            }

            OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
            val code = conn.responseCode
            val responseText = if (code in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            }

            Log.d(TAG, "Supabase /auth/v1/otp response [$code]: $responseText")

            if (code in 200..299) {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                prefs.edit()
                    .putString(KEY_EMAIL, cleanEmail)
                    .putBoolean(KEY_IS_SUPABASE, true)
                    .putLong(KEY_TIMESTAMP, System.currentTimeMillis())
                    .apply()

                return@withContext OtpSendResult(
                    success = true,
                    otp = "",
                    token = "",
                    maskedEmail = masked,
                    message = "✉️ आपके ईमेल ($masked) पर सत्यापन संदेश भेजा गया है! इनबॉक्स में 'Confirm' लिंक पर क्लिक करें अथवा 6-अंकों का ओटीपी दर्ज करें।",
                    isCloudSupabase = true
                )
            } else {
                val errObj = try { JSONObject(responseText) } catch (_: Exception) { null }
                val errMsg = errObj?.optString("msg") ?: errObj?.optString("message") ?: ""
                Log.w(TAG, "Supabase OTP error: $errMsg (code $code)")

                val userFriendlyMsg = when {
                    code == 429 || errMsg.contains("rate limit", ignoreCase = true) ->
                        "⚠️ Supabase ईमेल दर सीमा (Rate limit) पूरी हो गई है। कृपया कुछ देर प्रतीक्षा करें।"
                    code in 500..599 ->
                        "⚠️ ईमेल सर्वर एरर ($code)। कृपया Supabase में Custom SMTP सेटिंग्स जांचें।"
                    else ->
                        "⚠️ ईमेल भेजने में समस्या: ${errMsg.ifBlank { "सर्वर से कोड नहीं भेजा जा सका ($code)" }}"
                }

                return@withContext OtpSendResult(
                    success = false,
                    otp = "",
                    token = "",
                    maskedEmail = masked,
                    message = userFriendlyMsg,
                    isCloudSupabase = false
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Supabase OTP exception: ${e.message}")
            return@withContext OtpSendResult(
                success = false,
                otp = "",
                token = "",
                maskedEmail = masked,
                message = "⚠️ नेटवर्क त्रुटि: ${e.message}। कृपया इंटरनेट जांचें।",
                isCloudSupabase = false
            )
        }
    }

    /**
     * Checks if the user has clicked the 'Confirm' link in their email
     * by querying deep link state, RPC check_email_verified, and profiles table in Supabase.
     */
    suspend fun checkAutoVerificationStatus(
        context: Context,
        email: String,
        token: String = ""
    ): Boolean = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase(Locale.ROOT)
        if (!isValidEmail(cleanEmail)) return@withContext false

        // 1. In-memory deep link confirmation check
        if (isEmailConfirmed(cleanEmail)) {
            Log.i(TAG, "Email confirmed via in-memory deep link: $cleanEmail")
            return@withContext true
        }

        val isConfigured = SupabaseAuthService.isConfigured(context)
        val isOnline = SupabaseAuthService.isNetworkAvailable(context)
        if (!isConfigured || !isOnline) return@withContext false

        val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
        val key = SupabaseAuthService.getSupabaseAnonKey(context)

        // 2. Call Supabase RPC function check_email_verified
        try {
            val rpcEndpoint = "$url/rest/v1/rpc/check_email_verified"
            val conn = (URL(rpcEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                SupabaseAuthService.applyAuthHeaders(this, key)
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 4000
                readTimeout = 4000
            }
            val reqPayload = JSONObject().apply {
                put("p_email", cleanEmail)
            }
            OutputStreamWriter(conn.outputStream).use { it.write(reqPayload.toString()) }
            if (conn.responseCode in 200..299) {
                val respText = conn.inputStream.bufferedReader().use { it.readText().trim() }
                if (respText == "true" || respText.contains("true", ignoreCase = true)) {
                    Log.i(TAG, "Email verified via Supabase check_email_verified RPC: $cleanEmail")
                    notifyEmailConfirmedViaDeepLink(cleanEmail)
                    return@withContext true
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "check_email_verified RPC call failed: ${e.message}")
        }

        // 3. Check profiles table for is_email_verified
        try {
            val profileEndpoint = "$url/rest/v1/profiles?email=eq.$cleanEmail&is_email_verified=eq.true&select=id"
            val conn = (URL(profileEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                SupabaseAuthService.applyAuthHeaders(this, key)
                connectTimeout = 4000
                readTimeout = 4000
            }

            if (conn.responseCode in 200..299) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                if (text.isNotBlank() && text != "[]") {
                    Log.i(TAG, "Profile email confirmed in profiles table!")
                    notifyEmailConfirmedViaDeepLink(cleanEmail)
                    return@withContext true
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking profiles table: ${e.message}")
        }

        // 4. Check email_verifications table by token or email (if configured)
        try {
            val endpoint = if (token.isNotBlank()) {
                "$url/rest/v1/email_verifications?token=eq.$token&status=eq.CONFIRMED&select=id,status"
            } else {
                "$url/rest/v1/email_verifications?email=eq.$cleanEmail&status=eq.CONFIRMED&order=updated_at.desc&limit=1&select=id,status"
            }

            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                SupabaseAuthService.applyAuthHeaders(this, key)
                connectTimeout = 4000
                readTimeout = 4000
            }

            if (conn.responseCode in 200..299) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                if (text.isNotBlank() && text != "[]") {
                    Log.i(TAG, "Email verification confirmed via link in email_verifications table!")
                    notifyEmailConfirmedViaDeepLink(cleanEmail)
                    return@withContext true
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking email_verifications: ${e.message}")
        }

        return@withContext false
    }

    private fun saveLocalOtp(context: Context, email: String, otp: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_OTP, otp)
            .putString(KEY_EMAIL, email)
            .putBoolean(KEY_IS_SUPABASE, false)
            .putLong(KEY_TIMESTAMP, System.currentTimeMillis())
            .apply()
    }

    fun getLastGeneratedOtp(context: Context, email: String): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedEmail = prefs.getString(KEY_EMAIL, "") ?: ""
        val savedOtp = prefs.getString(KEY_OTP, null)
        val timestamp = prefs.getLong(KEY_TIMESTAMP, 0L)
        val isExpired = (System.currentTimeMillis() - timestamp) > OTP_EXPIRY_MS

        return if (!isExpired && savedEmail.equals(email.trim(), ignoreCase = true)) {
            savedOtp
        } else {
            null
        }
    }

    /**
     * Verifies OTP strictly via Supabase Auth API (`POST /auth/v1/verify`).
     * Only real OTP received in the email will be accepted.
     */
    suspend fun verifyOtp(
        context: Context,
        email: String,
        enteredOtp: String
    ): VerifyResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase(Locale.ROOT)
        val cleanOtp = enteredOtp.trim()

        if (cleanOtp.length < 6) {
            return@withContext VerifyResult(false, "कृपया ईमेल में आया पूरा 6 या 8 अंकों का सही ओटीपी कोड दर्ज करें!")
        }

        val isConfigured = SupabaseAuthService.isConfigured(context)
        val isOnline = SupabaseAuthService.isNetworkAvailable(context)

        if (!isConfigured || !isOnline) {
            return@withContext VerifyResult(false, "सत्यापन के लिए इंटरनेट कनेक्शन आवश्यक है!")
        }

        val url = SupabaseAuthService.getSupabaseUrl(context).removeSuffix("/")
        val key = SupabaseAuthService.getSupabaseAnonKey(context)
        val verifyEndpoint = "$url/auth/v1/verify"

        // Supabase GoTrue accepts types: "email", "magiclink", "signup", "recovery"
        val verifyTypes = listOf("email", "magiclink", "signup", "recovery")
        for (type in verifyTypes) {
            try {
                val conn = (URL(verifyEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    SupabaseAuthService.applyAuthHeaders(this, key)
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                }

                val payload = JSONObject().apply {
                    put("type", type)
                    put("email", cleanEmail)
                    put("token", cleanOtp)
                }

                OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
                val code = conn.responseCode
                val responseText = if (code in 200..299) {
                    conn.inputStream.bufferedReader().use { it.readText() }
                } else {
                    conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                }
                Log.d(TAG, "Supabase verify [$type] response [$code]: $responseText")

                if (code in 200..299) {
                    Log.i(TAG, "Supabase OTP verified successfully with type: $type")
                    clearOtp(context)
                    return@withContext VerifyResult(
                        isSuccess = true,
                        message = "🎉 Supabase द्वारा ईमेल सफलतापूर्वक सत्यापित हो गया!",
                        isCloudVerified = true
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Supabase verify exception for type $type: ${e.message}")
            }
        }

        // Also check if email_verifications table has a matching OTP record
        try {
            val dbEndpoint = "$url/rest/v1/email_verifications?email=eq.$cleanEmail&otp=eq.$cleanOtp&status=eq.PENDING&select=id"
            val conn = (URL(dbEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                SupabaseAuthService.applyAuthHeaders(this, key)
                connectTimeout = 5000
                readTimeout = 5000
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                if (body.isNotBlank() && body != "[]") {
                    try {
                        val patchConn = (URL("$url/rest/v1/email_verifications?email=eq.$cleanEmail&otp=eq.$cleanOtp").openConnection() as HttpURLConnection).apply {
                            requestMethod = "PATCH"
                            SupabaseAuthService.applyAuthHeaders(this, key)
                            setRequestProperty("Content-Type", "application/json")
                            doOutput = true
                        }
                        OutputStreamWriter(patchConn.outputStream).use { it.write("{\"status\":\"CONFIRMED\"}") }
                        patchConn.responseCode
                    } catch (_: Exception) {}

                    clearOtp(context)
                    return@withContext VerifyResult(
                        isSuccess = true,
                        message = "🎉 ईमेल सफलतापूर्वक सत्यापित हो गया!",
                        isCloudVerified = true
                    )
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "email_verifications check exception: ${e.message}")
        }

        return@withContext VerifyResult(
            isSuccess = false,
            message = "❌ गलत या समाप्त हो चुका ओटीपी! कृपया ईमेल पर आया सही कोड दर्ज करें।"
        )
    }

    private fun clearOtp(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_OTP).remove(KEY_TIMESTAMP).apply()
    }

    /**
     * Optional client action to open email app if user wants to inspect their mailbox
     */
    fun openEmailClient(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_APP_EMAIL)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("mailto:"))
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "कृपया अपना ईमेल ऐप खोलकर ओटीपी देखें।", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
