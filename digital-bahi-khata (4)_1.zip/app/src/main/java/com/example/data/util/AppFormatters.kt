package com.example.data.util

import java.util.Locale
import kotlin.math.roundToLong

object AppFormatters {

    /**
     * Formats session hours into crystal clear, human-readable Hindi duration:
     * - Less than 1 minute: e.g. "45 सेकंड"
     * - Less than 60 minutes: e.g. "2 मिनट", "18 मिनट" (NEVER shows confusing "0.0 hrs")
     * - 1 hour or more: e.g. "1 घंटा 20 मिनट", "2 घंटे 30 मिनट (2.5 hrs)"
     */
    fun formatSessionDuration(hours: Double, includeHrsBracket: Boolean = false): String {
        val totalSeconds = Math.round(hours * 3600.0).toInt()
        if (totalSeconds <= 0) return "0 मिनट"

        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60

        return when {
            h > 0 && m > 0 -> {
                val base = if (h == 1) "1 घंटा $m मिनट" else "$h घंटे $m मिनट"
                if (includeHrsBracket) "$base (${String.format(Locale.ROOT, "%.1f", hours)} hrs)" else base
            }
            h > 0 -> {
                val base = if (h == 1) "1 घंटा" else "$h घंटे"
                if (includeHrsBracket) "$base (${String.format(Locale.ROOT, "%.1f", hours)} hrs)" else base
            }
            m > 0 -> "$m मिनट"
            else -> "$s सेकंड"
        }
    }

    /**
     * Compact duration for chips and small badges:
     * - e.g. "5 min", "1h 20m", "2.5 hrs"
     */
    fun formatCompactDuration(hours: Double): String {
        val totalSeconds = Math.round(hours * 3600.0).toInt()
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h} hrs"
            m > 0 -> "${m} min"
            else -> "${totalSeconds}s"
        }
    }

    /**
     * Formats rupee amounts reliably with Math.round so that:
     * 1. Floating-point precision issues (e.g. 5.9999 or 2.333) never drop ₹1 due to .toInt() truncation.
     * 2. Grand totals and individual row sums always match 100% without ₹1 mismatch.
     */
    fun roundRupees(amount: Double): Long {
        return Math.round(amount)
    }

    /**
     * Formats rupee integer with comma separators: e.g. 10,500
     */
    fun formatRupees(amount: Double): String {
        return String.format(Locale.ROOT, "%,d", Math.round(amount))
    }
}
