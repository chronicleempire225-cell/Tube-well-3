package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles LIMIT 1")
    fun getProfile(): Flow<ProfileEntity?>

    @Query("SELECT * FROM profiles LIMIT 1")
    suspend fun getProfileOnce(): ProfileEntity?

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    fun getProfileByIdFlow(id: String): Flow<ProfileEntity?>

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: String): ProfileEntity?

    @Query("SELECT * FROM profiles WHERE phone = :phone LIMIT 1")
    suspend fun getProfileByPhone(phone: String): ProfileEntity?

    @Query("SELECT * FROM profiles WHERE email = :email LIMIT 1")
    suspend fun getProfileByEmail(email: String): ProfileEntity?

    @Query("SELECT * FROM profiles")
    suspend fun getAllProfiles(): List<ProfileEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: ProfileEntity)

    @Query("UPDATE profiles SET ratePerHour = :rate, updatedAt = :time WHERE id = :id")
    suspend fun updateRate(id: String, rate: Double, time: Long = System.currentTimeMillis())

    @Query("UPDATE profiles SET email = :email, isEmailVerified = :isVerified, updatedAt = :time WHERE id = :id")
    suspend fun updateEmail(id: String, email: String, isVerified: Boolean, time: Long = System.currentTimeMillis())

    @Query("UPDATE profiles SET pinHash = :newPin, updatedAt = :time WHERE id = :id")
    suspend fun updatePin(id: String, newPin: String, time: Long = System.currentTimeMillis())

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun deleteProfileById(id: String)

    @Query("DELETE FROM profiles")
    suspend fun clearProfile()
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE profileId = :profileId ORDER BY name ASC")
    fun getCustomersByProfile(profileId: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE profileId = :profileId ORDER BY name ASC")
    suspend fun getCustomersByProfileOnce(profileId: String): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id = :id")
    fun getCustomerById(id: String): Flow<CustomerEntity?>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerByIdOnce(id: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<CustomerEntity>)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun deleteCustomer(id: String)

    @Query("DELETE FROM customers WHERE profileId = :profileId")
    suspend fun clearCustomersForProfile(profileId: String)
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY sessionDate DESC")
    fun getAllSessions(): Flow<List<TubewellSessionEntity>>

    @Query("SELECT * FROM sessions WHERE profileId = :profileId ORDER BY sessionDate DESC")
    fun getSessionsByProfile(profileId: String): Flow<List<TubewellSessionEntity>>

    @Query("SELECT * FROM sessions WHERE profileId = :profileId ORDER BY sessionDate DESC")
    suspend fun getSessionsByProfileOnce(profileId: String): List<TubewellSessionEntity>

    @Query("SELECT * FROM sessions WHERE customerId = :customerId ORDER BY sessionDate DESC")
    fun getSessionsForCustomer(customerId: String): Flow<List<TubewellSessionEntity>>

    @Query("SELECT * FROM sessions WHERE customerId = :customerId AND profileId = :profileId ORDER BY sessionDate DESC")
    fun getSessionsForCustomerAndProfile(customerId: String, profileId: String): Flow<List<TubewellSessionEntity>>

    @Query("SELECT * FROM sessions WHERE id = :id")
    suspend fun getSessionById(id: String): TubewellSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: TubewellSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessions(sessions: List<TubewellSessionEntity>)

    @Update
    suspend fun updateSession(session: TubewellSessionEntity)

    @Query("DELETE FROM sessions WHERE id = :id")
    suspend fun deleteSession(id: String)

    @Query("DELETE FROM sessions WHERE profileId = :profileId")
    suspend fun clearSessionsForProfile(profileId: String)

    @Query("SELECT * FROM sessions WHERE customerId = :customerId ORDER BY sessionDate DESC LIMIT 1")
    suspend fun getLastSessionForCustomer(customerId: String): TubewellSessionEntity?

    @Query("SELECT * FROM sessions ORDER BY sessionDate DESC LIMIT 1")
    suspend fun getLastGlobalSession(): TubewellSessionEntity?

    @Query("SELECT COUNT(*) FROM sessions WHERE profileId = :profileId AND isSynced = 0")
    suspend fun getUnsyncedSessionCount(profileId: String): Int

    @Query("UPDATE sessions SET isSynced = 1 WHERE profileId = :profileId")
    suspend fun markAllSessionsSynced(profileId: String)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY depositDate DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE profileId = :profileId ORDER BY depositDate DESC")
    fun getTransactionsByProfile(profileId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE profileId = :profileId ORDER BY depositDate DESC")
    suspend fun getTransactionsByProfileOnce(profileId: String): List<TransactionEntity>

    @Query("SELECT * FROM transactions WHERE customerId = :customerId ORDER BY depositDate DESC")
    fun getTransactionsForCustomer(customerId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE customerId = :customerId AND profileId = :profileId ORDER BY depositDate DESC")
    fun getTransactionsForCustomerAndProfile(customerId: String, profileId: String): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<TransactionEntity>)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransaction(id: String)

    @Query("DELETE FROM transactions WHERE profileId = :profileId")
    suspend fun clearTransactionsForProfile(profileId: String)
}
