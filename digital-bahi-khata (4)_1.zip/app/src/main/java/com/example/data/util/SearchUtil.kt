package com.example.data.util

import java.util.Locale

object SearchUtil {
    fun matchesQuery(targetText: String, phone: String, fatherName: String, query: String): Boolean {
        if (query.isBlank()) return true
        val cleanQuery = query.trim().lowercase(Locale.ROOT)
        val cleanTarget = targetText.trim().lowercase(Locale.ROOT)
        val cleanPhone = phone.replace(Regex("[^0-9]"), "")
        val cleanFather = fatherName.trim().lowercase(Locale.ROOT)

        // 1. Direct contains check
        if (cleanTarget.contains(cleanQuery)) return true
        if (cleanPhone.contains(cleanQuery)) return true
        if (cleanFather.contains(cleanQuery)) return true

        // 2. Transliterated phonetic check
        val normTarget = normalizePhonetic(cleanTarget)
        val normFather = normalizePhonetic(cleanFather)
        val normQuery = normalizePhonetic(cleanQuery)

        if (normTarget.contains(normQuery) || normFather.contains(normQuery)) return true
        if (normTarget.contains(cleanQuery) || normFather.contains(cleanQuery)) return true
        if (cleanTarget.contains(normQuery) || cleanFather.contains(normQuery)) return true

        // 3. Token-based matching (e.g., first name, last name)
        val queryTokens = normQuery.split(" ", "_", "-").filter { it.isNotBlank() }
        val targetTokens = normTarget.split(" ", "_", "-").filter { it.isNotBlank() }
        val fatherTokens = normFather.split(" ", "_", "-").filter { it.isNotBlank() }

        if (queryTokens.isNotEmpty()) {
            val allTargetTokens = targetTokens + fatherTokens
            val allMatched = queryTokens.all { qToken ->
                allTargetTokens.any { it.contains(qToken) || qToken.contains(it) } ||
                        cleanPhone.contains(qToken)
            }
            if (allMatched) return true
        }

        return false
    }

    private fun normalizePhonetic(input: String): String {
        var res = input.lowercase(Locale.ROOT)
        val map = listOf(
            "क्ष" to "ksh", "त्र" to "tr", "ज्ञ" to "gy", "श्र" to "shr",
            "क" to "k", "ख" to "kh", "ग" to "g", "घ" to "gh", "ङ" to "n",
            "च" to "ch", "छ" to "chh", "ज" to "j", "झ" to "jh", "ञ" to "n",
            "ट" to "t", "ठ" to "th", "ड" to "d", "ढ" to "dh", "ण" to "n",
            "त" to "t", "थ" to "th", "द" to "d", "ध" to "dh", "न" to "n",
            "प" to "p", "फ" to "f", "ब" to "b", "भ" to "bh", "म" to "m",
            "य" to "y", "र" to "r", "ल" to "l", "व" to "v", "श" to "sh",
            "ष" to "sh", "स" to "s", "ह" to "h", "ड़" to "r", "ढ़" to "rh",
            "ा" to "a", "ि" to "i", "ी" to "i", "ु" to "u", "ू" to "u",
            "े" to "e", "ै" to "ai", "ो" to "o", "ौ" to "au", "ं" to "n", "ँ" to "n", "्" to "",
            "अ" to "a", "आ" to "a", "इ" to "i", "ई" to "i", "उ" to "u",
            "ऊ" to "u", "ए" to "e", "ऐ" to "ai", "ओ" to "o", "औ" to "au"
        )
        for ((dev, eng) in map) {
            res = res.replace(dev, eng)
        }
        // Normalize common phonetic variations in English
        return res
            .replace("w", "v")
            .replace("ee", "i")
            .replace("oo", "u")
            .replace("aa", "a")
            .replace("sh", "s")
            .replace("bh", "b")
            .replace("dh", "d")
            .replace("th", "t")
            .replace("kh", "k")
            .replace("gh", "g")
            .replace("ph", "f")
    }
}
