package com.example.data.supabase

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import com.example.data.db.CustomerEntity
import com.example.data.db.ProfileEntity
import com.example.data.db.TransactionEntity
import com.example.data.db.TubewellSessionEntity
import com.example.data.repository.BahiKhataRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Supabase Authentication & Real-time Cloud Synchronization Service.
 * 
 * Features:
 * 1. Cloud Sign-up & Verification (checking existing phone in Supabase profiles)
 * 2. Secure Login with Mobile Number and PIN/Password
 * 3. PIN / Password Reset with Cloud Sync
 * 4. Data Scoping & Multi-account Isolation per profileId
 * 5. Full 2-Way Sync for Customers, Tubewell Sessions, and Payment Transactions
 * 6. Offline-first fallback with local SQLite caching
 * 7. Publishable Key (`sb_publishable_...`) PostgREST support
 * 8. Dual schema compatibility (supports both camel/snake case and fallback column names)
 */
object SupabaseAuthService {
    private const val TAG = "SupabaseAuthService"
    private const val PREFS_NAME = "supabase_config_prefs"
    private const val KEY_URL = "supabase_url"
    private const val KEY_ANON_KEY = "supabase_anon_key"

    // Default Supabase configuration (User's Project: jwtppgebzjrpiwqttslm)
    private const val DEFAULT_SUPABASE_URL = "https://jwtppgebzjrpiwqttslm.supabase.co"
    private const val DEFAULT_SUPABASE_ANON_KEY = "sb_publishable_-5ZwhH5gXQCpTnWWA0NLUg_JbAJUu1H"

    sealed class AuthResult {
        data class Success(val profile: ProfileEntity, val source: String) : AuthResult()
        data class Error(val message: String) : AuthResult()
    }

    data class SyncResult(
        val success: Boolean,
        val message: String,
        val pulledCustomers: List<CustomerEntity> = emptyList(),
        val pulledSessions: List<TubewellSessionEntity> = emptyList(),
        val pulledTransactions: List<TransactionEntity> = emptyList()
    )

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getSupabaseUrl(context: Context): String {
        val saved = getPrefs(context).getString(KEY_URL, "") ?: ""
        if (saved.isNotBlank() && !saved.contains("your-project.supabase.co") && !saved.contains("qhkyddrjvfyauichmyie")) {
            return saved.trim().trimEnd('/')
        }
        return DEFAULT_SUPABASE_URL.trim().trimEnd('/')
    }

    fun getSupabaseAnonKey(context: Context): String {
        val saved = getPrefs(context).getString(KEY_ANON_KEY, "") ?: ""
        if (saved.isNotBlank() && !saved.contains("your-anon-key") && !saved.contains("1Zu_oA3UF3Pm25CW5AdfLg")) {
            return saved.trim()
        }
        return DEFAULT_SUPABASE_ANON_KEY.trim()
    }

    fun saveSupabaseConfig(context: Context, url: String, anonKey: String) {
        val cleanUrl = url.trim().trimEnd('/')
        val cleanKey = anonKey.trim()
        getPrefs(context).edit()
            .putString(KEY_URL, cleanUrl)
            .putString(KEY_ANON_KEY, cleanKey)
            .apply()
    }

    fun isConfigured(context: Context): Boolean {
        val url = getSupabaseUrl(context)
        val key = getSupabaseAnonKey(context)
        return url.startsWith("http") && key.isNotBlank() && !url.contains("your-project.supabase.co")
    }

    /**
     * Applies headers for Supabase PostgREST API.
     * CRITICAL: Supabase's new 'sb_publishable_...' keys are NOT JWTs.
     * Sending 'Authorization: Bearer sb_publishable_...' causes PostgREST to fail with 401 Unauthorized (Invalid JWT).
     * Only send 'apikey: <key>'. Only add 'Authorization: Bearer' if key starts with 'ey' (legacy JWT anon key).
     */
    fun applyAuthHeaders(conn: HttpURLConnection, key: String) {
        conn.setRequestProperty("apikey", key)
        if (key.startsWith("ey")) {
            conn.setRequestProperty("Authorization", "Bearer $key")
        }
    }

    fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val network = cm?.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(network) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                val info = cm?.activeNetworkInfo
                @Suppress("DEPRECATION")
                info != null && info.isConnected
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Checks if Supabase server is healthy, responsive and not overloaded before attempting data sync.
     * Returns Pair(isHealthy, message). If overloaded (e.g. HTTP 429, 503, 504 or response time > 5000ms), returns false.
     */
    fun checkServerHealthAndLoad(context: Context): Pair<Boolean, String> {
        if (!isNetworkAvailable(context)) {
            return Pair(false, "⚠️ इंटरनेट बंद है। कृपया डेटा सिंक करने के लिए इंटरनेट चालू करें।")
        }
        val url = getSupabaseUrl(context).trim().removeSuffix("/")
        val key = getSupabaseAnonKey(context).trim()
        if (url.isBlank() || key.isBlank() || !url.startsWith("http")) {
            return Pair(false, "Supabase URL या API Key कॉन्फ़िगर नहीं है")
        }

        return try {
            val startTime = System.currentTimeMillis()
            val healthEndpoint = "$url/rest/v1/profiles?select=id&limit=1"
            val conn = (URL(healthEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                applyAuthHeaders(this, key)
                setRequestProperty("Accept", "application/json")
                connectTimeout = 5000
                readTimeout = 5000
            }
            val responseCode = conn.responseCode
            val responseDuration = System.currentTimeMillis() - startTime

            when {
                responseCode == 429 -> {
                    Log.w(TAG, "Supabase server rate limit / overloaded (HTTP 429)")
                    Pair(false, "⚠️ सर्वर पर अभी बहुत अधिक लोड है (HTTP 429 Too Many Requests)। कृपया थोड़ी देर बाद प्रयास करें।")
                }
                responseCode in listOf(500, 502, 503, 504) -> {
                    Log.w(TAG, "Supabase server unavailable / down (HTTP $responseCode)")
                    Pair(false, "⚠️ सर्वर पर मेंटेनेंस या लोड चल रहा है (HTTP $responseCode)। आपका डेटा स्थानीय रूप से सुरक्षित है।")
                }
                responseDuration > 6000 -> {
                    Log.w(TAG, "Supabase server response too slow: ${responseDuration}ms")
                    Pair(false, "⚠️ सर्वर बहुत धीमा चल रहा है (${responseDuration}ms)। डेटा सुरक्षा के लिए सिंक रोक दिया गया है।")
                }
                responseCode in 200..299 || responseCode == 404 -> {
                    Pair(true, "सर्वर तैयार है (${responseDuration}ms)")
                }
                else -> {
                    // For other codes, allow proceed or handle accordingly
                    Pair(true, "सर्वर कनेक्टेड है (HTTP $responseCode)")
                }
            }
        } catch (e: java.net.SocketTimeoutException) {
            Log.w(TAG, "Supabase server timeout: ${e.message}")
            Pair(false, "⚠️ सर्वर से संपर्क समय समाप्त (Timeout)। सर्वर व्यस्त है, कृपया कुछ देर बाद सिंक करें।")
        } catch (e: Exception) {
            Log.w(TAG, "Supabase server health check error: ${e.message}")
            Pair(false, "⚠️ सर्वर अनुपलब्ध है: ${e.localizedMessage ?: "नेटवर्क समस्या"}")
        }
    }

    /**
     * Executes HTTP POST request to Supabase PostgREST
     */
    private fun executePost(
        endpoint: String,
        key: String,
        jsonBody: String,
        preferMerge: Boolean = true
    ): Pair<Int, String> {
        val finalEndpoint = if (preferMerge && !endpoint.contains("on_conflict")) {
            endpoint + (if (endpoint.contains("?")) "&" else "?") + "on_conflict=id"
        } else {
            endpoint
        }
        return try {
            val conn = (URL(finalEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                applyAuthHeaders(this, key)
                setRequestProperty("Content-Type", "application/json")
                if (preferMerge) {
                    setRequestProperty("Prefer", "resolution=merge-duplicates,return=representation")
                } else {
                    setRequestProperty("Prefer", "return=representation")
                }
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }
            OutputStreamWriter(conn.outputStream).use { it.write(jsonBody) }
            val code = conn.responseCode
            val body = if (code in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
            }
            Pair(code, body)
        } catch (e: Exception) {
            Log.e(TAG, "executePost error on $endpoint: ${e.message}")
            Pair(-1, e.localizedMessage ?: "Network error")
        }
    }

    /**
     * Executes HTTP GET request to Supabase PostgREST
     */
    fun getFromSupabase(endpoint: String, key: String): Pair<Int, String?> {
        return try {
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                applyAuthHeaders(this, key)
                setRequestProperty("Accept", "application/json")
                connectTimeout = 8000
                readTimeout = 8000
            }
            val code = conn.responseCode
            val body = if (code in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }
                Log.w(TAG, "getFromSupabase non-200 ($code) on $endpoint: $err")
                null
            }
            Pair(code, body)
        } catch (e: Exception) {
            Log.e(TAG, "getFromSupabase exception on $endpoint: ${e.message}")
            Pair(-1, null)
        }
    }

    /**
     * User Sign-up: Strictly checks internet and Supabase cloud.
     * Prevents fake sign-ups without genuine cloud confirmation.
     */
    suspend fun signUp(
        profile: ProfileEntity,
        context: Context,
        repository: BahiKhataRepository
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanPhone = profile.phone.trim()
        if (!cleanPhone.matches(Regex("^[6-9]\\d{9}$"))) {
            return@withContext AuthResult.Error("कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें (6, 7, 8 या 9 से शुरू)!")
        }

        val isOnline = isNetworkAvailable(context)
        if (!isOnline) {
            return@withContext AuthResult.Error("इंटरनेट बंद है! नया खाता बनाने के लिए कृपया इंटरनेट चालू करें ताकि आपका खाता क्लाउड में सुरक्षित हो सके।")
        }

        if (!isConfigured(context)) {
            return@withContext AuthResult.Error("क्लाउड सर्वर कॉन्फिगर नहीं है! कृपया सही URL और API Key सेट करें।")
        }

        var cloudSuccess = false
        var cloudErrorDetail: String? = null

        val url = getSupabaseUrl(context)
        val key = getSupabaseAnonKey(context)

        try {
            // Check if phone/mobile already exists in profiles
            var userExists = false
            val checkEndpoints = listOf(
                "$url/rest/v1/profiles?phone=eq.$cleanPhone&select=id",
                "$url/rest/v1/profiles?mobile=eq.$cleanPhone&select=id"
            )
            for (ep in checkEndpoints) {
                val (code, res) = getFromSupabase(ep, key)
                if (code == 200 && res != null) {
                    val arr = JSONArray(res)
                    if (arr.length() > 0) {
                        userExists = true
                        break
                    }
                }
            }
            if (userExists) {
                return@withContext AuthResult.Error("इस मोबाइल नंबर ($cleanPhone) से खाता क्लाउड में पहले से मौजूद है! कृपया 'लॉगिन करें' पर जाएं।")
            }

            // Attempt insertion into Supabase profiles
            val payload1 = JSONObject().apply {
                put("id", profile.id)
                put("name", profile.name)
                put("agency_name", profile.agencyName)
                put("phone", profile.phone)
                put("email", profile.email)
                put("is_email_verified", profile.isEmailVerified)
                put("rate_per_hour", profile.ratePerHour)
                put("pin_hash", profile.pinHash)
                put("is_premium", false)
                put("vip_member", false)
                put("vip_days_remaining", 0)
                put("vip_plan", "FREE")
                put("device_id", com.example.data.security.AppSecurityService.getDeviceId(context))
                put("client_version", com.example.data.security.AppSecurityService.getClientVersion())
                put("bot_trap", "")
                put("is_blocked", false)
                put("updated_at", profile.updatedAt)
            }

            val (insertCode1, body1) = executePost("$url/rest/v1/profiles", key, payload1.toString())
            if (insertCode1 in 200..299) {
                cloudSuccess = true
                Log.i(TAG, "Profile saved to Supabase with standard schema: ${profile.id}")
            } else {
                Log.w(TAG, "Standard schema failed ($insertCode1): $body1. Trying fallback schema...")
                val payload2 = JSONObject().apply {
                    put("id", profile.id)
                    put("name", profile.name)
                    put("mobile", profile.phone)
                    put("email", profile.email)
                    put("is_email_verified", profile.isEmailVerified)
                    put("pin_hash", profile.pinHash)
                    put("tubewell_rate", profile.ratePerHour)
                    put("is_premium", false)
                    put("vip_member", false)
                    put("vip_days_remaining", 0)
                    put("vip_plan", "FREE")
                }
                val (insertCode2, body2) = executePost("$url/rest/v1/profiles", key, payload2.toString())
                if (insertCode2 in 200..299) {
                    cloudSuccess = true
                    Log.i(TAG, "Profile saved to Supabase with fallback schema: ${profile.id}")
                } else {
                    // Try payload without email columns in case Supabase schema does not yet have email column
                    val payload3 = JSONObject().apply {
                        put("id", profile.id)
                        put("name", profile.name)
                        put("agency_name", profile.agencyName)
                        put("phone", profile.phone)
                        put("pin_hash", profile.pinHash)
                        put("rate_per_hour", profile.ratePerHour)
                        put("is_premium", false)
                        put("vip_member", false)
                        put("vip_days_remaining", 0)
                    }
                    val (insertCode3, _) = executePost("$url/rest/v1/profiles", key, payload3.toString())
                    if (insertCode3 in 200..299) {
                        cloudSuccess = true
                        Log.i(TAG, "Profile saved to Supabase without email columns: ${profile.id}")
                    } else {
                        cloudErrorDetail = when (insertCode1) {
                            401 -> "HTTP 401 (API Key अमान्य है)"
                            403 -> "HTTP 403 (क्लाउड RLS Policy अनुमति नहीं दे रही है)"
                            404 -> "HTTP 404 (क्लाउड में 'profiles' टेबल नहीं मिली)"
                            else -> "HTTP $insertCode1: $body1"
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Supabase sign up error: ${e.message}")
            cloudErrorDetail = e.localizedMessage ?: "नेटवर्क कनेक्शन त्रुटि"
        }

        if (cloudSuccess) {
            // Save profile locally in Room DB only after verified in Supabase Cloud
            val cleanProfile = profile.copy(isPremium = false)
            repository.saveProfile(cleanProfile)
            repository.setActiveProfileId(cleanProfile.id)
            com.example.data.remoteconfig.RemoteConfigService.resetVipState(context)
            AuthResult.Success(cleanProfile, "Cloud")
        } else {
            AuthResult.Error("क्लाउड में खाता दर्ज नहीं हो सका: ${cloudErrorDetail ?: "सर्वर से प्रतिक्रिया नहीं मिली"}")
        }
    }

    /**
     * User Login: Strictly authenticates with Supabase when online.
     * Prevents random unregistered numbers from logging in.
     */
    suspend fun loginWithMobileAndPassword(
        mobile: String,
        passwordOrPin: String,
        repository: BahiKhataRepository,
        context: Context
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanPhone = mobile.trim()
        val cleanPass = passwordOrPin.trim()

        if (!cleanPhone.matches(Regex("^[6-9]\\d{9}$"))) {
            return@withContext AuthResult.Error("कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें (6, 7, 8 या 9 से शुरू)!")
        }
        if (cleanPass.isEmpty()) {
            return@withContext AuthResult.Error("कृपया पासवर्ड या 4-अंकों का पिन दर्ज करें!")
        }

        // Special Demo Account Login (Allowed for app reviewers/testing)
        if (cleanPhone == "9876543210" && cleanPass == "1234") {
            val demoProfile = ProfileEntity(
                id = "demo_reviewer_profile",
                name = "Kisan Ramchandra",
                agencyName = "Kisan Tubewell & Sinchai Seva",
                phone = cleanPhone,
                ratePerHour = 160.0,
                pinHash = cleanPass
            )
            repository.saveProfile(demoProfile)
            repository.setActiveProfileId(demoProfile.id)
            return@withContext AuthResult.Success(demoProfile, "Demo Review Account")
        }

        // Security Check: Verify if the account or phone is currently locked/blocked
        val securityStatus = com.example.data.security.AppSecurityService.checkSecurityStatus(context, cleanPhone)
        if (securityStatus.isBlocked) {
            val mins = securityStatus.remainingMinutes
            val timeNote = if (mins > 0) " (शेष लॉक समय: लगभग $mins मिनट)" else ""
            return@withContext AuthResult.Error("${securityStatus.reason}$timeNote\nसहायता के लिए एडमिन/सपोर्ट से संपर्क करें।")
        }

        val isOnline = isNetworkAvailable(context)

        // 1. Live Cloud Authentication via Supabase (when online)
        if (isOnline && isConfigured(context)) {
            val url = getSupabaseUrl(context)
            val key = getSupabaseAnonKey(context)
            try {
                val endpoints = listOf(
                    "$url/rest/v1/profiles?phone=eq.$cleanPhone&select=*",
                    "$url/rest/v1/profiles?mobile=eq.$cleanPhone&select=*"
                )
                var foundUserInCloud = false

                for (endpoint in endpoints) {
                    val (code, response) = getFromSupabase(endpoint, key)
                    if (code in 200..299 && response != null) {
                        val arr = JSONArray(response)
                        if (arr.length() > 0) {
                            foundUserInCloud = true
                            val obj = arr.getJSONObject(0)
                            val isCloudBlocked = obj.optBoolean("is_blocked", false)
                            if (isCloudBlocked) {
                                com.example.data.security.AppSecurityService.blockAccount(
                                    context = context,
                                    phone = cleanPhone,
                                    reason = "खाता क्लाउड सर्वर में ब्लॉक है",
                                    profileId = obj.optString("id")
                                )
                                return@withContext AuthResult.Error("⛔ सुरक्षा प्रतिबंध (Blocked): आपका खाता क्लाउड में ब्लॉक है। कृपया एडमिन से संपर्क करें।")
                            }

                            val cloudPin = obj.optString("pin_hash", obj.optString("password", ""))
                            if (cloudPin == cleanPass) {
                                val cloudProfile = ProfileEntity(
                                    id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                                    name = obj.optString("name", "Kisan Owner"),
                                    agencyName = obj.optString("agency_name", ""),
                                    phone = obj.optString("phone", obj.optString("mobile", cleanPhone)),
                                    email = obj.optString("email", ""),
                                    isEmailVerified = obj.optBoolean("is_email_verified", false),
                                    ratePerHour = obj.optDouble("rate_per_hour", obj.optDouble("tubewell_rate", 160.0)),
                                    pinHash = cleanPass,
                                    isPremium = obj.optBoolean("is_premium", false),
                                    isBlocked = false,
                                    updatedAt = obj.optLong("updated_at", System.currentTimeMillis())
                                )
                                repository.saveProfile(cloudProfile)
                                repository.setActiveProfileId(cloudProfile.id)

                                // Restore custom Gemini API key from Supabase cloud if saved
                                val cloudGeminiKey = obj.optString("gemini_api_key", obj.optString("geminiApiKey", "")).trim()
                                if (cloudGeminiKey.isNotBlank()) {
                                    repository.setGeminiApiKey(cloudGeminiKey)
                                }

                                // 2-Way Sync: push any offline data that was saved before logout, and pull latest cloud records
                                try {
                                    val localCusts = repository.getCustomersByProfileOnce(cloudProfile.id)
                                    val localSess = repository.getSessionsByProfileOnce(cloudProfile.id)
                                    val localTxns = repository.getTransactionsByProfileOnce(cloudProfile.id)
                                    syncUserData(cloudProfile.id, localCusts, localSess, localTxns, context).let { res ->
                                        if (res.pulledCustomers.isNotEmpty()) {
                                            repository.insertCustomers(res.pulledCustomers)
                                        }
                                        if (res.pulledSessions.isNotEmpty()) {
                                            repository.insertSessions(res.pulledSessions)
                                        }
                                        if (res.pulledTransactions.isNotEmpty()) {
                                            repository.insertTransactions(res.pulledTransactions)
                                        }
                                        if (res.success) {
                                            repository.markAllSessionsSynced(cloudProfile.id)
                                            repository.setLastSyncTimestamp(cloudProfile.id, System.currentTimeMillis())
                                        }
                                    }
                                } catch (e: Exception) {
                                    Log.w(TAG, "Initial sync after login failed: ${e.message}")
                                }

                                return@withContext AuthResult.Success(cloudProfile, "Cloud")
                            } else {
                                return@withContext AuthResult.Error("गलत पासवर्ड या पिन! कृपया सही पिन दर्ज करें।")
                            }
                        }
                    }
                }

                if (!foundUserInCloud) {
                    return@withContext AuthResult.Error("यह मोबाइल नंबर ($cleanPhone) क्लाउड में पंजीकृत नहीं है! कृपया पहले 'नया खाता बनाएं' पर जाएं।")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Supabase login network error: ${e.message}")
                return@withContext AuthResult.Error("क्लाउड सर्वर से संपर्क नहीं हो पाया: ${e.localizedMessage}")
            }
        }

        // 2. Offline / Local Database verification (Only if previously registered on this phone)
        val localProfile = repository.getProfileByPhone(cleanPhone)
        if (localProfile != null) {
            if (localProfile.isBlocked) {
                return@withContext AuthResult.Error("⛔ सुरक्षा प्रतिबंध: आपका खाता सुरक्षा कारणों से ब्लॉक है।")
            }
            if (localProfile.pinHash == cleanPass) {
                repository.setActiveProfileId(localProfile.id)
                return@withContext AuthResult.Success(localProfile, "Local Storage (ऑफ़लाइन मोड)")
            } else {
                return@withContext AuthResult.Error("गलत पासवर्ड या पिन! कृपया सही पिन दर्ज करें।")
            }
        }

        return@withContext if (!isOnline) {
            AuthResult.Error("इंटरनेट बंद है और यह खाता इस फोन में मौजूद नहीं है! कृपया इंटरनेट चालू करके लॉगिन करें।")
        } else {
            AuthResult.Error("यह मोबाइल नंबर पंजीकृत नहीं है! कृपया पहले 'नया खाता बनाएं' पर क्लिक करें।")
        }
    }

    /**
     * Reset Password and Sync with Supabase
     */
    suspend fun resetPassword(
        phone: String,
        newPinOrPassword: String,
        repository: BahiKhataRepository,
        context: Context
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanPhone = phone.trim()
        val cleanPass = newPinOrPassword.trim()

        if (cleanPhone.length != 10) {
            return@withContext AuthResult.Error("कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें!")
        }
        if (cleanPass.isEmpty()) {
            return@withContext AuthResult.Error("कृपया नया पासवर्ड या 4-अंकों का पिन दर्ज करें!")
        }

        var profileToUpdate = repository.getProfileByPhone(cleanPhone) ?: repository.getProfileOnce()

        if (isConfigured(context) && isNetworkAvailable(context)) {
            val url = getSupabaseUrl(context)
            val key = getSupabaseAnonKey(context)
            try {
                val endpoints = listOf(
                    "$url/rest/v1/profiles?phone=eq.$cleanPhone",
                    "$url/rest/v1/profiles?mobile=eq.$cleanPhone"
                )
                val payload = JSONObject().apply {
                    put("pin_hash", cleanPass)
                    put("updated_at", System.currentTimeMillis())
                }

                for (patchEndpoint in endpoints) {
                    val conn = (URL(patchEndpoint).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        setRequestProperty("X-HTTP-Method-Override", "PATCH")
                        applyAuthHeaders(this, key)
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Prefer", "return=representation")
                        doOutput = true
                        connectTimeout = 7000
                        readTimeout = 7000
                    }
                    OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
                    if (conn.responseCode in 200..299) {
                        val response = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = JSONArray(response)
                        if (arr.length() > 0) {
                            val obj = arr.getJSONObject(0)
                            profileToUpdate = ProfileEntity(
                                id = obj.optString("id", profileToUpdate?.id ?: java.util.UUID.randomUUID().toString()),
                                name = obj.optString("name", profileToUpdate?.name ?: "Kisan Owner"),
                                agencyName = obj.optString("agency_name", profileToUpdate?.agencyName ?: ""),
                                phone = cleanPhone,
                                email = obj.optString("email", profileToUpdate?.email ?: ""),
                                isEmailVerified = obj.optBoolean("is_email_verified", profileToUpdate?.isEmailVerified ?: false),
                                ratePerHour = obj.optDouble("rate_per_hour", profileToUpdate?.ratePerHour ?: 160.0),
                                pinHash = cleanPass,
                                isPremium = obj.optBoolean("is_premium", false),
                                updatedAt = System.currentTimeMillis()
                            )
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Supabase reset password patch error: ${e.message}")
            }
        }

        val finalProfile = profileToUpdate?.copy(
            phone = cleanPhone,
            pinHash = cleanPass,
            updatedAt = System.currentTimeMillis()
        ) ?: ProfileEntity(
            phone = cleanPhone,
            name = "Kisan Owner",
            agencyName = "",
            email = "",
            isEmailVerified = false,
            ratePerHour = 160.0,
            pinHash = cleanPass
        )

        repository.saveProfile(finalProfile)
        repository.setActiveProfileId(finalProfile.id)
        // Also unblock account and clear failed attempts upon successful password/pin reset
        com.example.data.security.AppSecurityService.unblockAccount(context, cleanPhone, finalProfile.id)
        return@withContext AuthResult.Success(finalProfile, if (isConfigured(context)) "Supabase Cloud" else "Local Storage")
    }

    /**
     * Executes HTTP PATCH request with robust support for standard PATCH and X-HTTP-Method-Override
     */
    private fun patchSupabase(endpoint: String, key: String, jsonBody: String): Pair<Int, String> {
        try {
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                try {
                    requestMethod = "PATCH"
                } catch (_: Exception) {
                    requestMethod = "POST"
                    setRequestProperty("X-HTTP-Method-Override", "PATCH")
                }
                applyAuthHeaders(this, key)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Prefer", "return=representation")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }
            OutputStreamWriter(conn.outputStream).use { it.write(jsonBody) }
            val code = conn.responseCode
            val body = if (code in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
            }
            if (code in 200..299) return Pair(code, body)
        } catch (e: Exception) {
            Log.w(TAG, "patchSupabase direct PATCH attempt error: ${e.message}")
        }

        return try {
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("X-HTTP-Method-Override", "PATCH")
                applyAuthHeaders(this, key)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Prefer", "return=representation")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }
            OutputStreamWriter(conn.outputStream).use { it.write(jsonBody) }
            val code = conn.responseCode
            val body = if (code in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
            }
            Pair(code, body)
        } catch (e: Exception) {
            Log.e(TAG, "patchSupabase override attempt error: ${e.message}")
            Pair(-1, e.localizedMessage ?: "Network error")
        }
    }

    /**
     * Directly updates a user's email and verification status in Supabase profiles table.
     */
    suspend fun updateProfileEmailInSupabase(
        context: Context,
        profileId: String,
        phone: String,
        email: String,
        isEmailVerified: Boolean
    ): Boolean = withContext(Dispatchers.IO) {
        if (!isConfigured(context) || !isNetworkAvailable(context)) {
            Log.w(TAG, "Cannot update email in Supabase: not configured or offline")
            return@withContext false
        }
        val url = getSupabaseUrl(context).removeSuffix("/")
        val key = getSupabaseAnonKey(context)
        val cleanEmail = email.trim().lowercase(Locale.ROOT)
        val cleanPhone = phone.trim().filter { it.isDigit() }

        var targetId = profileId
        // If profileId is default or empty, resolve real id from cloud by phone
        if (targetId.isBlank() || targetId == "default" || targetId == "default_owner_profile") {
            if (cleanPhone.isNotBlank()) {
                val (qCode, qBody) = getFromSupabase("$url/rest/v1/profiles?phone=eq.$cleanPhone&select=id", key)
                if (qCode in 200..299 && !qBody.isNullOrBlank()) {
                    val arr = JSONArray(qBody)
                    if (arr.length() > 0) {
                        targetId = arr.getJSONObject(0).optString("id", targetId)
                    }
                }
            }
        }

        val endpoints = mutableListOf<String>()
        if (targetId.isNotBlank() && targetId != "default" && targetId != "default_owner_profile") {
            endpoints.add("$url/rest/v1/profiles?id=eq.$targetId")
        }
        if (cleanPhone.isNotBlank()) {
            endpoints.add("$url/rest/v1/profiles?phone=eq.$cleanPhone")
            endpoints.add("$url/rest/v1/profiles?mobile=eq.$cleanPhone")
        }

        val payload = JSONObject().apply {
            put("email", cleanEmail)
            put("is_email_verified", isEmailVerified)
            put("updated_at", System.currentTimeMillis())
        }

        var success = false
        for (ep in endpoints) {
            val (code, res) = patchSupabase(ep, key, payload.toString())
            if (code in 200..299 && res.isNotBlank() && res != "[]") {
                Log.i(TAG, "Profile email updated successfully in Supabase: $cleanEmail (verified=$isEmailVerified)")
                success = true
                break
            } else {
                Log.w(TAG, "Failed to update profile email at $ep ($code): $res")
            }
        }

        // Fallback: If PATCH didn't match existing rows, try upserting with merge-duplicates
        if (!success && targetId.isNotBlank() && targetId != "default_owner_profile") {
            val upsertPayload = JSONObject().apply {
                put("id", targetId)
                if (cleanPhone.isNotBlank()) {
                    put("phone", cleanPhone)
                    put("mobile", cleanPhone)
                }
                put("email", cleanEmail)
                put("is_email_verified", isEmailVerified)
                put("updated_at", System.currentTimeMillis())
            }
            val (uCode, uBody) = executePost("$url/rest/v1/profiles", key, upsertPayload.toString(), preferMerge = true)
            if (uCode in 200..299) {
                Log.i(TAG, "Profile email upserted into Supabase: $cleanEmail (verified=$isEmailVerified)")
                success = true
            } else {
                Log.w(TAG, "Profile email upsert fallback failed ($uCode): $uBody")
            }
        }

        return@withContext success
    }

    /**
     * Directly updates a user's custom Gemini API key in Supabase profiles table.
     */
    suspend fun updateProfileGeminiApiKeyInSupabase(
        context: Context,
        profileId: String,
        phone: String,
        apiKey: String
    ): Boolean = withContext(Dispatchers.IO) {
        if (!isConfigured(context) || !isNetworkAvailable(context)) {
            Log.w(TAG, "Cannot update gemini_api_key in Supabase: not configured or offline")
            return@withContext false
        }
        val url = getSupabaseUrl(context).removeSuffix("/")
        val key = getSupabaseAnonKey(context)
        val cleanKey = apiKey.trim()
        val cleanPhone = phone.trim().filter { it.isDigit() }

        var targetId = profileId
        if (targetId.isBlank() || targetId == "default" || targetId == "default_owner_profile") {
            if (cleanPhone.isNotBlank()) {
                val (qCode, qBody) = getFromSupabase("$url/rest/v1/profiles?phone=eq.$cleanPhone&select=id", key)
                if (qCode in 200..299 && !qBody.isNullOrBlank()) {
                    val arr = JSONArray(qBody)
                    if (arr.length() > 0) {
                        targetId = arr.getJSONObject(0).optString("id", targetId)
                    }
                }
            }
        }

        val endpoints = mutableListOf<String>()
        if (targetId.isNotBlank() && targetId != "default" && targetId != "default_owner_profile") {
            endpoints.add("$url/rest/v1/profiles?id=eq.$targetId")
        }
        if (cleanPhone.isNotBlank()) {
            endpoints.add("$url/rest/v1/profiles?phone=eq.$cleanPhone")
            endpoints.add("$url/rest/v1/profiles?mobile=eq.$cleanPhone")
        }

        val payload = JSONObject().apply {
            put("gemini_api_key", cleanKey)
            put("updated_at", System.currentTimeMillis())
        }

        var success = false
        for (ep in endpoints) {
            val (code, res) = patchSupabase(ep, key, payload.toString())
            if (code in 200..299 && res.isNotBlank() && res != "[]") {
                Log.i(TAG, "Profile gemini_api_key updated in Supabase cloud")
                success = true
                break
            }
        }

        if (!success && targetId.isNotBlank() && targetId != "default_owner_profile") {
            val upsertPayload = JSONObject().apply {
                put("id", targetId)
                if (cleanPhone.isNotBlank()) {
                    put("phone", cleanPhone)
                    put("mobile", cleanPhone)
                }
                put("gemini_api_key", cleanKey)
                put("updated_at", System.currentTimeMillis())
            }
            val (uCode, _) = executePost("$url/rest/v1/profiles", key, upsertPayload.toString(), preferMerge = true)
            if (uCode in 200..299) {
                success = true
            }
        }
        return@withContext success
    }

    /**
     * Updates an existing profile row in Supabase cloud.
     */
    suspend fun updateProfileInSupabase(
        context: Context,
        profile: ProfileEntity
    ): Boolean = withContext(Dispatchers.IO) {
        if (!isConfigured(context) || !isNetworkAvailable(context)) return@withContext false
        val url = getSupabaseUrl(context).removeSuffix("/")
        val key = getSupabaseAnonKey(context)
        val cleanPhone = profile.phone.trim().filter { it.isDigit() }

        var targetId = profile.id
        if (targetId.isBlank() || targetId == "default" || targetId == "default_owner_profile") {
            if (cleanPhone.isNotBlank()) {
                val (qCode, qBody) = getFromSupabase("$url/rest/v1/profiles?phone=eq.$cleanPhone&select=id", key)
                if (qCode in 200..299 && !qBody.isNullOrBlank()) {
                    val arr = JSONArray(qBody)
                    if (arr.length() > 0) {
                        targetId = arr.getJSONObject(0).optString("id", targetId)
                    }
                }
            }
        }

        val endpoints = mutableListOf<String>()
        if (targetId.isNotBlank() && targetId != "default" && targetId != "default_owner_profile") {
            endpoints.add("$url/rest/v1/profiles?id=eq.$targetId")
        }
        if (cleanPhone.isNotBlank()) {
            endpoints.add("$url/rest/v1/profiles?phone=eq.$cleanPhone")
            endpoints.add("$url/rest/v1/profiles?mobile=eq.$cleanPhone")
        }

        val payload = JSONObject().apply {
            put("name", profile.name)
            put("agency_name", profile.agencyName)
            put("rate_per_hour", profile.ratePerHour)
            put("tubewell_rate", profile.ratePerHour)
            put("email", profile.email)
            put("is_email_verified", profile.isEmailVerified)
            put("is_premium", profile.isPremium)
            put("updated_at", profile.updatedAt)
        }

        var success = false
        for (ep in endpoints) {
            val (code, res) = patchSupabase(ep, key, payload.toString())
            if (code in 200..299 && res.isNotBlank() && res != "[]") {
                Log.i(TAG, "Profile updated in Supabase cloud: $targetId")
                success = true
                break
            }
        }

        if (!success && targetId.isNotBlank() && targetId != "default_owner_profile") {
            val upsertPayload = JSONObject().apply {
                put("id", targetId)
                put("name", profile.name)
                put("agency_name", profile.agencyName)
                put("phone", profile.phone)
                put("mobile", profile.phone)
                put("rate_per_hour", profile.ratePerHour)
                put("tubewell_rate", profile.ratePerHour)
                put("pin_hash", profile.pinHash)
                put("email", profile.email)
                put("is_email_verified", profile.isEmailVerified)
                put("is_premium", profile.isPremium)
                put("updated_at", profile.updatedAt)
            }
            val (uCode, _) = executePost("$url/rest/v1/profiles", key, upsertPayload.toString(), preferMerge = true)
            if (uCode in 200..299) {
                success = true
            }
        }
        return@withContext success
    }

    /**
     * Look up user profile by mobile phone or email across Local DB and Supabase Cloud.
     * Used for Forgot Password and Email OTP delivery.
     */
    suspend fun lookupAccountForReset(
        identifier: String,
        context: Context,
        repository: BahiKhataRepository
    ): ProfileEntity? = withContext(Dispatchers.IO) {
        val clean = identifier.trim()
        if (clean.isBlank()) return@withContext null

        // 1. Try local database first
        val localByPhone = repository.getProfileByPhone(clean)
        if (localByPhone != null) return@withContext localByPhone

        val localByEmail = repository.getProfileByEmail(clean)
        if (localByEmail != null) return@withContext localByEmail

        // 2. Try Supabase Cloud
        if (isConfigured(context) && isNetworkAvailable(context)) {
            val url = getSupabaseUrl(context)
            val key = getSupabaseAnonKey(context)
            val endpoints = listOf(
                "$url/rest/v1/profiles?phone=eq.$clean&select=*",
                "$url/rest/v1/profiles?mobile=eq.$clean&select=*",
                "$url/rest/v1/profiles?email=eq.$clean&select=*"
            )
            for (endpoint in endpoints) {
                val (code, res) = getFromSupabase(endpoint, key)
                if (code in 200..299 && res != null) {
                    val arr = JSONArray(res)
                    if (arr.length() > 0) {
                        val obj = arr.getJSONObject(0)
                        return@withContext ProfileEntity(
                            id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                            name = obj.optString("name", "Kisan Owner"),
                            agencyName = obj.optString("agency_name", ""),
                            phone = obj.optString("phone", obj.optString("mobile", clean)),
                            email = obj.optString("email", if (clean.contains("@")) clean else ""),
                            isEmailVerified = obj.optBoolean("is_email_verified", false),
                            ratePerHour = obj.optDouble("rate_per_hour", 160.0),
                            pinHash = obj.optString("pin_hash", ""),
                            isPremium = obj.optBoolean("is_premium", false),
                            updatedAt = obj.optLong("updated_at", System.currentTimeMillis())
                        )
                    }
                }
            }
        }

        // Fallback: active profile if matching phone/email
        val active = repository.getProfileOnce()
        if (active != null && (active.phone == clean || active.email.equals(clean, ignoreCase = true))) {
            return@withContext active
        }

        return@withContext null
    }

    /**
     * 2-Way Sync for Customers, Sessions, and Transactions scoped strictly to profileId
     */
    suspend fun syncUserData(
        profileId: String,
        localCustomers: List<CustomerEntity>,
        localSessions: List<TubewellSessionEntity>,
        localTxns: List<TransactionEntity>,
        context: Context
    ): SyncResult = withContext(Dispatchers.IO) {
        if (!isConfigured(context)) {
            return@withContext SyncResult(true, "स्थानीय डेटाबेस सक्रिय है (Supabase URL कॉन्फ़िगर नहीं है)")
        }
        if (!isNetworkAvailable(context)) {
            return@withContext SyncResult(false, "⚠️ इंटरनेट बंद है। कृपया डेटा सिंक करने के लिए इंटरनेट चालू करें।")
        }

        // सर्वर लोड और हेल्थ चेक: यदि सर्वर पर लोड (HTTP 429, 503 या स्लो रिस्पॉन्स) है तो डेटा को रोककर सुरक्षित रखें
        val (isServerReady, healthMessage) = checkServerHealthAndLoad(context)
        if (!isServerReady) {
            Log.w(TAG, "Sync aborted due to server load check: $healthMessage")
            return@withContext SyncResult(false, healthMessage)
        }

        val url = getSupabaseUrl(context)
        val key = getSupabaseAnonKey(context)

        val pulledCustomers = mutableListOf<CustomerEntity>()
        val pulledSessions = mutableListOf<TubewellSessionEntity>()
        val pulledTxns = mutableListOf<TransactionEntity>()

        try {
            // 1. PUSH & PULL Customers
            if (localCustomers.isNotEmpty()) {
                val custPayload1 = JSONArray().apply {
                    localCustomers.forEach { c ->
                        put(JSONObject().apply {
                            put("id", c.id)
                            put("profile_id", profileId)
                            put("name", c.name)
                            put("s_o", c.sO)
                            put("phone", c.phone)
                            put("avatar_bg_color", c.avatarBgColor)
                            put("initial_balance", c.initialBalance)
                            put("created_at", c.createdAt)
                        })
                    }
                }
                val (cCode1, _) = executePost("$url/rest/v1/customers", key, custPayload1.toString())
                if (cCode1 !in 200..299) {
                    // Fallback schema (id, profile_id, name, phone, village, total_due)
                    val custPayload2 = JSONArray().apply {
                        localCustomers.forEach { c ->
                            put(JSONObject().apply {
                                put("id", c.id)
                                put("profile_id", profileId)
                                put("name", c.name)
                                put("phone", c.phone)
                                put("village", c.sO)
                                put("total_due", c.initialBalance)
                            })
                        }
                    }
                    executePost("$url/rest/v1/customers", key, custPayload2.toString())
                }
            }

            // Pull cloud customers
            val (_, custJson) = getFromSupabase("$url/rest/v1/customers?profile_id=eq.$profileId&select=*", key)
            if (custJson != null) {
                val arr = JSONArray(custJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    pulledCustomers.add(
                        CustomerEntity(
                            id = obj.getString("id"),
                            profileId = obj.optString("profile_id", profileId),
                            name = obj.getString("name"),
                            sO = obj.optString("s_o", obj.optString("village", "")),
                            phone = obj.optString("phone", obj.optString("mobile", "")),
                            avatarBgColor = obj.optLong("avatar_bg_color", 0xFF1B5E20),
                            initialBalance = obj.optDouble("initial_balance", obj.optDouble("total_due", 0.0)),
                            createdAt = obj.optLong("created_at", System.currentTimeMillis())
                        )
                    )
                }
            }

            // 2. PUSH & PULL Sessions
            if (localSessions.isNotEmpty()) {
                val sessPayload1 = JSONArray().apply {
                    localSessions.forEach { s ->
                        put(JSONObject().apply {
                            put("id", s.id)
                            put("profile_id", profileId)
                            put("customer_id", s.customerId)
                            put("hours", s.hours)
                            put("rate", s.rate)
                            put("total_amount", s.totalAmount)
                            put("paid_amount", s.paidAmount)
                            put("due_amount", s.dueAmount)
                            put("note", s.note)
                            put("session_date", s.sessionDate)
                        })
                    }
                }
                val (sCode1, _) = executePost("$url/rest/v1/sessions", key, sessPayload1.toString())
                if (sCode1 !in 200..299) {
                    // Fallback schema (start_time, duration_minutes, etc.)
                    val sessPayload2 = JSONArray().apply {
                        localSessions.forEach { s ->
                            put(JSONObject().apply {
                                put("id", s.id)
                                put("profile_id", profileId)
                                put("customer_id", s.customerId)
                                put("customer_name", "Customer")
                                put("start_time", s.sessionDate)
                                put("end_time", s.sessionDate + (s.hours * 3600000).toLong())
                                put("duration_minutes", (s.hours * 60).toInt())
                                put("rate_per_hour", s.rate)
                                put("total_amount", s.totalAmount)
                                put("amount_paid", s.paidAmount)
                                put("is_paid", s.dueAmount <= 0)
                                put("crop_type", s.note)
                            })
                        }
                    }
                    executePost("$url/rest/v1/sessions", key, sessPayload2.toString())
                }
            }

            val (_, sessJson) = getFromSupabase("$url/rest/v1/sessions?profile_id=eq.$profileId&select=*", key)
            if (sessJson != null) {
                val arr = JSONArray(sessJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val hrs = if (obj.has("hours")) {
                        obj.getDouble("hours")
                    } else {
                        val durMin = obj.optInt("duration_minutes", 0)
                        durMin / 60.0
                    }
                    val rate = obj.optDouble("rate", obj.optDouble("rate_per_hour", 160.0))
                    val tot = obj.optDouble("total_amount", hrs * rate)
                    val paid = obj.optDouble("paid_amount", obj.optDouble("amount_paid", 0.0))
                    val due = obj.optDouble("due_amount", (tot - paid).coerceAtLeast(0.0))
                    val sessDate = obj.optLong("session_date", obj.optLong("start_time", System.currentTimeMillis()))
                    val note = obj.optString("note", obj.optString("crop_type", ""))

                    pulledSessions.add(
                        TubewellSessionEntity(
                            id = obj.getString("id"),
                            profileId = obj.optString("profile_id", profileId),
                            customerId = obj.getString("customer_id"),
                            hours = hrs,
                            rate = rate,
                            totalAmount = tot,
                            paidAmount = paid,
                            dueAmount = due,
                            note = note,
                            sessionDate = sessDate,
                            isSynced = true
                        )
                    )
                }
            }

            // 3. PUSH & PULL Transactions
            if (localTxns.isNotEmpty()) {
                val txnPayload1 = JSONArray().apply {
                    localTxns.forEach { t ->
                        put(JSONObject().apply {
                            put("id", t.id)
                            put("profile_id", profileId)
                            put("customer_id", t.customerId)
                            put("amount_deposited", t.amountDeposited)
                            put("payment_mode", t.paymentMode)
                            put("note", t.note)
                            put("deposit_date", t.depositDate)
                        })
                    }
                }
                val (tCode1, _) = executePost("$url/rest/v1/transactions", key, txnPayload1.toString())
                if (tCode1 !in 200..299) {
                    // Fallback schema (amount, payment_mode, notes, date)
                    val txnPayload2 = JSONArray().apply {
                        localTxns.forEach { t ->
                            put(JSONObject().apply {
                                put("id", t.id)
                                put("profile_id", profileId)
                                put("customer_id", t.customerId)
                                put("amount", t.amountDeposited)
                                put("payment_mode", t.paymentMode)
                                put("notes", t.note)
                                put("date", t.depositDate)
                            })
                        }
                    }
                    executePost("$url/rest/v1/transactions", key, txnPayload2.toString())
                }
            }

            val (_, txnJson) = getFromSupabase("$url/rest/v1/transactions?profile_id=eq.$profileId&select=*", key)
            if (txnJson != null) {
                val arr = JSONArray(txnJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    pulledTxns.add(
                        TransactionEntity(
                            id = obj.getString("id"),
                            profileId = obj.optString("profile_id", profileId),
                            customerId = obj.getString("customer_id"),
                            amountDeposited = obj.optDouble("amount_deposited", obj.optDouble("amount", 0.0)),
                            paymentMode = obj.optString("payment_mode", "Cash"),
                            note = obj.optString("note", obj.optString("notes", "")),
                            depositDate = obj.optLong("deposit_date", obj.optLong("date", System.currentTimeMillis()))
                        )
                    )
                }
            }

            SyncResult(
                success = true,
                message = "✅ क्लाउड के साथ डेटा सिंक सफल! (${localCustomers.size} ग्राहक भेजे, ${pulledCustomers.size} प्राप्त)",
                pulledCustomers = pulledCustomers,
                pulledSessions = pulledSessions,
                pulledTransactions = pulledTxns
            )
        } catch (e: Exception) {
            Log.e(TAG, "Sync error: ${e.message}", e)
            SyncResult(false, "सिंक त्रुटि: ${e.localizedMessage ?: "नेटवर्क समस्या"}")
        }
    }

    /**
     * Tests connection to Supabase REST endpoint with detailed diagnostic messages
     */
    suspend fun testConnection(context: Context, testUrl: String? = null, testKey: String? = null): Result<String> = withContext(Dispatchers.IO) {
        val url = (testUrl ?: getSupabaseUrl(context)).trim().removeSuffix("/")
        val key = (testKey ?: getSupabaseAnonKey(context)).trim()

        if (url.isBlank() || key.isBlank() || !url.startsWith("http")) {
            return@withContext Result.failure(Exception("क्लाउड सर्वर URL और Key अमान्य हैं"))
        }

        try {
            val endpoint = "$url/rest/v1/profiles?select=id&limit=1"
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                applyAuthHeaders(this, key)
                setRequestProperty("Accept", "application/json")
                connectTimeout = 7000
                readTimeout = 7000
            }
            val code = conn.responseCode
            if (code in 200..299) {
                Result.success("✅ सुरक्षित क्लाउड सर्वर से सफलतापूर्वक कनेक्टेड है! (HTTP $code)")
            } else if (code == 401) {
                Result.failure(Exception("प्रमाणीकरण विफल (HTTP 401): API Key अमान्य है"))
            } else if (code == 403) {
                Result.failure(Exception("सुरक्षा प्रतिबंध (HTTP 403): क्लाउड सर्वर में Row Level Security (RLS) सक्षम है।"))
            } else if (code == 404) {
                Result.failure(Exception("टेबल नहीं मिली (HTTP 404): क्लाउड सर्वर में 'profiles' टेबल नहीं मिली।"))
            } else {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
                Result.failure(Exception("सर्वर कोड $code: $err"))
            }
        } catch (e: Exception) {
            Result.failure(Exception(e.localizedMessage ?: "नेटवर्क या URL अमान्य है"))
        }
    }

    /**
     * Returns the master SQL script to run in Supabase SQL Editor.
     * This ensures tables exist, adds all needed columns, and disables RLS so the publishable key works.
     */
    fun getSqlSetupScript(): String {
        return """
-- 1. Profiles Table (किसान प्रोफ़ाइल)
CREATE TABLE IF NOT EXISTS public.profiles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    agency_name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    mobile TEXT DEFAULT '',
    email TEXT DEFAULT '',
    is_email_verified BOOLEAN DEFAULT FALSE,
    rate_per_hour NUMERIC DEFAULT 160.0,
    tubewell_rate NUMERIC DEFAULT 160.0,
    pin_hash TEXT NOT NULL,
    is_premium BOOLEAN DEFAULT FALSE,
    vip_member BOOLEAN DEFAULT FALSE,
    vip_days_remaining INTEGER DEFAULT 0,
    vip_expiry TIMESTAMP WITH TIME ZONE,
    vip_plan TEXT DEFAULT 'FREE',
    updated_at BIGINT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Ensure Email, VIP and Gemini API Key columns exist if table was created previously
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS email TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_email_verified BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_premium BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_member BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_days_remaining INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_expiry TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS vip_plan TEXT DEFAULT 'FREE';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS gemini_api_key TEXT DEFAULT '';

-- 1.1 App Subscriptions Table (VIP सदस्यता व पेमेंट रिकॉर्ड्स)
CREATE TABLE IF NOT EXISTS public.app_subscriptions (
    id BIGSERIAL PRIMARY KEY,
    payment_id TEXT NOT NULL,
    phone TEXT DEFAULT '',
    plan_type TEXT DEFAULT 'MONTHLY',
    amount NUMERIC DEFAULT 0.0,
    days_added INTEGER DEFAULT 30,
    total_days_remaining INTEGER DEFAULT 30,
    expires_at TIMESTAMP WITH TIME ZONE,
    is_premium BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    payment_status TEXT DEFAULT 'SUCCESS',
    platform TEXT DEFAULT 'ANDROID_RAZORPAY',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 1.2 Function & Trigger to automatically update VIP days remaining daily based on expiry
CREATE OR REPLACE FUNCTION public.sync_profile_vip_status()
RETURNS TRIGGER AS ${'$'}${'$'}
BEGIN
    IF NEW.vip_expiry IS NOT NULL THEN
        NEW.vip_days_remaining := GREATEST(0, CEIL(EXTRACT(EPOCH FROM (NEW.vip_expiry - NOW())) / 86400)::INTEGER);
        IF NEW.vip_expiry > NOW() THEN
            NEW.vip_member := TRUE;
            NEW.is_premium := TRUE;
        ELSE
            NEW.vip_member := FALSE;
            NEW.is_premium := FALSE;
            NEW.vip_days_remaining := 0;
            NEW.vip_plan := 'FREE';
        END IF;
    ELSIF NEW.vip_days_remaining IS NOT NULL AND NEW.vip_days_remaining > 0 THEN
        IF NEW.vip_expiry IS NULL THEN
            NEW.vip_expiry := NOW() + (NEW.vip_days_remaining || ' days')::INTERVAL;
        END IF;
        NEW.vip_member := TRUE;
        NEW.is_premium := TRUE;
    ELSE
        NEW.vip_member := FALSE;
        NEW.is_premium := FALSE;
        NEW.vip_days_remaining := 0;
        NEW.vip_plan := 'FREE';
    END IF;
    RETURN NEW;
END;
${'$'}${'$'} LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_profile_vip_status ON public.profiles;
CREATE TRIGGER trg_sync_profile_vip_status
BEFORE INSERT OR UPDATE OF vip_expiry, vip_days_remaining ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.sync_profile_vip_status();

-- Periodic refresh function to recalculate days remaining across all profiles
CREATE OR REPLACE FUNCTION public.refresh_all_vip_days()
RETURNS void AS ${'$'}${'$'}
BEGIN
    UPDATE public.profiles
    SET vip_days_remaining = GREATEST(0, CEIL(EXTRACT(EPOCH FROM (vip_expiry - NOW())) / 86400)::INTEGER),
        vip_member = CASE WHEN vip_expiry > NOW() THEN TRUE ELSE FALSE END,
        is_premium = CASE WHEN vip_expiry > NOW() THEN TRUE ELSE FALSE END
    WHERE vip_expiry IS NOT NULL;
END;
${'$'}${'$'} LANGUAGE plpgsql;

-- 2. Customers Table (ग्राहक खाते)
CREATE TABLE IF NOT EXISTS public.customers (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    name TEXT NOT NULL,
    s_o TEXT DEFAULT '',
    village TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    avatar_bg_color BIGINT DEFAULT 4280018464,
    initial_balance NUMERIC DEFAULT 0.0,
    total_due NUMERIC DEFAULT 0.0,
    created_at BIGINT DEFAULT 0
);

-- 3. Sessions Table (सिंचाई रिकॉर्ड्स)
CREATE TABLE IF NOT EXISTS public.sessions (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    customer_name TEXT DEFAULT '',
    hours NUMERIC DEFAULT 0.0,
    duration_minutes INTEGER DEFAULT 0,
    rate NUMERIC DEFAULT 160.0,
    rate_per_hour NUMERIC DEFAULT 160.0,
    total_amount NUMERIC NOT NULL,
    paid_amount NUMERIC DEFAULT 0.0,
    amount_paid NUMERIC DEFAULT 0.0,
    due_amount NUMERIC DEFAULT 0.0,
    is_paid BOOLEAN DEFAULT FALSE,
    note TEXT DEFAULT '',
    crop_type TEXT DEFAULT '',
    session_date BIGINT DEFAULT 0,
    start_time BIGINT DEFAULT 0,
    end_time BIGINT DEFAULT 0
);

-- 4. Transactions Table (भुगतान व रसीदें)
CREATE TABLE IF NOT EXISTS public.transactions (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    amount_deposited NUMERIC DEFAULT 0.0,
    amount NUMERIC DEFAULT 0.0,
    payment_mode TEXT DEFAULT 'Cash',
    note TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    deposit_date BIGINT DEFAULT 0,
    date BIGINT DEFAULT 0
);

-- 5. Blocked Users Table (सुरक्षा ब्लॉक रिकॉर्ड्स)
CREATE TABLE IF NOT EXISTS public.blocked_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone TEXT NOT NULL,
    profile_id TEXT DEFAULT '',
    reason TEXT NOT NULL DEFAULT 'BRUTE_FORCE_FAILED_ATTEMPTS',
    failed_attempts INTEGER DEFAULT 5,
    device_id TEXT DEFAULT '',
    client_version TEXT DEFAULT 'android_v1.0',
    is_blocked BOOLEAN NOT NULL DEFAULT TRUE,
    blocked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    unblock_at TIMESTAMP WITH TIME ZONE,
    ip_address TEXT DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_blocked_users_phone ON public.blocked_users (phone);
CREATE INDEX IF NOT EXISTS idx_blocked_users_is_blocked ON public.blocked_users (is_blocked);

-- Ensure security columns in profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_blocked BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS device_id TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bot_trap TEXT DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS client_version TEXT DEFAULT 'android_v1.0';

-- 6. Row Level Security (RLS) & Policies (सुरक्षित एक्सेस)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow app access to profiles" ON public.profiles;
DROP POLICY IF EXISTS "Allow app access to customers" ON public.customers;
DROP POLICY IF EXISTS "Allow app access to sessions" ON public.sessions;
DROP POLICY IF EXISTS "Allow app access to transactions" ON public.transactions;
DROP POLICY IF EXISTS "Allow app access to app_subscriptions" ON public.app_subscriptions;
DROP POLICY IF EXISTS "Allow app access to blocked_users" ON public.blocked_users;

CREATE POLICY "Allow app access to profiles" ON public.profiles FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow app access to customers" ON public.customers FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow app access to sessions" ON public.sessions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow app access to transactions" ON public.transactions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow app access to app_subscriptions" ON public.app_subscriptions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow app access to blocked_users" ON public.blocked_users FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
        """.trimIndent()
    }
}
