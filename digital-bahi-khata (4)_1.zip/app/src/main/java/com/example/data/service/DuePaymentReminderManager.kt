package com.example.data.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.db.AppDatabase
import com.example.data.db.CustomerEntity
import com.example.data.localization.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.util.Locale

/**
 * Overdue durations for categorizing farmer payment delays
 */
enum class OverdueDuration(
    val minDays: Int,
    val labelHindi: String,
    val labelEnglish: String
) {
    ALL(0, "सभी बकाया", "All Overdue"),
    WEEK_1(7, "1 सप्ताह+", "1+ Week"),
    DAYS_15(15, "15 दिन+", "15+ Days"),
    MONTH_1(30, "1 महीना+", "1+ Month"),
    MONTH_2(60, "2 महीने+", "2+ Months"),
    MONTH_3(90, "3 महीने+", "3+ Months"),
    MONTH_6(180, "6 महीने+", "6+ Months"),
    YEAR_1(365, "1 साल+", "1+ Year")
}

data class OverdueCustomerItem(
    val customer: CustomerEntity,
    val dueAmount: Double,
    val oldestUnpaidDate: Long,
    val daysOverdue: Int,
    val durationCategory: OverdueDuration,
    val formattedDurationText: String
)

/**
 * Manager for Due Payment Tracking & Non-Permanent (Dismissible) Notifications for Tubewell Owner.
 * 
 * Note: These notifications are strictly dismissible (setOngoing(false) & setAutoCancel(true))
 * and appear directly in the phone's notification bar to alert the owner about unpaid accounts.
 */
object DuePaymentReminderManager {
    private const val TAG = "DueReminderManager"
    const val CHANNEL_ID = "tubewell_due_reminders_channel"
    private const val SUMMARY_NOTIFICATION_ID = 8800

    private const val PREFS_NAME = "bahi_khata_due_reminder_prefs"
    private const val KEY_AUTO_REMINDER_ENABLED = "auto_due_reminder_enabled"
    private const val KEY_FILTER_DURATION = "filter_duration_name"
    private const val KEY_LAST_CHECK_TS = "last_due_check_timestamp"

    fun isAutoReminderEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_AUTO_REMINDER_ENABLED, true)
    }

    fun setAutoReminderEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_AUTO_REMINDER_ENABLED, enabled).apply()
    }

    fun getSelectedDuration(context: Context): OverdueDuration {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val name = prefs.getString(KEY_FILTER_DURATION, OverdueDuration.ALL.name) ?: OverdueDuration.ALL.name
        return try {
            OverdueDuration.valueOf(name)
        } catch (e: Exception) {
            OverdueDuration.ALL
        }
    }

    fun setSelectedDuration(context: Context, duration: OverdueDuration) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_FILTER_DURATION, duration.name).apply()
    }

    /**
     * Scans database and calculates all overdue customers categorized by duration
     */
    suspend fun getOverdueCustomers(context: Context): List<OverdueCustomerItem> = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val customers: List<CustomerEntity> = db.customerDao().getAllCustomers().first()
        val sessions: List<com.example.data.db.TubewellSessionEntity> = db.sessionDao().getAllSessions().first()
        val txns: List<com.example.data.db.TransactionEntity> = db.transactionDao().getAllTransactions().first()

        val now = System.currentTimeMillis()
        val overdueList = mutableListOf<OverdueCustomerItem>()

        for (customer in customers) {
            val cSessions = sessions.filter { it.customerId == customer.id }
            val cTxns = txns.filter { it.customerId == customer.id }

            val sessionBilled = cSessions.sumOf { it.totalAmount }
            val directPaid = cSessions.sumOf { it.paidAmount }
            val deposits = cTxns.sumOf { it.amountDeposited }

            val totalBilled = customer.initialBalance + sessionBilled
            val totalPaid = directPaid + deposits
            val netDue = (totalBilled - totalPaid).coerceAtLeast(0.0)

            if (netDue > 1.0) { // Has overdue balance
                // Find oldest unpaid session date or customer creation date
                val earliestDate = if (cSessions.isNotEmpty()) {
                    cSessions.minOf { it.sessionDate }
                } else {
                    customer.createdAt
                }

                val daysDiff = ((now - earliestDate) / (1000 * 60 * 60 * 24L)).toInt().coerceAtLeast(1)

                val category = when {
                    daysDiff >= 365 -> OverdueDuration.YEAR_1
                    daysDiff >= 180 -> OverdueDuration.MONTH_6
                    daysDiff >= 90 -> OverdueDuration.MONTH_3
                    daysDiff >= 60 -> OverdueDuration.MONTH_2
                    daysDiff >= 30 -> OverdueDuration.MONTH_1
                    daysDiff >= 15 -> OverdueDuration.DAYS_15
                    daysDiff >= 7 -> OverdueDuration.WEEK_1
                    else -> OverdueDuration.ALL
                }

                val formattedText = formatDaysDuration(daysDiff)

                overdueList.add(
                    OverdueCustomerItem(
                        customer = customer,
                        dueAmount = netDue,
                        oldestUnpaidDate = earliestDate,
                        daysOverdue = daysDiff,
                        durationCategory = category,
                        formattedDurationText = formattedText
                    )
                )
            }
        }

        // Sort by longest overdue first, then by largest due amount
        overdueList.sortedWith(compareByDescending<OverdueCustomerItem> { it.daysOverdue }.thenByDescending { it.dueAmount })
    }

    fun formatDaysDuration(days: Int): String {
        return when {
            days >= 365 -> {
                val years = days / 365
                val remainingMonths = (days % 365) / 30
                if (remainingMonths > 0) "$years साल $remainingMonths माह" else "$years साल"
            }
            days >= 180 -> {
                val months = days / 30
                "$months महीने"
            }
            days >= 30 -> {
                val months = days / 30
                val remainingDays = days % 30
                if (remainingDays > 0) "$months माह $remainingDays दिन" else "$months महीना"
            }
            days >= 7 -> {
                val weeks = days / 7
                val remainingDays = days % 7
                if (remainingDays > 0) "$weeks सप्ताह $remainingDays दिन" else "$weeks सप्ताह"
            }
            else -> "$days दिन"
        }
    }

    private const val KEY_LAST_ROTATION_INDEX = "last_notified_rotation_index"

    /**
     * Sends non-permanent dismissible notifications for overdue accounts to the tubewell owner's mobile.
     * Posts at most 1 to 2 customers per cycle so the notification bar stays clean and actionable.
     */
    suspend fun checkAndPostDueNotifications(
        context: Context,
        minDuration: OverdueDuration = getSelectedDuration(context),
        isManualTrigger: Boolean = false
    ): Int = withContext(Dispatchers.IO) {
        createNotificationChannel(context)

        val overdueItems = getOverdueCustomers(context)
        val filtered = if (minDuration == OverdueDuration.ALL) {
            overdueItems
        } else {
            overdueItems.filter { it.daysOverdue >= minDuration.minDays }
        }

        if (filtered.isEmpty()) {
            if (isManualTrigger) {
                // Post info notification that all dues are cleared
                postNoDuesNotification(context, minDuration)
            }
            return@withContext 0
        }

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // Select exactly 1 or 2 customers per batch using rotation so all farmers get notified turn-by-turn
        val lastIndex = prefs.getInt(KEY_LAST_ROTATION_INDEX, 0)
        val batchSize = if (filtered.size == 1) 1 else 2
        val selectedItems = mutableListOf<OverdueCustomerItem>()

        for (i in 0 until batchSize) {
            val idx = (lastIndex + i) % filtered.size
            selectedItems.add(filtered[idx])
        }

        // Post notifications for the selected 1 or 2 customers
        selectedItems.forEachIndexed { index, item ->
            val notifId = 8801 + index
            val notif = buildSingleCustomerDueNotification(context, item, notifId)
            notificationManager.notify(notifId, notif)
        }

        // Update rotation index for next trigger cycle (3-4 times a day)
        val nextIndex = (lastIndex + batchSize) % filtered.size
        prefs.edit()
            .putInt(KEY_LAST_ROTATION_INDEX, nextIndex)
            .putLong(KEY_LAST_CHECK_TS, System.currentTimeMillis())
            .apply()

        selectedItems.size
    }

    private fun buildSingleCustomerDueNotification(
        context: Context,
        item: OverdueCustomerItem,
        notificationId: Int
    ): android.app.Notification {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_CUSTOMER_ID", item.customer.id)
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // WhatsApp Reminder Action
        val whatsappIntent = createWhatsAppReminderIntent(item)
        val whatsappPendingIntent = PendingIntent.getActivity(
            context,
            notificationId + 100,
            whatsappIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val durationLabel = item.formattedDurationText
        val title = "⚠️ उधारी तकादा • ${item.customer.name} ($durationLabel पुराना)"
        val bodyText = "बकाया: ₹${item.dueAmount.toInt()} (${durationLabel} हो गया है)। तकादा करने हेतु टैप करें।"

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_pump)
            .setContentTitle(title)
            .setContentText(bodyText)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("👤 किसान: ${item.customer.name}\n💰 कुल बकाया राशि: ₹${item.dueAmount.toInt()}\n⏰ समय अवधि: ${item.formattedDurationText} हो गया है\n📱 मोबाइल: ${item.customer.phone.ifBlank { "उपलब्ध नहीं" }}")
                    .setSummaryText("डिजिटल बही-खाता • उधारी रिमाइंडर")
            )
            .setContentIntent(openAppPendingIntent)
            .setOngoing(false) // Strictly Non-Permanent / Dismissible
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setColor(0xFFD32F2F.toInt()) // Alert Red color
            .addAction(
                android.R.drawable.ic_menu_send,
                "📲 व्हाट्सएप तकादा भेजें",
                whatsappPendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_agenda,
                "📑 खाता देखें",
                openAppPendingIntent
            )
            .build()
    }

    private fun buildSummaryDueNotification(
        context: Context,
        items: List<OverdueCustomerItem>,
        duration: OverdueDuration
    ): android.app.Notification {
        val totalDue = items.sumOf { it.dueAmount }
        val count = items.size

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            SUMMARY_NOTIFICATION_ID,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val durationText = if (duration == OverdueDuration.ALL) "कुल" else duration.labelHindi
        val title = "⚠️ उधारी अलर्ट: $count किसानों का ₹${totalDue.toInt()} बकाया है ($durationText)"
        
        val bigTextBuilder = StringBuilder()
        bigTextBuilder.append("कुल $count किसानों का ₹${totalDue.toInt()} बकाया है:\n")
        items.take(5).forEach {
            bigTextBuilder.append("• ${it.customer.name}: ₹${it.dueAmount.toInt()} (${it.formattedDurationText} हो गया)\n")
        }
        if (items.size > 5) {
            bigTextBuilder.append("...और ${items.size - 5} अन्य किसान")
        }

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_pump)
            .setContentTitle(title)
            .setContentText("कुल $count किसानों का ₹${totalDue.toInt()} बकाया है। विवरण देखने हेतु टैप करें।")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(bigTextBuilder.toString())
                    .setSummaryText("उधारी तकादा रिपोर्ट")
            )
            .setContentIntent(openAppPendingIntent)
            .setOngoing(false) // Non-Permanent / Dismissible
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setColor(0xFFD32F2F.toInt())
            .addAction(
                android.R.drawable.ic_menu_view,
                "📊 खाता सूची खोलें",
                openAppPendingIntent
            )
            .build()
    }

    private fun postNoDuesNotification(context: Context, duration: OverdueDuration) {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            8899,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val durationLabel = if (duration == OverdueDuration.ALL) "सभी ग्राहकों" else "${duration.labelHindi} अवधि"
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_pump)
            .setContentTitle("✅ कोई उधारी बकाया नहीं!")
            .setContentText("$durationLabel में सभी किसानों का हिसाब चुकता है।")
            .setContentIntent(openAppPendingIntent)
            .setOngoing(false)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setColor(0xFF2E7D32.toInt())
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(8899, notification)
    }

    private fun createWhatsAppReminderIntent(item: OverdueCustomerItem): Intent {
        val phone = item.customer.phone.filter { it.isDigit() }
        val formattedPhone = if (phone.length == 10) "91$phone" else phone

        val message = "नमस्ते ${item.customer.name} जी, आपके ट्यूबवेल सिंचाई का कुल बकाया ₹${item.dueAmount.toInt()} है (${item.formattedDurationText} से)। कृपया समय पर हिसाब चुकता करके सहयोग करें। धन्यवाद! - डिजिटल बही-खाता"
        val encodedMessage = URLEncoder.encode(message, "UTF-8")

        val uri = if (formattedPhone.isNotBlank()) {
            Uri.parse("https://wa.me/$formattedPhone?text=$encodedMessage")
        } else {
            Uri.parse("https://wa.me/?text=$encodedMessage")
        }

        return Intent(Intent.ACTION_VIEW, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "उधारी तकादा एवं रिमाइंडर (Due Reminders)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ग्राहकों के 1 सप्ताह, 1 महीना, 6 महीने, 1 साल पुराने बकाए के तकादा नोटिफिकेशन (हटाने योग्य / Dismissible)"
                setShowBadge(true)
                enableVibration(true)
                enableLights(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
