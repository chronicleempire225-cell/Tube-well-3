package com.example.data.localization

enum class AppLanguage(val code: String, val nativeName: String, val englishName: String, val region: String) {
    HINDI("hi", "हिंदी", "Hindi", "भारत (India)"),
    ENGLISH("en", "English", "English", "International"),
    PUNJABI("pa", "ਪੰਜਾਬੀ", "Punjabi", "ਪੰਜਾਬ (Punjab)"),
    GUJARATI("gu", "ગુજરાતી", "Gujarati", "ગુજરાત (Gujarat)"),
    MARATHI("mr", "मराठी", "Marathi", "महाराष्ट्र (Maharashtra)"),
    BENGALI("bn", "বাংলা", "Bengali", "পশ্চিমবঙ্গ (Bengal)"),
    TELUGU("te", "తెలుగు", "Telugu", "ఆంధ్ర / తెలంగాణ"),
    TAMIL("ta", "தமிழ்", "Tamil", "தமிழ்நாடு (Tamil Nadu)"),
    KANNADA("kn", "ಕನ್ನಡ", "Kannada", "ಕರ್ನಾಟಕ (Karnataka)"),
    URDU("ur", "اردو", "Urdu", "پاکستان / بھارت"),
    SPANISH("es", "Español", "Spanish", "América Latina / España"),
    ARABIC("ar", "العربية", "Arabic", "الشرق الأوسط")
}

object LanguageManager {
    fun getString(key: String, language: AppLanguage): String {
        val map = STRINGS[key] ?: return key
        return map[language] ?: map[AppLanguage.HINDI] ?: map[AppLanguage.ENGLISH] ?: key
    }

    private val STRINGS: Map<String, Map<AppLanguage, String>> = mapOf(
        "app_title" to mapOf(
            AppLanguage.HINDI to "डिजिटल बही-खाता",
            AppLanguage.ENGLISH to "Digital Bahi-Khata",
            AppLanguage.PUNJABI to "ਡਿਜੀਟਲ ਬਹੀ-ਖਾਤਾ",
            AppLanguage.GUJARATI to "ડિજિટલ બહી-ખાતા",
            AppLanguage.MARATHI to "डिजिटल वही-खाते",
            AppLanguage.BENGALI to "ডিজিটাল খাতা",
            AppLanguage.TELUGU to "డిజిటల్ బహి-ఖాతా",
            AppLanguage.TAMIL to "டிஜிட்டல் கணக்கு புத்தகம்",
            AppLanguage.KANNADA to "ಡಿಜಿಟಲ್ ಬಹಿ-ಖಾತಾ",
            AppLanguage.URDU to "ڈیجیٹل بہی کھاتہ",
            AppLanguage.SPANISH to "Libro Contable Digital",
            AppLanguage.ARABIC to "دفتر الحسابات الرقمي"
        ),
        "splash_slogan" to mapOf(
            AppLanguage.HINDI to "जय जवान, जय किसान",
            AppLanguage.ENGLISH to "Jai Jawan, Jai Kisan",
            AppLanguage.PUNJABI to "ਜੈ ਜਵਾਨ, ਜੈ ਕਿਸਾਨ",
            AppLanguage.GUJARATI to "જય જવાન, જય કિસાન",
            AppLanguage.MARATHI to "जय जवान, जय किसान",
            AppLanguage.BENGALI to "জয় জওয়ান, জয় কিষান",
            AppLanguage.TELUGU to "జై జవాన్, జై కిసాన్",
            AppLanguage.TAMIL to "ஜெய் ஜவான், ஜெய் கிசான்",
            AppLanguage.KANNADA to "ಜೈ ಜವಾನ್, ಜೈ ಕಿಸಾನ್",
            AppLanguage.URDU to "جے جوان، جے کسان",
            AppLanguage.SPANISH to "Honor al Agricultor",
            AppLanguage.ARABIC to "تحية للمزارع والفلاح"
        ),
        "splash_subtext" to mapOf(
            AppLanguage.HINDI to "अब ट्यूबवेल हिसाब करना हुआ बेहद आसान!",
            AppLanguage.ENGLISH to "Now Tubewell & Irrigation accounting made super easy!",
            AppLanguage.PUNJABI to "ਹੁਣ ਟਿਊਬਵੈੱਲ ਹਿਸਾਬ ਕਰਨਾ ਹੋਇਆ ਆਸਾਨ!",
            AppLanguage.GUJARATI to "હવે ટ્યુબવેલ હિસાબ કરવો થયો સરળ!",
            AppLanguage.MARATHI to "आता कूपनलिका हिशोब झाला अतिशय सोपा!",
            AppLanguage.BENGALI to "এখন টিউবওয়েল হিসাব করা আরও সহজ!",
            AppLanguage.TELUGU to "ఇప్పుడు బోరుబావి లెక్కలు చాలా సులభం!",
            AppLanguage.TAMIL to "இப்போது பாசன கணக்கு மிகவும் எளிது!",
            AppLanguage.KANNADA to "ಈಗ ಕೊಳವೆಬಾವಿ ಲೆಕ್ಕಾಚಾರ ತುಂಬಾ ಸುಲಭ!",
            AppLanguage.URDU to "اب ٹیوب ویل کا حساب رکھنا ہوا انتہائی آسان!",
            AppLanguage.SPANISH to "¡Gestión de riego y bombeo fácil y rápida!",
            AppLanguage.ARABIC to "حسابات الري وتشغيل الآبار أصبحت أسهل بكثير!"
        ),
        "choose_language" to mapOf(
            AppLanguage.HINDI to "भाषा चुनें / Choose Language",
            AppLanguage.ENGLISH to "Choose Language / भाषा चुनें",
            AppLanguage.PUNJABI to "ਭਾਸ਼ਾ ਚੁਣੋ / Choose Language",
            AppLanguage.GUJARATI to "ભાષા પસંદ કરો / Choose Language",
            AppLanguage.MARATHI to "भाषा निवडा / Choose Language",
            AppLanguage.BENGALI to "ভাষা নির্বাচন করুন / Choose Language",
            AppLanguage.TELUGU to "భాషను ఎంచుకోండి / Choose Language",
            AppLanguage.TAMIL to "மொழியைத் தேர்ந்தெடுக்கவும் / Choose Language",
            AppLanguage.KANNADA to "ಭಾಷೆಯನ್ನು ಆರಿಸಿ / Choose Language",
            AppLanguage.URDU to "زبان منتخب کریں / Choose Language",
            AppLanguage.SPANISH to "Seleccionar Idioma / Choose Language",
            AppLanguage.ARABIC to "اختر اللغة / Choose Language"
        ),
        "continue_btn" to mapOf(
            AppLanguage.HINDI to "आगे बढ़ें →",
            AppLanguage.ENGLISH to "Continue →",
            AppLanguage.PUNJABI to "ਅੱਗੇ ਵਧੋ →",
            AppLanguage.GUJARATI to "આગળ વધો →",
            AppLanguage.MARATHI to "पुढे जा →",
            AppLanguage.BENGALI to "এগিয়ে যান →",
            AppLanguage.TELUGU to "ముందుకు సాగండి →",
            AppLanguage.TAMIL to "தொடரவும் →",
            AppLanguage.KANNADA to "ಮುಂದುವರಿಯಿರಿ →",
            AppLanguage.URDU to "آگے بڑھیں →",
            AppLanguage.SPANISH to "Continuar →",
            AppLanguage.ARABIC to "متابعة ←"
        ),
        "auth_welcome_title" to mapOf(
            AppLanguage.HINDI to "किसान बही-खाता में आपका स्वागत है",
            AppLanguage.ENGLISH to "Welcome to Digital Bahi-Khata",
            AppLanguage.PUNJABI to "ਕਿਸਾਨ ਬਹੀ-ਖਾਤਾ ਵਿੱਚ ਜੀ ਆਇਆਂ ਨੂੰ",
            AppLanguage.GUJARATI to "કિસાન બહી-ખાતા માં આપનું સ્વાગત છે",
            AppLanguage.MARATHI to "शेतकरी वही-खात्यामध्ये आपले स्वागत आहे",
            AppLanguage.BENGALI to "কৃষক খাতা অ্যাপে স্বাগতম",
            AppLanguage.TELUGU to "రైతు బహి-ఖాతాకు స్వాగతం",
            AppLanguage.TAMIL to "விவசாய கணக்கு ஏட்டிற்கு நல்வரவு",
            AppLanguage.KANNADA to "ರೈತ ಬಹಿ-ಖಾತಾಗೆ ಸುಸ್ವಾಗತ",
            AppLanguage.URDU to "کسان بہی کھاتہ میں خوش آمدید",
            AppLanguage.SPANISH to "Bienvenido al Gestor de Riego",
            AppLanguage.ARABIC to "مرحباً بك في دفتر حسابات الري"
        ),
        "auth_welcome_subtitle" to mapOf(
            AppLanguage.HINDI to "ट्यूबवेल और पानी किराये का 100% सटीक और सुरक्षित हिसाब रखें",
            AppLanguage.ENGLISH to "Manage your Tubewell & irrigation rentals with 100% accuracy offline",
            AppLanguage.PUNJABI to "ਟਿਊਬਵੈੱਲ ਅਤੇ ਪਾਣੀ ਕਿਰਾਏ ਦਾ ਸਹੀ ਹਿਸਾਬ ਰੱਖੋ",
            AppLanguage.GUJARATI to "ટ્યુબવેલ અને પાણી ભાડાનો સચોટ હિસાબ રાખો",
            AppLanguage.MARATHI to "कूपनलिका आणि पाणी भाड्याचा अचूक हिशोब ठेवा",
            AppLanguage.BENGALI to "টিউবওয়েল ও সেচ ভাড়ার সঠিক হিসাব রাখুন",
            AppLanguage.TELUGU to "బోరుబావి మరియు నీటి అద్దె ఖచ్చితమైన లెక్కలు ఉంచండి",
            AppLanguage.TAMIL to "பாசன நீர் வாடகையை துல்லியமாக பதிவு செய்யுங்கள்",
            AppLanguage.KANNADA to "ಕೊಳವೆಬಾವಿ ಬಾಡಿಗೆಯ ನಿಖರ ಲೆಕ್ಕ ನಿರ್ವಹಿಸಿ",
            AppLanguage.URDU to "ٹیوب ویل اور پانی کے کرائے کا مکمل محفوظ حساب رکھیں",
            AppLanguage.SPANISH to "Gestione el alquiler y horas de bombeo sin conexión",
            AppLanguage.ARABIC to "إدارة ساعات الضخ وتأجير الآبار والمدفوعات بدون إنترنت"
        ),
        "create_new_account" to mapOf(
            AppLanguage.HINDI to "नया खाता बनाएं",
            AppLanguage.ENGLISH to "Create New Account",
            AppLanguage.PUNJABI to "ਨਵਾਂ ਖਾਤਾ ਬਣਾਓ",
            AppLanguage.GUJARATI to "નવું ખાતું બનાવો",
            AppLanguage.MARATHI to "नवीन खाते तयार करा",
            AppLanguage.BENGALI to "নতুন একাউন্ট তৈরি করুন",
            AppLanguage.TELUGU to "కొత్త ఖాతాను సృష్టించండి",
            AppLanguage.TAMIL to "புதிய கணக்கை உருவாக்கவும்",
            AppLanguage.KANNADA to "ಹೊಸ ಖಾತೆ ತೆರೆಯಿರಿ",
            AppLanguage.URDU to "نیا اکاؤنٹ بنائیں",
            AppLanguage.SPANISH to "Crear Nueva Cuenta",
            AppLanguage.ARABIC to "إنشاء حساب جديد"
        ),
        "already_have_account" to mapOf(
            AppLanguage.HINDI to "मेरे पास पहले से खाता है (लॉग इन)",
            AppLanguage.ENGLISH to "I already have an account (Login)",
            AppLanguage.PUNJABI to "ਮੇਰੇ ਕੋਲ ਪਹਿਲਾਂ ਤੋਂ ਖਾਤਾ ਹੈ (ਲਾਗਇਨ)",
            AppLanguage.GUJARATI to "મારી પાસે પહેલેથી ખાતું છે (લૉગિન)",
            AppLanguage.MARATHI to "माझं आधीच खाते आहे (लॉग इन)",
            AppLanguage.BENGALI to "আমার ইতিমধ্যে একাউন্ট আছে (লগইন)",
            AppLanguage.TELUGU to "నాకు ఇప్పటికే ఖాతా ఉంది (లాగిన్)",
            AppLanguage.TAMIL to "ஏற்கனவே கணக்கு உள்ளது (உள்நுழையவும்)",
            AppLanguage.KANNADA to "ನನಗೆ ಈಗಾಗಲೇ ಖಾತೆ ಇದೆ (ಲಾಗಿನ್)",
            AppLanguage.URDU to "میرے پاس پہلے سے اکاؤنٹ ہے (لاگ ان)",
            AppLanguage.SPANISH to "Ya tengo una cuenta (Iniciar sesión)",
            AppLanguage.ARABIC to "لدي حساب بالفعل (تسجيل الدخول)"
        ),
        "owner_name" to mapOf(
            AppLanguage.HINDI to "मालिक का नाम (Owner Name)",
            AppLanguage.ENGLISH to "Owner Name",
            AppLanguage.PUNJABI to "ਮਾਲਕ ਦਾ ਨਾਮ",
            AppLanguage.GUJARATI to "માલિકનું નામ",
            AppLanguage.MARATHI to "मालकाचे नाव",
            AppLanguage.BENGALI to "মালিকের নাম",
            AppLanguage.TELUGU to "యజమాని పేరు",
            AppLanguage.TAMIL to "உரிமையாளர் பெயர்",
            AppLanguage.KANNADA to "ಮಾಲೀಕರ ಹೆಸರು",
            AppLanguage.URDU to "مالک کا نام",
            AppLanguage.SPANISH to "Nombre del Propietario",
            AppLanguage.ARABIC to "اسم المالك"
        ),
        "agency_name" to mapOf(
            AppLanguage.HINDI to "ट्यूबवेल / फार्म / दुकान का नाम",
            AppLanguage.ENGLISH to "Tubewell / Farm / Agency Name",
            AppLanguage.PUNJABI to "ਟਿਊਬਵੈੱਲ / ਫਾਰਮ ਦਾ ਨਾਮ",
            AppLanguage.GUJARATI to "ટ્યુબવેલ / ફાર્મનું નામ",
            AppLanguage.MARATHI to "कूपनलिका / शेतीचे नाव",
            AppLanguage.BENGALI to "টিউবওয়েল / খামারের নাম",
            AppLanguage.TELUGU to "బోరుబావి / ఫారం పేరు",
            AppLanguage.TAMIL to "பண்ணை / பாசன நிலைய பெயர்",
            AppLanguage.KANNADA to "ಕೊಳವೆಬಾವಿ / ಕೃಷಿ ಜಮೀನಿನ ಹೆಸರು",
            AppLanguage.URDU to "ٹیوب ویل / فارم کا نام",
            AppLanguage.SPANISH to "Nombre del Pozo / Finca",
            AppLanguage.ARABIC to "اسم البئر / المزرعة"
        ),
        "mobile_number" to mapOf(
            AppLanguage.HINDI to "मोबाइल नंबर (Mobile No.)",
            AppLanguage.ENGLISH to "Mobile Number",
            AppLanguage.PUNJABI to "ਮੋਬਾਈਲ ਨੰਬਰ",
            AppLanguage.GUJARATI to "મોબાઇલ નંબર",
            AppLanguage.MARATHI to "मोबाईल नंबर",
            AppLanguage.BENGALI to "মোবাইল নম্বর",
            AppLanguage.TELUGU to "మొబైల్ నంబర్",
            AppLanguage.TAMIL to "கைபேசி எண்",
            AppLanguage.KANNADA to "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ",
            AppLanguage.URDU to "موبائل نمبر",
            AppLanguage.SPANISH to "Número de Teléfono",
            AppLanguage.ARABIC to "رقم الهاتف المحمول"
        ),
        "create_pin" to mapOf(
            AppLanguage.HINDI to "4-अंकों का सुरक्षा पिन बनाएं",
            AppLanguage.ENGLISH to "Create 4-Digit Security PIN",
            AppLanguage.PUNJABI to "4-ਅੰਕਾਂ ਦਾ ਸੁਰੱਖਿਆ ਪਿੰਨ ਬਣਾਓ",
            AppLanguage.GUJARATI to "4-અંકનો સુરક્ષા પિન બનાવો",
            AppLanguage.MARATHI to "4-अंकी सुरक्षा पिन तयार करा",
            AppLanguage.BENGALI to "৪-সংখ্যার সুরক্ষা পিন তৈরি করুন",
            AppLanguage.TELUGU to "4-అంకెల సెక్యూరిటీ పిన్ సృష్టించండి",
            AppLanguage.TAMIL to "4-இலக்க பாதுகாப்பு பின்னை உருவாக்கவும்",
            AppLanguage.KANNADA to "4-ಅಂಕಿಯ ಭದ್ರತಾ ಪಿನ್ ರಚಿಸಿ",
            AppLanguage.URDU to "4 ہندسوں کا سیکیورٹی پن بنائیں",
            AppLanguage.SPANISH to "Crear PIN de 4 dígitos",
            AppLanguage.ARABIC to "إنشاء رمز PIN مكون من 4 أرقام"
        ),
        "confirm_pin" to mapOf(
            AppLanguage.HINDI to "पिन दोबारा दर्ज करें (Confirm PIN)",
            AppLanguage.ENGLISH to "Confirm 4-Digit PIN",
            AppLanguage.PUNJABI to "ਪਿੰਨ ਦੁਬਾਰਾ ਦਰਜ ਕਰੋ",
            AppLanguage.GUJARATI to "પિન ફરીથી દાખલ કરો",
            AppLanguage.MARATHI to "पिन पुन्हा प्रविष्ट करा",
            AppLanguage.BENGALI to "পিন পুনরায় লিখুন",
            AppLanguage.TELUGU to "పిన్‌ను నిర్ధారించండి",
            AppLanguage.TAMIL to "பின்னை மீண்டும் உள்ளிடவும்",
            AppLanguage.KANNADA to "ಪಿನ್ ಅನ್ನು ದೃಢೀಕರಿಸಿ",
            AppLanguage.URDU to "پن دوبارہ درج کریں",
            AppLanguage.SPANISH to "Confirmar PIN",
            AppLanguage.ARABIC to "تأكيد رمز PIN"
        ),
        "default_rate" to mapOf(
            AppLanguage.HINDI to "डिफ़ॉल्ट दर (₹ प्रति घंटा)",
            AppLanguage.ENGLISH to "Default Rate (₹ per hour)",
            AppLanguage.PUNJABI to "ਡਿਫੌਲਟ ਰੇਟ (₹ ਪ੍ਰਤੀ ਘੰਟਾ)",
            AppLanguage.GUJARATI to "ડિફૉલ્ટ દર (₹ પ્રતિ કલાક)",
            AppLanguage.MARATHI to "मूळ दर (₹ प्रति तास)",
            AppLanguage.BENGALI to "ডিফল্ট রেট (₹ প্রতি ঘণ্টা)",
            AppLanguage.TELUGU to "డిఫాల్ట్ రేటు (₹ గంటకు)",
            AppLanguage.TAMIL to "வழக்கமான கட்டணம் (₹ மணிக்கு)",
            AppLanguage.KANNADA to "ಸಾಮಾನ್ಯ ದರ (₹ ಗಂಟೆಗೆ)",
            AppLanguage.URDU to "پہلے سے طے شدہ ریٹ (₹ فی گھنٹہ)",
            AppLanguage.SPANISH to "Tarifa Predeterminada ($/hora)",
            AppLanguage.ARABIC to "السعر الافتراضي (لكل ساعة)"
        ),
        "login_screen_title" to mapOf(
            AppLanguage.HINDI to "खाते में लॉग इन करें",
            AppLanguage.ENGLISH to "Login to Account",
            AppLanguage.PUNJABI to "ਖਾਤੇ ਵਿੱਚ ਲੌਗਇਨ ਕਰੋ",
            AppLanguage.GUJARATI to "ખાતામાં લૉગિન કરો",
            AppLanguage.MARATHI to "खात्यात लॉग इन करा",
            AppLanguage.BENGALI to "একাউন্টে লগইন করুন",
            AppLanguage.TELUGU to "ఖాతాలోకి లాగిన్ అవ్వండి",
            AppLanguage.TAMIL to "கணக்கில் உள்நுழையவும்",
            AppLanguage.KANNADA to "ಖಾತೆಗೆ ಲಾಗಿನ್ ಮಾಡಿ",
            AppLanguage.URDU to "اکاؤنٹ میں لاگ ان کریں",
            AppLanguage.SPANISH to "Iniciar Sesión",
            AppLanguage.ARABIC to "تسجيل الدخول إلى الحساب"
        ),
        "login_screen_subtitle" to mapOf(
            AppLanguage.HINDI to "अपना 10 अंकों का मोबाइल नंबर और पासवर्ड / पिन दर्ज करें",
            AppLanguage.ENGLISH to "Enter your 10-digit mobile number and password / PIN",
            AppLanguage.PUNJABI to "ਆਪਣਾ 10 ਅੰਕਾਂ ਦਾ ਮੋਬਾਈਲ ਨੰਬਰ ਅਤੇ ਪਾਸਵਰਡ / ਪਿੰਨ ਦਰਜ ਕਰੋ",
            AppLanguage.GUJARATI to "તમારો 10 અંકનો મોબાઇલ નંબર અને પાસવર્ડ / પિન દાખલ કરો",
            AppLanguage.MARATHI to "तुमचा 10 अंकी मोबाईल नंबर आणि पासवर्ड / पिन प्रविष्ट करा",
            AppLanguage.BENGALI to "আপনার ১০ সংখ্যার মোবাইল নম্বর এবং পাসওয়ার্ড / পিন লিখুন",
            AppLanguage.TELUGU to "మీ 10 అంకెల మొబైల్ నంబర్ మరియు పాస్‌వర్డ్ / పిన్ నమోదు చేయండి",
            AppLanguage.TAMIL to "உங்கள் 10 இலக்க மொபைல் எண் மற்றும் கடவுச்சொல் / பின் உள்ளிடவும்",
            AppLanguage.KANNADA to "ನಿಮ್ಮ 10 ಅಂಕಿಯ ಮೊಬೈಲ್ ಸಂಖ್ಯೆ ಮತ್ತು ಪಾಸ್‌ವರ್ಡ್ / ಪಿನ್ ನಮೂದಿಸಿ",
            AppLanguage.URDU to "اپنا 10 ہندسوں کا موبائل نمبر اور پاس ورڈ / پن درج کریں",
            AppLanguage.SPANISH to "Ingrese su número de 10 dígitos y contraseña / PIN",
            AppLanguage.ARABIC to "أدخل رقم هاتفك المكون من 10 أرقام وكلمة المرور / PIN"
        ),
        "password_or_pin_label" to mapOf(
            AppLanguage.HINDI to "पासवर्ड या सुरक्षा पिन (Password / PIN)",
            AppLanguage.ENGLISH to "Password or Security PIN",
            AppLanguage.PUNJABI to "ਪਾਸਵਰਡ ਜਾਂ ਸੁਰੱਖਿਆ ਪਿੰਨ",
            AppLanguage.GUJARATI to "પાસવર્ડ અથવા સુરક્ષા પિન",
            AppLanguage.MARATHI to "पासवर्ड किंवा सुरक्षा पिन",
            AppLanguage.BENGALI to "পাসওয়ার্ড বা সুরক্ষা পিন",
            AppLanguage.TELUGU to "పాస్‌వర్డ్ లేదా సెక్యూరిటీ పిన్",
            AppLanguage.TAMIL to "கடவுச்சொல் அல்லது பாதுகாப்பு பின்",
            AppLanguage.KANNADA to "ಪಾಸ್‌ವರ್ಡ್ ಅಥವಾ ಭದ್ರತಾ ಪಿನ್",
            AppLanguage.URDU to "پاس ورڈ یا سیکیورٹی پن",
            AppLanguage.SPANISH to "Contraseña o PIN de Seguridad",
            AppLanguage.ARABIC to "كلمة المرور أو رمز PIN"
        ),
        "login_action_button" to mapOf(
            AppLanguage.HINDI to "लॉग इन करें →",
            AppLanguage.ENGLISH to "Login →",
            AppLanguage.PUNJABI to "ਲਾਗਇਨ ਕਰੋ →",
            AppLanguage.GUJARATI to "લૉગિન કરો →",
            AppLanguage.MARATHI to "लॉग इन करा →",
            AppLanguage.BENGALI to "লগইন করুন →",
            AppLanguage.TELUGU to "లాగిన్ అవ్వండి →",
            AppLanguage.TAMIL to "உள்நுழைக →",
            AppLanguage.KANNADA to "ಲಾಗಿನ್ ಮಾಡಿ →",
            AppLanguage.URDU to "لاگ ان کریں →",
            AppLanguage.SPANISH to "Iniciar Sesión →",
            AppLanguage.ARABIC to "دخول ←"
        ),
        "nav_home" to mapOf(
            AppLanguage.HINDI to "होम",
            AppLanguage.ENGLISH to "Home",
            AppLanguage.PUNJABI to "ਹੋਮ",
            AppLanguage.GUJARATI to "હોમ",
            AppLanguage.MARATHI to "होम",
            AppLanguage.BENGALI to "হোম",
            AppLanguage.TELUGU to "హోమ్",
            AppLanguage.TAMIL to "முகப்பு",
            AppLanguage.KANNADA to "ಮುಖಪುಟ",
            AppLanguage.URDU to "ہوم",
            AppLanguage.SPANISH to "Inicio",
            AppLanguage.ARABIC to "الرئيسية"
        ),
        "nav_customers" to mapOf(
            AppLanguage.HINDI to "ग्राहक सूची",
            AppLanguage.ENGLISH to "Customers",
            AppLanguage.PUNJABI to "ਗਾਹਕ",
            AppLanguage.GUJARATI to "ગ્રાહકો",
            AppLanguage.MARATHI to "ग्राहक",
            AppLanguage.BENGALI to "গ্রাহক",
            AppLanguage.TELUGU to "రైతులు",
            AppLanguage.TAMIL to "வாடிக்கையாளர்",
            AppLanguage.KANNADA to "ಗ್ರಾಹಕರು",
            AppLanguage.URDU to "کسٹمرز",
            AppLanguage.SPANISH to "Clientes",
            AppLanguage.ARABIC to "العملاء"
        ),
        "nav_reports" to mapOf(
            AppLanguage.HINDI to "रिपोर्ट्स",
            AppLanguage.ENGLISH to "Reports",
            AppLanguage.PUNJABI to "ਰਿਪੋਰਟਾਂ",
            AppLanguage.GUJARATI to "રિપોર્ટ્સ",
            AppLanguage.MARATHI to "अहवाल",
            AppLanguage.BENGALI to "রিপোর্ট",
            AppLanguage.TELUGU to "నివేదికలు",
            AppLanguage.TAMIL to "அறிக்கைகள்",
            AppLanguage.KANNADA to "ವರದಿಗಳು",
            AppLanguage.URDU to "رپورٹس",
            AppLanguage.SPANISH to "Informes",
            AppLanguage.ARABIC to "التقارير"
        ),
        "nav_settings" to mapOf(
            AppLanguage.HINDI to "सेटिंग्स",
            AppLanguage.ENGLISH to "Settings",
            AppLanguage.PUNJABI to "ਸੈਟਿੰਗਾਂ",
            AppLanguage.GUJARATI to "સેટિંગ્સ",
            AppLanguage.MARATHI to "सेटिंग्ज",
            AppLanguage.BENGALI to "সেটিংস",
            AppLanguage.TELUGU to "సెట్టింగ్‌లు",
            AppLanguage.TAMIL to "அமைப்புகள்",
            AppLanguage.KANNADA to "ಸೆಟ್ಟಿಂಗ್ಸ್",
            AppLanguage.URDU to "سیٹنگز",
            AppLanguage.SPANISH to "Ajustes",
            AppLanguage.ARABIC to "الإعدادات"
        ),
        "quick_session_entry" to mapOf(
            AppLanguage.HINDI to "⚡ नया ट्यूबवेल एंट्री दर्ज करें",
            AppLanguage.ENGLISH to "⚡ Quick Tubewell Session Entry",
            AppLanguage.PUNJABI to "⚡ ਨਵੀਂ ਐਂਟਰੀ ਦਰਜ ਕਰੋ",
            AppLanguage.GUJARATI to "⚡ નવી એન્ટ્રી નોંધો",
            AppLanguage.MARATHI to "⚡ नवीन नोंद करा",
            AppLanguage.BENGALI to "⚡ নতুন এন্ট্রি যোগ করুন",
            AppLanguage.TELUGU to "⚡ కొత్త ఎంట్రీ నమోదు చేయండి",
            AppLanguage.TAMIL to "⚡ புதிய பதிவு சேர்க்கவும்",
            AppLanguage.KANNADA to "⚡ ಹೊಸ ನಮೂದು ದಾಖಲಿಸಿ",
            AppLanguage.URDU to "⚡ نیا سیشن درج کریں",
            AppLanguage.SPANISH to "⚡ Registrar Sesión de Riego",
            AppLanguage.ARABIC to "⚡ تسجيل جلسة ضخ جديدة"
        ),
        "select_customer" to mapOf(
            AppLanguage.HINDI to "किसान / ग्राहक चुनें",
            AppLanguage.ENGLISH to "Select Farmer / Customer",
            AppLanguage.PUNJABI to "ਕਿਸਾਨ ਚੁਣੋ",
            AppLanguage.GUJARATI to "ખેડૂત પસંદ કરો",
            AppLanguage.MARATHI to "शेतकरी निवडा",
            AppLanguage.BENGALI to "কৃষক নির্বাচন করুন",
            AppLanguage.TELUGU to "రైతును ఎంచుకోండి",
            AppLanguage.TAMIL to "விவசாயியை தேர்வு செய்யவும்",
            AppLanguage.KANNADA to "ರೈತರನ್ನು ಆಯ್ಕೆಮಾಡಿ",
            AppLanguage.URDU to "کسان منتخب کریں",
            AppLanguage.SPANISH to "Seleccionar Agricultor",
            AppLanguage.ARABIC to "اختر المزارع"
        ),
        "search_customer_placeholder" to mapOf(
            AppLanguage.HINDI to "नाम या मोबाइल नंबर से खोजें (हिंदी / Eng)...",
            AppLanguage.ENGLISH to "Search by Name or Mobile No...",
            AppLanguage.PUNJABI to "ਨਾਮ ਜਾਂ ਫੋਨ ਨਾਲ ਖੋਜੋ...",
            AppLanguage.GUJARATI to "નામ અથવા નંબર શોધો...",
            AppLanguage.MARATHI to "नाव किंवा फोन नंबर शोधा...",
            AppLanguage.BENGALI to "নাম বা মোবাইল দিয়ে খুঁজুন...",
            AppLanguage.TELUGU to "పేరు లేదా నంబర్ ద్వారా శోధించండి...",
            AppLanguage.TAMIL to "பெயர் அல்லது எண்ணை தேடவும்...",
            AppLanguage.KANNADA to "ಹೆಸರು ಅಥವಾ ಮೊಬೈಲ್ ಮೂಲಕ ಹುಡುಕಿ...",
            AppLanguage.URDU to "نام یا فون نمبر سے تلاش کریں...",
            AppLanguage.SPANISH to "Buscar por nombre o móvil...",
            AppLanguage.ARABIC to "البحث بالاسم أو رقم الجوال..."
        ),
        "hours_count" to mapOf(
            AppLanguage.HINDI to "कुल घंटे (Hours)",
            AppLanguage.ENGLISH to "Total Hours",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਘੰਟੇ",
            AppLanguage.GUJARATI to "કુલ કલાકો",
            AppLanguage.MARATHI to "एकूण तास",
            AppLanguage.BENGALI to "মোট ঘণ্টা",
            AppLanguage.TELUGU to "మొత్తం గంటలు",
            AppLanguage.TAMIL to "மொத்த மணிநேரம்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಗಂಟೆಗಳು",
            AppLanguage.URDU to "کل گھنٹے",
            AppLanguage.SPANISH to "Horas Totales",
            AppLanguage.ARABIC to "إجمالي الساعات"
        ),
        "rate_per_hr" to mapOf(
            AppLanguage.HINDI to "दर (₹ प्रति घंटा)",
            AppLanguage.ENGLISH to "Rate (₹/hr)",
            AppLanguage.PUNJABI to "ਰੇਟ (₹/ਘੰਟਾ)",
            AppLanguage.GUJARATI to "દર (₹/કલાક)",
            AppLanguage.MARATHI to "दर (₹/तास)",
            AppLanguage.BENGALI to "রেট (₹/ঘণ্টা)",
            AppLanguage.TELUGU to "రేటు (₹/గంట)",
            AppLanguage.TAMIL to "கட்டணம் (₹/மணி)",
            AppLanguage.KANNADA to "ದರ (₹/ಗಂಟೆ)",
            AppLanguage.URDU to "ریٹ (₹ فی گھنٹہ)",
            AppLanguage.SPANISH to "Tarifa ($/h)",
            AppLanguage.ARABIC to "السعر (لكل ساعة)"
        ),
        "total_amount" to mapOf(
            AppLanguage.HINDI to "कुल रकम (Total Amount)",
            AppLanguage.ENGLISH to "Total Amount",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਰਕਮ",
            AppLanguage.GUJARATI to "કુલ રકમ",
            AppLanguage.MARATHI to "एकूण रक्कम",
            AppLanguage.BENGALI to "মোট টাকা",
            AppLanguage.TELUGU to "మొత్తం మొత్తం",
            AppLanguage.TAMIL to "மொத்த தொகை",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಮೊತ್ತ",
            AppLanguage.URDU to "کل رقم",
            AppLanguage.SPANISH to "Monto Total",
            AppLanguage.ARABIC to "المبلغ الإجمالي"
        ),
        "paid_amount" to mapOf(
            AppLanguage.HINDI to "नकद जमा (Paid Amount)",
            AppLanguage.ENGLISH to "Paid Amount",
            AppLanguage.PUNJABI to "ਜਮ੍ਹਾ ਰਕਮ",
            AppLanguage.GUJARATI to "જમા રકમ",
            AppLanguage.MARATHI to "जमा रक्कम",
            AppLanguage.BENGALI to "জমা দেওয়া টাকা",
            AppLanguage.TELUGU to "చెల్లించిన మొత్తం",
            AppLanguage.TAMIL to "செலுத்திய தொகை",
            AppLanguage.KANNADA to "ಪಾವತಿಸಿದ ಮೊತ್ತ",
            AppLanguage.URDU to "وصول رقم",
            AppLanguage.SPANISH to "Monto Pagado",
            AppLanguage.ARABIC to "المبلغ المدفوع"
        ),
        "due_amount" to mapOf(
            AppLanguage.HINDI to "बाकी रकम (Balance Due)",
            AppLanguage.ENGLISH to "Balance Due",
            AppLanguage.PUNJABI to "ਬਾਕੀ ਰਕਮ",
            AppLanguage.GUJARATI to "બાકી રકમ",
            AppLanguage.MARATHI to "बाकी रक्कम",
            AppLanguage.BENGALI to "বাকি টাকা",
            AppLanguage.TELUGU to "మిగిలిన బకాయి",
            AppLanguage.TAMIL to "நிலுவைத் தொகை",
            AppLanguage.KANNADA to "ಬಾಕಿ ಮೊತ್ತ",
            AppLanguage.URDU to "باقی واجب الادا",
            AppLanguage.SPANISH to "Saldo Pendiente",
            AppLanguage.ARABIC to "المبلغ المتبقي"
        ),
        "save_session" to mapOf(
            AppLanguage.HINDI to "खाते में दर्ज करें (Save Entry)",
            AppLanguage.ENGLISH to "Save Session Entry",
            AppLanguage.PUNJABI to "ਐਂਟਰੀ ਸੇਵ ਕਰੋ",
            AppLanguage.GUJARATI to "એન્ટ્રી સેવ કરો",
            AppLanguage.MARATHI to "नोंद सेव्ह करा",
            AppLanguage.BENGALI to "এন্ট্রি সংরক্ষণ করুন",
            AppLanguage.TELUGU to "ఎంట్రీ సేవ్ చేయండి",
            AppLanguage.TAMIL to "பதிவை சேமிக்கவும்",
            AppLanguage.KANNADA to "ನಮೂದನ್ನು ಉಳಿಸಿ",
            AppLanguage.URDU to "سیشن محفوظ کریں",
            AppLanguage.SPANISH to "Guardar Sesión",
            AppLanguage.ARABIC to "حفظ الجلسة"
        ),
        "total_due_all" to mapOf(
            AppLanguage.HINDI to "कुल बाकीदार राशि (Total Due)",
            AppLanguage.ENGLISH to "Total Pending Balance",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਬਾਕੀ",
            AppLanguage.GUJARATI to "કુલ બાકી",
            AppLanguage.MARATHI to "एकूण बाकी",
            AppLanguage.BENGALI to "সর্বমোট বাকি",
            AppLanguage.TELUGU to "మొత్తం బకాయిలు",
            AppLanguage.TAMIL to "மொத்த நிலுவை",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಬಾಕಿ",
            AppLanguage.URDU to "کل باقی رقم",
            AppLanguage.SPANISH to "Total por Cobrar",
            AppLanguage.ARABIC to "إجمالي المستحقات"
        ),
        "total_collected" to mapOf(
            AppLanguage.HINDI to "कुल प्राप्त (Collected)",
            AppLanguage.ENGLISH to "Total Collected",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਪ੍ਰਾਪਤ",
            AppLanguage.GUJARATI to "કુલ મળેલ",
            AppLanguage.MARATHI to "एकूण जमा",
            AppLanguage.BENGALI to "মোট সংগৃহীত",
            AppLanguage.TELUGU to "మొత్తం వసూలు",
            AppLanguage.TAMIL to "மொத்த வசூல்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಸಂಗ್ರಹ",
            AppLanguage.URDU to "کل وصولی",
            AppLanguage.SPANISH to "Total Recaudado",
            AppLanguage.ARABIC to "إجمالي المحصل"
        ),
        "total_hours_run" to mapOf(
            AppLanguage.HINDI to "कुल चले घंटे (Total Hours)",
            AppLanguage.ENGLISH to "Total Pumped Hours",
            AppLanguage.PUNJABI to "ਕੁੱਲ ਚੱਲੇ ਘੰਟੇ",
            AppLanguage.GUJARATI to "કુલ ચાલેલા કલાકો",
            AppLanguage.MARATHI to "एकूण चाललेले तास",
            AppLanguage.BENGALI to "মোট পাম্প চালিত ঘণ্টা",
            AppLanguage.TELUGU to "మొత్తం నడిచిన గంటలు",
            AppLanguage.TAMIL to "மொத்த ஓடிய மணிநேரம்",
            AppLanguage.KANNADA to "ಒಟ್ಟು ಚಾಲನೆಯಾದ ಗಂಟೆಗಳು",
            AppLanguage.URDU to "کل چلے ہوئے گھنٹے",
            AppLanguage.SPANISH to "Horas Totales de Bombeo",
            AppLanguage.ARABIC to "إجمالي ساعات التشغيل"
        ),
        "deposit_btn" to mapOf(
            AppLanguage.HINDI to "रुपये जमा करें",
            AppLanguage.ENGLISH to "Deposit Payment",
            AppLanguage.PUNJABI to "ਰੁਪਏ ਜਮ੍ਹਾ ਕਰੋ",
            AppLanguage.GUJARATI to "રૂપિયા જમા કરો",
            AppLanguage.MARATHI to "रक्कम जमा करा",
            AppLanguage.BENGALI to "টাকা জমা দিন",
            AppLanguage.TELUGU to "చెల్లింపు స్వీకరించండి",
            AppLanguage.TAMIL to "பணம் பெறவும்",
            AppLanguage.KANNADA to "ಹಣ ಜಮೆ ಮಾಡಿ",
            AppLanguage.URDU to "رقم جمع کریں",
            AppLanguage.SPANISH to "Registrar Cobro",
            AppLanguage.ARABIC to "تسجيل دفعة"
        ),
        "call_btn" to mapOf(
            AppLanguage.HINDI to "कॉल करें",
            AppLanguage.ENGLISH to "Call Now",
            AppLanguage.PUNJABI to "ਕਾਲ ਕਰੋ",
            AppLanguage.GUJARATI to "કૉલ કરો",
            AppLanguage.MARATHI to "कॉल करा",
            AppLanguage.BENGALI to "কল করুন",
            AppLanguage.TELUGU to "కాల్ చేయండి",
            AppLanguage.TAMIL to "அழைக்கவும்",
            AppLanguage.KANNADA to "ಕರೆ ಮಾಡಿ",
            AppLanguage.URDU to "کال کریں",
            AppLanguage.SPANISH to "Llamar",
            AppLanguage.ARABIC to "اتصال"
        ),
        "whatsapp_share" to mapOf(
            AppLanguage.HINDI to "WhatsApp पर्ची भेजें",
            AppLanguage.ENGLISH to "Send WhatsApp Bill",
            AppLanguage.PUNJABI to "WhatsApp ਪਰਚੀ ਭੇਜੋ",
            AppLanguage.GUJARATI to "WhatsApp રસીદ મોકલો",
            AppLanguage.MARATHI to "WhatsApp पावती पाठवा",
            AppLanguage.BENGALI to "WhatsApp এ রসিদ পাঠান",
            AppLanguage.TELUGU to "WhatsApp బిల్లు పంపండి",
            AppLanguage.TAMIL to "WhatsApp ரசீது அனுப்பவும்",
            AppLanguage.KANNADA to "WhatsApp ರಸೀದಿ ಕಳುಹಿಸಿ",
            AppLanguage.URDU to "واٹس ایپ رسید بھیجیں",
            AppLanguage.SPANISH to "Enviar Factura por WhatsApp",
            AppLanguage.ARABIC to "إرسال الفاتورة عبر واتساب"
        ),
        "sms_share" to mapOf(
            AppLanguage.HINDI to "SMS मैसेज भेजें",
            AppLanguage.ENGLISH to "Send SMS",
            AppLanguage.PUNJABI to "SMS ਸੁਨੇਹਾ ਭੇਜੋ",
            AppLanguage.GUJARATI to "SMS મોકલો",
            AppLanguage.MARATHI to "SMS पाठवा",
            AppLanguage.BENGALI to "SMS পাঠান",
            AppLanguage.TELUGU to "SMS పంపండి",
            AppLanguage.TAMIL to "SMS அனுப்பவும்",
            AppLanguage.KANNADA to "SMS ಕಳುಹಿಸಿ",
            AppLanguage.URDU to "SMS میسج بھیجیں",
            AppLanguage.SPANISH to "Enviar SMS",
            AppLanguage.ARABIC to "إرسال رسالة نصية SMS"
        ),
        "generate_pdf" to mapOf(
            AppLanguage.HINDI to "📄 मास्टर PDF लेजर डाउनलोड व शेयर करें",
            AppLanguage.ENGLISH to "📄 Generate & Share Master PDF Ledger",
            AppLanguage.PUNJABI to "📄 ਮਾਸਟਰ PDF ਡਾਊਨਲੋਡ ਕਰੋ",
            AppLanguage.GUJARATI to "📄 માસ્ટર PDF ડાઉનલોડ કરો",
            AppLanguage.MARATHI to "📄 मास्टर PDF डाउनलोड करा",
            AppLanguage.BENGALI to "📄 মাস্টার PDF ডাউনলোড করুন",
            AppLanguage.TELUGU to "📄 మాస్టర్ PDF డౌన్‌లోడ్ చేయండి",
            AppLanguage.TAMIL to "📄 முழு PDF கணக்கை பெறவும்",
            AppLanguage.KANNADA to "📄 ಮಾಸ್ಟರ್ PDF ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ",
            AppLanguage.URDU to "📄 ماسٹر PDF لیجر ڈاؤن لوڈ کریں",
            AppLanguage.SPANISH to "📄 Generar y Compartir PDF Maestro",
            AppLanguage.ARABIC to "📄 إنشاء ومشاركة تقرير PDF الشامل"
        ),
        "tab_all" to mapOf(
            AppLanguage.HINDI to "सभी (All)",
            AppLanguage.ENGLISH to "All",
            AppLanguage.PUNJABI to "ਸਾਰੇ",
            AppLanguage.GUJARATI to "બધા",
            AppLanguage.MARATHI to "सर्व",
            AppLanguage.BENGALI to "সব",
            AppLanguage.TELUGU to "అన్ని",
            AppLanguage.TAMIL to "அனைத்தும்",
            AppLanguage.KANNADA to "ಎಲ್ಲಾ",
            AppLanguage.URDU to "تمام",
            AppLanguage.SPANISH to "Todos",
            AppLanguage.ARABIC to "الكل"
        ),
        "tab_due" to mapOf(
            AppLanguage.HINDI to "बाकीदार (Due)",
            AppLanguage.ENGLISH to "Due",
            AppLanguage.PUNJABI to "ਬਾਕੀ ਵਾਲੇ",
            AppLanguage.GUJARATI to "બાકીવાળા",
            AppLanguage.MARATHI to "बाकीदार",
            AppLanguage.BENGALI to "বকেয়া",
            AppLanguage.TELUGU to "బకాయిలు",
            AppLanguage.TAMIL to "நிலுவை",
            AppLanguage.KANNADA to "ಬಾಕಿ ಇರುವವರು",
            AppLanguage.URDU to "واجب الادا",
            AppLanguage.SPANISH to "Pendientes",
            AppLanguage.ARABIC to "الآجل / المستحق"
        ),
        "tab_cash" to mapOf(
            AppLanguage.HINDI to "चुक्ता (No Due)",
            AppLanguage.ENGLISH to "Settled (Cash)",
            AppLanguage.PUNJABI to "ਨਿਪਟਾਏ",
            AppLanguage.GUJARATI to "ચૂકતે",
            AppLanguage.MARATHI to "निल बाकी",
            AppLanguage.BENGALI to "পরিশোধিত",
            AppLanguage.TELUGU to "చెల్లించినవి",
            AppLanguage.TAMIL to "முழுதும் செலுத்தியவை",
            AppLanguage.KANNADA to "ಪೂರ್ಣ ಪಾವತಿಸಿದವರು",
            AppLanguage.URDU to "بے باق",
            AppLanguage.SPANISH to "Liquidados",
            AppLanguage.ARABIC to "المسدد بالكامل"
        ),
        "filter_today" to mapOf(
            AppLanguage.HINDI to "आज (Today)",
            AppLanguage.ENGLISH to "Today",
            AppLanguage.PUNJABI to "ਅੱਜ",
            AppLanguage.GUJARATI to "આજે",
            AppLanguage.MARATHI to "आज",
            AppLanguage.BENGALI to "আজ",
            AppLanguage.TELUGU to "ఈ రోజు",
            AppLanguage.TAMIL to "இன்று",
            AppLanguage.KANNADA to "ಇಂದು",
            AppLanguage.URDU to "آج",
            AppLanguage.SPANISH to "Hoy",
            AppLanguage.ARABIC to "اليوم"
        ),
        "filter_weekly" to mapOf(
            AppLanguage.HINDI to "इस सप्ताह (Weekly)",
            AppLanguage.ENGLISH to "This Week",
            AppLanguage.PUNJABI to "ਇਸ ਹਫ਼ਤੇ",
            AppLanguage.GUJARATI to "આ અઠવાડિયે",
            AppLanguage.MARATHI to "या आठवड्यात",
            AppLanguage.BENGALI to "এই সপ্তাহ",
            AppLanguage.TELUGU to "ఈ వారం",
            AppLanguage.TAMIL to "இந்த வாரம்",
            AppLanguage.KANNADA to "ಈ ವಾರ",
            AppLanguage.URDU to "اس ہفتے",
            AppLanguage.SPANISH to "Esta Semana",
            AppLanguage.ARABIC to "هذا الأسبوع"
        ),
        "filter_monthly" to mapOf(
            AppLanguage.HINDI to "इस महीने (Monthly)",
            AppLanguage.ENGLISH to "This Month",
            AppLanguage.PUNJABI to "ਇਸ ਮਹੀਨੇ",
            AppLanguage.GUJARATI to "આ મહિને",
            AppLanguage.MARATHI to "या महिन्यात",
            AppLanguage.BENGALI to "এই মাস",
            AppLanguage.TELUGU to "ఈ నెల",
            AppLanguage.TAMIL to "இந்த மாதம்",
            AppLanguage.KANNADA to "ಈ ತಿಂಗಳು",
            AppLanguage.URDU to "اس مہینے",
            AppLanguage.SPANISH to "Este Mes",
            AppLanguage.ARABIC to "هذا الشهر"
        ),
        "filter_yearly" to mapOf(
            AppLanguage.HINDI to "1 साल (Yearly)",
            AppLanguage.ENGLISH to "1 Year",
            AppLanguage.PUNJABI to "1 ਸਾਲ",
            AppLanguage.GUJARATI to "1 વર્ષ",
            AppLanguage.MARATHI to "1 वर्ष",
            AppLanguage.BENGALI to "১ বছর",
            AppLanguage.TELUGU to "1 సంవత్సరం",
            AppLanguage.TAMIL to "1 வருடம்",
            AppLanguage.KANNADA to "1 ವರ್ಷ",
            AppLanguage.URDU to "1 سال",
            AppLanguage.SPANISH to "1 Año",
            AppLanguage.ARABIC to "سنة واحدة"
        ),
        "filter_2years" to mapOf(
            AppLanguage.HINDI to "2 साल (2 Years)",
            AppLanguage.ENGLISH to "2 Years",
            AppLanguage.PUNJABI to "2 ਸਾਲ",
            AppLanguage.GUJARATI to "2 વર્ષ",
            AppLanguage.MARATHI to "2 वर्षे",
            AppLanguage.BENGALI to "২ বছর",
            AppLanguage.TELUGU to "2 సంవత్సరాలు",
            AppLanguage.TAMIL to "2 வருடங்கள்",
            AppLanguage.KANNADA to "2 ವರ್ಷಗಳು",
            AppLanguage.URDU to "2 سال",
            AppLanguage.SPANISH to "2 Años",
            AppLanguage.ARABIC to "سنتان"
        ),
        "offline_synced" to mapOf(
            AppLanguage.HINDI to "ऑफ़लाइन सुरक्षित (100% सेफ)",
            AppLanguage.ENGLISH to "Offline Safe (100% Synced)",
            AppLanguage.PUNJABI to "ਆਫਲਾਈਨ ਸੁਰੱਖਿਅਤ",
            AppLanguage.GUJARATI to "ઓફલાઇન સુરક્ષિત",
            AppLanguage.MARATHI to "ऑफलाईन सुरक्षित",
            AppLanguage.BENGALI to "অফলাইনে সংরক্ষিত",
            AppLanguage.TELUGU to "ఆఫ్‌లైన్ సురక్షితం",
            AppLanguage.TAMIL to "ஆஃப்லைன் பாதுகாப்பானது",
            AppLanguage.KANNADA to "ಆಫ್‌ಲೈನ್ ಸುರಕ್ಷಿತ",
            AppLanguage.URDU to "آف لائن محفوظ",
            AppLanguage.SPANISH to "Modo Offline Seguro",
            AppLanguage.ARABIC to "آمن بدون إنترنت"
        ),
        "local_active_ready" to mapOf(
            AppLanguage.HINDI to "लोकल सक्रिय • तैयार",
            AppLanguage.ENGLISH to "LOCAL ACTIVE • READY"
        ),
        "kpi_income" to mapOf(
            AppLanguage.HINDI to "कुल आय (बिलिंग)",
            AppLanguage.ENGLISH to "Total Billed Income"
        ),
        "kpi_income_sub" to mapOf(
            AppLanguage.HINDI to "ट्यूबवेल से कुल बिलिंग",
            AppLanguage.ENGLISH to "Total billed irrigation"
        ),
        "kpi_hours" to mapOf(
            AppLanguage.HINDI to "कुल चले घंटे",
            AppLanguage.ENGLISH to "Total Pump Runtime"
        ),
        "kpi_hours_sub" to mapOf(
            AppLanguage.HINDI to "इंजन / मोटर चलने का समय",
            AppLanguage.ENGLISH to "Engine pump runtime"
        ),
        "kpi_cash" to mapOf(
            AppLanguage.HINDI to "कुल नकद वसूली",
            AppLanguage.ENGLISH to "Cash Collected"
        ),
        "kpi_cash_sub" to mapOf(
            AppLanguage.HINDI to "नकद प्राप्त व जमा रकम",
            AppLanguage.ENGLISH to "Cash & deposits"
        ),
        "kpi_due" to mapOf(
            AppLanguage.HINDI to "कुल बाकी बकाया",
            AppLanguage.ENGLISH to "Market Balance Due"
        ),
        "kpi_due_sub" to mapOf(
            AppLanguage.HINDI to "मार्केट में बाकी रकम",
            AppLanguage.ENGLISH to "Market balance"
        ),
        "reports_title" to mapOf(
            AppLanguage.HINDI to "रिपोर्ट्स एवं बही-खाता",
            AppLanguage.ENGLISH to "Reports & Ledger"
        ),
        "offline_pdf_title" to mapOf(
            AppLanguage.HINDI to "Offline Master Bahi-Khata PDF",
            AppLanguage.ENGLISH to "Offline Master Bahi-Khata PDF"
        ),
        "offline_pdf_desc" to mapOf(
            AppLanguage.HINDI to "पूरा खाता विवरण ऑफलाइन PDF में डाउनलोड करें",
            AppLanguage.ENGLISH to "Generates complete ledger statement offline"
        ),
        "btn_view_share_master_pdf" to mapOf(
            AppLanguage.HINDI to "📥 मास्टर बही-खाता PDF देखें / शेयर करें",
            AppLanguage.ENGLISH to "📥 View / Share Master PDF"
        ),
        "farmer_ledger_summary" to mapOf(
            AppLanguage.HINDI to "किसान-वार बही-खाता विवरण",
            AppLanguage.ENGLISH to "Farmer-wise Ledger Summary"
        ),
        "farmer_unit" to mapOf(
            AppLanguage.HINDI to "किसान",
            AppLanguage.ENGLISH to "Farmers"
        ),
        "filter_chip_all" to mapOf(
            AppLanguage.HINDI to "सभी",
            AppLanguage.ENGLISH to "All"
        ),
        "filter_chip_today" to mapOf(
            AppLanguage.HINDI to "आज",
            AppLanguage.ENGLISH to "Today"
        ),
        "filter_chip_week" to mapOf(
            AppLanguage.HINDI to "इस हफ्ते",
            AppLanguage.ENGLISH to "This Week"
        ),
        "filter_chip_month" to mapOf(
            AppLanguage.HINDI to "इस महीने",
            AppLanguage.ENGLISH to "This Month"
        ),
        "filter_chip_year" to mapOf(
            AppLanguage.HINDI to "इस साल",
            AppLanguage.ENGLISH to "This Year"
        ),
        "filter_chip_2years" to mapOf(
            AppLanguage.HINDI to "2 वर्ष",
            AppLanguage.ENGLISH to "2 Years"
        ),
        "tab_live_timer" to mapOf(
            AppLanguage.HINDI to "लाइव टाइमर",
            AppLanguage.ENGLISH to "Live Timer"
        ),
        "tab_start_end" to mapOf(
            AppLanguage.HINDI to "शुरू-अंत समय",
            AppLanguage.ENGLISH to "Start-End Time"
        ),
        "tab_direct_hours" to mapOf(
            AppLanguage.HINDI to "सीधे घंटे",
            AppLanguage.ENGLISH to "Direct Hours"
        ),
        "motor_start_title" to mapOf(
            AppLanguage.HINDI to "▶ मोटर चालू करने का समय (Start):",
            AppLanguage.ENGLISH to "▶ Motor Start Time (Start):"
        ),
        "motor_end_title" to mapOf(
            AppLanguage.HINDI to "⏹ मोटर बंद समय (End):",
            AppLanguage.ENGLISH to "⏹ Motor Stop Time (End):"
        ),
        "time_12hr_title" to mapOf(
            AppLanguage.HINDI to "12-घंटे समय चयन (Start - End Time):",
            AppLanguage.ENGLISH to "12-Hour Time Entry (Start - End Time):"
        ),
        "morning_am_text" to mapOf(
            AppLanguage.HINDI to "सुबह (AM)",
            AppLanguage.ENGLISH to "Morning (AM)"
        ),
        "evening_pm_text" to mapOf(
            AppLanguage.HINDI to "शाम (PM)",
            AppLanguage.ENGLISH to "Evening (PM)"
        ),
        "hour_0_12" to mapOf(
            AppLanguage.HINDI to "घंटा (0-12)",
            AppLanguage.ENGLISH to "Hour (0-12)"
        ),
        "min_0_59" to mapOf(
            AppLanguage.HINDI to "मिनट (0-59)",
            AppLanguage.ENGLISH to "Min (0-59)"
        ),
        "live_time_badge" to mapOf(
            AppLanguage.HINDI to "🕒 लाइव समय",
            AppLanguage.ENGLISH to "🕒 Current Time"
        ),
        "total_motor_runtime" to mapOf(
            AppLanguage.HINDI to "कुल मोटर चला समय:",
            AppLanguage.ENGLISH to "Total Pump Duration:"
        ),
        "rate_billing_box" to mapOf(
            AppLanguage.HINDI to "💰 दर एवं बिल गणना (Hourly Rate & Billing):",
            AppLanguage.ENGLISH to "💰 Rate & Bill Calculation (Hourly Rate & Billing):"
        ),
        "rate_unit_label" to mapOf(
            AppLanguage.HINDI to "दर (₹/घंटा)",
            AppLanguage.ENGLISH to "Rate (₹/hr)"
        ),
        "total_charge_box" to mapOf(
            AppLanguage.HINDI to "कुल चार्ज (₹)",
            AppLanguage.ENGLISH to "Total Charge (₹)"
        ),
        "paid_today_input" to mapOf(
            AppLanguage.HINDI to "आज जमा नकद राशि (Paid Amount)",
            AppLanguage.ENGLISH to "Cash Paid Today (Paid Amount)"
        ),
        "full_pay_chip" to mapOf(
            AppLanguage.HINDI to "पूरा ₹",
            AppLanguage.ENGLISH to "Full ₹"
        ),
        "today_due_calc" to mapOf(
            AppLanguage.HINDI to "आज का बाकी बकाया:",
            AppLanguage.ENGLISH to "Today's Pending Due:"
        ),
        "btn_finish_save_session" to mapOf(
            AppLanguage.HINDI to "✓ सत्र समाप्त करें एवं बही-खाता में जोड़ें",
            AppLanguage.ENGLISH to "✓ Complete Session & Save to Ledger"
        ),
        "btn_timer_pause" to mapOf(
            AppLanguage.HINDI to "⏸ रोकें",
            AppLanguage.ENGLISH to "⏸ Pause"
        ),
        "btn_timer_resume" to mapOf(
            AppLanguage.HINDI to "▶ पुनः शुरू",
            AppLanguage.ENGLISH to "▶ Resume"
        ),
        "btn_timer_start" to mapOf(
            AppLanguage.HINDI to "▶ शुरू करें",
            AppLanguage.ENGLISH to "▶ Start"
        ),
        "btn_adjust_time" to mapOf(
            AppLanguage.HINDI to "🎛 समय सुधारें",
            AppLanguage.ENGLISH to "🎛 Adjust Time"
        ),
        "btn_view_home_timer" to mapOf(
            AppLanguage.HINDI to "होमस्क्रीन पर लाइव टाइमर देखें",
            AppLanguage.ENGLISH to "View Live Timer on Home"
        ),
        "due_tag" to mapOf(
            AppLanguage.HINDI to "बाकी:",
            AppLanguage.ENGLISH to "Due:"
        ),
        "billed_tag" to mapOf(
            AppLanguage.HINDI to "बिल:",
            AppLanguage.ENGLISH to "Billed:"
        ),
        "paid_tag" to mapOf(
            AppLanguage.HINDI to "जमा:",
            AppLanguage.ENGLISH to "Paid:"
        ),
        "support_help" to mapOf(
            AppLanguage.HINDI to "सहायता / Support",
            AppLanguage.ENGLISH to "Support / Help",
            AppLanguage.PUNJABI to "ਸਹਾਇਤਾ / Support",
            AppLanguage.GUJARATI to "સહાય / Support",
            AppLanguage.MARATHI to "मदत / Support",
            AppLanguage.BENGALI to "সহায়তা / Support",
            AppLanguage.TELUGU to "సహాయం / Support",
            AppLanguage.TAMIL to "உதவி / Support",
            AppLanguage.KANNADA to "ಸಹಾಯ / Support",
            AppLanguage.URDU to "مدد / Support",
            AppLanguage.SPANISH to "Soporte / Ayuda",
            AppLanguage.ARABIC to "الدعم والمساعدة"
        ),
        "forgot_password" to mapOf(
            AppLanguage.HINDI to "पासवर्ड भूल गए?",
            AppLanguage.ENGLISH to "Forgot Password?",
            AppLanguage.PUNJABI to "ਪਾਸਵਰਡ ਭੁੱਲ ਗਏ?",
            AppLanguage.GUJARATI to "પાસવર્ડ ભૂલી ગયા?",
            AppLanguage.MARATHI to "पासवर्ड विसरलात?",
            AppLanguage.BENGALI to "পাসওয়ার্ড ভুলে গেছেন?",
            AppLanguage.TELUGU to "పాస్‌వర్డ్ మర్చిపోయారా?",
            AppLanguage.TAMIL to "கடவுச்சொல் மறந்துவிட்டதா?",
            AppLanguage.KANNADA to "ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರಾ?",
            AppLanguage.URDU to "پاس ورڈ بھول گئے؟",
            AppLanguage.SPANISH to "¿Olvidaste tu contraseña?",
            AppLanguage.ARABIC to "هل نسيت كلمة المرور؟"
        )
    )
}
