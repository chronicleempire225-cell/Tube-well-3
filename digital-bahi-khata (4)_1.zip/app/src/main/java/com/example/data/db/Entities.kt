package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val agencyName: String = "",
    val phone: String,
    val email: String = "",
    val isEmailVerified: Boolean = false,
    val ratePerHour: Double = 150.0,
    val pinHash: String,
    val photoUri: String? = null,
    val isPremium: Boolean = false,
    val isBlocked: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val profileId: String = "default",
    val name: String,
    val sO: String = "", // Father's Name (Son of / S/O)
    val phone: String = "",
    val photoUri: String? = null,
    val avatarBgColor: Long = 0xFF2E7D32,
    val initialBalance: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sessions")
data class TubewellSessionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val profileId: String = "default",
    val customerId: String,
    val hours: Double,
    val rate: Double,
    val totalAmount: Double,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val note: String = "",
    val sessionDate: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val profileId: String = "default",
    val customerId: String,
    val amountDeposited: Double,
    val paymentMode: String = "Cash", // Cash, UPI, Bank
    val note: String = "",
    val depositDate: Long = System.currentTimeMillis()
)
