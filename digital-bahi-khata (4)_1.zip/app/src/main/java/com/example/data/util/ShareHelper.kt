package com.example.data.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.db.CustomerEntity
import com.example.data.db.ProfileEntity
import com.example.data.db.TubewellSessionEntity
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ShareHelper {

    fun dialPhone(context: Context, phone: String) {
        try {
            val cleanPhone = phone.replace(Regex("[^0-9+]"), "")
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$cleanPhone")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "डायलर नहीं खुला: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareViaWhatsApp(context: Context, phone: String, message: String) {
        try {
            val cleanPhone = phone.replace(Regex("[^0-9]"), "")
            // If 10 digits in India, prefix 91
            val formattedPhone = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
            val encodedMsg = URLEncoder.encode(message, "UTF-8")
            val url = if (formattedPhone.isNotBlank()) {
                "https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedMsg"
            } else {
                "https://api.whatsapp.com/send?text=$encodedMsg"
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to general share
            shareGeneralText(context, message, "WhatsApp पर्ची")
        }
    }

    fun sendWhatsAppPaymentReminder(
        context: Context,
        phone: String,
        customerName: String,
        dueAmount: Double,
        agencyName: String
    ) {
        val message = """
            🌾 *उधारी तकादा / सिंचाई बकाया सूचना*
            ━━━━━━━━━━━━━━━━━━━━━
            👤 किसान: *$customerName*
            🏢 $agencyName
            💰 कुल बकाया राशि: *₹${Math.round(dueAmount)}*
            ━━━━━━━━━━━━━━━━━━━━━
            कृपया समय पर हिसाब चुकता करके सहयोग करें।
            धन्यवाद! 🙏
        """.trimIndent()
        shareViaWhatsApp(context, phone, message)
    }

    fun shareViaSms(context: Context, phone: String, message: String) {
        try {
            val cleanPhone = phone.replace(Regex("[^0-9+]"), "")
            val uri = if (cleanPhone.isNotBlank()) Uri.parse("smsto:$cleanPhone") else Uri.parse("smsto:")
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", message)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            shareGeneralText(context, message, "SMS मैसेज")
        }
    }

    fun shareGeneralText(context: Context, message: String, title: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
            }
            context.startActivity(Intent.createChooser(intent, title))
        } catch (e: Exception) {
            Toast.makeText(context, "शेयर नहीं हो सका", Toast.LENGTH_SHORT).show()
        }
    }

    fun sharePdfFile(context: Context, file: File, title: String = "मास्टर बही-खाता PDF") {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, title))
        } catch (e: Exception) {
            Toast.makeText(context, "PDF शेयर विफल: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openPdfFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to chooser or share if no viewer app is installed
            sharePdfFile(context, file, "किसान खाता PDF")
        }
    }

    fun formatDurationText(hours: Double): String {
        val totalMinutes = Math.round(hours * 60.0).toInt().coerceAtLeast(0)
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return when {
            h > 0 && m > 0 -> "$h घंटे $m मिनट"
            h > 0 -> "$h घंटे 00 मिनट"
            m > 0 -> "0 घंटे $m मिनट ($m मिनट)"
            else -> "0 घंटे 01 मिनट (1 मिनट)"
        }
    }

    fun formatDurationShort(hours: Double): String {
        val totalMinutes = Math.round(hours * 60.0).toInt().coerceAtLeast(0)
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return when {
            h > 0 && m > 0 -> "$h घंटे $m मिनट"
            h > 0 -> "$h घंटे"
            m > 0 -> "$m मिनट"
            else -> "1 मिनट"
        }
    }

    fun formatSessionReceiptMessage(
        profile: ProfileEntity?,
        customer: CustomerEntity,
        session: TubewellSessionEntity,
        totalCustomerDue: Double
    ): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy, hh:mm a", Locale.getDefault())
        val dateStr = sdf.format(Date(session.sessionDate))
        val agency = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "ट्यूबवेल सेवा"
        val ownerPhone = profile?.phone ?: ""
        val timeDisplay = formatDurationText(session.hours)

        return """
            💧 *ट्यूबवेल हिसाब पर्ची (Digital Receipt)* 💧
            --------------------------------
            🏢 *${agency}*
            👤 *किसान:* ${customer.name} ${if (customer.sO.isNotBlank()) "(सुपुत्र श्री ${customer.sO})" else ""}
            📅 *दिनांक:* $dateStr
            --------------------------------
            ⏱️ *आज का चला समय:* $timeDisplay (${String.format(Locale.ROOT, "%.2f", session.hours)} घंटे)
            ⚡ *आज की दर:* ₹${session.rate.toInt()}/घंटा
            💰 *आज का चार्ज:* ₹${String.format(Locale.ROOT, "%,d", Math.round(session.totalAmount))}
            💵 *आज का जमा किया:* ₹${String.format(Locale.ROOT, "%,d", Math.round(session.paidAmount))}
            🔴 *आज का बाकी बकाया:* ₹${String.format(Locale.ROOT, "%,d", Math.round(session.dueAmount))}
            --------------------------------
            📌 *खाते का कुल बाकी बकाया:* ₹${String.format(Locale.ROOT, "%,d", Math.round(totalCustomerDue))}
            --------------------------------
            ${if (ownerPhone.isNotBlank()) "📞 संचालक संपर्क: $ownerPhone\n" else ""}🌾 जय जवान, जय किसान! धन्यवाद! 🌾
        """.trimIndent()
    }

    fun formatCustomerStatementMessage(
        profile: ProfileEntity?,
        customer: CustomerEntity,
        totalHours: Double,
        totalAmount: Double,
        totalPaid: Double,
        netDue: Double
    ): String {
        val agency = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "ट्यूबवेल सेवा"
        val timeDisplay = formatDurationText(totalHours)
        return """
            🌾 *डिजिटल बही-खाता विवरण (Khata Statement)* 🌾
            --------------------------------
            🏢 *${agency}*
            👤 *किसान का नाम:* ${customer.name}
            ${if (customer.sO.isNotBlank()) "👨‍👦 *पिताजी:* ${customer.sO}\n" else ""}📱 *मोबाइल:* ${customer.phone}
            --------------------------------
            ⏱️ *कुल ट्यूबवेल चला समय:* $timeDisplay (${String.format(Locale.ROOT, "%.2f", totalHours)} घंटे)
            💰 *कुल बनी रकम:* ₹${String.format(Locale.ROOT, "%,d", Math.round(totalAmount))}
            💵 *कुल जमा की गई रकम:* ₹${String.format(Locale.ROOT, "%,d", Math.round(totalPaid))}
            🔴 *वर्तमान कुल बाकी शेष:* ₹${String.format(Locale.ROOT, "%,d", Math.round(netDue))}
            --------------------------------
            कृपया समय पर बकाया राशि का भुगतान करें।
            🌾 जय जवान, जय किसान! 🌾
        """.trimIndent()
    }

    fun formatPaymentReceiptMessage(
        profile: ProfileEntity?,
        customer: CustomerEntity,
        amount: Double,
        mode: String,
        netDue: Double
    ): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy, hh:mm a", Locale.getDefault())
        val dateStr = sdf.format(Date())
        val agency = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "ट्यूबवेल सेवा"
        val ownerPhone = profile?.phone ?: ""

        return """
            💵 *जमा भुगतान रसीद (Payment Receipt)* 💵
            --------------------------------
            🏢 *$agency*
            👤 *किसान:* ${customer.name} ${if (customer.sO.isNotBlank()) "(सुपुत्र श्री ${customer.sO})" else ""}
            📅 *दिनांक:* $dateStr
            --------------------------------
            💰 *जमा की गई राशि:* ₹${String.format(Locale.ROOT, "%,d", Math.round(amount))}
            💳 *भुगतान माध्यम:* $mode
            --------------------------------
            🔴 *वर्तमान कुल बाकी शेष:* ₹${String.format(Locale.ROOT, "%,d", Math.round(netDue))}
            --------------------------------
            ${if (ownerPhone.isNotBlank()) "📞 संचालक संपर्क: $ownerPhone\n" else ""}🌾 भुगतान के लिए धन्यवाद! जय जवान, जय किसान! 🌾
        """.trimIndent()
    }

    fun openSupportEmail(context: Context) {
        val supportEmail = "tubewellsupport@gmail.com"
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$supportEmail")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(supportEmail))
                putExtra(Intent.EXTRA_SUBJECT, "ट्यूबवेल बही-खाता सहायता / Tubewell App Support")
                putExtra(
                    Intent.EXTRA_TEXT,
                    "नमस्ते सपोर्ट टीम,\n\nमुझे निम्नलिखित समस्या / प्रश्न के लिए सहायता चाहिए:\n\n[कृपया अपना संदेश यहाँ लिखें]\n\n"
                )
            }
            context.startActivity(Intent.createChooser(intent, "सपोर्ट ईमेल भेजें"))
        } catch (e: Exception) {
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("mailto:$supportEmail"))
                context.startActivity(fallbackIntent)
            } catch (e2: Exception) {
                Toast.makeText(context, "ईमेल ऐप नहीं मिला: $supportEmail", Toast.LENGTH_LONG).show()
            }
        }
    }

    const val TERMS_POLICY_URL = "https://sites.google.com/view/tubewellapppolicies/home?authuser=1"

    enum class AppStore(
        val id: String,
        val displayName: String,
        val packageName: String?,
        val webFallbackUrl: (String) -> String
    ) {
        PLAY_STORE(
            "play_store",
            "Google Play Store",
            "com.android.vending",
            { pkg -> "https://play.google.com/store/apps/details?id=$pkg" }
        ),
        XIAOMI_GETAPPS(
            "xiaomi_getapps",
            "Xiaomi GetApps",
            "com.xiaomi.mipicks",
            { pkg -> "https://global.app.mi.com/details?id=$pkg" }
        ),
        SAMSUNG_GALAXY_STORE(
            "samsung_galaxy_store",
            "Samsung Galaxy Store",
            "com.sec.android.app.samsungapps",
            { pkg -> "https://galaxystore.samsung.com/detail/$pkg" }
        ),
        HUAWEI_APPGALLERY(
            "huawei_appgallery",
            "Huawei AppGallery",
            "com.huawei.appmarket",
            { pkg -> "https://appgallery.huawei.com/app/C$pkg" }
        ),
        VIVO_APPSTORE(
            "vivo_appstore",
            "Vivo V-Appstore",
            "com.vivo.appstore",
            { pkg -> "https://play.google.com/store/apps/details?id=$pkg" }
        ),
        OPPO_APP_MARKET(
            "oppo_app_market",
            "OPPO App Market",
            "com.oppo.market",
            { pkg -> "https://play.google.com/store/apps/details?id=$pkg" }
        ),
        AMAZON_APPSTORE(
            "amazon_appstore",
            "Amazon Appstore",
            "com.amazon.venezia",
            { pkg -> "https://www.amazon.com/gp/mas/dl/android?p=$pkg" }
        ),
        GENERIC_MARKET(
            "generic_market",
            "App Store",
            null,
            { pkg -> "https://play.google.com/store/apps/details?id=$pkg" }
        )
    }

    private fun getInstallerPackage(context: Context): String? {
        return try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getInstallerPackageName(context.packageName)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun isPackageInstalled(context: Context, targetPackage: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(targetPackage, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * जिस ऐप स्टोर से ऐप इंस्टॉल हुआ है केवल उसी को पहचानता है।
     * अगर ऐप साइडलोड या सीधे इंस्टॉल हुआ है तो कोई भी ब्रैंड जबरन नहीं थोपेगा।
     */
    fun detectAppStore(context: Context): AppStore {
        val installer = getInstallerPackage(context)?.lowercase()

        // केवल वास्तविक इंस्टॉलर पैकेज के आधार पर स्टोर पहचानें
        return when (installer) {
            "com.android.vending" -> AppStore.PLAY_STORE
            "com.xiaomi.mipicks" -> AppStore.XIAOMI_GETAPPS
            "com.sec.android.app.samsungapps" -> AppStore.SAMSUNG_GALAXY_STORE
            "com.huawei.appmarket" -> AppStore.HUAWEI_APPGALLERY
            "com.vivo.appstore", "com.bbk.appstore" -> AppStore.VIVO_APPSTORE
            "com.oppo.market", "com.heytap.market" -> AppStore.OPPO_APP_MARKET
            "com.amazon.venezia" -> AppStore.AMAZON_APPSTORE
            else -> AppStore.GENERIC_MARKET
        }
    }

    fun getStoreDisplayName(context: Context): String {
        val store = detectAppStore(context)
        return if (store == AppStore.GENERIC_MARKET) "ऐप स्टोर" else store.displayName
    }

    fun openPrivacyPolicy(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(TERMS_POLICY_URL)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "ब्राउज़र नहीं खुला: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * जिस ऐप स्टोर से डाउनलोड किया गया है (Play Store, Xiaomi GetApps, Samsung Galaxy Store आदि),
     * उसी स्टोर पर सीधे ऐप की रेटिंग व रिव्यू पेज खोलता है।
     */
    fun rateApp(context: Context) {
        val packageName = context.packageName
        val store = detectAppStore(context)
        var opened = false

        // 1. Try store-specific deep link / intent
        val storeUriString = when (store) {
            AppStore.PLAY_STORE -> "market://details?id=$packageName"
            AppStore.XIAOMI_GETAPPS -> "mimarket://details?id=$packageName"
            AppStore.SAMSUNG_GALAXY_STORE -> "samsungapps://ProductDetail/$packageName"
            AppStore.HUAWEI_APPGALLERY -> "appmarket://details?id=$packageName"
            AppStore.VIVO_APPSTORE -> "vivoMarket://details?id=$packageName"
            AppStore.OPPO_APP_MARKET -> "oppomarket://details?packagename=$packageName"
            AppStore.AMAZON_APPSTORE -> "amzn://apps/android?p=$packageName"
            AppStore.GENERIC_MARKET -> "market://details?id=$packageName"
        }

        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(storeUriString)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                store.packageName?.let { setPackage(it) }
            }
            context.startActivity(intent)
            opened = true
        } catch (e: Exception) {
            // Fallback: standard market uri
            try {
                val genericIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                }
                context.startActivity(genericIntent)
                opened = true
            } catch (e2: Exception) {
                opened = false
            }
        }

        // 2. If native app store intent fails, open store web link in browser
        if (!opened) {
            try {
                val webUri = Uri.parse(store.webFallbackUrl(packageName))
                val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(webIntent)
            } catch (e3: Exception) {
                Toast.makeText(context, "${store.displayName} लिंक नहीं खुल सका: ${e3.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Play Store / संबंधित ऐप स्टोर के लिए Backward Compatibility alias
     */
    fun rateAppOnPlayStore(context: Context) {
        rateApp(context)
    }

    /**
     * किसान भाइयों के साथ ऐप शेयर करने के लिए संदेश।
     */
    fun shareAppWithFriends(context: Context) {
        val packageName = context.packageName
        val store = detectAppStore(context)
        val storeLink = store.webFallbackUrl(packageName)
        val downloadLabel = if (store == AppStore.GENERIC_MARKET) "👉 अभी ऐप डाउनलोड करें:" else "👉 अभी ${store.displayName} से डाउनलोड करें:"

        val shareMessage = """
            🌾 *किसान ट्यूबवेल व डिजिटल बहीखाता* 🌾
            _Soft Empire द्वारा प्रस्तुत_
            
            अब अपने ट्यूबवेल, बोरिंग और सिंचाई का पूरा हिसाब-किताब रखें अपने मोबाइल में!
            
            ✅ लाइव मोटर टाइमर और ऑटोमैटिक किराया गणना
            ✅ किसानों का खाता और बकाया उधारी ट्रैकिंग
            ✅ 1-क्लिक में WhatsApp पर्ची और PDF रसीद
            ✅ मुंशी AI वॉयस असिस्टेंट (बोलकर खाता व हिसाब)
            ✅ 100% सुरक्षित और ऑटोमैटिक क्लाउड बैकअप
            
            $downloadLabel
            $storeLink
        """.trimIndent()

        shareGeneralText(context, shareMessage, "किसान ट्यूबवेल ऐप शेयर करें")
    }
}
