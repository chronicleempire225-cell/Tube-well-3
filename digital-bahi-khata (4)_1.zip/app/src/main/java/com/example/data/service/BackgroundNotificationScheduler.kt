package com.example.data.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Background Notification Scheduler for Digital Bahi Khata.
 *
 * Provides a dual-mechanism background engine (WorkManager + AlarmManager) so that
 * notifications for overdue accounts and farmer hours/sessions trigger automatically
 * at scheduled times in the background, even when the app is completely closed or killed.
 */
object BackgroundNotificationScheduler {
    private const val TAG = "BgNotifScheduler"
    private const val ALARM_REQUEST_CODE_MORNING = 9910   // 8:00 AM (सुबह)
    private const val ALARM_REQUEST_CODE_AFTERNOON = 9911 // 1:00 PM (दोपहर)
    private const val ALARM_REQUEST_CODE_EVENING = 9912   // 5:30 PM (शाम)
    private const val ALARM_REQUEST_CODE_NIGHT = 9913     // 8:30 PM (रात)

    /**
     * Schedules periodic WorkManager background execution (every 3 hours)
     * and 4 daily AlarmManager checkpoints for high reliability.
     */
    fun schedulePeriodicWork(context: Context) {
        try {
            Log.d(TAG, "Initializing background notification scheduler...")

            // Ensure notification channel is created
            DuePaymentReminderManager.createNotificationChannel(context)

            // 1. Setup WorkManager Periodic Request
            val constraints = Constraints.Builder()
                .setRequiresBatteryNotLow(false)
                .build()

            // Run periodic check every 3 hours with 15-minute flex interval
            val periodicWorkRequest = PeriodicWorkRequestBuilder<DuePaymentNotificationWorker>(
                3, TimeUnit.HOURS,
                15, TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .addTag(DuePaymentNotificationWorker.WORK_NAME_PERIODIC)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                DuePaymentNotificationWorker.WORK_NAME_PERIODIC,
                ExistingPeriodicWorkPolicy.KEEP,
                periodicWorkRequest
            )

            // 2. Setup 4 AlarmManager Daily Reminders (8:00 AM, 1:00 PM, 5:30 PM, 8:30 PM)
            scheduleDailyAlarms(context)

            Log.d(TAG, "WorkManager periodic task and 4 daily AlarmManager checkpoints scheduled successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule background notifications: ${e.message}", e)
        }
    }

    /**
     * Triggers an immediate one-time background calculation and notification worker.
     */
    fun triggerImmediateCheck(context: Context) {
        try {
            Log.d(TAG, "Triggering immediate one-time WorkManager task...")
            val oneTimeWorkRequest = OneTimeWorkRequestBuilder<DuePaymentNotificationWorker>()
                .addTag(DuePaymentNotificationWorker.WORK_NAME_ONE_TIME)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                DuePaymentNotificationWorker.WORK_NAME_ONE_TIME,
                ExistingWorkPolicy.REPLACE,
                oneTimeWorkRequest
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to trigger immediate work: ${e.message}")
        }
    }

    /**
     * Sets repeating daily alarms 4 times a day to guarantee wake-up and execution even on aggressive
     * battery-saving Android ROMs.
     */
    private fun scheduleDailyAlarms(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        // 1. Morning (सुबह 8:00 AM)
        scheduleSingleDailyAlarm(
            context = context,
            alarmManager = alarmManager,
            requestCode = ALARM_REQUEST_CODE_MORNING,
            targetHour = 8,
            targetMinute = 0
        )

        // 2. Afternoon (दोपहर 1:00 PM)
        scheduleSingleDailyAlarm(
            context = context,
            alarmManager = alarmManager,
            requestCode = ALARM_REQUEST_CODE_AFTERNOON,
            targetHour = 13,
            targetMinute = 0
        )

        // 3. Evening (शाम 5:30 PM)
        scheduleSingleDailyAlarm(
            context = context,
            alarmManager = alarmManager,
            requestCode = ALARM_REQUEST_CODE_EVENING,
            targetHour = 17,
            targetMinute = 30
        )

        // 4. Night (रात 8:30 PM)
        scheduleSingleDailyAlarm(
            context = context,
            alarmManager = alarmManager,
            requestCode = ALARM_REQUEST_CODE_NIGHT,
            targetHour = 20,
            targetMinute = 30
        )
    }

    private fun scheduleSingleDailyAlarm(
        context: Context,
        alarmManager: AlarmManager,
        requestCode: Int,
        targetHour: Int,
        targetMinute: Int
    ) {
        val intent = Intent(context, LiveTimerRestartReceiver::class.java).apply {
            action = LiveTimerRestartReceiver.ACTION_CHECK_DUE_REMINDERS
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, targetHour)
            set(Calendar.MINUTE, targetMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    AlarmManager.INTERVAL_DAY,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Permission to set exact alarm denied, using standard alarm: ${e.message}")
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule alarm: ${e.message}")
        }
    }

    /**
     * Cancels all scheduled WorkManager periodic work and alarms
     */
    fun cancelAll(context: Context) {
        try {
            WorkManager.getInstance(context).cancelUniqueWork(DuePaymentNotificationWorker.WORK_NAME_PERIODIC)
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            
            listOf(
                ALARM_REQUEST_CODE_MORNING,
                ALARM_REQUEST_CODE_AFTERNOON,
                ALARM_REQUEST_CODE_EVENING,
                ALARM_REQUEST_CODE_NIGHT
            ).forEach { reqCode ->
                val intent = Intent(context, LiveTimerRestartReceiver::class.java).apply {
                    action = LiveTimerRestartReceiver.ACTION_CHECK_DUE_REMINDERS
                }
                val pi = PendingIntent.getBroadcast(
                    context,
                    reqCode,
                    intent,
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                if (pi != null) alarmManager.cancel(pi)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling background work: ${e.message}")
        }
    }
}
