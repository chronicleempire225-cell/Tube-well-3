package com.example.data.remoteconfig

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Rewarded Video Ad Manager.
 * 
 * Preloads AdMob Rewarded Ads in background so users experience zero lag
 * when unlocking the 24-hour feature pass.
 * Automatically reloads a fresh ad whenever an ad is displayed or closed.
 */
object RewardedAdManager {
    private const val TAG = "RewardedAdManager"
    const val DEFAULT_TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    private var rewardedAd: RewardedAd? = null
    private var isAdLoading = false

    private val _isReadyFlow = MutableStateFlow(false)
    val isReadyFlow: StateFlow<Boolean> = _isReadyFlow.asStateFlow()

    fun init(context: Context) {
        preload(context)
    }

    /**
     * Preloads a rewarded ad using the ad unit ID configured in RemoteConfigService or fallback test ID.
     */
    fun preload(context: Context) {
        if (rewardedAd != null || isAdLoading) return

        isAdLoading = true
        val config = RemoteConfigService.getConfigForScreen("REWARDED_FEATURE_UNLOCK")
        val adUnitId = config?.adUnitId?.ifBlank { DEFAULT_TEST_REWARDED_ID } ?: DEFAULT_TEST_REWARDED_ID

        Log.d(TAG, "Preloading Rewarded Ad with Unit ID: $adUnitId")

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context.applicationContext,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "Rewarded Ad loaded successfully!")
                    rewardedAd = ad
                    isAdLoading = false
                    _isReadyFlow.value = true
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "Failed to load Rewarded Ad: ${loadAdError.message} (code: ${loadAdError.code})")
                    rewardedAd = null
                    isAdLoading = false
                    _isReadyFlow.value = false
                }
            }
        )
    }

    /**
     * Checks if a rewarded ad is currently cached and ready to show immediately.
     */
    fun isAdReady(): Boolean = rewardedAd != null

    /**
     * Displays the rewarded ad to the user.
     * If user watches for at least requiredSeconds (e.g. 7 or 8 seconds), the reward is granted
     * even if they dismiss earlier, or when AdMob issues the reward event.
     * Automatically requests preloading of the next ad upon dismissal.
     */
    fun showRewardedAd(
        activity: Activity,
        requiredSeconds: Int = 0,
        onUserEarnedReward: () -> Unit,
        onAdDismissed: () -> Unit = {},
        onAdFailed: (String) -> Unit = {}
    ) {
        val ad = rewardedAd
        if (ad == null) {
            preload(activity)
            onAdFailed("विज्ञापन अभी लोड हो रहा है, कृपया 2 सेकंड बाद पुनः प्रयास करें।")
            return
        }

        var rewardGranted = false
        var showStartTimeMs = 0L

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "Rewarded ad showed full screen.")
                showStartTimeMs = System.currentTimeMillis()
                rewardedAd = null
                _isReadyFlow.value = false
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.e(TAG, "Failed to show full screen ad: ${adError.message}")
                rewardedAd = null
                _isReadyFlow.value = false
                preload(activity)
                onAdFailed("विज्ञापन दिखाने में त्रुटि: ${adError.message}")
            }

            override fun onAdDismissedFullScreenContent() {
                val elapsedSeconds = if (showStartTimeMs > 0L) {
                    ((System.currentTimeMillis() - showStartTimeMs) / 1000L).toInt()
                } else 0

                Log.d(TAG, "Rewarded ad dismissed after $elapsedSeconds seconds.")

                // If user specified custom threshold > 0, allow early reward fallback
                if (!rewardGranted && requiredSeconds > 0 && elapsedSeconds >= requiredSeconds) {
                    Log.d(TAG, "Custom seconds threshold reached ($elapsedSeconds >= $requiredSeconds)!")
                    rewardGranted = true
                    onUserEarnedReward()
                }

                rewardedAd = null
                _isReadyFlow.value = false
                preload(activity)
                onAdDismissed()
            }
        }

        // Official Google AdMob Reward Callback
        ad.show(activity) { rewardItem ->
            Log.d(TAG, "Google AdMob verified user earned reward: ${rewardItem.type}, amount: ${rewardItem.amount}")
            if (!rewardGranted) {
                rewardGranted = true
                onUserEarnedReward()
            }
        }
    }
}
