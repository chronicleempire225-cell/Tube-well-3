package com.example.data.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver to keep Live Pump Timer running across process recreation,
 * app clearing from recents, phone boot, and to process due payment reminders.
 */
class LiveTimerRestartReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "TimerRestartReceiver"
        const val ACTION_RESTART_TIMER_SERVICE = "com.example.service.ACTION_RESTART_TIMER_SERVICE"
        const val ACTION_CHECK_DUE_REMINDERS = "com.example.service.ACTION_CHECK_DUE_REMINDERS"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        Log.d(TAG, "Broadcast received: $action")

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            ACTION_RESTART_TIMER_SERVICE -> {
                // Ensure Background WorkManager & Alarms are scheduled
                BackgroundNotificationScheduler.schedulePeriodicWork(context)

                // Initialize state from SharedPreferences
                LiveTimerManager.init(context)
                val isRunning = LiveTimerPreferences.getIsRunning(context)
                val isPaused = LiveTimerPreferences.getIsPaused(context)

                if (isRunning) {
                    Log.d(TAG, "Restoring Live Pump Timer Foreground Service after restart/kill...")
                    val serviceIntent = Intent(context, LivePumpTimerService::class.java).apply {
                        this.action = if (isPaused) LivePumpTimerService.ACTION_PAUSE else LivePumpTimerService.ACTION_START
                    }
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            ContextCompat.startForegroundService(context, serviceIntent)
                        } else {
                            context.startService(serviceIntent)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to restore LivePumpTimerService: ${e.message}")
                    }
                }
            }

            ACTION_CHECK_DUE_REMINDERS -> {
                // Background check for overdue customer payments
                if (DuePaymentReminderManager.isAutoReminderEnabled(context)) {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            DuePaymentReminderManager.checkAndPostDueNotifications(
                                context = context,
                                minDuration = DuePaymentReminderManager.getSelectedDuration(context),
                                isManualTrigger = false
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to run due reminders: ${e.message}")
                        }
                    }
                }
            }
        }
    }
}
