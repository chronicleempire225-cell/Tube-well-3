package com.example.data.pdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.db.CustomerEntity
import com.example.data.db.ProfileEntity
import com.example.data.db.TubewellSessionEntity
import com.example.data.db.TransactionEntity
import com.example.data.util.AppFormatters
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CustomerLedgerRow(
    val customer: CustomerEntity,
    val totalHours: Double,
    val totalAmount: Double,
    val totalPaid: Double,
    val totalDue: Double,
    val sessionCount: Int
)

object PdfGenerator {

    fun generateMasterReportPdf(
        context: Context,
        profile: ProfileEntity?,
        rows: List<CustomerLedgerRow>,
        periodTitle: String
    ): File? {
        try {
            val pdfDoc = PdfDocument()
            val pageWidth = 595 // A4 standard point width
            val pageHeight = 842 // A4 standard point height

            val grandHours = rows.sumOf { it.totalHours }
            val grandAmount = rows.sumOf { Math.round(it.totalAmount).toLong() }
            val grandPaid = rows.sumOf { Math.round(it.totalPaid).toLong() }
            val grandDue = rows.sumOf { (Math.round(it.totalAmount).toLong() - Math.round(it.totalPaid).toLong()).coerceAtLeast(0L) }

            val sdf = SimpleDateFormat("dd/MM/yyyy, hh:mm a", Locale.getDefault())
            val dateStr = "रिपोर्ट दिनांक: ${sdf.format(Date())} | अवधि: $periodTitle"
            val agencyName = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "किसान ट्यूबवेल & सिंचाई बही-खाता"
            val ownerInfo = "संचालक: ${profile?.name ?: "किसान मालिक"} | संपर्क: ${profile?.phone ?: "-"} | दर: ₹${profile?.ratePerHour?.toInt() ?: 160}/घंटा"

            // Paints
            val textPaint = Paint().apply {
                isAntiAlias = true
                color = Color.rgb(30, 41, 59)
                textSize = 9.5f
            }
            val titlePaint = Paint().apply {
                isAntiAlias = true
                color = Color.WHITE
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val subTitlePaint = Paint().apply {
                isAntiAlias = true
                color = Color.rgb(187, 247, 208)
                textSize = 10f
            }
            val linePaint = Paint().apply {
                color = Color.rgb(226, 232, 240)
                strokeWidth = 1f
            }
            val redDuePaint = Paint().apply {
                color = Color.rgb(220, 38, 38)
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val greenPaidPaint = Paint().apply {
                color = Color.rgb(22, 163, 74)
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            var rowIndex = 0
            var pageNumber = 1
            val totalRows = rows.size

            while (rowIndex < totalRows || pageNumber == 1) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                val page = pdfDoc.startPage(pageInfo)
                val canvas: Canvas = page.canvas
                var currentY = 24f

                if (pageNumber == 1) {
                    // 1. Top Green Header Banner
                    val bannerPaint = Paint().apply {
                        color = Color.rgb(20, 83, 45) // Deep Green #14532D
                        style = Paint.Style.FILL
                    }
                    canvas.drawRoundRect(20f, currentY, (pageWidth - 20).toFloat(), currentY + 58f, 8f, 8f, bannerPaint)

                    canvas.drawText("🌾 $agencyName", 32f, currentY + 22f, titlePaint)
                    canvas.drawText(ownerInfo, 32f, currentY + 38f, subTitlePaint)
                    canvas.drawText(dateStr, 32f, currentY + 50f, Paint().apply {
                        isAntiAlias = true
                        color = Color.rgb(254, 240, 138)
                        textSize = 9f
                    })

                    currentY += 70f

                    // 2. GRAND TOTAL SUMMARY BOX (चारों मुख्य योग सबसे ऊपर: कुल इनकम, कुल घंटे, कुल जमा, कुल बकाया)
                    val summaryBgPaint = Paint().apply {
                        color = Color.rgb(248, 250, 252) // #F8FAFC
                        style = Paint.Style.FILL
                    }
                    val summaryBorderPaint = Paint().apply {
                        color = Color.rgb(203, 213, 225)
                        style = Paint.Style.STROKE
                        strokeWidth = 1.2f
                    }
                    canvas.drawRoundRect(20f, currentY, (pageWidth - 20).toFloat(), currentY + 70f, 6f, 6f, summaryBgPaint)
                    canvas.drawRoundRect(20f, currentY, (pageWidth - 20).toFloat(), currentY + 70f, 6f, 6f, summaryBorderPaint)

                    // Summary Title
                    canvas.drawText(
                        "📊 समग्र सारांश (OVERALL GRAND TOTAL SUMMARY)",
                        32f,
                        currentY + 16f,
                        Paint().apply {
                            color = Color.rgb(15, 23, 42)
                            textSize = 10.5f
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                        }
                    )
                    canvas.drawLine(20f, currentY + 22f, (pageWidth - 20).toFloat(), currentY + 22f, linePaint)

                    // 4 Quadrants: Total Income, Total Hours, Total Paid, Total Due
                    val midX = pageWidth / 2f

                    // Row 1
                    // 1. कुल इनकम (Total Income)
                    canvas.drawText("📈 कुल इनकम (Total Income):", 32f, currentY + 38f, Paint().apply {
                        textSize = 10f; color = Color.rgb(71, 85, 105); typeface = Typeface.DEFAULT_BOLD
                    })
                    canvas.drawText("₹${String.format(Locale.ROOT, "%,d", grandAmount)}", 195f, currentY + 38f, Paint().apply {
                        textSize = 11f; color = Color.rgb(15, 23, 42); typeface = Typeface.DEFAULT_BOLD
                    })

                    // 2. कुल घंटे (Total Hours)
                    canvas.drawText("⏱️ कुल चले घंटे (Total Hours):", midX + 10f, currentY + 38f, Paint().apply {
                        textSize = 10f; color = Color.rgb(71, 85, 105); typeface = Typeface.DEFAULT_BOLD
                    })
                    canvas.drawText("${String.format(Locale.ROOT, "%.1f", grandHours)} hrs", midX + 175f, currentY + 38f, Paint().apply {
                        textSize = 11f; color = Color.rgb(20, 83, 45); typeface = Typeface.DEFAULT_BOLD
                    })

                    // Row 2
                    // 3. कुल जमा हुआ (Total Paid)
                    canvas.drawText("💰 कुल जमा राशि (Total Paid):", 32f, currentY + 58f, Paint().apply {
                        textSize = 10f; color = Color.rgb(22, 163, 74); typeface = Typeface.DEFAULT_BOLD
                    })
                    canvas.drawText("₹${String.format(Locale.ROOT, "%,d", grandPaid)}", 195f, currentY + 58f, Paint().apply {
                        textSize = 11f; color = Color.rgb(22, 163, 74); typeface = Typeface.DEFAULT_BOLD
                    })

                    // 4. कुल बकाया (Total Due)
                    canvas.drawText("⚠️ कुल बाकी बकाया (Total Due):", midX + 10f, currentY + 58f, Paint().apply {
                        textSize = 10f; color = Color.rgb(220, 38, 38); typeface = Typeface.DEFAULT_BOLD
                    })
                    canvas.drawText("₹${String.format(Locale.ROOT, "%,d", grandDue)}", midX + 175f, currentY + 58f, Paint().apply {
                        textSize = 11f; color = Color.rgb(220, 38, 38); typeface = Typeface.DEFAULT_BOLD
                    })

                    currentY += 86f
                } else {
                    // Header for subsequent pages
                    val miniHeaderPaint = Paint().apply {
                        color = Color.rgb(20, 83, 45)
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(20f, currentY, (pageWidth - 20).toFloat(), currentY + 28f, miniHeaderPaint)
                    canvas.drawText("🌾 $agencyName - रिपोर्ट जारी (पृष्ठ $pageNumber)", 30f, currentY + 18f, Paint().apply {
                        color = Color.WHITE; textSize = 11f; typeface = Typeface.DEFAULT_BOLD
                    })
                    currentY += 38f
                }

                // 3. Table Header
                val thPaint = Paint().apply {
                    color = Color.rgb(20, 83, 45)
                    style = Paint.Style.FILL
                }
                canvas.drawRect(20f, currentY, (pageWidth - 20).toFloat(), currentY + 22f, thPaint)

                val thTextPaint = Paint().apply {
                    color = Color.WHITE
                    textSize = 9.5f
                    typeface = Typeface.DEFAULT_BOLD
                }

                canvas.drawText("क्र.", 26f, currentY + 15f, thTextPaint)
                canvas.drawText("किसान का नाम", 48f, currentY + 15f, thTextPaint)
                canvas.drawText("पिता का नाम", 175f, currentY + 15f, thTextPaint)
                canvas.drawText("मोबाइल नंबर", 270f, currentY + 15f, thTextPaint)
                canvas.drawText("कुल घंटे", 365f, currentY + 15f, thTextPaint)
                canvas.drawText("कुल राशि", 420f, currentY + 15f, thTextPaint)
                canvas.drawText("जमा राशि", 480f, currentY + 15f, thTextPaint)
                canvas.drawText("बाकी बकाया", 535f, currentY + 15f, thTextPaint)

                currentY += 22f

                // Table Rows
                val rowHeight = 22f
                val maxY = (pageHeight - 45).toFloat()

                while (rowIndex < totalRows && currentY + rowHeight <= maxY) {
                    val row = rows[rowIndex]
                    val rowAmount = Math.round(row.totalAmount).toLong()
                    val rowPaid = Math.round(row.totalPaid).toLong()
                    val rowDue = (rowAmount - rowPaid).coerceAtLeast(0L)

                    // Zebra Background
                    if (rowIndex % 2 == 1) {
                        canvas.drawRect(20f, currentY, (pageWidth - 20).toFloat(), currentY + rowHeight, Paint().apply {
                            color = Color.rgb(248, 250, 252)
                        })
                    }

                    // Bottom divider line
                    canvas.drawLine(20f, currentY + rowHeight, (pageWidth - 20).toFloat(), currentY + rowHeight, linePaint)

                    val textY = currentY + 15f
                    canvas.drawText("${rowIndex + 1}", 26f, textY, textPaint)
                    canvas.drawText(row.customer.name.take(16), 48f, textY, Paint().apply {
                        textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD; color = Color.rgb(15, 23, 42)
                    })
                    canvas.drawText(row.customer.sO.ifBlank { "-" }.take(14), 175f, textY, textPaint)
                    canvas.drawText(row.customer.phone.ifBlank { "-" }.take(12), 270f, textY, textPaint)
                    val formattedTotalHours = if (row.totalHours < 1.0) AppFormatters.formatCompactDuration(row.totalHours) else "${String.format(Locale.ROOT, "%.1f", row.totalHours)}h"
                    canvas.drawText(formattedTotalHours, 365f, textY, textPaint)
                    canvas.drawText("₹${String.format(Locale.ROOT, "%,d", rowAmount)}", 420f, textY, textPaint)
                    canvas.drawText("₹${String.format(Locale.ROOT, "%,d", rowPaid)}", 480f, textY, greenPaidPaint)

                    if (rowDue > 0L) {
                        canvas.drawText("₹${String.format(Locale.ROOT, "%,d", rowDue)}", 535f, textY, redDuePaint)
                    } else {
                        canvas.drawText("₹0", 535f, textY, greenPaidPaint)
                    }

                    currentY += rowHeight
                    rowIndex++
                }

                // If no rows at all
                if (totalRows == 0) {
                    canvas.drawText("इस अवधि के लिए कोई किसान रिकॉर्ड नहीं है", 200f, currentY + 30f, Paint().apply {
                        color = Color.GRAY; textSize = 11f
                    })
                }

                // Footer
                val footerY = (pageHeight - 20).toFloat()
                canvas.drawText(
                    "🌾 जय जवान, जय किसान | डिजिटल बही-खाता (Tubewell & Sinchai App) • पृष्ठ $pageNumber 🌾",
                    (pageWidth / 2f),
                    footerY,
                    Paint().apply {
                        color = Color.rgb(100, 116, 139)
                        textSize = 8.5f
                        textAlign = Paint.Align.CENTER
                    }
                )

                pdfDoc.finishPage(page)
                pageNumber++
            }

            // Save to internal cache
            val file = File(context.cacheDir, "BahiKhata_Master_Report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(file)
            pdfDoc.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDoc.close()
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    data class CustomerTimelineEntry(
        val timestamp: Long,
        val type: String, // "सत्र (Session)" or "जमा (Deposit)"
        val hours: Double,
        val rate: Double,
        val totalAmount: Double,
        val paidAmount: Double,
        val dueAmount: Double,
        val note: String
    )

    fun generateCustomerReportPdf(
        context: Context,
        profile: ProfileEntity?,
        customer: CustomerEntity,
        sessions: List<TubewellSessionEntity>,
        transactions: List<TransactionEntity>,
        periodTitle: String,
        filteredHours: Double,
        filteredBilled: Double,
        filteredPaid: Double,
        filteredDue: Double,
        overallNetDue: Double
    ): File? {
        try {
            val pdfDoc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            val textPaint = Paint().apply {
                isAntiAlias = true
                color = Color.BLACK
                textSize = 9.5f
            }
            val titlePaint = Paint().apply {
                isAntiAlias = true
                color = Color.rgb(27, 94, 32) // Agriculture Dark Green
                textSize = 17f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val subTitlePaint = Paint().apply {
                isAntiAlias = true
                color = Color.rgb(230, 81, 0) // Royal Orange
                textSize = 11.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val headerBgPaint = Paint().apply {
                color = Color.rgb(232, 245, 233)
                style = Paint.Style.FILL
            }
            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 1f
            }

            var currentY = 38f

            // 1. Header Banner
            canvas.drawRect(20f, 18f, (pageWidth - 20).toFloat(), 88f, headerBgPaint)
            val agencyName = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "डिजिटल बही-खाता (Tubewell & Sinchai Seva)"
            canvas.drawText(agencyName, 32f, currentY + 6f, titlePaint)

            currentY += 26f
            val ownerInfo = "संचालक: ${profile?.name ?: "किसान मालिक"} | मो.: ${profile?.phone ?: "-"} | सामान्य दर: ₹${profile?.ratePerHour?.toInt() ?: 160}/घंटा"
            canvas.drawText(ownerInfo, 32f, currentY, Paint().apply {
                isAntiAlias = true
                color = Color.DKGRAY
                textSize = 10f
            })

            currentY += 40f

            // 2. Customer Information Card (Top section as requested)
            val infoCardPaint = Paint().apply {
                color = Color.rgb(248, 250, 252)
                style = Paint.Style.FILL
            }
            val infoCardBorderPaint = Paint().apply {
                color = Color.rgb(203, 213, 225)
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRoundRect(20f, currentY - 14f, (pageWidth - 20).toFloat(), currentY + 54f, 8f, 8f, infoCardPaint)
            canvas.drawRoundRect(20f, currentY - 14f, (pageWidth - 20).toFloat(), currentY + 54f, 8f, 8f, infoCardBorderPaint)

            val custNamePaint = Paint().apply {
                isAntiAlias = true
                color = Color.rgb(15, 23, 42)
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("👤 किसान का नाम: ${customer.name}", 32f, currentY + 4f, custNamePaint)
            canvas.drawText("👨‍👦 पिता का नाम: ${customer.sO.ifBlank { "लागू नहीं (-)" }}", 320f, currentY + 4f, textPaint)

            currentY += 22f
            canvas.drawText("📱 मोबाइल नंबर: ${if (customer.phone.isNotBlank()) customer.phone else "-"}", 32f, currentY + 2f, textPaint)
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            canvas.drawText("⏱️ रिपोर्ट अवधि: $periodTitle (प्रिंट: ${sdf.format(Date())})", 320f, currentY + 2f, textPaint)

            currentY += 44f

            // 3. Filtered Summary KPI Box (चयनित अवधि का कुल हिसाब)
            val kpiBgPaint = Paint().apply {
                color = Color.rgb(240, 253, 244)
                style = Paint.Style.FILL
            }
            val kpiBorderPaint = Paint().apply {
                color = Color.rgb(187, 247, 208)
                style = Paint.Style.STROKE
                strokeWidth = 1.5f
            }
            canvas.drawRoundRect(20f, currentY - 10f, (pageWidth - 20).toFloat(), currentY + 46f, 8f, 8f, kpiBgPaint)
            canvas.drawRoundRect(20f, currentY - 10f, (pageWidth - 20).toFloat(), currentY + 46f, 8f, 8f, kpiBorderPaint)

            val billedInt = Math.round(filteredBilled).toLong()
            val paidInt = Math.round(filteredPaid).toLong()
            val netDueInt = Math.round(overallNetDue).toLong()

            val hoursSummary = if (filteredHours < 1.0) AppFormatters.formatSessionDuration(filteredHours) else "${String.format(Locale.ROOT, "%.1f", filteredHours)} hrs"
            val summaryLine1 = "कुल चले घंटे: $hoursSummary   |   कुल बनी रकम: ₹${String.format(Locale.ROOT, "%,d", billedInt)}"
            val summaryLine2 = "कुल जमा रकम: ₹${String.format(Locale.ROOT, "%,d", paidInt)}   |   🔴 कुल बाकी शेष (Net Due): ₹${String.format(Locale.ROOT, "%,d", netDueInt)}"

            canvas.drawText(summaryLine1, 32f, currentY + 10f, Paint().apply {
                isAntiAlias = true
                color = Color.rgb(22, 101, 52)
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
            })
            canvas.drawText(summaryLine2, 32f, currentY + 30f, Paint().apply {
                isAntiAlias = true
                color = if (netDueInt > 0L) Color.rgb(185, 28, 28) else Color.rgb(22, 101, 52)
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
            })

            currentY += 66f

            // 4. Detailed History Table Header
            val thPaint = Paint().apply {
                color = Color.rgb(27, 94, 32)
                style = Paint.Style.FILL
            }
            canvas.drawRect(20f, currentY - 12f, (pageWidth - 20).toFloat(), currentY + 12f, thPaint)

            val thTextPaint = Paint().apply {
                color = Color.WHITE
                textSize = 9.5f
                typeface = Typeface.DEFAULT_BOLD
            }

            canvas.drawText("क्र.", 26f, currentY + 2f, thTextPaint)
            canvas.drawText("दिनांक व समय", 50f, currentY + 2f, thTextPaint)
            canvas.drawText("प्रकार / विवरण", 160f, currentY + 2f, thTextPaint)
            canvas.drawText("घंटे", 280f, currentY + 2f, thTextPaint)
            canvas.drawText("दर (₹)", 335f, currentY + 2f, thTextPaint)
            canvas.drawText("रकम (₹)", 395f, currentY + 2f, thTextPaint)
            canvas.drawText("जमा (₹)", 455f, currentY + 2f, thTextPaint)
            canvas.drawText("बाकी (₹)", 515f, currentY + 2f, thTextPaint)

            currentY += 22f

            // Combine Sessions and Deposits into timeline
            val timelineEntries = mutableListOf<CustomerTimelineEntry>()
            sessions.forEach { s ->
                timelineEntries.add(
                    CustomerTimelineEntry(
                        timestamp = s.sessionDate,
                        type = if (s.note.isNotBlank()) "सत्र: ${s.note}" else "ट्यूबवेल सिंचाई",
                        hours = s.hours,
                        rate = s.rate,
                        totalAmount = s.totalAmount,
                        paidAmount = s.paidAmount,
                        dueAmount = s.dueAmount,
                        note = s.note
                    )
                )
            }
            transactions.forEach { t ->
                timelineEntries.add(
                    CustomerTimelineEntry(
                        timestamp = t.depositDate,
                        type = "जमा (${t.paymentMode})",
                        hours = 0.0,
                        rate = 0.0,
                        totalAmount = 0.0,
                        paidAmount = t.amountDeposited,
                        dueAmount = 0.0,
                        note = t.note
                    )
                )
            }
            timelineEntries.sortByDescending { it.timestamp }

            val rowDateSdf = SimpleDateFormat("dd/MM/yy hh:mm a", Locale.getDefault())
            val redTextPaint = Paint().apply {
                color = Color.rgb(185, 28, 28)
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
            }
            val greenTextPaint = Paint().apply {
                color = Color.rgb(22, 101, 52)
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
            }

            if (timelineEntries.isEmpty()) {
                canvas.drawText("चयनित अवधि में कोई एंट्री दर्ज नहीं है", 200f, currentY + 10f, textPaint)
            } else {
                for ((index, entry) in timelineEntries.withIndex()) {
                    if (currentY > pageHeight - 65) break

                    if (index % 2 == 1) {
                        canvas.drawRect(20f, currentY - 10f, (pageWidth - 20).toFloat(), currentY + 8f, Paint().apply {
                            color = Color.rgb(250, 250, 250)
                        })
                    }

                    val rowTotalAmt = Math.round(entry.totalAmount).toLong()
                    val rowPaidAmt = Math.round(entry.paidAmount).toLong()
                    val rowDueAmt = (rowTotalAmt - rowPaidAmt).coerceAtLeast(0L)

                    canvas.drawText("${index + 1}", 26f, currentY + 2f, textPaint)
                    canvas.drawText(rowDateSdf.format(Date(entry.timestamp)), 50f, currentY + 2f, textPaint)
                    canvas.drawText(entry.type.take(18), 160f, currentY + 2f, textPaint)

                    if (entry.hours > 0) {
                        val durationCompact = if (entry.hours < 1.0) AppFormatters.formatCompactDuration(entry.hours) else "${String.format(Locale.ROOT, "%.1f", entry.hours)}h"
                        canvas.drawText(durationCompact, 280f, currentY + 2f, textPaint)
                        canvas.drawText("₹${entry.rate.toInt()}", 335f, currentY + 2f, textPaint)
                        canvas.drawText("₹${String.format(Locale.ROOT, "%,d", rowTotalAmt)}", 395f, currentY + 2f, textPaint)
                    } else {
                        canvas.drawText("-", 280f, currentY + 2f, textPaint)
                        canvas.drawText("-", 335f, currentY + 2f, textPaint)
                        canvas.drawText("-", 395f, currentY + 2f, textPaint)
                    }

                    canvas.drawText("₹${String.format(Locale.ROOT, "%,d", rowPaidAmt)}", 455f, currentY + 2f, if (rowPaidAmt > 0L) greenTextPaint else textPaint)
                    if (rowDueAmt > 0L && entry.hours > 0) {
                        canvas.drawText("₹${String.format(Locale.ROOT, "%,d", rowDueAmt)}", 515f, currentY + 2f, redTextPaint)
                    } else {
                        canvas.drawText(if (entry.hours > 0) "चुक्ता" else "-", 515f, currentY + 2f, textPaint)
                    }

                    currentY += 18f
                    canvas.drawLine(20f, currentY - 4f, (pageWidth - 20).toFloat(), currentY - 4f, linePaint)
                }
            }

            // 5. Footer & Signature
            currentY = (pageHeight - 38).toFloat()
            val footerPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 8.5f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("🌾 जय जवान, जय किसान | डिजिटल बही-खाता (Tubewell & Sinchai Seva) 🌾", (pageWidth / 2).toFloat(), currentY, footerPaint)

            pdfDoc.finishPage(page)

            val file = File(context.cacheDir, "Khata_${customer.name.replace(" ", "_")}_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(file)
            pdfDoc.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDoc.close()
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}
