package com.example.data.service

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Android WorkManager Background Worker that executes periodically even when the app
 * is completely closed, killed, or the phone was restarted (like YouTube / messaging apps).
 *
 * It reads the local Room Database, calculates overdue accounts, farmer hours summaries,
 * and posts timely notifications directly into the Android system notification tray.
 */
class DuePaymentNotificationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "DuePaymentWorker"
        const val WORK_NAME_PERIODIC = "tubewell_periodic_due_and_hours_check"
        const val WORK_NAME_ONE_TIME = "tubewell_one_time_due_and_hours_check"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "DuePaymentNotificationWorker started background calculation...")
        try {
            val context = applicationContext

            // 1. Check if auto due reminder is enabled by the owner
            val isAutoEnabled = DuePaymentReminderManager.isAutoReminderEnabled(context)
            if (!isAutoEnabled) {
                Log.d(TAG, "Auto reminder is disabled in preferences. Skipping.")
                return@withContext Result.success()
            }

            // 2. Perform background calculation from Room DB & post notifications
            val selectedDuration = DuePaymentReminderManager.getSelectedDuration(context)
            val notifiedCount = DuePaymentReminderManager.checkAndPostDueNotifications(
                context = context,
                minDuration = selectedDuration,
                isManualTrigger = false
            )

            Log.d(TAG, "DuePaymentNotificationWorker finished successfully. Notified: $notifiedCount accounts.")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Error running DuePaymentNotificationWorker: ${e.message}", e)
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure()
            }
        }
    }
}
