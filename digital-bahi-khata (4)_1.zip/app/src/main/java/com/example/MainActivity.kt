package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.data.payment.RazorpayManager
import com.example.data.util.EmailVerificationManager
import com.example.ui.screens.*
import com.example.ui.theme.DigitalBahiKhataTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.MainTab
import com.razorpay.PaymentResultListener

class MainActivity : ComponentActivity(), PaymentResultListener {
    private val viewModel: BahiKhataViewModel by viewModels()

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Preload Razorpay checkout for fast opening
        RazorpayManager.preload(this)

        // Request POST_NOTIFICATIONS for Android 13+ to support permanent live timer status notification
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Handle incoming deep link if launched via email confirmation
        handleDeepLink(intent)

        setContent {
            val fontScale by viewModel.fontScale.collectAsState()
            val currentLanguage by viewModel.currentLanguage.collectAsState()

            DigitalBahiKhataTheme(fontScale = fontScale) {
                key(currentLanguage) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        AppNavigation(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String?) {
        RazorpayManager.onPaymentSuccess(razorpayPaymentID)
    }

    override fun onPaymentError(errorCode: Int, responseDescription: String?) {
        RazorpayManager.onPaymentError(errorCode, responseDescription)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDeepLink(intent)
    }

    private fun handleDeepLink(intent: android.content.Intent?) {
        val data = intent?.data ?: return
        android.util.Log.d("MainActivity", "Deep link received: $data")
        if (data.scheme == "tubewell") {
            val queryEmail = data.getQueryParameter("email")?.trim()?.lowercase() ?: ""
            val profile = viewModel.profile.value
            val targetEmail = queryEmail.ifBlank {
                profile?.email?.ifBlank { null } ?: EmailVerificationManager.getLastOtpEmail(this)
            }
            if (targetEmail.isNotBlank()) {
                viewModel.updateOwnerEmail(targetEmail, true)
            }
            EmailVerificationManager.notifyEmailConfirmedViaDeepLink(targetEmail)
            android.widget.Toast.makeText(this, "🎉 बधाई हो! ईमेल सफलतापूर्वक सत्यापित हो गया!", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun AppNavigation(viewModel: BahiKhataViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val selectedCustomerId by viewModel.selectedCustomerId.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()

    // Determine if back press should navigate within app or allow system back to exit/minimize
    val shouldInterceptBack = when (currentScreen) {
        AppScreen.MAIN_CONTAINER -> (selectedCustomerId != null || currentTab != MainTab.HOME)
        AppScreen.AUTH_CHOICE -> true
        AppScreen.SIGN_UP, AppScreen.LOGIN, AppScreen.FORGOT_PASSWORD -> true
        else -> false
    }

    // Handle back button for screens
    BackHandler(enabled = shouldInterceptBack) {
        when (currentScreen) {
            AppScreen.MAIN_CONTAINER -> {
                if (selectedCustomerId != null) {
                    viewModel.clearSelectedCustomer()
                } else if (currentTab != MainTab.HOME) {
                    viewModel.setTab(MainTab.HOME)
                }
            }
            AppScreen.AUTH_CHOICE -> viewModel.navigateTo(AppScreen.LANGUAGE_SELECT)
            AppScreen.SIGN_UP, AppScreen.LOGIN -> viewModel.navigateTo(AppScreen.AUTH_CHOICE)
            AppScreen.FORGOT_PASSWORD -> viewModel.navigateTo(AppScreen.LOGIN)
            else -> {}
        }
    }

    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
            AppScreen.SPLASH -> SplashScreen(viewModel = viewModel)
            AppScreen.LANGUAGE_SELECT -> LanguageSelectScreen(viewModel = viewModel)
            AppScreen.AUTH_CHOICE -> AuthChoiceScreen(viewModel = viewModel)
            AppScreen.SIGN_UP -> SignUpScreen(viewModel = viewModel)
            AppScreen.LOGIN -> LoginScreen(viewModel = viewModel)
            AppScreen.FORGOT_PASSWORD -> ForgotPasswordScreen(viewModel = viewModel)
            AppScreen.MAIN_CONTAINER -> MainContainerScreen(viewModel = viewModel)
        }
    }
}
