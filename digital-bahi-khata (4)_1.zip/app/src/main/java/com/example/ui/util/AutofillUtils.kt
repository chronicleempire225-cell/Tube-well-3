package com.example.ui.util

import android.content.Context
import android.os.Build
import android.view.autofill.AutofillManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.autofill.AutofillNode
import androidx.compose.ui.autofill.AutofillType
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalAutofill
import androidx.compose.ui.platform.LocalAutofillTree

/**
 * Android & Google Autofill (Password Manager) Utility for Login & SignUp.
 * Provides keyboard suggestions for Phone number and Password / PIN,
 * and triggers "Save credentials to Google" prompt on successful login/registration.
 */
object AutofillUtils {

    @OptIn(ExperimentalComposeUiApi::class)
    @Composable
    fun Modifier.autofill(
        autofillTypes: List<AutofillType>,
        onFill: (String) -> Unit
    ): Modifier {
        val autofill = LocalAutofill.current
        val autofillNode = AutofillNode(onFill = onFill, autofillTypes = autofillTypes)
        LocalAutofillTree.current += autofillNode

        return this
            .onGloballyPositioned { coordinates ->
                autofillNode.boundingBox = coordinates.boundsInWindow()
            }
            .onFocusChanged { focusState ->
                autofill?.run {
                    if (focusState.isFocused) {
                        requestAutofillForNode(autofillNode)
                    } else {
                        cancelAutofillForNode(autofillNode)
                    }
                }
            }
    }

    /**
     * Mobile Number / Username autofill for keyboard suggestion & auto-fill.
     */
    @OptIn(ExperimentalComposeUiApi::class)
    @Composable
    fun Modifier.autofillPhone(onFill: (String) -> Unit): Modifier {
        return this.autofill(
            autofillTypes = listOf(
                AutofillType.PhoneNumber,
                AutofillType.PhoneNumberNational,
                AutofillType.PhoneNumberDevice,
                AutofillType.Username
            ),
            onFill = { raw ->
                // Clean phone number: keep only 10 digits
                val clean = raw.filter { it.isDigit() }.let {
                    if (it.length > 10 && (it.startsWith("91") || it.startsWith("0"))) {
                        it.takeLast(10)
                    } else {
                        it.take(10)
                    }
                }
                onFill(clean)
            }
        )
    }

    /**
     * Existing Password / Security PIN autofill for Login.
     */
    @OptIn(ExperimentalComposeUiApi::class)
    @Composable
    fun Modifier.autofillLoginPassword(onFill: (String) -> Unit): Modifier {
        return this.autofill(
            autofillTypes = listOf(AutofillType.Password),
            onFill = onFill
        )
    }

    /**
     * New Password / Security PIN autofill for SignUp (triggers Google to save).
     */
    @OptIn(ExperimentalComposeUiApi::class)
    @Composable
    fun Modifier.autofillNewPassword(onFill: (String) -> Unit): Modifier {
        return this.autofill(
            autofillTypes = listOf(AutofillType.NewPassword, AutofillType.Password),
            onFill = onFill
        )
    }

    /**
     * Owner Name autofill for SignUp.
     */
    @OptIn(ExperimentalComposeUiApi::class)
    @Composable
    fun Modifier.autofillPersonName(onFill: (String) -> Unit): Modifier {
        return this.autofill(
            autofillTypes = listOf(AutofillType.PersonFullName),
            onFill = onFill
        )
    }

    /**
     * Email Address autofill for keyboard suggestion & auto-fill.
     */
    @OptIn(ExperimentalComposeUiApi::class)
    @Composable
    fun Modifier.autofillEmail(onFill: (String) -> Unit): Modifier {
        return this.autofill(
            autofillTypes = listOf(AutofillType.EmailAddress),
            onFill = { onFill(it.trim()) }
        )
    }

    /**
     * Commits the current autofill context so Android prompts:
     * "Save password to Google Password Manager?"
     */
    fun commitAutofill(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val autofillManager = context.getSystemService(AutofillManager::class.java)
                autofillManager?.commit()
            } catch (ignored: Exception) {}
        }
    }

    /**
     * Cancels the current autofill session if login failed.
     */
    fun cancelAutofill(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val autofillManager = context.getSystemService(AutofillManager::class.java)
                autofillManager?.cancel()
            } catch (ignored: Exception) {}
        }
    }
}

