package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.SupabaseAuthService
import com.example.data.util.ShareHelper
import com.example.ui.components.AppTopBar
import com.example.ui.components.appTextFieldColors
import com.example.ui.theme.*
import com.example.ui.util.AutofillUtils
import com.example.ui.util.AutofillUtils.autofillLoginPassword
import com.example.ui.util.AutofillUtils.autofillPhone
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.BahiKhataViewModel

@Composable
fun LoginScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val focusManager = LocalFocusManager.current

    // State for Mobile and Password
    var mobileNumber by remember { mutableStateOf("") }
    var passwordOrPin by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var botTrapHoneypot by remember { mutableStateOf("") }
    val isOnline = remember { SupabaseAuthService.isNetworkAvailable(context) }

    key(currentLang) {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = viewModel.getString("login_screen_title"),
                    viewModel = viewModel,
                    showBackButton = true,
                    onBackClick = { viewModel.navigateTo(AppScreen.AUTH_CHOICE) }
                )
            },
            containerColor = OffWhiteBackground
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Spacer(modifier = Modifier.height(8.dp))

                    // Brand Icon Header
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(AgriGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Login",
                            tint = AgriGreenPrimary,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = viewModel.getString("login_screen_title"),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = AgriGreenPrimary,
                        fontSize = 22.sp,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = viewModel.getString("login_screen_subtitle"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    // Network Status Banner
                    Surface(
                        color = if (isOnline) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, if (isOnline) Color(0xFFA5D6A7) else Color(0xFFFFCDD2)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 14.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isOnline) Color(0xFF2E7D32) else Color(0xFFC62828))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isOnline) "🟢 क्लाउड कनेक्टेड (लाइव प्रमाणीकरण)" else "🔴 इंटरनेट बंद है (केवल ऑफ़लाइन सहेजे गए खाते की अनुमति)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isOnline) Color(0xFF1B5E20) else Color(0xFFB71C1C),
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Card Form Container
                    Surface(
                        color = SurfaceCard,
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // 1. Mobile Number (Strict 10 digits only)
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = viewModel.getString("mobile_number"),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "${mobileNumber.length}/10",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (mobileNumber.length == 10) AgriGreenPrimary else TextMuted
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = mobileNumber,
                                    onValueChange = { input ->
                                        // Strictly allow only digits and max 10 characters
                                        val cleanDigits = input.filter { it.isDigit() }.take(10)
                                        mobileNumber = cleanDigits
                                        errorMessage = null
                                    },
                                    placeholder = { Text("10 अंकों का मोबाइल नंबर दर्ज करें") },
                                    leadingIcon = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(start = 12.dp, end = 6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Phone,
                                                contentDescription = "Phone",
                                                tint = AgriGreenPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "+91",
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary,
                                                fontSize = 14.sp
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Box(
                                                modifier = Modifier
                                                    .height(18.dp)
                                                    .width(1.dp)
                                                    .background(Color(0xFFCBD5E1))
                                            )
                                        }
                                    },
                                    trailingIcon = {
                                        if (mobileNumber.isNotEmpty()) {
                                            IconButton(onClick = { mobileNumber = ""; errorMessage = null }) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "Clear",
                                                    tint = TextSecondary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    },
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Number,
                                        imeAction = ImeAction.Next
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                    ),
                                    singleLine = true,
                                    colors = appTextFieldColors(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .autofillPhone { mobileNumber = it }
                                        .testTag("login_mobile_input")
                                )
                            }

                            // 2. Password or Security PIN
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = viewModel.getString("password_or_pin_label"),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "पासवर्ड भूल गए?",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalOrange,
                                        modifier = Modifier
                                            .clickable { viewModel.navigateTo(AppScreen.FORGOT_PASSWORD) }
                                            .testTag("login_forgot_password_button")
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = passwordOrPin,
                                    onValueChange = {
                                        passwordOrPin = it
                                        errorMessage = null
                                    },
                                    placeholder = { Text("पासवर्ड या 4-अंकों का पिन दर्ज करें") },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "Password",
                                            tint = RoyalOrange,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                            Icon(
                                                imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                contentDescription = if (isPasswordVisible) "Hide" else "Show",
                                                tint = TextSecondary
                                            )
                                        }
                                    },
                                    visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Password,
                                        imeAction = ImeAction.Done
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onDone = {
                                            focusManager.clearFocus()
                                            performLogin(context, viewModel, mobileNumber, passwordOrPin, botTrapHoneypot, { isLoading = it }, { errorMessage = it })
                                        }
                                    ),
                                    singleLine = true,
                                    colors = appTextFieldColors(focusedBorderColor = RoyalOrange, focusedLabelColor = RoyalOrange),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .autofillLoginPassword { passwordOrPin = it }
                                        .testTag("login_password_input")
                                )
                            }

                            // Hidden honeypot field for bot trapping (invisible to normal users)
                            Box(modifier = Modifier.size(0.dp).padding(0.dp)) {
                                TextField(
                                    value = botTrapHoneypot,
                                    onValueChange = { botTrapHoneypot = it },
                                    modifier = Modifier.size(0.dp),
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent
                                    )
                                )
                            }

                            // Error Message Banner
                            if (errorMessage != null) {
                                Surface(
                                    color = DueRedContainer,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFFFFCDD2)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ErrorOutline,
                                            contentDescription = "Error",
                                            tint = DueRed,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = errorMessage ?: "",
                                            color = DueRed,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            // 3. Login Button
                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    performLogin(context, viewModel, mobileNumber, passwordOrPin, botTrapHoneypot, { isLoading = it }, { errorMessage = it })
                                },
                                enabled = !isLoading,
                                colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("login_submit_button")
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(22.dp),
                                        strokeWidth = 2.5.dp
                                    )
                                } else {
                                    Text(
                                        text = viewModel.getString("login_action_button"),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Footer: Support at Bottom-Left & Navigate to Sign Up
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. Bottom-Left Support Button
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .clickable { ShareHelper.openSupportEmail(context) }
                            .testTag("login_support_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.HeadsetMic,
                                contentDescription = "Support",
                                tint = AgriGreenPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Support / Help",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        }
                    }

                    // 2. Navigate to Sign Up
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "खाता नहीं है?",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = viewModel.getString("create_new_account"),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = RoyalOrange,
                            modifier = Modifier
                                .clickable { viewModel.navigateTo(AppScreen.SIGN_UP) }
                                .testTag("login_to_signup_link")
                        )
                    }
                }
            }
        }
    }
}

private fun performLogin(
    context: android.content.Context,
    viewModel: BahiKhataViewModel,
    mobile: String,
    passwordOrPin: String,
    botTrapHoneypot: String = "",
    setLoading: (Boolean) -> Unit,
    setError: (String?) -> Unit
) {
    if (com.example.data.security.AppSecurityService.isBotTrapTriggered(botTrapHoneypot)) {
        setError("⛔ स्वचालित बॉट / स्पैम का पता चला! अनुरोध निरस्त कर दिया गया है।")
        return
    }

    val cleanMobile = mobile.trim()
    val cleanPass = passwordOrPin.trim()

    if (cleanMobile.isEmpty()) {
        setError("कृपया 10 अंकों का मोबाइल नंबर दर्ज करें!")
        return
    }
    if (cleanMobile.length != 10 || !cleanMobile.matches(Regex("^[6-9]\\d{9}$"))) {
        setError("कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें (6, 7, 8 या 9 से शुरू)!")
        return
    }
    if (cleanPass.isEmpty()) {
        setError("कृपया पासवर्ड या 4-अंकों का पिन दर्ज करें!")
        return
    }

    setLoading(true)
    setError(null)

    viewModel.loginWithMobileAndPassword(
        mobile = cleanMobile,
        passwordOrPin = cleanPass,
        onSuccess = {
            setLoading(false)
            // Trigger Android / Google Password Manager to save credentials
            AutofillUtils.commitAutofill(context)
        },
        onError = { err ->
            setLoading(false)
            setError(err)
            AutofillUtils.cancelAutofill(context)
        }
    )
}
