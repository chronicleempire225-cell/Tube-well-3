package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.CustomerEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.SessionInputMode
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionEntryBottomSheet(
    customer: CustomerEntity?,
    viewModel: BahiKhataViewModel,
    onDismiss: () -> Unit,
    onViewLiveTimerOnHome: () -> Unit
) {
    if (customer == null) return

    val profile by viewModel.profile.collectAsState()
    val currentMode by viewModel.sessionInputMode.collectAsState()

    // Live Timer state
    val isTimerRunningRaw by viewModel.isLiveTimerRunning.collectAsState()
    val isTimerPaused by viewModel.isLiveTimerPaused.collectAsState()
    val isTimerRunning = isTimerRunningRaw && !isTimerPaused
    val timerSeconds by viewModel.liveTimerSeconds.collectAsState()

    // Start-End state (12-Hour Format)
    val startHour by viewModel.startHourText.collectAsState()
    val startMin by viewModel.startMinText.collectAsState()
    val startAmPm by viewModel.startAmPmText.collectAsState()
    val endHour by viewModel.endHourText.collectAsState()
    val endMin by viewModel.endMinText.collectAsState()
    val endAmPm by viewModel.endAmPmText.collectAsState()

    // Ensure live time is refreshed for end time and start time is 00:00
    LaunchedEffect(Unit) {
        viewModel.resetStartEndTimeDefaults()
    }

    // Direct Hours state
    val directHours by viewModel.directHoursText.collectAsState()

    // Rate & Paid state
    val formRate by viewModel.formRate.collectAsState()
    val formPaidAmount by viewModel.formPaidAmount.collectAsState()

    var showAdjustTimeDialog by remember { mutableStateOf(false) }
    var adjustHoursInput by remember { mutableStateOf("") }
    var adjustMinsInput by remember { mutableStateOf("") }

    // Calculate effective hours based on selected mode
    val effectiveHours = when (currentMode) {
        SessionInputMode.LIVE_TIMER -> (timerSeconds / 3600.0)
        SessionInputMode.START_END_TIME -> viewModel.calculate12HourDurationInHours(startHour, startMin, startAmPm, endHour, endMin, endAmPm)
        SessionInputMode.DIRECT_HOURS -> (directHours.toDoubleOrNull() ?: 0.0)
    }

    val ratePerHour = formRate.toDoubleOrNull() ?: (profile?.ratePerHour ?: 160.0)
    val totalCharge = effectiveHours * ratePerHour
    val paidAmount = formPaidAmount.toDoubleOrNull() ?: 0.0
    val dueAmount = (totalCharge - paidAmount).coerceAtLeast(0.0)

    // 🛡️ Bot Protection State: 1. Invisible Honeypot & 2. Interaction Timing
    var sessionHoneypot by remember { mutableStateOf("") }
    val sheetOpenedAt = remember { System.currentTimeMillis() }

    val scrollState = rememberScrollState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(top = 12.dp, bottom = 6.dp)
                    .width(44.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFCBD5E1))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 🛡️ 1. Invisible Honeypot Trap (बॉट सुरक्षा जाल - सामान्य किसान को नहीं दिखता)
            Box(
                modifier = Modifier
                    .size(0.dp)
                    .clipToBounds()
            ) {
                BasicTextField(
                    value = sessionHoneypot,
                    onValueChange = { sessionHoneypot = it },
                    modifier = Modifier.testTag("session_form_honeypot_field")
                )
            }

            // 1. Farmer Header Card (Water drop icon, Name, Father's Name, Phone, Close button)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Green Water Drop Icon
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5E9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = "Tubewell",
                            tint = Color(0xFF1B5E20),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = customer.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val subtitle = buildString {
                            if (customer.sO.isNotBlank()) append("पिता: ${customer.sO} • ")
                            if (customer.phone.isNotBlank()) append("📞 ${customer.phone}")
                        }
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Close Button
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color(0xFF475569),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // 2. Three Tab Pill Selector (लाइव टाइमर, शुरू-अंत समय, सीधे घंटे)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFE2E8F0))
                    .padding(5.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Tab 1: Live Timer
                SessionTabPill(
                    title = "लाइव टाइमर",
                    icon = Icons.Default.Timer,
                    isSelected = currentMode == SessionInputMode.LIVE_TIMER,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.sessionInputMode.value = SessionInputMode.LIVE_TIMER }
                )

                // Tab 2: Start-End Time
                SessionTabPill(
                    title = "शुरू-अंत समय",
                    icon = Icons.Default.Schedule,
                    isSelected = currentMode == SessionInputMode.START_END_TIME,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.sessionInputMode.value = SessionInputMode.START_END_TIME }
                )

                // Tab 3: Direct Hours
                SessionTabPill(
                    title = "सीधे घंटे",
                    icon = Icons.Default.EventNote,
                    isSelected = currentMode == SessionInputMode.DIRECT_HOURS,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.sessionInputMode.value = SessionInputMode.DIRECT_HOURS }
                )
            }

            // 3. Tab Specific Content Area
            when (currentMode) {
                SessionInputMode.LIVE_TIMER -> {
                    LiveTimerContent(
                        isTimerRunning = isTimerRunning,
                        timerSeconds = timerSeconds,
                        ratePerHour = ratePerHour,
                        onStart = { viewModel.startLiveTimer(customer.id) },
                        onPause = { viewModel.pauseLiveTimer() },
                        onResume = { viewModel.resumeLiveTimer() },
                        onAdjustClick = {
                            val hrs = timerSeconds / 3600
                            val mins = (timerSeconds % 3600) / 60
                            adjustHoursInput = hrs.toString()
                            adjustMinsInput = mins.toString()
                            showAdjustTimeDialog = true
                        },
                        onViewOnHomeScreen = {
                            if (!isTimerRunning && timerSeconds == 0L) {
                                viewModel.startLiveTimer(customer.id)
                            }
                            onViewLiveTimerOnHome()
                        }
                    )
                }

                SessionInputMode.START_END_TIME -> {
                    StartEndTimeContent(
                        startHour = startHour,
                        startMin = startMin,
                        startAmPm = startAmPm,
                        endHour = endHour,
                        endMin = endMin,
                        endAmPm = endAmPm,
                        calculatedHours = effectiveHours,
                        onStartHourChange = { viewModel.startHourText.value = it },
                        onStartMinChange = { viewModel.startMinText.value = it },
                        onStartAmPmChange = { viewModel.startAmPmText.value = it },
                        onEndHourChange = { viewModel.endHourText.value = it },
                        onEndMinChange = { viewModel.endMinText.value = it },
                        onEndAmPmChange = { viewModel.endAmPmText.value = it },
                        onQuickStartMin = { viewModel.setStartMinuteQuick(it) },
                        onQuickEndMin = { viewModel.setEndMinuteQuick(it) },
                        onSetEndLiveTime = { viewModel.setEndTimeToLiveCurrentTime() }
                    )
                }

                SessionInputMode.DIRECT_HOURS -> {
                    DirectHoursContent(
                        directHours = directHours,
                        onHoursChange = { viewModel.directHoursText.value = it },
                        onAddHours = { viewModel.addDirectHours(it) },
                        onClear = { viewModel.clearDirectHours() }
                    )
                }
            }

            // 4. Common Billing & Payment Section (Hourly Rate & Billing)
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "💰 दर एवं बिल गणना (Hourly Rate & Billing):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A),
                        fontSize = 14.sp
                    )

                    // Rate & Total Charge Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Rate Field (Bold, HD, auto-persisting as default)
                        OutlinedTextField(
                            value = formRate,
                            onValueChange = { viewModel.updateDefaultRate(it) },
                            label = { Text("दर (₹/घंटा)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B)) },
                            prefix = { Text("₹ ", fontWeight = FontWeight.Black, color = Color(0xFF0F172A), fontSize = 16.sp) },
                            textStyle = TextStyle(
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A)
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = appTextFieldColors(containerColor = Color.White),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("session_rate_input")
                        )

                        // Total Charge Box (Calculated, Ultra High Contrast)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.5.dp, Color(0xFF16A34A)),
                            color = Color(0xFFF0FDF4),
                            modifier = Modifier
                                .weight(1f)
                                .height(58.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "कुल चार्ज (₹)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF15803D),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "₹ ${String.format(Locale.ROOT, "%,d", Math.round(totalCharge))}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF14532D),
                                    fontSize = 17.sp
                                )
                            }
                        }
                    }

                    // Paid Amount Field with 'पूरा' Quick Button
                    OutlinedTextField(
                        value = formPaidAmount,
                        onValueChange = { viewModel.formPaidAmount.value = it },
                        label = { Text("आज जमा नकद राशि (Paid Amount)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B)) },
                        placeholder = { Text("0.00", color = Color(0xFF94A3B8)) },
                        prefix = { Text("₹ ", fontWeight = FontWeight.Black, color = Color(0xFF0F172A), fontSize = 16.sp) },
                        textStyle = TextStyle(
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A)
                        ),
                        trailingIcon = {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1B5E20),
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .clickable {
                                        viewModel.formPaidAmount.value = "${Math.round(totalCharge)}"
                                    }
                            ) {
                                Text(
                                    text = "पूरा ₹",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("session_paid_input")
                    )

                    // Remaining Balance Row (आज का बाकी बकाया)
                    Surface(
                        color = if (dueAmount > 0) Color(0xFFFEF2F2) else Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (dueAmount > 0) Color(0xFFFCA5A5) else Color(0xFF86EFAC)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "आज का बाकी बकाया:",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (dueAmount > 0) Color(0xFFB71C1C) else Color(0xFF15803D),
                                fontSize = 14.sp
                            )

                            Text(
                                text = "₹${String.format(Locale.ROOT, "%,d", Math.round(dueAmount))}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = if (dueAmount > 0) Color(0xFFB71C1C) else Color(0xFF15803D),
                                fontSize = 17.sp
                            )
                        }
                    }
                }
            }

            // 5. Main Action Confirmation Button (✓ सत्र समाप्त करें एवं बही-खाता में जोड़ें)
            Button(
                onClick = {
                    val saved = viewModel.saveSessionFromActiveMode(
                        customerId = customer.id,
                        customHours = effectiveHours,
                        customRate = ratePerHour,
                        customPaid = paidAmount,
                        honeypotText = sessionHoneypot,
                        openedAtMillis = sheetOpenedAt
                    )
                    if (saved) {
                        onDismiss()
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("submit_session_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "✓ सत्र समाप्त करें एवं बही-खाता में जोड़ें",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }

    // Manual Time Adjust Dialog
    if (showAdjustTimeDialog) {
        AlertDialog(
            onDismissRequest = { showAdjustTimeDialog = false },
            title = {
                Text(
                    text = "समय सुधारें (Adjust Time)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFF0F172A)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "लाइव टाइमर के कुल घंटे और मिनट दर्ज करें:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = adjustHoursInput,
                            onValueChange = { adjustHoursInput = it },
                            label = { Text("घंटे") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = adjustMinsInput,
                            onValueChange = { adjustMinsInput = it },
                            label = { Text("मिनट") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val h = adjustHoursInput.toLongOrNull() ?: 0L
                        val m = adjustMinsInput.toLongOrNull() ?: 0L
                        val totalSecs = h * 3600 + m * 60
                        viewModel.liveTimerSeconds.value = totalSecs
                        showAdjustTimeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20))
                ) {
                    Text("लागू करें (Apply)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdjustTimeDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

// -------------------------------------------------------------
// TAB PILL
// -------------------------------------------------------------
@Composable
private fun SessionTabPill(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) Color(0xFF1B5E20) else Color.White,
        shape = RoundedCornerShape(10.dp),
        shadowElevation = if (isSelected) 2.dp else 0.dp,
        border = if (!isSelected) BorderStroke(1.dp, Color(0xFFCBD5E1)) else null,
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.White else Color(0xFF1E293B),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isSelected) Color.White else Color(0xFF0F172A),
                fontSize = 13.sp,
                maxLines = 1
            )
        }
    }
}

// -------------------------------------------------------------
// TAB 1: LIVE STOPWATCH TIMER CONTENT (Matching Screenshot 1)
// -------------------------------------------------------------
@Composable
private fun LiveTimerContent(
    isTimerRunning: Boolean,
    timerSeconds: Long,
    ratePerHour: Double,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onAdjustClick: () -> Unit,
    onViewOnHomeScreen: () -> Unit
) {
    val hrs = timerSeconds / 3600
    val mins = (timerSeconds % 3600) / 60
    val secs = timerSeconds % 60
    val timeFormatted = String.format(Locale.ROOT, "%02d:%02d:%02d", hrs, mins, secs)

    val decimalHours = timerSeconds / 3600.0
    val totalCost = decimalHours * ratePerHour

    Surface(
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Subtitle
            Text(
                text = if (isTimerRunning) "🟢 लाइव स्टॉपवॉच चल रही है..." else "लाइव स्टॉपवॉच शुरू करें",
                style = MaterialTheme.typography.bodySmall,
                color = if (isTimerRunning) Color(0xFF1B5E20) else Color(0xFF64748B),
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )

            // Huge Timer Digits (00:00:00)
            Text(
                text = timeFormatted,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Black,
                color = Color(0xFF0F172A),
                fontSize = 42.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )

            // Calculation subtext with rupees and paise
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "${String.format(Locale.ROOT, "%.2f", decimalHours)} घंटे @ ₹${ratePerHour.toInt()}/घंटा = ",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF334155),
                        fontSize = 13.sp
                    )
                    Text(
                        text = "₹${String.format(Locale.ROOT, "%,d", Math.round(totalCost))}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF15803D),
                        fontSize = 15.sp
                    )
                }
            }

            // Action Buttons Row: [▶ शुरू करें / ⏸ रोकें] [🎛 समय सुधारें]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Start / Pause / Resume Button
                Button(
                    onClick = {
                        if (isTimerRunning) {
                            onPause()
                        } else if (timerSeconds > 0L) {
                            onResume()
                        } else {
                            onStart()
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isTimerRunning) Color(0xFFE65100) else Color(0xFF1B5E20)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("live_timer_toggle_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isTimerRunning) "⏸ रोकें" else if (timerSeconds > 0L) "▶ पुनः शुरू" else "▶ शुरू करें",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }

                // Adjust Time Button
                OutlinedButton(
                    onClick = onAdjustClick,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF0F172A)),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFF334155),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🎛 समय सुधारें",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Dark Pill Button: 🏠 ▶ होमस्क्रीन पर लाइव टाइमर देखें
            Surface(
                color = Color(0xFF0F172A),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onViewOnHomeScreen)
                    .testTag("view_timer_on_home_button")
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "▶",
                        color = Color(0xFFFFB74D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "होमस्क्रीन पर लाइव टाइमर देखें",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

// Helper to cleanly handle 00 placeholder / typing over 00 without blocking user inputs
private fun cleanTimeDigitInput(input: String, currentValue: String, maxVal: Int): String {
    if (input.isEmpty()) return ""
    val digits = input.filter { it.isDigit() }
    if (digits.isEmpty()) return ""

    val result = if (currentValue == "00" || currentValue == "0") {
        val nonZero = digits.trimStart('0')
        if (nonZero.isNotEmpty()) nonZero.take(2) else "0"
    } else {
        if (digits.length > 2) {
            digits.takeLast(2)
        } else {
            digits
        }
    }
    val num = result.toIntOrNull() ?: 0
    return if (num <= maxVal) result else currentValue
}

@Composable
private fun AmPmSegmentedSelector(
    selectedAmPm: String,
    onSelect: (String) -> Unit,
    activeColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF1F5F9),
        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val isAm = selectedAmPm.equals("AM", ignoreCase = true)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isAm) activeColor else Color.Transparent,
                border = if (!isAm) BorderStroke(1.dp, Color(0xFFE2E8F0)) else null,
                shadowElevation = if (isAm) 2.dp else 0.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSelect("AM") }
            ) {
                Text(
                    text = "सुबह (AM)",
                    color = if (isAm) Color.White else Color(0xFF334155),
                    fontWeight = if (isAm) FontWeight.Black else FontWeight.Bold,
                    fontSize = 11.5.sp,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }

            val isPm = selectedAmPm.equals("PM", ignoreCase = true)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isPm) activeColor else Color.Transparent,
                border = if (!isPm) BorderStroke(1.dp, Color(0xFFE2E8F0)) else null,
                shadowElevation = if (isPm) 2.dp else 0.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSelect("PM") }
            ) {
                Text(
                    text = "शाम (PM)",
                    color = if (isPm) Color.White else Color(0xFF334155),
                    fontWeight = if (isPm) FontWeight.Black else FontWeight.Bold,
                    fontSize = 11.5.sp,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 2: START-END TIME CONTENT (HD Quality for Farmers)
// -------------------------------------------------------------
@Composable
private fun StartEndTimeContent(
    startHour: String,
    startMin: String,
    startAmPm: String,
    endHour: String,
    endMin: String,
    endAmPm: String,
    calculatedHours: Double,
    onStartHourChange: (String) -> Unit,
    onStartMinChange: (String) -> Unit,
    onStartAmPmChange: (String) -> Unit,
    onEndHourChange: (String) -> Unit,
    onEndMinChange: (String) -> Unit,
    onEndAmPmChange: (String) -> Unit,
    onQuickStartMin: (Int) -> Unit,
    onQuickEndMin: (Int) -> Unit,
    onSetEndLiveTime: () -> Unit
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = Color(0xFF1B5E20),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "12-घंटे समय चयन (Start - End Time):",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF0F172A),
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }

            // 1. Start Time Block (Motor Start Time)
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "▶ मोटर चालू समय (Start):",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B),
                            fontSize = 12.5.sp,
                            maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        // AM / PM Segmented Toggle for Start Time (Agri Green active)
                        AmPmSegmentedSelector(
                            selectedAmPm = startAmPm,
                            onSelect = onStartAmPmChange,
                            activeColor = Color(0xFF1B5E20)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Hour Field (HD Bold Large, ignores 00 when typed over)
                        OutlinedTextField(
                            value = startHour,
                            onValueChange = { input ->
                                val cleaned = cleanTimeDigitInput(input, startHour, 12)
                                onStartHourChange(cleaned)
                            },
                            label = { Text("घंटा (1-12)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF334155)) },
                            placeholder = { Text("00", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFF94A3B8)) },
                            textStyle = TextStyle(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = appTextFieldColors(containerColor = Color.White),
                            modifier = Modifier.weight(1f)
                        )

                        Text(
                            text = ":",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A),
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        // Minute Field (HD Bold Large, ignores 00 when typed over)
                        OutlinedTextField(
                            value = startMin,
                            onValueChange = { input ->
                                val cleaned = cleanTimeDigitInput(input, startMin, 59)
                                onStartMinChange(cleaned)
                            },
                            label = { Text("मिनट (0-59)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF334155)) },
                            placeholder = { Text("00", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFF94A3B8)) },
                            textStyle = TextStyle(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = appTextFieldColors(containerColor = Color.White),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Quick minute buttons for Start Time
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0 to ":00", 15 to ":15", 30 to ":30", 45 to ":45").forEach { (min, label) ->
                            QuickMinuteChip(
                                label = label,
                                onClick = { onQuickStartMin(min) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 2. End Time Block (Motor Stop Time)
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⏹ मोटर बंद समय (End):",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B),
                            fontSize = 12.5.sp,
                            maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        // AM / PM Segmented Toggle for End Time (Orange active)
                        AmPmSegmentedSelector(
                            selectedAmPm = endAmPm,
                            onSelect = onEndAmPmChange,
                            activeColor = Color(0xFFC2410C)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Hour Field (HD Bold Large)
                        OutlinedTextField(
                            value = endHour,
                            onValueChange = { input ->
                                val cleaned = cleanTimeDigitInput(input, endHour, 12)
                                onEndHourChange(cleaned)
                            },
                            label = { Text("घंटा (1-12)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF334155)) },
                            placeholder = { Text("00", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFF94A3B8)) },
                            textStyle = TextStyle(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = appTextFieldColors(containerColor = Color.White),
                            modifier = Modifier.weight(1f)
                        )

                        Text(
                            text = ":",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A),
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        // Minute Field (HD Bold Large)
                        OutlinedTextField(
                            value = endMin,
                            onValueChange = { input ->
                                val cleaned = cleanTimeDigitInput(input, endMin, 59)
                                onEndMinChange(cleaned)
                            },
                            label = { Text("मिनट (0-59)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF334155)) },
                            placeholder = { Text("00", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color(0xFF94A3B8)) },
                            textStyle = TextStyle(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = appTextFieldColors(containerColor = Color.White),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Quick Actions: Minute buttons + "Set Live Time" button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(0 to ":00", 15 to ":15", 30 to ":30", 45 to ":45").forEach { (min, label) ->
                            QuickMinuteChip(
                                label = label,
                                onClick = { onQuickEndMin(min) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Set Current Live Time Button
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF3B82F6)),
                            modifier = Modifier
                                .clickable { onSetEndLiveTime() }
                                .padding(horizontal = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Update,
                                    contentDescription = null,
                                    tint = Color(0xFF1D4ED8),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "🕒 लाइव समय",
                                    color = Color(0xFF1D4ED8),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Total Calculated Duration Badge (High Contrast HD)
            val totalMins = Math.round(calculatedHours * 60.0).toInt().coerceAtLeast(0)
            val hoursInt = totalMins / 60
            val minsInt = totalMins % 60

            Surface(
                color = Color(0xFFF0FDF4),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.5.dp, Color(0xFF22C55E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = Color(0xFF15803D),
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "कुल मोटर चला समय:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D),
                            fontSize = 14.sp
                        )
                    }

                    Text(
                        text = "$hoursInt घंटे $minsInt मिनट (${String.format(Locale.ROOT, "%.2f", calculatedHours)} hrs)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF14532D),
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: DIRECT HOURS CONTENT (HD Quality)
// -------------------------------------------------------------
@Composable
private fun DirectHoursContent(
    directHours: String,
    onHoursChange: (String) -> Unit,
    onAddHours: (Double) -> Unit,
    onClear: () -> Unit
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Text(
                text = "✍️ कुल मोटर चलने के घंटे दर्ज करें:",
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFF0F172A),
                fontWeight = FontWeight.Black,
                fontSize = 14.sp
            )

            // Direct Hours TextField (HD Bold)
            OutlinedTextField(
                value = directHours,
                onValueChange = onHoursChange,
                label = { Text("कुल घंटे (जैसे 2.5 या 3)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                placeholder = { Text("0.0", color = Color(0xFF94A3B8)) },
                textStyle = TextStyle(
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF0F172A)
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                trailingIcon = {
                    if (directHours.isNotBlank() && directHours != "0.0") {
                        IconButton(onClick = onClear) {
                            Icon(
                                imageVector = Icons.Default.HighlightOff,
                                contentDescription = "Clear",
                                tint = Color(0xFF64748B)
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = appTextFieldColors(containerColor = Color(0xFFF8FAFC)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("direct_hours_input")
            )

            // Quick Add Increments Row: [+0.5] [+1.0] [+2.0] [+3.0] [+5.0]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(0.5, 1.0, 2.0, 3.0, 5.0).forEach { delta ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFF94A3B8)),
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onAddHours(delta) }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "+${delta}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// HELPER CHIP (HD Quality & Larger Touch Target)
// -------------------------------------------------------------
@Composable
private fun QuickMinuteChip(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, Color(0xFF94A3B8)),
        color = Color(0xFFF1F5F9),
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                color = Color(0xFF0F172A),
                textAlign = TextAlign.Center,
                fontSize = 13.sp
            )
        }
    }
}
