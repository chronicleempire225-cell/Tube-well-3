package com.example.ui.components

import android.view.ViewGroup
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.remoteconfig.AdSlotConfig
import com.example.data.remoteconfig.RemoteConfigService
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

/**
 * Persistent Google AdMob Banner that stays alive across screen/tab navigation.
 *
 * AdMob Policy & Revenue Optimization:
 * 1. PERSISTENCE: Reuses the single AdView instance across tabs (Home, Customers, Reports, History)
 *    so Google AdMob can measure continuous view time without resetting or spamming reload requests.
 * 2. AUTO-REFRESH: Relies on Google AdMob's built-in 30-60s refresh cycle + resilient auto-retry if network fails.
 * 3. ATTRIBUTION: Displays clear "विज्ञापन • Ad" label compliant with Google Publisher Policies.
 * 4. NO OVERLAP: Anchored inside Scaffold bottomBar so it never covers clickable interactive elements.
 * 5. LIFECYCLE MANAGEMENT: Pauses ad when app is backgrounded, resumes when app is foregrounded.
 * 6. ZERO SPACE WHEN OFF: Takes 0dp height ONLY when user is VIP/Premium or admin disabled via remote config.
 */
@Composable
fun PersistentBottomAdBanner(
    currentScreen: String,
    modifier: Modifier = Modifier,
    isSuppressed: Boolean = false
) {
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()

    val screenUpper = currentScreen.uppercase()
    val config = (configs[screenUpper]
        ?: if (screenUpper == "REPORTS") configs["HISTORY"]
        else if (screenUpper == "HISTORY") configs["REPORTS"]
        else null)

    // Check if this screen is enabled by remote config
    val isScreenEnabled = config?.isEnabled ?: true
    val isAllowedToShow = !isAdFree && isScreenEnabled

    if (isSuppressed || !isAllowedToShow) {
        return
    }

    var isAdLoaded by remember { mutableStateOf(false) }
    var adFailedToLoad by remember { mutableStateOf(false) }
    var retryTrigger by remember { mutableIntStateOf(0) }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Retain the single AdView instance for the lifecycle of the MainContainer
    val adView = remember {
        try {
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                val unitId = config?.adUnitId?.ifBlank { AdSlotConfig.GOOGLE_TEST_BANNER_ID }
                    ?: AdSlotConfig.GOOGLE_TEST_BANNER_ID
                adUnitId = unitId
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        isAdLoaded = true
                        adFailedToLoad = false
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        super.onAdFailedToLoad(error)
                        adFailedToLoad = true
                    }
                }
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        } catch (t: Throwable) {
            null
        }
    }

    // Auto-load and auto-retry loading ad
    LaunchedEffect(adView, retryTrigger) {
        if (adView != null && !isAdLoaded) {
            try {
                adView.loadAd(AdRequest.Builder().build())
            } catch (t: Throwable) {
                adFailedToLoad = true
            }
        }
    }

    // Exponential/periodic retry if load failed (e.g. at startup before MobileAds initialized)
    LaunchedEffect(adFailedToLoad) {
        if (adFailedToLoad) {
            kotlinx.coroutines.delay(15000L)
            retryTrigger++
        }
    }

    // Safely pause/resume with Android lifecycle
    DisposableEffect(lifecycleOwner, adView) {
        if (adView == null) return@DisposableEffect onDispose {}
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> adView.resume()
                Lifecycle.Event.ON_PAUSE -> adView.pause()
                Lifecycle.Event.ON_DESTROY -> adView.destroy()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    if (!isAdLoaded || adView == null) {
        return
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFFF8FAFC))
            .padding(horizontal = 8.dp, vertical = 3.dp)
            .testTag("persistent_bottom_ad_banner"),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = Color.White,
            shape = RoundedCornerShape(8.dp),
            shadowElevation = 1.dp,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                // Official discreet ad attribution tag
                Text(
                    text = "विज्ञापन • Ad",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(bottom = 1.dp)
                )

                AndroidView(
                    factory = {
                        (adView.parent as? ViewGroup)?.removeView(adView)
                        adView
                    },
                    modifier = Modifier.wrapContentSize()
                )
            }
        }
    }
}

/**
 * High-eCPM Medium Rectangle (300x250) Ad Banner shown exclusively during active Live Running Sessions.
 *
 * Appears directly in the empty space below the Live Timer on the Home Screen.
 * Provides ~3x higher eCPM compared to standard 320x50 banners while maintaining 100% Google AdMob compliance:
 * - Proper separation from the "सत्र समाप्त करें" (Stop) action button to avoid accidental clicks
 * - Clear discreet "विज्ञापन • Ad" attribution tag
 * - Paused on lifecycle pause, resumed on resume
 * - Automatically hidden when disabled via remote config or premium user
 */
@Composable
fun LiveSessionMediumRectangleAd(
    modifier: Modifier = Modifier
) {
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()

    val config = configs["LIVE_SESSION"]
    val isScreenEnabled = config?.isEnabled ?: true
    val isAllowedToShow = !isAdFree && isScreenEnabled

    var isAdLoaded by remember { mutableStateOf(false) }
    var adFailedToLoad by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val adView = remember {
        try {
            AdView(context).apply {
                setAdSize(AdSize.MEDIUM_RECTANGLE)
                val unitId = config?.adUnitId?.ifBlank { AdSlotConfig.GOOGLE_TEST_BANNER_ID }
                    ?: AdSlotConfig.GOOGLE_TEST_BANNER_ID
                adUnitId = unitId
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        isAdLoaded = true
                        adFailedToLoad = false
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        super.onAdFailedToLoad(error)
                        adFailedToLoad = true
                    }
                }
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                loadAd(AdRequest.Builder().build())
            }
        } catch (t: Throwable) {
            null
        }
    }

    DisposableEffect(lifecycleOwner, adView) {
        if (adView == null) return@DisposableEffect onDispose {}
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> adView.resume()
                Lifecycle.Event.ON_PAUSE -> adView.pause()
                Lifecycle.Event.ON_DESTROY -> adView.destroy()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    if (!isAllowedToShow || !isAdLoaded || adFailedToLoad || adView == null) {
        return
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_session_medium_rectangle_ad"),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = Color.White,
            shape = RoundedCornerShape(16.dp),
            shadowElevation = 2.dp,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 8.dp, bottom = 8.dp, start = 8.dp, end = 8.dp)
            ) {
                // Official discreet ad attribution tag
                Text(
                    text = "विज्ञापन • Ad",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                AndroidView(
                    factory = {
                        (adView.parent as? ViewGroup)?.removeView(adView)
                        adView
                    },
                    modifier = Modifier.wrapContentSize()
                )
            }
        }
    }
}

/**
 * Dynamic Remote-Controlled AdMob Banner Composable.
 * 
 * Automatically responds to:
 * 1. Admin toggles (ON / OFF) via RemoteConfigService / Supabase
 * 2. User Premium status (Ad-Free users never see ads)
 * 3. Dynamic Ad Sizes (BANNER, LARGE_BANNER, MEDIUM_RECTANGLE)
 * 4. Error handling (collapses cleanly if offline or no fill)
 */
@Composable
fun RemoteAdBanner(
    screenName: String,
    modifier: Modifier = Modifier
) {
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()

    if (isAdFree) {
        // Premium user: 0 space taken, ad completely hidden
        return
    }

    val upperScreen = screenName.uppercase()
    val config = (configs[upperScreen]
        ?: if (upperScreen == "REPORTS") configs["HISTORY"]
        else if (upperScreen == "HISTORY") configs["REPORTS"]
        else null)
        ?: return
    if (!config.isEnabled) {
        // Admin disabled ads on this screen: 0 space taken
        return
    }

    var isAdLoaded by remember(config.adSize, config.adUnitId) { mutableStateOf(false) }
    var adFailedToLoad by remember(config.adSize, config.adUnitId) { mutableStateOf(false) }

    val context = LocalContext.current
    val targetAdSize = when (config.adSize.uppercase()) {
        "LARGE_BANNER" -> AdSize.LARGE_BANNER
        "MEDIUM_RECTANGLE" -> AdSize.MEDIUM_RECTANGLE
        else -> AdSize.BANNER
    }

    val adView = remember(config.adSize, config.adUnitId) {
        try {
            AdView(context).apply {
                setAdSize(targetAdSize)
                adUnitId = config.adUnitId.ifBlank { AdSlotConfig.GOOGLE_TEST_BANNER_ID }
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        isAdLoaded = true
                        adFailedToLoad = false
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        super.onAdFailedToLoad(error)
                        adFailedToLoad = true
                    }
                }
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                loadAd(AdRequest.Builder().build())
            }
        } catch (t: Throwable) {
            adFailedToLoad = true
            null
        }
    }

    if (!isAdLoaded || adFailedToLoad || adView == null) {
        return
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("remote_ad_banner_${screenName.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = Color(0xFFF8FAFC),
            shape = RoundedCornerShape(12.dp),
            tonalElevation = 1.dp,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(vertical = 4.dp, horizontal = 4.dp)
            ) {
                // Discreet label adhering to Google AdMob publisher guidelines
                Text(
                    text = "विज्ञापन • Ad",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(bottom = 2.dp)
                )

                AndroidView(
                    factory = {
                        (adView.parent as? ViewGroup)?.removeView(adView)
                        adView
                    },
                    onRelease = { view ->
                        if (view is AdView) {
                            try {
                                view.destroy()
                            } catch (_: Throwable) {}
                        }
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}
