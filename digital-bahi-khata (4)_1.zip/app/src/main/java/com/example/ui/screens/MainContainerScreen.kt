package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ui.components.*
import com.example.ui.theme.OffWhiteBackground
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.MainTab

@Composable
fun MainContainerScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val selectedCustomerId by viewModel.selectedCustomerId.collectAsState()
    val showInternetWarning by viewModel.showInternetWarningDialog.collectAsState()
    val showReceiptDialog by viewModel.showSessionReceiptDialog.collectAsState()
    val lastCompletedSession by viewModel.lastCompletedSession.collectAsState()
    val lastCompletedCustomer by viewModel.lastCompletedCustomer.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    // Show toast when message triggers
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.toastMessage.value = null
        }
    }

    val topBarTitle = when {
        selectedCustomerId != null -> "किसान बही-खाता"
        currentTab == MainTab.HOME -> viewModel.getString("app_title")
        currentTab == MainTab.CUSTOMERS -> viewModel.getString("nav_customers")
        currentTab == MainTab.REPORTS -> viewModel.getString("nav_reports")
        currentTab == MainTab.SETTINGS -> viewModel.getString("nav_settings")
        else -> viewModel.getString("app_title")
    }

    val isLiveTimerRunning by viewModel.isLiveTimerRunning.collectAsState()
    val liveTimerSeconds by viewModel.liveTimerSeconds.collectAsState()
    val isLiveSessionActive = isLiveTimerRunning || liveTimerSeconds > 0L

    val isHomeLiveSessionActive = currentTab == MainTab.HOME && isLiveSessionActive && selectedCustomerId == null

    val currentScreenKey = when {
        selectedCustomerId != null -> "HISTORY"
        currentTab == MainTab.HOME -> "HOME"
        currentTab == MainTab.CUSTOMERS -> "CUSTOMERS"
        currentTab == MainTab.REPORTS -> "REPORTS"
        currentTab == MainTab.SETTINGS -> "SETTINGS"
        else -> "HOME"
    }

    Scaffold(
        topBar = {
            if (selectedCustomerId != null || currentTab != MainTab.HOME) {
                AppTopBar(
                    title = topBarTitle,
                    viewModel = viewModel,
                    showBackButton = selectedCustomerId != null,
                    onBackClick = { viewModel.clearSelectedCustomer() },
                    showLanguageToggle = true
                )
            }
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                PersistentBottomAdBanner(
                    currentScreen = currentScreenKey,
                    isSuppressed = isHomeLiveSessionActive
                )
                if (selectedCustomerId == null) {
                    AppBottomNavigationBar(
                        currentTab = currentTab,
                        onTabSelected = { tab -> viewModel.setTab(tab) },
                        viewModel = viewModel
                    )
                } else {
                    Spacer(modifier = Modifier.navigationBarsPadding())
                }
            }
        },
        containerColor = OffWhiteBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (selectedCustomerId != null) {
                CustomerDetailScreen(
                    customerId = selectedCustomerId!!,
                    viewModel = viewModel,
                    onBack = { viewModel.clearSelectedCustomer() }
                )
            } else {
                when (currentTab) {
                    MainTab.HOME -> HomeScreen(viewModel = viewModel)
                    MainTab.CUSTOMERS -> CustomerDirectoryScreen(viewModel = viewModel)
                    MainTab.REPORTS -> ReportsScreen(viewModel = viewModel)
                    MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }

                // 🌾 Left-Side Compact Voice Assistant ("मुंशी जी") - No full page, transforms into Ear with ripple waves
                MunshiVoiceWidget(
                    viewModel = viewModel,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 12.dp)
                )
            }
        }
    }

    // Global Internet Warning Dialog (4-Hour rule enforced)
    if (showInternetWarning) {
        InternetWarningDialog(
            onDismiss = { viewModel.showInternetWarningDialog.value = false }
        )
    }

    // Session Completion WhatsApp / SMS Receipt Dialog
    if (showReceiptDialog && lastCompletedSession != null && lastCompletedCustomer != null) {
        SessionReceiptDialog(
            session = lastCompletedSession!!,
            customer = lastCompletedCustomer!!,
            viewModel = viewModel,
            onDismiss = { viewModel.showSessionReceiptDialog.value = false }
        )
    }
}
