package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Agriculture Dark Green Primary
val AgriGreenPrimary = Color(0xFF1B5E20)
val AgriGreenDark = Color(0xFF0D3B13)
val AgriGreenLight = Color(0xFF4C8C4A)
val AgriGreenContainer = Color(0xFFE8F5E9)
val AgriGreenOnContainer = Color(0xFF00390B)

// Royal Orange Secondary / Accent
val RoyalOrange = Color(0xFFE65100)
val RoyalOrangeLight = Color(0xFFFF833A)
val RoyalOrangeDark = Color(0xFFAC1900)
val RoyalOrangeContainer = Color(0xFFFFE0B2)
val RoyalOrangeOnContainer = Color(0xFF4E1500)

// Warning / Balance Due Deep Red
val DueRed = Color(0xFFC62828)
val DueRedContainer = Color(0xFFFFEBEE)
val DueRedOnContainer = Color(0xFF5F0000)

// Paid / Success Green
val PaidGreen = Color(0xFF2E7D32)
val PaidGreenContainer = Color(0xFFE8F8F5)

// Neutral Off-White & Backgrounds (Clean Minimalism)
val OffWhiteBackground = Color(0xFFF5F5F5)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceCardElevated = Color(0xFFF8FAFC)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF334155)
val TextMuted = Color(0xFF64748B)
val DividerColor = Color(0xFFE2E8F0)
val MintAccent = Color(0xFFA5D6A7)
