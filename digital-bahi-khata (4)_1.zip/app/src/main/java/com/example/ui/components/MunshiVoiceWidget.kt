package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.gemini.GeminiMunshiService
import com.example.ui.viewmodel.BahiKhataViewModel
import java.util.Locale

/**
 * Plays sensory haptic vibration and pleasant chime on button activation.
 */
fun playMunshiChimeAndVibrate(context: Context) {
    try {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(80)
        }
    } catch (_: Exception) {}

    try {
        val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
        toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 140)
    } catch (_: Exception) {}
}

/**
 * Compact in-place Floating Voice Widget.
 * - Sits at bottom-left.
 * - No full page popup!
 * - When clicked, the button transforms into an EAR 👂 (listening mode).
 * - Concentric animated ripples ("गोल-गोल कम ज्यादा होता रहता है") animate according to mic RMS level.
 * - A compact sleek floating bubble appears right above the button with live transcript and natural spoken Hindi response.
 */
@Composable
fun MunshiVoiceWidget(
    viewModel: BahiKhataViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var isListening by remember { mutableStateOf(false) }
    var isBubbleOpen by remember { mutableStateOf(false) }
    var liveSpokenText by remember { mutableStateOf("") }
    var rmsLevel by remember { mutableFloatStateOf(0f) }
    var isTtsReady by remember { mutableStateOf(false) }
    var ttsInstance by remember { mutableStateOf<TextToSpeech?>(null) }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }

    val isThinking = viewModel.isMunshiThinking.value
    val lastResponse = viewModel.munshiLastResponse.value
    val lastQuery = viewModel.munshiLastQuery.value
    val errorMessage = viewModel.munshiErrorMessage.value

    var hasRecordPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    // TTS Setup with high quality Hindi voice (prefer Google Neural TTS)
    DisposableEffect(Unit) {
        val onInitListener = TextToSpeech.OnInitListener { status ->
            if (status == TextToSpeech.SUCCESS) {
                val locale = Locale("hi", "IN")
                val voices = ttsInstance?.voices
                // Pick the most natural, human-like Hindi neural voice
                val bestVoice = voices?.firstOrNull { v ->
                    v.locale.language == "hi" && (
                        v.name.contains("hi-in-x-hie", ignoreCase = true) ||
                        v.name.contains("hi-in-x-hif", ignoreCase = true) ||
                        v.name.contains("hi-in-x", ignoreCase = true)
                    )
                } ?: voices?.firstOrNull { v ->
                    v.locale.language == "hi" && v.name.contains("hi-in", ignoreCase = true)
                } ?: voices?.firstOrNull { v ->
                    v.locale.language == "hi"
                }

                if (bestVoice != null) {
                    ttsInstance?.voice = bestVoice
                } else {
                    ttsInstance?.language = locale
                }
                ttsInstance?.setPitch(1.0f)
                ttsInstance?.setSpeechRate(0.94f)
                isTtsReady = true
            }
        }

        val tts = try {
            TextToSpeech(context, onInitListener, "com.google.android.tts")
        } catch (_: Throwable) {
            TextToSpeech(context, onInitListener)
        }
        ttsInstance = tts

        onDispose {
            tts.stop()
            tts.shutdown()
            speechRecognizer?.destroy()
        }
    }

    fun speakAloud(text: String) {
        if (text.isNotBlank() && isTtsReady) {
            try {
                ttsInstance?.stop()
                val clean = GeminiMunshiService.cleanTextForSpeech(text)

                // Adapt TTS language dynamically
                val isEnglish = clean.matches(Regex("^[a-zA-Z0-9\\s\\p{Punct}]+$"))
                val hasPunjabi = clean.any { it.code in 0x0A00..0x0A7F }
                val hasMarathi = clean.contains("आहे") || clean.contains("झाले")
                val hasGujarati = clean.any { it.code in 0x0A80..0x0AFF }
                val hasBengali = clean.any { it.code in 0x0980..0x09FF }
                val hasTelugu = clean.any { it.code in 0x0C00..0x0C7F }
                val hasTamil = clean.any { it.code in 0x0B80..0x0BFF }
                val hasKannada = clean.any { it.code in 0x0C80..0x0CFF }
                val hasUrdu = clean.any { it.code in 0x0600..0x06FF }

                val targetLocale = when {
                    isEnglish -> Locale("en", "IN")
                    hasPunjabi -> Locale("pa", "IN")
                    hasMarathi -> Locale("mr", "IN")
                    hasGujarati -> Locale("gu", "IN")
                    hasBengali -> Locale("bn", "IN")
                    hasTelugu -> Locale("te", "IN")
                    hasTamil -> Locale("ta", "IN")
                    hasKannada -> Locale("kn", "IN")
                    hasUrdu -> Locale("ur", "IN")
                    else -> Locale("hi", "IN")
                }
                ttsInstance?.language = targetLocale
                ttsInstance?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "munshi_voice_reply")
            } catch (_: Exception) {}
        }
    }

    fun startListening() {
        val isGated = com.example.data.remoteconfig.RemoteConfigService.isMunshiGatedByPass()
        val hasPass = com.example.data.remoteconfig.RemoteConfigService.hasMunshiUnlimitedPassAccess()
        if (isGated && !hasPass) {
            isBubbleOpen = true
            viewModel.showMunshiPassUnlockDialog.value = true
            val msg = "मुंशी जी का उपयोग करने के लिए 24 घंटे का पास (छोटा वीडियो देखकर) अनलॉक करें या VIP पास लें!"
            viewModel.munshiLastResponse.value = msg
            speakAloud(msg)
            return
        }
        if (!hasRecordPermission) return
        playMunshiChimeAndVibrate(context)
        ttsInstance?.stop()
        liveSpokenText = ""
        isListening = true
        isBubbleOpen = true

        try {
            speechRecognizer?.destroy()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {
                    // Normalize -2dB to 10dB into 0f..1f for live pulsing ripples
                    val norm = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    rmsLevel = norm
                }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListening = false
                    rmsLevel = 0f
                }
                override fun onError(error: Int) {
                    isListening = false
                    rmsLevel = 0f
                    if (liveSpokenText.isBlank()) {
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "आवाज़ समझ नहीं आई, कृपया कान दबाकर दोबारा बोलें।"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "समय समाप्त। कृपया दोबारा बोलें।"
                            SpeechRecognizer.ERROR_NETWORK -> "इंटरनेट कनेक्शन की जांच करें।"
                            else -> "कृपया साफ़ आवाज़ में दोबारा बोलें।"
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onResults(results: Bundle?) {
                    isListening = false
                    rmsLevel = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val resultText = matches?.firstOrNull() ?: ""
                    if (resultText.isNotBlank()) {
                        liveSpokenText = resultText
                        viewModel.askMunshiVoice(
                            query = resultText,
                            onSuccess = { reply ->
                                speakAloud(reply)
                            }
                        )
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val pText = matches?.firstOrNull() ?: ""
                    if (pText.isNotBlank()) liveSpokenText = pText
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            speechRecognizer = recognizer

            val activeLang = viewModel.munshiActiveLanguage.value
            val langCode = when (activeLang) {
                com.example.data.gemini.MunshiLang.ENGLISH -> "en-IN"
                com.example.data.gemini.MunshiLang.PUNJABI -> "pa-IN"
                com.example.data.gemini.MunshiLang.GUJARATI -> "gu-IN"
                com.example.data.gemini.MunshiLang.MARATHI -> "mr-IN"
                com.example.data.gemini.MunshiLang.BENGALI -> "bn-IN"
                com.example.data.gemini.MunshiLang.TELUGU -> "te-IN"
                com.example.data.gemini.MunshiLang.TAMIL -> "ta-IN"
                com.example.data.gemini.MunshiLang.KANNADA -> "kn-IN"
                com.example.data.gemini.MunshiLang.URDU -> "ur-IN"
                else -> "hi-IN"
            }
            val promptText = when (activeLang) {
                com.example.data.gemini.MunshiLang.HARYANVI -> "बोल भाई, सुनूं सूं..."
                com.example.data.gemini.MunshiLang.BHOJPURI -> "बोलल जाव भाई जी..."
                com.example.data.gemini.MunshiLang.RAJASTHANI -> "बोलो सा, सुणूं छूं..."
                com.example.data.gemini.MunshiLang.ENGLISH -> "Speak now, I'm listening..."
                com.example.data.gemini.MunshiLang.PUNJABI -> "ਬੋਲੋ ਵੀਰ ਜੀ, ਸੁਣ ਰਿਹਾ ਹਾਂ..."
                com.example.data.gemini.MunshiLang.MARATHI -> "बोला, ऐकत आहे..."
                com.example.data.gemini.MunshiLang.GUJARATI -> "બોલો, સાંભળું છું..."
                else -> "किसान भाई, बोलिए..."
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langCode)
                putExtra(RecognizerIntent.EXTRA_PROMPT, promptText)
            }
            recognizer.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            Toast.makeText(context, "माइक शुरू नहीं हो सका: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasRecordPermission = granted
        if (granted) {
            startListening()
        } else {
            Toast.makeText(context, "बोलने के लिए माइक अनुमति आवश्यक है", Toast.LENGTH_LONG).show()
        }
    }

    // Ripple wave animations ("गोल-गोल कम ज्यादा होता रहता है")
    val infiniteTransition = rememberInfiniteTransition(label = "VoiceWaveRipple")
    val basePulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "basePulse"
    )
    val outerPulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.65f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "outerPulse"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.Start
    ) {
        // Compact Floating Voice Speech Bubble (Directly above the button, NO full page!)
        AnimatedVisibility(
            visible = isBubbleOpen,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 })
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.White,
                shadowElevation = 8.dp,
                border = BorderStroke(1.5.dp, Color(0xFF86EFAC)),
                modifier = Modifier
                    .widthIn(min = 260.dp, max = 340.dp)
                    .heightIn(max = 300.dp)
                    .padding(bottom = 12.dp)
                    .testTag("munshi_compact_bubble")
            ) {
                Column(
                    modifier = Modifier
                        .padding(14.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header with Ear / Wheat branding + Close button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = if (isListening) "👂" else "🌾", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isListening) "ध्यान से सुन रहा हूँ..." else "मुंशी जी (AI हिसाब)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF166534)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (viewModel.munshiChatHistory.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        ttsInstance?.stop()
                                        viewModel.clearMunshiHistory()
                                        liveSpokenText = ""
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "नई बातचीत शुरू करें (इतिहास साफ़ करें)",
                                        tint = Color(0xFF64748B),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            IconButton(
                                onClick = {
                                    ttsInstance?.stop()
                                    speechRecognizer?.destroy()
                                    isListening = false
                                    isBubbleOpen = false
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "बंद करें",
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Pass Status Banner (Only if gated & pass is needed)
                    val isGated = com.example.data.remoteconfig.RemoteConfigService.isMunshiGatedByPass()
                    val isVip = com.example.data.remoteconfig.RemoteConfigService.isAdFreeUser.collectAsState().value ||
                                com.example.data.remoteconfig.RemoteConfigService.vipDaysRemaining.collectAsState().value > 0
                    val isPassActive = com.example.data.remoteconfig.RemoteConfigService.isFeaturePassActive()

                    if (isGated && !isVip && !isPassActive) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEE2E2),
                            border = BorderStroke(1.dp, Color(0xFFEF4444)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🔒 24h पास या VIP पास आवश्यक",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFB91C1C)
                                )

                                Surface(
                                    onClick = { viewModel.showMunshiPassUnlockDialog.value = true },
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF16A34A)
                                ) {
                                    Text(
                                        text = "🎬 पास लें",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Top 10+ Languages & Dialects (हिंदी, English, भोजपुरी, हरियाणवी, ਪੰਜਾਬੀ, मराठी, ગુજરાતી, বাংলা, తెలుగు, தமிழ், ಕನ್ನಡ, اردو)
                    val activeLang = viewModel.munshiActiveLanguage.value
                    val topLanguages = listOf(
                        com.example.data.gemini.MunshiLang.HINDI to "हिंदी",
                        com.example.data.gemini.MunshiLang.ENGLISH to "English",
                        com.example.data.gemini.MunshiLang.BHOJPURI to "भोजपुरी",
                        com.example.data.gemini.MunshiLang.HARYANVI to "हरियाणवी",
                        com.example.data.gemini.MunshiLang.RAJASTHANI to "राजस्थानी",
                        com.example.data.gemini.MunshiLang.PUNJABI to "ਪੰਜਾਬੀ",
                        com.example.data.gemini.MunshiLang.MARATHI to "मराठी",
                        com.example.data.gemini.MunshiLang.GUJARATI to "ગુજરાતી",
                        com.example.data.gemini.MunshiLang.BENGALI to "বাংলা",
                        com.example.data.gemini.MunshiLang.TELUGU to "తెలుగు",
                        com.example.data.gemini.MunshiLang.TAMIL to "தமிழ்",
                        com.example.data.gemini.MunshiLang.KANNADA to "ಕನ್ನಡ",
                        com.example.data.gemini.MunshiLang.URDU to "اردو"
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        topLanguages.forEach { (langOpt, label) ->
                            val isSelected = activeLang == langOpt
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) Color(0xFF16A34A) else Color(0xFFF1F5F9),
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFF15803D) else Color(0xFFCBD5E1)),
                                shadowElevation = if (isSelected) 2.dp else 0.dp,
                                modifier = Modifier.clickable {
                                    viewModel.setMunshiLanguage(langOpt)
                                    val switchReply = com.example.data.gemini.MunshiSmartLocalEngine.tryAnswerFromAppLogic(
                                        query = label,
                                        customersWithStats = viewModel.allCustomerStatsList.value,
                                        sessions = viewModel.allSessions.value,
                                        profile = viewModel.profile.value,
                                        isVipActive = com.example.data.remoteconfig.RemoteConfigService.isAdFreeUser.value,
                                        vipDaysRemaining = com.example.data.remoteconfig.RemoteConfigService.vipDaysRemaining.value,
                                        vipPlan = com.example.data.remoteconfig.RemoteConfigService.planType.value,
                                        hasPriorChat = true,
                                        activeLang = langOpt
                                    ) ?: "भाषा: $label"
                                    viewModel.munshiLastResponse.value = switchReply
                                    speakAloud(switchReply)
                                }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                ) {
                                    if (isSelected) {
                                        Text(
                                            text = "✓ ",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) Color.White else Color(0xFF334155)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Live Listening / Speaking State
                    when {
                        isThinking -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 6.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color(0xFF16A34A),
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "क्लाउड से लाइव हिसाब निकाल रहे हैं...",
                                    fontSize = 12.sp,
                                    color = Color(0xFF15803D),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        isListening -> {
                            Column {
                                Text(
                                    text = if (liveSpokenText.isNotBlank()) "\"$liveSpokenText\"" else "बोलिए किसान भाई, कान लगाकर सुन रहा हूँ...",
                                    fontSize = 13.sp,
                                    color = if (liveSpokenText.isNotBlank()) Color(0xFF1E293B) else Color(0xFF64748B),
                                    fontWeight = if (liveSpokenText.isNotBlank()) FontWeight.Bold else FontWeight.Normal
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                // Dancing audio bars
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val bar1Height = (8 + (rmsLevel * 20)).dp
                                    val bar2Height = (12 + (rmsLevel * 26)).dp
                                    val bar3Height = (16 + (rmsLevel * 30)).dp
                                    val bar4Height = (10 + (rmsLevel * 22)).dp

                                    Box(modifier = Modifier.width(4.dp).height(bar1Height).clip(RoundedCornerShape(2.dp)).background(Color(0xFF22C55E)))
                                    Box(modifier = Modifier.width(4.dp).height(bar2Height).clip(RoundedCornerShape(2.dp)).background(Color(0xFF16A34A)))
                                    Box(modifier = Modifier.width(4.dp).height(bar3Height).clip(RoundedCornerShape(2.dp)).background(Color(0xFF15803D)))
                                    Box(modifier = Modifier.width(4.dp).height(bar4Height).clip(RoundedCornerShape(2.dp)).background(Color(0xFF22C55E)))
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text("या छूकर पूछें:", fontSize = 11.sp, color = Color(0xFF64748B))
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf("कुल बकाया?", "ऐड कैसे हटाएं?", "ग्राहक बटन?").forEach { quickQ ->
                                        Surface(
                                            onClick = {
                                                speechRecognizer?.stopListening()
                                                isListening = false
                                                liveSpokenText = quickQ
                                                viewModel.askMunshiVoice(
                                                    query = quickQ,
                                                    onSuccess = { reply -> speakAloud(reply) }
                                                )
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            color = Color(0xFFF1F5F9),
                                            border = BorderStroke(0.5.dp, Color(0xFFCBD5E1))
                                        ) {
                                            Text(
                                                text = quickQ,
                                                fontSize = 10.sp,
                                                color = Color(0xFF334155),
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        lastResponse != null -> {
                            // If conversation history has multiple messages, show them as a smooth chat stream
                            if (viewModel.munshiChatHistory.size > 2) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    viewModel.munshiChatHistory.takeLast(4).forEach { chatMsg ->
                                        if (chatMsg.role == "user") {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp, 12.dp, 2.dp, 12.dp),
                                                    color = Color(0xFFF1F5F9),
                                                    border = BorderStroke(0.5.dp, Color(0xFFCBD5E1))
                                                ) {
                                                    Text(
                                                        text = "🗣️ ${chatMsg.text}",
                                                        fontSize = 11.sp,
                                                        color = Color(0xFF334155),
                                                        fontWeight = FontWeight.Medium,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                        } else {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.Start
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp, 12.dp, 12.dp, 2.dp),
                                                    color = Color(0xFFF0FDF4),
                                                    border = BorderStroke(0.5.dp, Color(0xFF86EFAC))
                                                ) {
                                                    Text(
                                                        text = chatMsg.text,
                                                        fontSize = 12.sp,
                                                        color = Color(0xFF14532D),
                                                        lineHeight = 17.sp,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                val userQuery = liveSpokenText.ifBlank { lastQuery ?: "" }
                                if (userQuery.isNotBlank()) {
                                    Text(
                                        text = "🗣️ \"$userQuery\"",
                                        fontSize = 12.sp,
                                        color = Color(0xFF475569),
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                }

                                Text(
                                    text = lastResponse,
                                    fontSize = 13.sp,
                                    color = Color(0xFF14532D),
                                    lineHeight = 19.sp,
                                    fontWeight = FontWeight.Normal
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    onClick = { speakAloud(lastResponse) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF0FDF4),
                                    border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VolumeUp,
                                            contentDescription = null,
                                            tint = Color(0xFF16A34A),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("फिर से सुनें", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
                                    }
                                }

                                Surface(
                                    onClick = { startListening() },
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF16A34A),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Hearing,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("दूसरा पूछें", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                        }
                        errorMessage != null -> {
                            Text(
                                text = "⚠️ $errorMessage",
                                fontSize = 12.sp,
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Concentric Ripple Button Centerpiece
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(70.dp)
        ) {
            // "गोल-गोल कम ज्यादा होता रहता है" Animated Audio Ripple Waves
            if (isListening) {
                val reactiveScale1 = basePulse * (1f + rmsLevel * 0.35f)
                val reactiveScale2 = outerPulse * (1f + rmsLevel * 0.55f)

                // Outer Ripple Ring
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .scale(reactiveScale2)
                        .clip(CircleShape)
                        .background(Color(0x2E16A34A))
                )
                // Middle Ripple Ring
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .scale(reactiveScale1)
                        .clip(CircleShape)
                        .background(Color(0x4D22C55E))
                )
            }

            // The Round Floating Button (Transforms into EAR 👂 when listening)
            Surface(
                onClick = {
                    val isGated = com.example.data.remoteconfig.RemoteConfigService.isMunshiGatedByPass()
                    val hasPass = com.example.data.remoteconfig.RemoteConfigService.hasMunshiUnlimitedPassAccess()
                    if (isGated && !hasPass) {
                        isBubbleOpen = true
                        viewModel.showMunshiPassUnlockDialog.value = true
                        val msg = "मुंशी जी का उपयोग करने के लिए 24 घंटे का पास (छोटा वीडियो देखकर) अनलॉक करें या VIP पास लें!"
                        viewModel.munshiLastResponse.value = msg
                        speakAloud(msg)
                    } else if (!hasRecordPermission) {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    } else if (isListening) {
                        speechRecognizer?.stopListening()
                        isListening = false
                    } else {
                        startListening()
                    }
                },
                shape = CircleShape,
                color = Color.Transparent,
                shadowElevation = if (isListening) 10.dp else 6.dp,
                border = BorderStroke(
                    width = 2.5.dp,
                    color = if (isListening) Color(0xFFFACC15) else Color(0xFFFDE047)
                ),
                modifier = Modifier
                    .size(54.dp)
                    .testTag("munshi_floating_voice_button")
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = if (isListening) {
                                    listOf(Color(0xFF15803D), Color(0xFF14532D))
                                } else {
                                    listOf(Color(0xFF16A34A), Color(0xFF0F3E1E))
                                }
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isThinking) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(26.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        // Transforms into EAR 👂 when listening, or MIC when idle!
                        Icon(
                            imageVector = if (isListening) Icons.Default.Hearing else Icons.Default.Mic,
                            contentDescription = if (isListening) "सुन रहा हूँ" else "मुंशी जी से पूछें",
                            tint = if (isListening) Color(0xFFFACC15) else Color.White,
                            modifier = Modifier.size(if (isListening) 30.dp else 26.dp)
                        )
                    }

                    // Small wheat badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 3.dp, end = 3.dp)
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = if (isListening) "👂" else "🌾", fontSize = 8.sp)
                    }
                }
            }
        }
    }

    // Rewarded Ad Dialog for unlocking 24-Hour Pass for Munshi AI
    if (viewModel.showMunshiPassUnlockDialog.value) {
        RewardedAdUnlockDialog(
            featureName = "मुंशी जी AI (Gemini असिस्टेंट)",
            onDismiss = { viewModel.showMunshiPassUnlockDialog.value = false },
            onUnlockSuccess = {
                viewModel.showMunshiPassUnlockDialog.value = false
                com.example.data.remoteconfig.RemoteConfigService.grant24HourFeaturePass(context)
                val passUnlockedMsg = when (viewModel.munshiActiveLanguage.value) {
                    com.example.data.gemini.MunshiLang.HARYANVI -> "बधाई हो भाई! थारा 24 घंटे का पास चालू होग्या सै। इब 24 घंटे खातर मुंशी जी तै जित्ते मर्ज़ी सवाल पूछ!"
                    com.example.data.gemini.MunshiLang.BHOJPURI -> "बधाई हो भाई जी! रउआ 24 घंटा के पास चालू हो गइल। अब 24 घंटा खातिर जेतना मन करे सवाल पूछीं!"
                    com.example.data.gemini.MunshiLang.RAJASTHANI -> "बधाई हो सा! आपरो 24 घंटा रो पास चालू हो गयो छै। अब 24 घंटा तांई असीमित सवाल पूछो सा!"
                    com.example.data.gemini.MunshiLang.PUNJABI -> "ਮੁਬਾਰਕਾਂ ਵੀਰ ਜੀ! ਤੁਹਾਡਾ 24 ਘੰਟੇ ਦਾ ਪਾਸ ਚਾਲੂ ਹੋ ਗਿਆ ਹੈ। ਹੁਣ 24 ਘੰਟੇ ਲਈ ਜਿੰਨੇ ਮਰਜ਼ੀ ਸਵਾਲ ਪੁੱਛੋ ਜੀ!"
                    com.example.data.gemini.MunshiLang.ENGLISH -> "Congratulations! Your 24-hour pass is now active. You have unlimited access to Munshi AI for the next 24 hours!"
                    else -> "बधाई हो किसान भाई! आपका 24 घंटे का पास सक्रिय हो गया है। अब अगले 24 घंटे के लिए मुंशी जी से असीमित सवाल पूछ सकते हैं!"
                }
                viewModel.munshiLastResponse.value = passUnlockedMsg
            }
        )
    }
}
