package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.CustomerEntity
import com.example.data.db.TubewellSessionEntity
import com.example.data.localization.AppLanguage
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.util.ShareHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.MainTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    title: String,
    viewModel: BahiKhataViewModel,
    showBackButton: Boolean = true,
    onBackClick: () -> Unit = {},
    showLanguageToggle: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    var showLangMenu by remember { mutableStateOf(false) }

    Surface(
        color = AgriGreenPrimary,
        shadowElevation = 4.dp
    ) {
        TopAppBar(
            title = {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                if (showBackButton) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("top_bar_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                }
            },
            actions = {
                actions()
                if (showLanguageToggle) {
                    Box {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = RoyalOrange,
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clickable { showLangMenu = true }
                                .testTag("language_toggle_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentLang.nativeName,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showLangMenu,
                            onDismissRequest = { showLangMenu = false }
                        ) {
                            AppLanguage.values().forEach { lang ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${lang.nativeName} (${lang.englishName})",
                                                fontWeight = if (lang == currentLang) FontWeight.Bold else FontWeight.Normal
                                            )
                                            if (lang == currentLang) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "Selected",
                                                    tint = AgriGreenPrimary
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        viewModel.setLanguage(lang)
                                        showLangMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = AgriGreenPrimary
            )
        )
    }
}

@Composable
fun appTextFieldColors(
    focusedBorderColor: Color = AgriGreenPrimary,
    unfocusedBorderColor: Color = Color(0xFFCBD5E1),
    focusedLabelColor: Color = AgriGreenPrimary,
    unfocusedLabelColor: Color = TextSecondary,
    focusedTextColor: Color = TextPrimary,
    unfocusedTextColor: Color = TextPrimary,
    containerColor: Color = Color.White
): TextFieldColors {
    return OutlinedTextFieldDefaults.colors(
        focusedTextColor = focusedTextColor,
        unfocusedTextColor = unfocusedTextColor,
        focusedContainerColor = containerColor,
        unfocusedContainerColor = containerColor,
        cursorColor = focusedBorderColor,
        focusedBorderColor = focusedBorderColor,
        unfocusedBorderColor = unfocusedBorderColor,
        focusedLabelColor = focusedLabelColor,
        unfocusedLabelColor = unfocusedLabelColor,
        focusedPlaceholderColor = TextMuted,
        unfocusedPlaceholderColor = TextMuted,
        focusedLeadingIconColor = focusedBorderColor,
        unfocusedLeadingIconColor = TextSecondary,
        focusedTrailingIconColor = focusedBorderColor,
        unfocusedTrailingIconColor = TextSecondary
    )
}

fun getInitials(name: String): String {
    val trimmed = name.trim()
    if (trimmed.isEmpty()) return "क"

    // Clean common prefixes (e.g. श्री, श्रीमती, Sh., Mr., Mrs., Dr.)
    val cleaned = trimmed.replace(Regex("^(श्री|श्रीमती|Sh\\.?|Mr\\.?|Mrs\\.?|Dr\\.?)\\s+", RegexOption.IGNORE_CASE), "")
    val effective = if (cleaned.isNotBlank()) cleaned else trimmed
    val parts = effective.split(Regex("\\s+")).filter { it.isNotBlank() }

    return if (parts.size >= 2) {
        val f1 = extractFirstCharOrGrapheme(parts[0])
        val f2 = extractFirstCharOrGrapheme(parts[1])
        (f1 + f2).uppercase()
    } else {
        val f1 = extractFirstCharOrGrapheme(parts[0])
        f1.uppercase()
    }
}

fun getSingleInitial(name: String): String {
    val trimmed = name.trim()
    if (trimmed.isEmpty()) return "क"
    val cleaned = trimmed.replace(Regex("^(श्री|श्रीमती|Sh\\.?|Mr\\.?|Mrs\\.?|Dr\\.?)\\s+", RegexOption.IGNORE_CASE), "")
    val effective = if (cleaned.isNotBlank()) cleaned else trimmed
    val parts = effective.split(Regex("\\s+")).filter { it.isNotBlank() }
    if (parts.isNotEmpty()) {
        val f1 = extractFirstCharOrGrapheme(parts[0])
        return if (f1.isNotBlank()) f1.uppercase() else "क"
    }
    return "क"
}

private fun extractFirstCharOrGrapheme(word: String): String {
    if (word.isEmpty()) return ""
    val first = word.first()
    // For standard ASCII / Latin letters (e.g. Balwan Singh -> BS, balwan sinh -> BS)
    if ((first in 'a'..'z') || (first in 'A'..'Z')) {
        return first.toString()
    }
    // For Indic / Devanagari scripts, extract the base consonant / character
    val codePoints = word.codePoints().toArray()
    if (codePoints.isEmpty()) return ""
    val sb = StringBuilder()
    sb.appendCodePoint(codePoints[0])
    for (i in 1 until codePoints.size) {
        val cp = codePoints[i]
        val type = Character.getType(cp)
        if (type == Character.NON_SPACING_MARK.toInt() ||
            type == Character.COMBINING_SPACING_MARK.toInt() ||
            type == Character.ENCLOSING_MARK.toInt()) {
            sb.appendCodePoint(cp)
        } else {
            break
        }
    }
    return sb.toString()
}

val avatarPalette = listOf(
    Color(0xFFE11D48), // Vibrant Rose Red
    Color(0xFFEA580C), // Vibrant Deep Orange
    Color(0xFFD97706), // Vibrant Amber
    Color(0xFF16A34A), // Vibrant Forest Green
    Color(0xFF059669), // Vibrant Emerald Green
    Color(0xFF0891B2), // Vibrant Cyan
    Color(0xFF0284C7), // Vibrant Sky Blue
    Color(0xFF2563EB), // Vibrant Royal Blue
    Color(0xFF4F46E5), // Vibrant Indigo
    Color(0xFF7C3AED), // Vibrant Violet
    Color(0xFF9333EA), // Vibrant Purple
    Color(0xFFC026D3), // Vibrant Fuchsia
    Color(0xFFDB2777), // Vibrant Pink
    Color(0xFF0D9488), // Vibrant Teal
    Color(0xFF65A30D), // Vibrant Lime
    Color(0xFFB45309)  // Vibrant Bronze Amber
)

fun getAvatarColor(name: String): Color {
    val trimmed = name.trim()
    if (trimmed.isBlank()) return avatarPalette[0]
    val cleaned = trimmed.replace(Regex("^(श्री|श्रीमती|Sh\\.?|Mr\\.?|Mrs\\.?|Dr\\.?)\\s+", RegexOption.IGNORE_CASE), "").ifBlank { trimmed }
    val hash = kotlin.math.abs(cleaned.lowercase().hashCode())
    return avatarPalette[hash % avatarPalette.size]
}

@Composable
fun AppBottomNavigationBar(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    viewModel: BahiKhataViewModel
) {
    val currentLang by viewModel.currentLanguage.collectAsState()

    Surface(
        color = Color.White,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        NavigationBar(
            containerColor = Color.White,
            tonalElevation = 0.dp
        ) {
            val items = listOf(
                Triple(MainTab.HOME, viewModel.getString("nav_home"), Icons.Default.WaterDrop),
                Triple(MainTab.CUSTOMERS, viewModel.getString("nav_customers"), Icons.Default.People),
                Triple(MainTab.REPORTS, viewModel.getString("nav_reports"), Icons.Default.Assessment),
                Triple(MainTab.SETTINGS, viewModel.getString("nav_settings"), Icons.Default.Settings)
            )

            items.forEach { (tab, label, icon) ->
                val selected = currentTab == tab
                NavigationBarItem(
                    selected = selected,
                    onClick = { onTabSelected(tab) },
                    icon = {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (selected) AgriGreenPrimary else Color(0xFF94A3B8),
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) AgriGreenPrimary else Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AgriGreenPrimary,
                        selectedTextColor = AgriGreenPrimary,
                        indicatorColor = Color(0xFFE8F5E9),
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                )
            }
        }
    }
}

@Composable
fun AvatarView(
    name: String,
    photoUri: String? = null,
    bgColor: Long = 0L,
    size: Int = 46,
    shape: androidx.compose.ui.graphics.Shape = CircleShape,
    singleLetter: Boolean = false,
    hasDue: Boolean? = null,
    modifier: Modifier = Modifier
) {
    val letterText = if (singleLetter) getSingleInitial(name) else getInitials(name)
    val avatarBg = getAvatarColor(name)

    Box(
        modifier = modifier
            .size(size.dp)
            .clip(shape)
            .background(avatarBg),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = letterText,
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            fontSize = if (letterText.length > 1) (size * 0.38).sp else (size * 0.46).sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun InternetWarningDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.WifiOff,
                contentDescription = "Offline",
                tint = RoyalOrange,
                modifier = Modifier.size(36.dp)
            )
        },
        title = {
            Text(
                text = "इंटरनेट डिस्कनेक्टेड (Offline Mode)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Text(
                text = "आप वर्तमान में ऑफ़लाइन हैं। चिंता न करें, आपका सारा ट्यूबवेल हिसाब-किताब फोन में 100% सुरक्षित है। इंटरनेट कनेक्ट होते ही क्लाउड बैकअप स्वतः सिंक हो जाएगा।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                modifier = Modifier.testTag("offline_dialog_ok_button")
            ) {
                Text("समझ गया / ठीक है", color = Color.White)
            }
        }
    )
}

@Composable
fun SessionReceiptDialog(
    session: TubewellSessionEntity,
    customer: CustomerEntity,
    viewModel: BahiKhataViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val profile by viewModel.profile.collectAsState()
    val allCustomerStats by viewModel.customerStatsList.collectAsState()
    val customerStat = allCustomerStats.firstOrNull { it.customer.id == customer.id }
    val totalDue = customerStat?.netDue ?: session.dueAmount

    val hoursFormatted = ShareHelper.formatDurationText(session.hours)

    var showRewardedUnlockDialog by remember { mutableStateOf(false) }
    var pendingShareAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    if (showRewardedUnlockDialog) {
        RewardedAdUnlockDialog(
            featureName = "WhatsApp व SMS मैसेजिंग",
            onDismiss = { showRewardedUnlockDialog = false },
            onUnlockSuccess = {
                showRewardedUnlockDialog = false
                pendingShareAction?.invoke()
                pendingShareAction = null
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Green Circle with Checkmark Icon
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF16A34A)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Success",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // 2. Heading & Subtitle (HD Large Bold)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "सत्र सफलतापूर्वक बही-खाता में दर्ज!",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF14532D),
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "${customer.name} • $hoursFormatted",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B),
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center
                    )
                }

                // 3. Receipt Details Card (HD High Contrast)
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Row 1: आज का चला समय (Hours & Minutes)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "आज का चला समय:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF334155),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = hoursFormatted,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                fontSize = 15.sp
                            )
                        }

                        // Row 2: आज का चार्ज
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "आज का चार्ज:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF334155),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "₹${String.format(java.util.Locale.ROOT, "%,d", Math.round(session.totalAmount))}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                fontSize = 15.sp
                            )
                        }

                        // Row 3: आज जमा किया
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "आज का जमा किया:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF15803D),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "₹${String.format(java.util.Locale.ROOT, "%,d", Math.round(session.paidAmount))}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF15803D),
                                fontSize = 15.sp
                            )
                        }

                        Divider(color = Color(0xFFE2E8F0), thickness = 1.dp)

                        // Row 4: कुल बाकी बकाया (Red High Contrast HD)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "खाते का कुल बाकी बकाया:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFDC2626),
                                fontSize = 15.sp
                            )
                            Text(
                                text = "₹${String.format(java.util.Locale.ROOT, "%,d", Math.round(totalDue))}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFDC2626),
                                fontSize = 18.sp
                            )
                        }
                    }
                }

                // 4. Section Subtitle: व्हाट्सएप या मैसेज पर लिखित रसीद भेजें
                Text(
                    text = "व्हाट्सएप या एसएमएस पर लिखित पर्ची भेजें:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF0F172A),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                // 5. Dual Action Buttons: [💬 WhatsApp] & [📲 SMS] side by side (HD Quality)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // WhatsApp Button
                    Button(
                        onClick = {
                            val action = {
                                val msg = ShareHelper.formatSessionReceiptMessage(profile, customer, session, totalDue)
                                ShareHelper.shareViaWhatsApp(context, customer.phone, msg)
                            }
                            if (RemoteConfigService.isFeaturePassActive()) {
                                action()
                            } else {
                                pendingShareAction = action
                                showRewardedUnlockDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("share_receipt_whatsapp_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = "WhatsApp",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "WhatsApp",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                    }

                    // SMS Button
                    Button(
                        onClick = {
                            val action = {
                                val msg = ShareHelper.formatSessionReceiptMessage(profile, customer, session, totalDue)
                                ShareHelper.shareViaSms(context, customer.phone, msg)
                            }
                            if (RemoteConfigService.isFeaturePassActive()) {
                                action()
                            } else {
                                pendingShareAction = action
                                showRewardedUnlockDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("share_receipt_sms_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "SMS",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SMS मैसेज",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                // 6. Close Outline Button
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF334155)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("close_receipt_dialog_button")
                ) {
                    Text(
                        text = "पूर्ण / बंद करें",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF334155),
                        fontSize = 14.sp
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = {}
    )
}

@Composable
fun DepositPaymentDialog(
    customer: CustomerEntity,
    currentDue: Double,
    viewModel: BahiKhataViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val profile by viewModel.profile.collectAsState()
    var amountText by remember { mutableStateOf(if (currentDue > 0) String.format(java.util.Locale.ROOT, "%.0f", currentDue) else "") }
    var selectedMode by remember { mutableStateOf("नकद (Cash)") }
    var noteText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = null,
                    tint = PaidGreen,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "रुपये जमा करें (Payment)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF0F172A),
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = Color(0xFFF0FDF4),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "किसान: ${customer.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF14532D)
                            )
                            if (customer.sO.isNotBlank()) {
                                Text(
                                    text = "सुपुत्र: श्री ${customer.sO}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF15803D)
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "वर्तमान बाकी",
                                style = MaterialTheme.typography.labelSmall,
                                color = DueRed,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "₹${String.format(java.util.Locale.ROOT, "%,d", Math.round(currentDue))}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = DueRed
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("जमा की जाने वाली रकम (₹) *", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                    placeholder = { Text("जैसे: 500", color = Color(0xFF94A3B8)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = appTextFieldColors(
                        containerColor = Color.White,
                        focusedBorderColor = PaidGreen,
                        focusedLabelColor = PaidGreen
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("deposit_amount_input")
                )

                Text(
                    text = "भुगतान का माध्यम चुनें:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("नकद (Cash)", "UPI / ऑनलाइन", "बैंक").forEach { mode ->
                        FilterChip(
                            selected = selectedMode == mode,
                            onClick = { selectedMode = mode },
                            label = { Text(mode, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PaidGreen,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("विवरण / नोट (वैकल्पिक)", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                    placeholder = { Text("जैसे: फसल कटाई के बाद दिया", color = Color(0xFF94A3B8)) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = appTextFieldColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        viewModel.depositPayment(customer.id, amt, selectedMode, noteText)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PaidGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("confirm_deposit_button")
            ) {
                Text("जमा दर्ज करें", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun AddCustomerDialog(
    viewModel: BahiKhataViewModel,
    onDismiss: () -> Unit,
    onCustomerAdded: ((CustomerEntity) -> Unit)? = null
) {
    var name by remember { mutableStateOf("") }
    var fatherName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var initialDue by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // 🛡️ Invisible Honeypot field for automated bots & scripts
    var honeypotField by remember { mutableStateOf("") }
    // ⏱️ Time-based bot detection: Record timestamp when dialog opens
    val dialogOpenedAt = remember { System.currentTimeMillis() }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PersonAdd,
                    contentDescription = null,
                    tint = AgriGreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "नया किसान / ग्राहक जोड़ें",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF0F172A),
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Avatar Preview Header (HD Clarity)
                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvatarView(
                            name = if (name.isNotBlank()) name else "नया किसान",
                            size = 46,
                            shape = CircleShape,
                            singleLetter = true,
                            hasDue = (initialDue.toDoubleOrNull() ?: 0.0) > 0
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (name.isNotBlank()) name else "किसान का पूरा नाम",
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                style = MaterialTheme.typography.bodyMedium,
                                fontSize = 15.sp
                            )
                            if (fatherName.isNotBlank()) {
                                Text(
                                    text = "सुपुत्र: श्री $fatherName",
                                    color = Color(0xFF475569),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            if (phone.isNotBlank()) {
                                Text(
                                    text = "📞 $phone",
                                    color = Color(0xFF166534),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { 
                        name = it
                        errorMessage = null
                    },
                    label = { Text("किसान का पूरा नाम *", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                    placeholder = { Text("जैसे: रामेश्वर यादव", color = Color(0xFF94A3B8)) },
                    textStyle = TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = appTextFieldColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_customer_name_input")
                )

                OutlinedTextField(
                    value = fatherName,
                    onValueChange = { fatherName = it },
                    label = { Text("पिताजी का नाम (S/O)", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                    placeholder = { Text("जैसे: सूरजभान", color = Color(0xFF94A3B8)) },
                    textStyle = TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = appTextFieldColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_customer_father_input")
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { input ->
                        val digitsOnly = input.filter { it.isDigit() }.take(10)
                        phone = digitsOnly
                        errorMessage = null
                    },
                    label = { Text("मोबाइल नंबर (केवल 10 अंक) *", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                    placeholder = { Text("उदा. 9876543210", color = Color(0xFF94A3B8)) },
                    supportingText = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (phone.isNotEmpty() && phone.length < 10) "10 अंक अनिवार्य हैं" else "केवल संख्यात्मक अंक (0-9)",
                                color = if (phone.isNotEmpty() && phone.length < 10) Color(0xFFDC2626) else Color(0xFF64748B),
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${phone.length}/10",
                                color = if (phone.length == 10) Color(0xFF16A34A) else Color(0xFF64748B),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    },
                    isError = phone.isNotEmpty() && phone.length != 10,
                    textStyle = TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = appTextFieldColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_customer_phone_input")
                )

                OutlinedTextField(
                    value = initialDue,
                    onValueChange = { initialDue = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("पिछला बकाया यदि कोई हो (₹)", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                    placeholder = { Text("₹0", color = Color(0xFF94A3B8)) },
                    textStyle = TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = appTextFieldColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )

                // 🛡️ Invisible Honeypot Trap (Hidden from real human users, scanned by automated bots)
                Box(
                    modifier = Modifier
                        .size(0.dp)
                        .clipToBounds()
                ) {
                    androidx.compose.foundation.text.BasicTextField(
                        value = honeypotField,
                        onValueChange = { honeypotField = it },
                        modifier = Modifier.testTag("website_url_field")
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = Color(0xFFDC2626),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "कृपया किसान का नाम दर्ज करें!"
                        return@Button
                    }
                    if (phone.length != 10) {
                        errorMessage = "मोबाइल नंबर ठीक 10 अंकों का होना चाहिए! (न कम ना ज्यादा)"
                        return@Button
                    }
                    val due = initialDue.toDoubleOrNull() ?: 0.0
                    val colorVal = getAvatarColor(name).value.toLong()
                    viewModel.addNewCustomer(
                        name = name,
                        fatherName = fatherName,
                        phone = phone,
                        initialBal = due,
                        avatarColor = colorVal,
                        honeypotText = honeypotField,
                        openedAtMillis = dialogOpenedAt,
                        onCustomerCreated = { customer ->
                            onCustomerAdded?.invoke(customer)
                        }
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("save_new_customer_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("सुरक्षित करें", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
            }
        }
    )
}
