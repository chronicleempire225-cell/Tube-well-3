package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.SupabaseAuthService
import com.example.data.util.EmailVerificationManager
import com.example.data.util.ShareHelper
import com.example.ui.components.AppTopBar
import com.example.ui.components.appTextFieldColors
import com.example.ui.theme.*
import com.example.ui.util.AutofillUtils
import com.example.ui.util.AutofillUtils.autofillEmail
import com.example.ui.util.AutofillUtils.autofillNewPassword
import com.example.ui.util.AutofillUtils.autofillPhone
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.BahiKhataViewModel
import kotlinx.coroutines.launch

private enum class ForgotStep {
    ENTER_PHONE,
    VERIFY_OTP,
    RESET_PASSWORD
}

@Composable
fun ForgotPasswordScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val focusManager = LocalFocusManager.current
    val coroutineScope = rememberCoroutineScope()

    var currentStep by remember { mutableStateOf(ForgotStep.ENTER_PHONE) }

    // Step 1: Input both phone and optional email
    var mobileNumber by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }

    // Account identification resolved for OTP
    var resolvedMobile by remember { mutableStateOf("") }
    var targetEmail by remember { mutableStateOf("") }

    // Step 2: OTP
    var otpInput by remember { mutableStateOf("") }

    // Step 3: New Password
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(true) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    key(currentLang) {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "पासवर्ड रीसेट / Reset Password",
                    viewModel = viewModel,
                    showBackButton = true,
                    onBackClick = {
                        when (currentStep) {
                            ForgotStep.ENTER_PHONE -> viewModel.navigateTo(AppScreen.LOGIN)
                            ForgotStep.VERIFY_OTP -> currentStep = ForgotStep.ENTER_PHONE
                            ForgotStep.RESET_PASSWORD -> currentStep = ForgotStep.VERIFY_OTP
                        }
                    }
                )
            },
            containerColor = OffWhiteBackground
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Spacer(modifier = Modifier.height(8.dp))

                    // Step Icon Header
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(AgriGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (currentStep) {
                                ForgotStep.ENTER_PHONE -> Icons.Default.LockReset
                                ForgotStep.VERIFY_OTP -> Icons.Default.MarkEmailRead
                                ForgotStep.RESET_PASSWORD -> Icons.Default.Key
                            },
                            contentDescription = "Reset Password",
                            tint = AgriGreenPrimary,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = when (currentStep) {
                            ForgotStep.ENTER_PHONE -> "पासवर्ड भूल गए?"
                            ForgotStep.VERIFY_OTP -> "ईमेल ओटीपी (OTP) सत्यापन"
                            ForgotStep.RESET_PASSWORD -> "नया पासवर्ड बनाएं"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = AgriGreenPrimary,
                        fontSize = 22.sp,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = when (currentStep) {
                            ForgotStep.ENTER_PHONE -> "मोबाइल नंबर या ईमेल दर्ज करें, सत्यापन ओटीपी ईमेल पर भेजा जाएगा"
                            ForgotStep.VERIFY_OTP -> if (targetEmail.isNotBlank()) "ईमेल (${EmailVerificationManager.maskEmail(targetEmail)}) पर भेजा गया 6 या 8 अंकों का ओटीपी दर्ज करें" else "सत्यापन के लिए 6 या 8 अंकों का ओटीपी दर्ज करें"
                            ForgotStep.RESET_PASSWORD -> "कृपया अपनी पसंद का नया सुरक्षा पासवर्ड या 4-अंकों का पिन सेट करें"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    // Step Indicator Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 20.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StepBubble(number = "1", title = "पहचान", isActive = currentStep == ForgotStep.ENTER_PHONE, isCompleted = currentStep > ForgotStep.ENTER_PHONE)
                        StepDivider(isCompleted = currentStep > ForgotStep.ENTER_PHONE)
                        StepBubble(number = "2", title = "ईमेल OTP", isActive = currentStep == ForgotStep.VERIFY_OTP, isCompleted = currentStep > ForgotStep.VERIFY_OTP)
                        StepDivider(isCompleted = currentStep > ForgotStep.VERIFY_OTP)
                        StepBubble(number = "3", title = "नया पासवर्ड", isActive = currentStep == ForgotStep.RESET_PASSWORD, isCompleted = false)
                    }

                    // Main Form Card
                    Surface(
                        color = SurfaceCard,
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            when (currentStep) {
                                // STEP 1: Enter Phone Number or Email
                                ForgotStep.ENTER_PHONE -> {
                                    // Field 1: Mobile Number
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "पंजीकृत मोबाइल नंबर",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = "${mobileNumber.length}/10",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (mobileNumber.length == 10) AgriGreenPrimary else TextMuted
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        OutlinedTextField(
                                            value = mobileNumber,
                                            onValueChange = { input ->
                                                val cleanDigits = input.filter { it.isDigit() }.take(10)
                                                mobileNumber = cleanDigits
                                                errorMessage = null
                                            },
                                            placeholder = { Text("10 अंकों का मोबाइल नंबर") },
                                            leadingIcon = {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(start = 12.dp, end = 6.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Phone,
                                                        contentDescription = "Phone",
                                                        tint = AgriGreenPrimary,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "+91",
                                                        fontWeight = FontWeight.Bold,
                                                        color = TextPrimary,
                                                        fontSize = 14.sp
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Box(
                                                        modifier = Modifier
                                                            .height(18.dp)
                                                            .width(1.dp)
                                                            .background(Color(0xFFCBD5E1))
                                                    )
                                                }
                                            },
                                            trailingIcon = {
                                                if (mobileNumber.isNotEmpty()) {
                                                    IconButton(onClick = { mobileNumber = ""; errorMessage = null }) {
                                                        Icon(
                                                            imageVector = Icons.Default.Close,
                                                            contentDescription = "Clear",
                                                            tint = TextSecondary,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            },
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Number,
                                                imeAction = ImeAction.Next
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                            ),
                                            singleLine = true,
                                            colors = appTextFieldColors(),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .autofillPhone { mobileNumber = it }
                                                .testTag("forgot_phone_input")
                                        )
                                    }

                                    // Field 2: Email ID (Both mobile & email option as requested)
                                    Column {
                                        Text(
                                            text = "पंजीकृत ईमेल आईडी (वैकल्पिक / यदि याद हो)",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )

                                        Spacer(modifier = Modifier.height(6.dp))

                                        OutlinedTextField(
                                            value = emailInput,
                                            onValueChange = {
                                                emailInput = it.trim()
                                                errorMessage = null
                                            },
                                            placeholder = { Text("जैसे: kisan@gmail.com") },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Email,
                                                    contentDescription = "Email",
                                                    tint = Color(0xFF0284C7),
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            },
                                            trailingIcon = {
                                                if (emailInput.isNotEmpty()) {
                                                    IconButton(onClick = { emailInput = ""; errorMessage = null }) {
                                                        Icon(
                                                            imageVector = Icons.Default.Close,
                                                            contentDescription = "Clear",
                                                            tint = TextSecondary,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            },
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Email,
                                                imeAction = ImeAction.Done
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onDone = { focusManager.clearFocus() }
                                            ),
                                            singleLine = true,
                                            colors = appTextFieldColors(),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .autofillEmail { emailInput = it }
                                                .testTag("forgot_email_input")
                                        )
                                    }

                                    // Helpful explanation box
                                    Surface(
                                        color = Color(0xFFEFF6FF),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Info,
                                                contentDescription = null,
                                                tint = Color(0xFF1D4ED8),
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "💡 सुरक्षा नियम: ओटीपी इस खाते में पंजीकृत ईमेल पर भेजा जाएगा। बिना SMS शुल्क के तुरंत सत्यापन होगा।",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFF1E3A8A),
                                                fontSize = 11.5.sp
                                            )
                                        }
                                    }

                                    // Error message banner
                                    if (errorMessage != null) {
                                        ErrorBanner(message = errorMessage ?: "")
                                    }

                                    Button(
                                        onClick = {
                                            focusManager.clearFocus()
                                            val cleanPhone = mobileNumber.trim()
                                            val cleanEmail = emailInput.trim().lowercase()

                                            if (cleanPhone.isEmpty() && cleanEmail.isEmpty()) {
                                                errorMessage = "कृपया 10 अंकों का मोबाइल नंबर या ईमेल आईडी दर्ज करें!"
                                                return@Button
                                            }
                                            if (cleanPhone.isNotEmpty() && cleanPhone.length != 10) {
                                                errorMessage = "कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें!"
                                                return@Button
                                            }
                                            if (cleanEmail.isNotEmpty() && !EmailVerificationManager.isValidEmail(cleanEmail)) {
                                                errorMessage = "कृपया सही ईमेल पता दर्ज करें!"
                                                return@Button
                                            }

                                            isLoading = true
                                            errorMessage = null

                                            coroutineScope.launch {
                                                val account = SupabaseAuthService.lookupAccountForReset(
                                                    identifier = cleanPhone.ifBlank { cleanEmail },
                                                    context = context,
                                                    repository = viewModel.repository
                                                ) ?: if (cleanEmail.isNotBlank() && cleanPhone.isNotBlank()) {
                                                    SupabaseAuthService.lookupAccountForReset(
                                                        identifier = cleanEmail,
                                                        context = context,
                                                        repository = viewModel.repository
                                                    )
                                                } else null

                                                isLoading = false

                                                val finalPhone = account?.phone ?: cleanPhone
                                                val finalEmail = account?.email?.ifBlank { null } ?: cleanEmail

                                                resolvedMobile = finalPhone
                                                targetEmail = finalEmail

                                                if (finalEmail.isNotBlank()) {
                                                    val res = EmailVerificationManager.sendEmailOtp(
                                                        context = context,
                                                        email = finalEmail,
                                                        purpose = "पासवर्ड रीसेट"
                                                    )
                                                    otpInput = ""
                                                    if (res.success) {
                                                        currentStep = ForgotStep.VERIFY_OTP
                                                    } else {
                                                        errorMessage = res.message
                                                    }
                                                } else {
                                                    errorMessage = "इस खाते में कोई ईमेल नहीं जुड़ा है। कृपया पंजीकृत ईमेल दर्ज करें।"
                                                }
                                            }
                                        },
                                        enabled = !isLoading,
                                        colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                            .testTag("get_otp_button")
                                    ) {
                                        if (isLoading) {
                                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("खाता खोज रहे हैं...", fontWeight = FontWeight.Bold, color = Color.White)
                                        } else {
                                            Text(
                                                text = "ओटीपी प्राप्त करें →",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }

                                // STEP 2: Verify OTP
                                ForgotStep.VERIFY_OTP -> {
                                    Surface(
                                        color = Color(0xFFE8F5E9),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, Color(0xFFA5D6A7)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MarkEmailRead,
                                                contentDescription = null,
                                                tint = AgriGreenPrimary,
                                                modifier = Modifier.size(22.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = if (targetEmail.isNotBlank()) {
                                                        "📧 पंजीकृत ईमेल पर ओटीपी भेज दिया गया है:"
                                                    } else {
                                                        "📱 मोबाइल +91 $resolvedMobile के लिए ओटीपी:"
                                                    },
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = Color(0xFF1B5E20),
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = if (targetEmail.isNotBlank()) {
                                                        EmailVerificationManager.maskEmail(targetEmail)
                                                    } else {
                                                        "+91 $resolvedMobile (कोई ईमेल पंजीकृत नहीं)"
                                                    },
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = Color(0xFF0F5132),
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                        }
                                    }

                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "ईमेल सत्यापन ओटीपी (Email OTP)",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        OutlinedTextField(
                                            value = otpInput,
                                            onValueChange = { input ->
                                                val clean = input.filter { it.isDigit() }.take(8)
                                                otpInput = clean
                                                errorMessage = null
                                            },
                                            placeholder = { Text("ईमेल में आया 6 या 8 अंकों का कोड दर्ज करें") },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Pin,
                                                    contentDescription = "OTP",
                                                    tint = RoyalOrange,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            },
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Number,
                                                imeAction = ImeAction.Done
                                            ),
                                            singleLine = true,
                                            colors = appTextFieldColors(focusedBorderColor = RoyalOrange, focusedLabelColor = RoyalOrange),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("otp_input_field")
                                        )

                                        if (targetEmail.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            OutlinedButton(
                                                onClick = { EmailVerificationManager.openEmailClient(context) },
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(vertical = 4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Email,
                                                    contentDescription = null,
                                                    tint = Color(0xFF0284C7),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "📧 ईमेल ऐप खोलें (Open Inbox)",
                                                    fontSize = 12.sp,
                                                    color = Color(0xFF0284C7),
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                        }
                                    }

                                    // Resend OTP Option
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "ओटीपी नहीं मिला?",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF64748B)
                                        )
                                        TextButton(
                                            onClick = {
                                                coroutineScope.launch {
                                                    if (targetEmail.isNotBlank()) {
                                                        val res = EmailVerificationManager.sendEmailOtp(
                                                            context = context,
                                                            email = targetEmail,
                                                            purpose = "पासवर्ड रीसेट"
                                                        )
                                                        Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                                                    }
                                                    errorMessage = null
                                                }
                                            }
                                        ) {
                                            Text("दोबारा भेजें (Resend)", fontWeight = FontWeight.Bold, color = Color(0xFF0284C7), fontSize = 12.sp)
                                        }
                                    }

                                    if (errorMessage != null) {
                                        ErrorBanner(message = errorMessage ?: "")
                                    }

                                    Button(
                                        onClick = {
                                            focusManager.clearFocus()
                                            if (otpInput.length < 6) {
                                                errorMessage = "कृपया ईमेल में आया सही 6 या 8 अंकों का ओटीपी दर्ज करें!"
                                                return@Button
                                            }

                                            coroutineScope.launch {
                                                isLoading = true
                                                val verifyTarget = targetEmail.ifBlank { resolvedMobile }
                                                val verifyRes = EmailVerificationManager.verifyOtp(context, verifyTarget, otpInput)
                                                isLoading = false

                                                if (verifyRes.isSuccess) {
                                                    errorMessage = null
                                                    currentStep = ForgotStep.RESET_PASSWORD
                                                } else {
                                                    errorMessage = verifyRes.message
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                            .testTag("verify_otp_button")
                                    ) {
                                        Text(
                                            text = "ओटीपी सत्यापित करें →",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }

                                // STEP 3: Reset Password
                                ForgotStep.RESET_PASSWORD -> {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "सुरक्षा पासवर्ड / 4-अंकों का पिन",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = AgriGreenPrimary
                                        )

                                        TextButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                            Text(
                                                text = if (isPasswordVisible) "छिपाएं" else "दिखाएं",
                                                color = RoyalOrange,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.labelMedium
                                            )
                                        }
                                    }

                                    // New Password
                                    Column {
                                        Text(
                                            text = "नया पासवर्ड / पिन:",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        OutlinedTextField(
                                            value = newPassword,
                                            onValueChange = {
                                                newPassword = it
                                                errorMessage = null
                                            },
                                            placeholder = { Text("नया पासवर्ड या 4-अंकों का पिन") },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Lock,
                                                    contentDescription = "New Password",
                                                    tint = AgriGreenPrimary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            },
                                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Password,
                                                imeAction = ImeAction.Next
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                            ),
                                            singleLine = true,
                                            colors = appTextFieldColors(),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .autofillNewPassword { newPassword = it }
                                                .testTag("new_password_input")
                                        )
                                    }

                                    // Confirm Password
                                    Column {
                                        Text(
                                            text = "नए पासवर्ड की पुष्टि करें:",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        OutlinedTextField(
                                            value = confirmPassword,
                                            onValueChange = {
                                                confirmPassword = it
                                                errorMessage = null
                                            },
                                            placeholder = { Text("दोबारा वही पासवर्ड दर्ज करें") },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.LockReset,
                                                    contentDescription = "Confirm Password",
                                                    tint = RoyalOrange,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            },
                                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Password,
                                                imeAction = ImeAction.Done
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onDone = {
                                                    focusManager.clearFocus()
                                                    submitPasswordReset(
                                                        context = context,
                                                        viewModel = viewModel,
                                                        mobile = resolvedMobile,
                                                        newPass = newPassword,
                                                        confirmPass = confirmPassword,
                                                        setLoading = { isLoading = it },
                                                        setError = { errorMessage = it }
                                                    )
                                                }
                                            ),
                                            singleLine = true,
                                            colors = appTextFieldColors(focusedBorderColor = RoyalOrange, focusedLabelColor = RoyalOrange),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .autofillNewPassword { confirmPassword = it }
                                                .testTag("confirm_password_input")
                                        )
                                    }

                                    if (errorMessage != null) {
                                        ErrorBanner(message = errorMessage ?: "")
                                    }

                                    Button(
                                        onClick = {
                                            focusManager.clearFocus()
                                            submitPasswordReset(
                                                context = context,
                                                viewModel = viewModel,
                                                mobile = resolvedMobile,
                                                newPass = newPassword,
                                                confirmPass = confirmPassword,
                                                setLoading = { isLoading = it },
                                                setError = { errorMessage = it }
                                            )
                                        },
                                        enabled = !isLoading,
                                        colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                            .testTag("save_new_password_button")
                                    ) {
                                        if (isLoading) {
                                            CircularProgressIndicator(
                                                color = Color.White,
                                                modifier = Modifier.size(22.dp),
                                                strokeWidth = 2.5.dp
                                            )
                                        } else {
                                            Text(
                                                text = "नया पासवर्ड सहेजें और लॉगिन करें ✓",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Return to Login Link
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .clickable { viewModel.navigateTo(AppScreen.LOGIN) }
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = RoyalOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "लॉगिन पेज पर वापस जाएं",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = RoyalOrange
                        )
                    }
                }

                // Bottom-Left Support Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 8.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .clickable { ShareHelper.openSupportEmail(context) }
                            .testTag("forgot_support_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.HeadsetMic,
                                contentDescription = "Support",
                                tint = AgriGreenPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Support / Help",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepBubble(
    number: String,
    title: String,
    isActive: Boolean,
    isCompleted: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isCompleted -> AgriGreenPrimary
                        isActive -> RoyalOrange
                        else -> Color(0xFFE2E8F0)
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isCompleted) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Done",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Text(
                    text = number,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) Color.White else Color(0xFF64748B),
                    fontSize = 13.sp
                )
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isActive || isCompleted) FontWeight.Bold else FontWeight.Medium,
            color = if (isActive) RoyalOrange else if (isCompleted) AgriGreenPrimary else Color(0xFF64748B),
            fontSize = 11.sp
        )
    }
}

@Composable
private fun StepDivider(isCompleted: Boolean) {
    Box(
        modifier = Modifier
            .width(40.dp)
            .height(2.dp)
            .padding(horizontal = 4.dp)
            .background(if (isCompleted) AgriGreenPrimary else Color(0xFFCBD5E1))
    )
}

@Composable
private fun ErrorBanner(message: String) {
    Surface(
        color = DueRedContainer,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = "Error",
                tint = DueRed,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = message,
                color = DueRed,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun submitPasswordReset(
    context: android.content.Context,
    viewModel: BahiKhataViewModel,
    mobile: String,
    newPass: String,
    confirmPass: String,
    setLoading: (Boolean) -> Unit,
    setError: (String?) -> Unit
) {
    val cleanMobile = mobile.trim()
    val cleanPass = newPass.trim()
    val cleanConfirm = confirmPass.trim()

    if (cleanMobile.length != 10) {
        setError("कृपया 10 अंकों का सही मोबाइल नंबर दर्ज करें!")
        return
    }
    if (cleanPass.isEmpty()) {
        setError("कृपया नया पासवर्ड या 4-अंकों का पिन दर्ज करें!")
        return
    }
    if (cleanPass != cleanConfirm) {
        setError("दोनों पासवर्ड आपस में मेल नहीं खा रहे हैं!")
        return
    }

    setLoading(true)
    setError(null)

    viewModel.resetPasswordAndLogin(
        mobile = cleanMobile,
        newPinOrPassword = cleanPass,
        onSuccess = {
            setLoading(false)
            // Save updated credentials to Google Password Manager / Android Autofill
            AutofillUtils.commitAutofill(context)
        },
        onError = { err ->
            setLoading(false)
            setError(err)
            AutofillUtils.cancelAutofill(context)
        }
    )
}
