package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.remoteconfig.RewardedAdManager

/**
 * Finds the host Activity from a Compose Context.
 */
fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

/**
 * Rewarded Ad Unlock Dialog.
 * Prompts user to watch a short video ad to unlock all messaging & PDF export features for 24 hours.
 * 
 * Per business rules:
 * - Banner ads continue running as normal.
 * - WhatsApp & SMS receipts, PDF statement reports, and downloads unlock for 24 hours.
 */
@Composable
fun RewardedAdUnlockDialog(
    onDismiss: () -> Unit,
    onUnlockSuccess: () -> Unit,
    featureName: String = "मैसेज व PDF शेयरिंग"
) {
    val context = LocalContext.current
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val rewardedConfig = configs["REWARDED_FEATURE_UNLOCK"]
    val requiredSeconds = rewardedConfig?.requiredWatchSeconds ?: 8

    val isAdReady by RewardedAdManager.isReadyFlow.collectAsState()
    var isLoadingAd by remember { mutableStateOf(false) }

    // Preload if not yet cached
    LaunchedEffect(Unit) {
        RewardedAdManager.preload(context)
    }

    Dialog(
        onDismissRequest = { if (!isLoadingAd) onDismiss() },
        properties = DialogProperties(dismissOnBackPress = !isLoadingAd, dismissOnClickOutside = !isLoadingAd)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .testTag("rewarded_ad_unlock_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Close Button
                Box(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .align(Alignment.Center)
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(Color(0xFFFEF3C7), Color(0xFFFDE68A))
                                ),
                                shape = CircleShape
                            )
                            .border(2.dp, Color(0xFFF59E0B), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CardGiftcard,
                            contentDescription = "Gift",
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(32.dp),
                        enabled = !isLoadingAd
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Title
                Text(
                    text = "24 घंटे के लिए फ़ीचर्स अनलॉक करें",
                    fontWeight = FontWeight.Black,
                    fontSize = 19.sp,
                    color = Color(0xFF0F172A),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Subtitle
                Text(
                    text = "एक छोटा वीडियो विज्ञापन देखें और 24 घंटे के लिए सभी फीचर्स और मुंशी AI का मुफ़्त उपयोग करें!",
                    fontSize = 13.sp,
                    color = Color(0xFF475569),
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Unlocked Features Card
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FeatureRow("ग्राहक को सीधे WhatsApp पर रसीद भेजना")
                        FeatureRow("SMS मैसेज द्वारा हिसाब व रसीद भेजना")
                        FeatureRow("PDF खाता व सिचाई रिपोर्ट डाउनलोड/शेयर")
                        FeatureRow("मुंशी AI वॉयस असिस्टेंट (बोलकर खाता व लाइव हिसाब)")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Clarification note regarding banner ads & VIP option
                Surface(
                    color = Color(0xFFFEF9C3),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE047)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFFB45309),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "नोट: बैनर विज्ञापन चालू रहेंगे (यह 24 घंटे का फ़ीचर पास है)।",
                                fontSize = 11.sp,
                                color = Color(0xFF92400E),
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "👑 वीआईपी (VIP) पास: यदि आप बिना विज्ञापन देखे हमेशा के लिए यह सभी फीचर्स + 100% Ad-Free चाहते हैं, तो सेटिंग्स में VIP पास भी ले सकते हैं!",
                            fontSize = 11.sp,
                            color = Color(0xFF78350F),
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Watch Video Ad Button
                Button(
                    onClick = {
                        val activity = context.findActivity()
                        if (activity == null) {
                            Toast.makeText(context, "त्रुटि: एक्टिविटी उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        if (!RewardedAdManager.isAdReady()) {
                            isLoadingAd = true
                            RewardedAdManager.preload(context)
                            Toast.makeText(context, "विज्ञापन लोड हो रहा है, कृपया 2 सेकंड प्रतीक्षा करें...", Toast.LENGTH_SHORT).show()
                            // Try again after small delay
                            return@Button
                        }

                        isLoadingAd = true
                        RewardedAdManager.showRewardedAd(
                            activity = activity,
                            requiredSeconds = requiredSeconds,
                            onUserEarnedReward = {
                                isLoadingAd = false
                                RemoteConfigService.grant24HourFeaturePass(context)
                                Toast.makeText(
                                    context,
                                    "🎉 बधाई! 24 घंटे के लिए सभी मैसेज और PDF फ़ीचर्स अनलॉक हो गए हैं!",
                                    Toast.LENGTH_LONG
                                ).show()
                                onUnlockSuccess()
                                onDismiss()
                            },
                            onAdDismissed = {
                                isLoadingAd = false
                            },
                            onAdFailed = { error ->
                                isLoadingAd = false
                                Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    enabled = !isLoadingAd,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF16A34A)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("watch_rewarded_ad_button")
                ) {
                    if (isLoadingAd) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("वीडियो खुल रहा है...", color = Color.White, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "वीडियो देखें (24 घंटे अनलॉक)",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Later / Cancel Button
                TextButton(
                    onClick = onDismiss,
                    enabled = !isLoadingAd,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("बाद में", color = Color(0xFF64748B), fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun FeatureRow(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF16A34A),
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF1E293B)
        )
    }
}
