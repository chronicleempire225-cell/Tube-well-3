package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.data.security.AppSecurityService
import com.example.data.supabase.SupabaseAuthService
import com.example.data.util.EmailVerificationManager
import com.example.data.util.ShareHelper
import com.example.ui.components.AppTopBar
import com.example.ui.components.AvatarView
import com.example.ui.components.appTextFieldColors
import com.example.ui.theme.*
import com.example.ui.util.AutofillUtils
import com.example.ui.util.AutofillUtils.autofillEmail
import com.example.ui.util.AutofillUtils.autofillNewPassword
import com.example.ui.util.AutofillUtils.autofillPersonName
import com.example.ui.util.AutofillUtils.autofillPhone
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.BahiKhataViewModel

enum class SignUpStep {
    PROFILE_DETAILS,
    SECURITY_PIN
}

@Composable
fun SignUpScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val coroutineScope = rememberCoroutineScope()
    val currentLang by viewModel.currentLanguage.collectAsState()

    var currentStep by remember { mutableStateOf(SignUpStep.PROFILE_DETAILS) }

    // Step 1 States
    var ownerName by remember { mutableStateOf("") }
    var agencyName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var isEmailVerified by remember { mutableStateOf(false) }
    var defaultRate by remember { mutableStateOf("160") }

    // Email OTP Verification Dialog States
    var showEmailOtpDialog by remember { mutableStateOf(false) }
    var activeEmailVerificationToken by remember { mutableStateOf("") }
    var emailOtpInput by remember { mutableStateOf("") }
    var emailOtpError by remember { mutableStateOf<String?>(null) }
    var isCloudSupabaseOtp by remember { mutableStateOf(false) }
    var isSendingEmailOtp by remember { mutableStateOf(false) }
    var isVerifyingEmailOtp by remember { mutableStateOf(false) }

    // Live Auto-Detection for Email Verification confirmation from Email Link or Deep Link in SignUpScreen
    LaunchedEffect(showEmailOtpDialog, activeEmailVerificationToken, email) {
        if (!showEmailOtpDialog) return@LaunchedEffect
        // Immediate check for deep link confirmation
        if (EmailVerificationManager.isEmailConfirmed(email)) {
            isEmailVerified = true
            showEmailOtpDialog = false
            return@LaunchedEffect
        }
        while (showEmailOtpDialog && !isEmailVerified) {
            kotlinx.coroutines.delay(2000L)
            val isConfirmed = EmailVerificationManager.isEmailConfirmed(email) ||
                EmailVerificationManager.checkAutoVerificationStatus(
                    context = context,
                    email = email,
                    token = activeEmailVerificationToken
                )
            if (isConfirmed) {
                isEmailVerified = true
                showEmailOtpDialog = false
                Toast.makeText(context, "🎉 बधाई हो! ईमेल लिंक से स्वतः सत्यापित हो गया!", Toast.LENGTH_LONG).show()
                break
            }
        }
    }

    // Step 2 States
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var isPinVisible by remember { mutableStateOf(true) } // High visibility as requested
    var agreedToTerms by remember { mutableStateOf(false) }

    // 🛡️ Invisible Honeypot & Timing Bot Detection for SignUp
    var signupHoneypot by remember { mutableStateOf("") }
    val screenOpenedAt = remember { System.currentTimeMillis() }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    val isOnline = remember { SupabaseAuthService.isNetworkAvailable(context) }

    key(currentLang) {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = if (currentStep == SignUpStep.PROFILE_DETAILS) "नया खाता: प्रोफाइल विवरण" else "नया खाता: सुरक्षा पिन",
                    viewModel = viewModel,
                    showBackButton = true,
                    onBackClick = {
                        if (currentStep == SignUpStep.SECURITY_PIN) {
                            currentStep = SignUpStep.PROFILE_DETAILS
                        } else {
                            viewModel.navigateTo(AppScreen.AUTH_CHOICE)
                        }
                    }
                )
            },
            containerColor = OffWhiteBackground
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Step Progress Indicator (Step 1 -> Step 2)
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Step 1 Chip
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable {
                                currentStep = SignUpStep.PROFILE_DETAILS
                            }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(if (currentStep == SignUpStep.PROFILE_DETAILS) AgriGreenPrimary else Color(0xFF15803D)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (currentStep == SignUpStep.SECURITY_PIN) "✓" else "1",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "1. प्रोफाइल विवरण",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (currentStep == SignUpStep.PROFILE_DETAILS) FontWeight.Bold else FontWeight.Medium,
                                color = if (currentStep == SignUpStep.PROFILE_DETAILS) AgriGreenPrimary else Color(0xFF475569)
                            )
                        }

                        // Arrow
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )

                        // Step 2 Chip
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(if (currentStep == SignUpStep.SECURITY_PIN) RoyalOrange else Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "2",
                                    color = if (currentStep == SignUpStep.SECURITY_PIN) Color.White else Color(0xFF64748B),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "2. सुरक्षा पिन",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (currentStep == SignUpStep.SECURITY_PIN) FontWeight.Bold else FontWeight.Medium,
                                color = if (currentStep == SignUpStep.SECURITY_PIN) RoyalOrange else Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                // Network Status Banner
                Surface(
                    color = if (isOnline) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, if (isOnline) Color(0xFFA5D6A7) else Color(0xFFFFCDD2)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isOnline) Color(0xFF2E7D32) else Color(0xFFC62828))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isOnline) "🟢 क्लाउड कनेक्टेड (लाइव प्रमाणीकरण सक्रिय)" else "🔴 इंटरनेट बंद है (खाता बनाने के लिए इंटरनेट आवश्यक है)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isOnline) Color(0xFF1B5E20) else Color(0xFFB71C1C),
                            fontSize = 11.sp
                        )
                    }
                }

                // ==========================================
                // STEP 1: PROFILE DETAILS
                // ==========================================
                if (currentStep == SignUpStep.PROFILE_DETAILS) {
                    // Avatar Card
                    Surface(
                        color = SurfaceCard,
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            AvatarView(
                                name = if (ownerName.isNotBlank()) ownerName else if (agencyName.isNotBlank()) agencyName else "Kisan Seva",
                                size = 72,
                                shape = CircleShape
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (ownerName.isNotBlank()) ownerName else "ट्यूबवेल मालिक प्रोफाइल",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "कृपया अपनी सामान्य जानकारी दर्ज करें",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Form Inputs Card
                    Surface(
                        color = SurfaceCard,
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Owner Name
                            OutlinedTextField(
                                value = ownerName,
                                onValueChange = { ownerName = it; errorMessage = null },
                                label = { Text(viewModel.getString("owner_name")) },
                                placeholder = { Text("जैसे: रामेश्वर किसान") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = AgriGreenPrimary)
                                },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                singleLine = true,
                                colors = appTextFieldColors(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .autofillPersonName { ownerName = it }
                                    .testTag("signup_owner_name_input")
                            )

                            // Agency / Tubewell Name
                            OutlinedTextField(
                                value = agencyName,
                                onValueChange = { agencyName = it },
                                label = { Text(viewModel.getString("agency_name")) },
                                placeholder = { Text("जैसे: Kisan Tubewell & Sinchai Seva") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Storefront, contentDescription = null, tint = AgriGreenPrimary)
                                },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                singleLine = true,
                                colors = appTextFieldColors(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("signup_agency_name_input")
                            )

                            // Mobile Number
                            OutlinedTextField(
                                value = phone,
                                onValueChange = { input ->
                                    val clean = input.filter { it.isDigit() }.take(10)
                                    phone = clean
                                    errorMessage = null
                                },
                                label = { Text(viewModel.getString("mobile_number") + " *") },
                                placeholder = { Text("10 अंकों का मोबाइल नंबर") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = AgriGreenPrimary)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                singleLine = true,
                                colors = appTextFieldColors(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .autofillPhone { phone = it }
                                    .testTag("signup_phone_input")
                            )

                            // Optional Email ID Field
                            Column {
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { input ->
                                        email = input.trim()
                                        // Reset verification if user modifies email
                                        isEmailVerified = false
                                        errorMessage = null
                                    },
                                    label = { Text("ईमेल आईडी (वैकल्पिक / Optional)") },
                                    placeholder = { Text("जैसे: kisan@gmail.com") },
                                    leadingIcon = {
                                        Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = Color(0xFF1E88E5))
                                    },
                                    trailingIcon = {
                                        if (isEmailVerified) {
                                            Surface(
                                                color = Color(0xFFDCFCE7),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = "Verified",
                                                        tint = Color(0xFF15803D),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "सत्यापित",
                                                        color = Color(0xFF15803D),
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                    singleLine = true,
                                    colors = appTextFieldColors(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .autofillEmail { email = it; isEmailVerified = false }
                                        .testTag("signup_email_input")
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                // Email Action and Helpful Advice
                                if (isEmailVerified) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VerifiedUser,
                                            contentDescription = null,
                                            tint = Color(0xFF15803D),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "✅ ईमेल सत्यापित है! पिन भूलने पर इस ईमेल पर ओटीपी आएगा।",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF15803D),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                } else if (email.isNotBlank()) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "💡 बिना SMS खर्च के रिकवरी के लिए ईमेल वेरीफाई करें:",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B),
                                            modifier = Modifier.weight(1f)
                                        )

                                        Button(
                                            onClick = {
                                                focusManager.clearFocus()
                                                if (!EmailVerificationManager.isValidEmail(email)) {
                                                    errorMessage = "कृपया मान्य ईमेल पता दर्ज करें!"
                                                    return@Button
                                                }
                                                coroutineScope.launch {
                                                    isSendingEmailOtp = true
                                                    val res = EmailVerificationManager.sendEmailOtp(context, email, "साइन-अप ईमेल सत्यापन")
                                                    isSendingEmailOtp = false
                                                    isCloudSupabaseOtp = res.isCloudSupabase
                                                    activeEmailVerificationToken = res.token
                                                    emailOtpInput = ""
                                                    emailOtpError = null
                                                    showEmailOtpDialog = true
                                                    Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                                                }
                                            },
                                            enabled = !isSendingEmailOtp,
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                            modifier = Modifier.testTag("signup_verify_email_btn")
                                        ) {
                                            if (isSendingEmailOtp) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(14.dp),
                                                    color = Color.White,
                                                    strokeWidth = 2.dp
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "भेज रहे हैं...",
                                                    fontSize = 11.sp,
                                                    color = Color.White
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.MarkEmailRead,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "वेरीफाई करें",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Text(
                                        text = "💡 (वैकल्पिक) ईमेल जोड़ने से पिन भूलने पर ईमेल द्वारा मुफ़्त ओटीपी से रिकवरी हो सकेगी।",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B),
                                        modifier = Modifier.padding(horizontal = 4.dp)
                                    )
                                }
                            }

                            // Default Rate
                            OutlinedTextField(
                                value = defaultRate,
                                onValueChange = { defaultRate = it },
                                label = { Text(viewModel.getString("default_rate") + " (₹/hr)") },
                                placeholder = { Text("160") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.CurrencyRupee, contentDescription = null, tint = RoyalOrange)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                singleLine = true,
                                colors = appTextFieldColors(focusedBorderColor = RoyalOrange, focusedLabelColor = RoyalOrange),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("signup_rate_input")
                            )

                            // 🛡️ Invisible Honeypot Trap (Hidden from real human users, auto-filled by bots)
                            Box(
                                modifier = Modifier
                                    .size(0.dp)
                                    .clipToBounds()
                            ) {
                                BasicTextField(
                                    value = signupHoneypot,
                                    onValueChange = { signupHoneypot = it },
                                    modifier = Modifier.testTag("signup_website_url_field")
                                )
                            }

                            if (errorMessage != null) {
                                Surface(
                                    color = Color(0xFFFEF2F2),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, Color(0xFFFECACA)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = DueRed, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = errorMessage ?: "",
                                            color = DueRed,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Next Step Button: Move to Security PIN
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            val cleanPhone = phone.trim()

                            // 🛡️ Invisible Bot Shield Validation for Step 1
                            if (AppSecurityService.isBotTrapTriggered(signupHoneypot)) {
                                errorMessage = "⛔ सुरक्षा चेतावनी: स्वचालित बॉट गतिविधि पकड़ी गई!"
                                coroutineScope.launch(Dispatchers.IO) {
                                    AppSecurityService.reportBotActivitySilently(
                                        context = context,
                                        profileId = "bot_signup_target",
                                        action = "SIGNUP_STEP1_BOT_TRAP",
                                        details = "Honeypot triggered with '$signupHoneypot', phone=$cleanPhone, name=$ownerName",
                                        phone = cleanPhone
                                    )
                                    if (cleanPhone.length == 10) {
                                        AppSecurityService.blockAccount(
                                            context = context,
                                            phone = cleanPhone,
                                            reason = "स्वचालित बॉट द्वारा खाता बनाने का प्रयास (Honeypot)",
                                            profileId = ""
                                        )
                                    }
                                }
                                return@Button
                            }

                            if (ownerName.isBlank()) {
                                errorMessage = "कृपया अपना नाम दर्ज करें!"
                            } else if (cleanPhone.length != 10 || !cleanPhone.matches(Regex("^[6-9]\\d{9}$"))) {
                                errorMessage = "कृपया 10 अंकों का मान्य भारतीय मोबाइल नंबर दर्ज करें (6, 7, 8 या 9 से शुरू)!"
                            } else if (email.isNotBlank() && !EmailVerificationManager.isValidEmail(email)) {
                                errorMessage = "कृपया सही ईमेल आईडी दर्ज करें अथवा इसे खाली छोड़ें!"
                            } else {
                                errorMessage = null
                                currentStep = SignUpStep.SECURITY_PIN
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("signup_goto_pin_btn")
                    ) {
                        Text(
                            text = "आगे बढ़ें: सुरक्षा पिन सेट करें →",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // ==========================================
                // STEP 2: SECURITY PIN & CONFIRMATION
                // ==========================================
                if (currentStep == SignUpStep.SECURITY_PIN) {
                    // Back to step 1 link
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { currentStep = SignUpStep.PROFILE_DETAILS }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = RoyalOrange,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "← वापस प्रोफ़ाइल विवरण में बदलाव करें",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = RoyalOrange
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Profile Summary Card
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "👤 $ownerName",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A),
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "📱 $phone",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1E293B),
                                    fontSize = 13.sp
                                )
                            }
                            if (agencyName.isNotBlank()) {
                                Text(
                                    text = "🏢 $agencyName",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                            if (email.isNotBlank()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Text(
                                        text = "📧 $email",
                                        fontSize = 12.sp,
                                        color = Color(0xFF0284C7)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isEmailVerified) "(सत्यापित ✓)" else "(वैकल्पिक)",
                                        fontSize = 11.sp,
                                        color = if (isEmailVerified) Color(0xFF15803D) else Color(0xFF64748B),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Security PIN Input Card
                    Surface(
                        color = SurfaceCard,
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "सुरक्षा पिन (4 Digits PIN):",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = AgriGreenPrimary
                                )

                                TextButton(onClick = { isPinVisible = !isPinVisible }) {
                                    Text(
                                        text = if (isPinVisible) "पिन छिपाएं" else "पिन दिखाएं",
                                        color = RoyalOrange,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }

                            // PIN Input
                            OutlinedTextField(
                                value = pin,
                                onValueChange = {
                                    if (it.length <= 4 && it.all { ch -> ch.isDigit() }) {
                                        pin = it
                                        errorMessage = null
                                    }
                                },
                                label = { Text(viewModel.getString("create_pin")) },
                                placeholder = { Text("जैसे: 1234") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = AgriGreenPrimary)
                                },
                                visualTransformation = if (isPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
                                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                                singleLine = true,
                                colors = appTextFieldColors(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .autofillNewPassword { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) pin = it }
                                    .testTag("signup_pin_input")
                            )

                            // Confirm PIN Input
                            OutlinedTextField(
                                value = confirmPin,
                                onValueChange = {
                                    if (it.length <= 4 && it.all { ch -> ch.isDigit() }) {
                                        confirmPin = it
                                        errorMessage = null
                                    }
                                },
                                label = { Text(viewModel.getString("confirm_pin")) },
                                placeholder = { Text("दोबारा 4 अंक दर्ज करें") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.LockReset, contentDescription = null, tint = RoyalOrange)
                                },
                                visualTransformation = if (isPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                singleLine = true,
                                colors = appTextFieldColors(focusedBorderColor = RoyalOrange, focusedLabelColor = RoyalOrange),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .autofillNewPassword { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) confirmPin = it }
                                    .testTag("signup_confirm_pin_input")
                            )

                            // 🛡️ Invisible Honeypot Trap in Step 2 (Auto-filled by automated bots)
                            Box(
                                modifier = Modifier
                                    .size(0.dp)
                                    .clipToBounds()
                            ) {
                                BasicTextField(
                                    value = signupHoneypot,
                                    onValueChange = { signupHoneypot = it },
                                    modifier = Modifier.testTag("signup_step2_honeypot_field")
                                )
                            }

                            if (errorMessage != null) {
                                Surface(
                                    color = Color(0xFFFEF2F2),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, Color(0xFFFECACA)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = DueRed, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = errorMessage ?: "",
                                            color = DueRed,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Terms & Conditions Agreement Card
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (agreedToTerms) Color(0xFFBBF7D0) else Color(0xFFFECACA)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("signup_terms_card")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = agreedToTerms,
                                    onCheckedChange = { agreedToTerms = it },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = AgriGreenPrimary,
                                        checkmarkColor = Color.White
                                    ),
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { agreedToTerms = !agreedToTerms }
                                ) {
                                    Text(
                                        text = "मैं नियम, शर्तें और प्राइवेसी पॉलिसी स्वीकार करता हूँ",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF1E293B),
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "खाता बनाकर आप सभी शर्तों से सहमत होते हैं",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF64748B),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Policy link
                            Surface(
                                color = Color(0xFFF0FDF4),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { ShareHelper.openPrivacyPolicy(context) }
                                    .testTag("signup_open_terms_link_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Description,
                                            contentDescription = "Policy Document",
                                            tint = AgriGreenPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "📜 नियम व शर्तें (Terms & Policy) पढ़ें",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = AgriGreenPrimary,
                                            textDecoration = TextDecoration.Underline,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.OpenInNew,
                                        contentDescription = "Open Web Link",
                                        tint = AgriGreenPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Final Submit Button
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            val cleanPhone = phone.trim()
                            if (pin.length != 4) {
                                errorMessage = "कृपया 4 अंकों का सुरक्षा पिन बनाएं!"
                            } else if (pin != confirmPin) {
                                errorMessage = "दोनों पिन आपस में मेल नहीं खा रहे हैं!"
                            } else if (!agreedToTerms) {
                                errorMessage = "कृपया खाता बनाने के लिए नियम, शर्तें और प्राइवेसी पॉलिसी स्वीकार करें!"
                            } else if (!SupabaseAuthService.isNetworkAvailable(context)) {
                                errorMessage = "इंटरनेट बंद है! नया खाता बनाने के लिए कृपया इंटरनेट चालू करें ताकि आपका खाता क्लाउड में सुरक्षित हो सके।"
                            } else {
                                // 🛡️ Invisible Bot Shield & Timing Validation:
                                // Even if a bot attempts to inject real customer details,
                                // the honeypot field and human interaction duration threshold (< 2200ms) catches and blocks it!
                                val isBot = AppSecurityService.isBotDetected(
                                    honeypotText = signupHoneypot,
                                    openedAtMillis = screenOpenedAt,
                                    minAllowedMs = 2200L
                                )
                                if (isBot) {
                                    errorMessage = "⛔ सुरक्षा चेतावनी: स्वचालित बॉट (Automated Bot) गतिविधि पहचानी गई! सुरक्षा कारणों से यह पंजीकरण रोक दिया गया है और यह नंबर ब्लॉक कर दिया गया है।"
                                    coroutineScope.launch(Dispatchers.IO) {
                                        AppSecurityService.reportBotActivitySilently(
                                            context = context,
                                            profileId = "bot_signup_target",
                                            action = "SIGNUP_BOT_BLOCKED",
                                            details = "Bot attempted signup with phone=$cleanPhone, name=$ownerName, honeypot='$signupHoneypot', elapsed=${System.currentTimeMillis() - screenOpenedAt}ms",
                                            phone = cleanPhone
                                        )
                                        if (cleanPhone.length == 10) {
                                            AppSecurityService.blockAccount(
                                                context = context,
                                                phone = cleanPhone,
                                                reason = "स्वचालित बॉट द्वारा खाता बनाने की कोशिश के कारण ब्लॉक किया गया (Honeypot / Speed trap)",
                                                profileId = ""
                                            )
                                        }
                                    }
                                    return@Button
                                }

                                errorMessage = null
                                isLoading = true

                                coroutineScope.launch {
                                    val secStatus = AppSecurityService.checkSecurityStatus(context, cleanPhone)
                                    if (secStatus.isBlocked) {
                                        isLoading = false
                                        errorMessage = "⛔ सुरक्षा प्रतिबंध (Blocked): यह मोबाइल नंबर सुरक्षा कारणों से ब्लॉक है। सहायता के लिए एडमिन से संपर्क करें।"
                                        return@launch
                                    }

                                    val rate = defaultRate.toDoubleOrNull() ?: 160.0
                                    viewModel.createOwnerProfile(
                                        name = ownerName,
                                        agencyName = agencyName,
                                        phone = cleanPhone,
                                        pin = pin,
                                        defaultRate = rate,
                                        email = email.trim(),
                                        isEmailVerified = isEmailVerified,
                                        onSuccess = {
                                            isLoading = false
                                            AutofillUtils.commitAutofill(context)
                                        },
                                        onError = { err ->
                                            isLoading = false
                                            errorMessage = err
                                            AutofillUtils.cancelAutofill(context)
                                        }
                                    )
                                }
                            }
                        },
                        enabled = agreedToTerms && !isLoading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AgriGreenPrimary,
                            disabledContainerColor = Color(0xFFCBD5E1),
                            contentColor = Color.White,
                            disabledContentColor = Color(0xFF64748B)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("signup_submit_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "क्लाउड में सुरक्षित हो रहा है...",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        } else {
                            Text(
                                text = if (agreedToTerms) "खाता बनाएं और होम पेज पर जाएं ✓" else "🔒 पहले नियम व शर्तें स्वीकार करें",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (agreedToTerms) Color.White else Color(0xFF64748B)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Bottom-Left Support & Login Links
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .clickable { ShareHelper.openSupportEmail(context) }
                            .testTag("signup_support_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.HeadsetMic,
                                contentDescription = "Support",
                                tint = AgriGreenPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Support / Help",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        }
                    }

                    // Already have account link
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "खाता है?",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "लॉगिन करें",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = RoyalOrange,
                            modifier = Modifier
                                .clickable { viewModel.navigateTo(AppScreen.LOGIN) }
                                .testTag("signup_to_login_link")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Email OTP Verification Dialog
        if (showEmailOtpDialog) {
            AlertDialog(
                onDismissRequest = { showEmailOtpDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.MarkEmailRead, contentDescription = null, tint = Color(0xFF0284C7))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ईमेल ओटीपी सत्यापन", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (isCloudSupabaseOtp) {
                            Surface(
                                color = Color(0xFFF0FDF4),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudDone,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${EmailVerificationManager.maskEmail(email)} पर 6-अंकों का सत्यापन ओटीपी भेजा गया है। इनबॉक्स व स्पैम फोल्डर देखें।",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF14532D)
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = "आपके ईमेल (${EmailVerificationManager.maskEmail(email)}) पर सत्यापन कोड भेजा गया है।",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF334155)
                            )
                        }

                        // Open Mailbox Quick Action
                        OutlinedButton(
                            onClick = { EmailVerificationManager.openEmailClient(context) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ईमेल ऐप खोलें (Open Email App)",
                                fontSize = 12.sp,
                                color = Color(0xFF0284C7),
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Auto-verification live detection status
                        Surface(
                            color = Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp,
                                    color = Color(0xFF16A34A)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "लिंक पर क्लिक करते ही ऐप स्वतः सत्यापित हो जाएगा (या नीचे कोड डालें)",
                                    fontSize = 11.sp,
                                    color = Color(0xFF14532D)
                                )
                            }
                        }

                        OutlinedTextField(
                            value = emailOtpInput,
                            onValueChange = {
                                if (it.length <= 8 && it.all { ch -> ch.isDigit() }) {
                                    emailOtpInput = it
                                    emailOtpError = null
                                }
                            },
                            label = { Text("ईमेल में आया असली ओटीपी दर्ज करें") },
                            placeholder = { Text("6 या 8 अंकों का कोड (जैसे: 15364960)") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Pin, contentDescription = null, tint = Color(0xFF0284C7))
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                            singleLine = true,
                            colors = appTextFieldColors(focusedBorderColor = Color(0xFF0284C7), focusedLabelColor = Color(0xFF0284C7)),
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (emailOtpError != null) {
                            Text(
                                text = "⚠️ $emailOtpError",
                                color = DueRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isVerifyingEmailOtp = true
                                val verifyRes = EmailVerificationManager.verifyOtp(context, email, emailOtpInput)
                                isVerifyingEmailOtp = false
                                if (verifyRes.isSuccess) {
                                    isEmailVerified = true
                                    showEmailOtpDialog = false
                                    Toast.makeText(context, "🎉 ईमेल सफलतापूर्वक सत्यापित हो गया!", Toast.LENGTH_LONG).show()
                                } else {
                                    emailOtpError = verifyRes.message
                                }
                            }
                        },
                        enabled = !isVerifyingEmailOtp && emailOtpInput.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary)
                    ) {
                        if (isVerifyingEmailOtp) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("जांच रहे हैं...", color = Color.White)
                        } else {
                            Text("सत्यापित करें ✓", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEmailOtpDialog = false }) {
                        Text("रद्द करें", color = Color(0xFF64748B))
                    }
                }
            )
        }
    }
}
