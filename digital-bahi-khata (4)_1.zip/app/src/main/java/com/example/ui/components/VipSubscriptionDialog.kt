package com.example.ui.components

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.payment.PaymentEvent
import com.example.data.payment.RazorpayManager
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.supabase.SupabaseAuthService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * VIP Subscription Modal with Monthly and Yearly Plan Selection.
 * Connected seamlessly with Razorpay Checkout and dynamic Supabase pricing.
 */
@Composable
fun VipSubscriptionDialog(
    onDismiss: () -> Unit,
    onPaymentSuccess: () -> Unit = {},
    userPhone: String = "",
    userEmail: String = ""
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val pricingConfig by RemoteConfigService.pricingOffer.collectAsState()
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()
    val vipDaysRemaining by RemoteConfigService.vipDaysRemaining.collectAsState()

    // Plan selection: "MONTHLY" or "YEARLY"
    var selectedPlan by remember { mutableStateOf("YEARLY") } // Yearly is recommended default
    var isProcessingPayment by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Listen to Razorpay callbacks
    LaunchedEffect(Unit) {
        RazorpayManager.paymentEvents.collect { event ->
            isProcessingPayment = false
            when (event) {
                is PaymentEvent.Success -> {
                    val totalDays = RemoteConfigService.vipDaysRemaining.value
                    Toast.makeText(
                        context,
                        "🎉 बधाई हो! VIP सदस्यता सक्रिय हो गई है। कुल $totalDays दिन शेष हैं! सभी विज्ञापन बंद हो गए हैं।",
                        Toast.LENGTH_LONG
                    ).show()
                    onPaymentSuccess()
                    onDismiss()
                }
                is PaymentEvent.Error -> {
                    Toast.makeText(context, "पेमेंट पूरा नहीं हुआ: ${event.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // Live countdown timer calculation for offer
    val isLive = pricingConfig.isOfferLiveNow()
    var remainingSeconds by remember(pricingConfig.offerEndTimeMs) {
        mutableStateOf(pricingConfig.remainingOfferMillis() / 1000L)
    }

    LaunchedEffect(pricingConfig.offerEndTimeMs) {
        while (isLive) {
            val rem = pricingConfig.remainingOfferMillis() / 1000L
            remainingSeconds = rem
            if (rem <= 0) break
            delay(1000L)
        }
    }

    val hours = (remainingSeconds / 3600L).coerceAtLeast(0L)
    val minutes = ((remainingSeconds % 3600L) / 60L).coerceAtLeast(0L)
    val seconds = (remainingSeconds % 60L).coerceAtLeast(0L)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            shadowElevation = 10.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("vip_subscription_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Close Button and Crown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF3C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "VIP बहीखाता सदस्यता",
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = Color(0xFF0F172A)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF64748B)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Festival Flash Sale Countdown Banner inside Dialog (Flipkart Style)
                if (isLive && remainingSeconds > 0) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFFFFBEB),
                        border = BorderStroke(1.5.dp, Color(0xFFF59E0B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "🔥",
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = pricingConfig.offerTitle,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFFB45309)
                                    )
                                    Text(
                                        text = pricingConfig.offerSubtitle,
                                        fontSize = 10.sp,
                                        color = Color(0xFF78350F)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFDC2626)
                            ) {
                                Text(
                                    text = String.format("%02d:%02d:%02d", hours, minutes, seconds),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                }

                // VIP Benefits Bullet Points
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(14.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VipBenefitItem("🚫 100% विज्ञापन-मुक्त अनुभव (नो बैनर, नो पॉपअप)")
                    VipBenefitItem("⚡ लाइव टाइमर व रसीद शेयरिंग बिना किसी रुकावट के")
                    VipBenefitItem("📑 असीमित PDF खाता रिपोर्ट व WhatsApp रसीद")
                    VipBenefitItem("☁️ 100% सुरक्षित क्लाउड बैकअप व ऑटो-सिंक")
                }

                Spacer(modifier = Modifier.height(16.dp))

                // If user is already a VIP, inform them that newly purchased days are stacked onto existing days
                if (isAdFree && vipDaysRemaining > 0) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF0FDF4),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddCircle,
                                contentDescription = null,
                                tint = Color(0xFF15803D),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "💡 आपके खाते में पहले से $vipDaysRemaining दिन शेष हैं। नया प्लान लेने पर ये दिन नए प्लान में जुड़ जाएंगे!",
                                fontSize = 11.5.sp,
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // The 2 Plans: [मासिक (Monthly)] vs [वार्षिक (Yearly)]
                Text(
                    text = if (isLive) "ऑफर प्लान चुनें (Select Plan):" else "प्लान चुनें (Select Plan):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF475569),
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(8.dp))

                val effectiveYearly = pricingConfig.getEffectiveYearlyPrice()
                val effectiveMonthly = pricingConfig.getEffectiveMonthlyPrice()

                // Plan 1: Yearly (वार्षिक)
                PlanCard(
                    title = if (isAdFree) "वार्षिक प्लान (+365 दिन जोड़ें)" else "वार्षिक प्लान (12 महीने)",
                    price = "₹${effectiveYearly.toInt()}",
                    originalPrice = if (isLive) "₹${pricingConfig.yearlyOriginalPrice.toInt()}" else null,
                    perMonthText = "सिर्फ ₹${(effectiveYearly / 12).toInt()}/महीना",
                    badge = if (isLive) {
                        if (pricingConfig.bannerBadgeText.isNotBlank()) pricingConfig.bannerBadgeText else "धमाका ऑफर 💥"
                    } else {
                        "वार्षिक बचत (Best Value)"
                    },
                    isSelected = selectedPlan == "YEARLY",
                    onClick = { selectedPlan = "YEARLY" }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Plan 2: Monthly (मासिक)
                PlanCard(
                    title = if (isAdFree) "मासिक प्लान (+30 दिन जोड़ें)" else "मासिक प्लान (1 महीना)",
                    price = "₹${effectiveMonthly.toInt()}",
                    originalPrice = if (isLive) "₹${pricingConfig.monthlyOriginalPrice.toInt()}" else null,
                    perMonthText = "₹${effectiveMonthly.toInt()} प्रति महीना",
                    badge = null,
                    isSelected = selectedPlan == "MONTHLY",
                    onClick = { selectedPlan = "MONTHLY" }
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Razorpay Pay Now Button
                val selectedAmount = if (selectedPlan == "YEARLY") effectiveYearly else effectiveMonthly
                Button(
                    onClick = {
                        if (activity != null) {
                            isProcessingPayment = true
                            val effectivePhone = if (userPhone.isNotBlank()) userPhone else "9876543210"
                            val effectiveEmail = if (userEmail.isNotBlank()) userEmail else "kisan@example.com"
                            RazorpayManager.startPayment(
                                activity = activity,
                                planType = selectedPlan,
                                amountRupees = selectedAmount,
                                userPhone = effectivePhone,
                                userEmail = effectiveEmail
                            )
                        } else {
                            Toast.makeText(context, "Activity context not available", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !isProcessingPayment,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1B5E20)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("razorpay_pay_now_btn")
                ) {
                    if (isProcessingPayment) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Razorpay सुरक्षित लोड हो रहा है...",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isAdFree) "₹${selectedAmount.toInt()} में सदस्यता बढ़ाएं (+ दिन जुड़ेंगे)" else "₹${selectedAmount.toInt()} का भुगतान करें (UPI / Card)",
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 100% Secure Razorpay Trust Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color(0xFF16A34A),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "100% सुरक्षित भुगतान • Razorpay UPI, GPay, PhonePe, Paytm द्वारा समर्थित",
                        fontSize = 10.5.sp,
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun VipBenefitItem(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF16A34A),
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            color = Color(0xFF1E293B),
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun PlanCard(
    title: String,
    price: String,
    originalPrice: String?,
    perMonthText: String,
    badge: String?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) Color(0xFFF0FDF4) else Color.White,
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) Color(0xFF16A34A) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            if (badge != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFDC2626),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Text(
                        text = badge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = isSelected,
                        onClick = onClick,
                        colors = RadioButtonDefaults.colors(
                            selectedColor = Color(0xFF16A34A)
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = perMonthText,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = price,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = if (isSelected) Color(0xFF15803D) else Color(0xFF0F172A)
                    )
                    if (originalPrice != null) {
                        Text(
                            text = originalPrice,
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                }
            }
        }
    }
}
