package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.util.ShareHelper
import com.example.ui.components.AddCustomerDialog
import com.example.ui.components.AvatarView
import com.example.ui.components.RemoteAdBanner
import com.example.ui.components.appTextFieldColors
import com.example.ui.theme.*
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.CustomerFilter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDirectoryScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val customerStats by viewModel.customerStatsList.collectAsState()
    val allCustomerStats by viewModel.allCustomerStatsList.collectAsState()
    val allCustomers by viewModel.allCustomers.collectAsState()
    val currentFilter by viewModel.customerFilter.collectAsState()
    val searchQuery by viewModel.customerSearchQuery.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    val todayTotalHours = remember(allSessions) {
        val startOfDay = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        allSessions.filter { it.sessionDate >= startOfDay }.sumOf { it.hours }
    }
    val totalOverallDue = allCustomerStats.sumOf { it.netDue }
    val customersWithDueCount = allCustomerStats.count { it.netDue > 0 }
    val totalCustomerCount = allCustomers.size

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = RoyalOrange,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                elevation = FloatingActionButtonDefaults.elevation(6.dp),
                modifier = Modifier
                    .padding(bottom = 10.dp)
                    .testTag("fab_add_customer")
            ) {
                Icon(
                    imageVector = Icons.Default.PersonAdd,
                    contentDescription = "Add Customer",
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "नया किसान जोड़ें",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            }
        },
        containerColor = Color(0xFFF8FAFC)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 88.dp)
        ) {
            // 1. Top Green Header Banner (Matching Provided Image)
            item {
                Surface(
                    color = Color(0xFF14532D), // Deep Agriculture Green
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 3.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left Icon Circle
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF3C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WaterDrop,
                                contentDescription = null,
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Title & Subtitle
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "किसान सूची / Customers",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            val agencyName = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "Kisan Tubewell & Sinchai Seva"
                            val rate = profile?.ratePerHour?.toInt() ?: 160
                            Text(
                                text = "📍 $agencyName • ₹$rate/hr",
                                color = Color(0xFFBBF7D0),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Right Profile Badge (KR / Avatar)
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE65100)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = profile?.name?.take(2)?.uppercase() ?: "KR",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // 2. Top 2 Summary KPI Cards (Side-by-Side)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Card 1: आज का समय
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFDCFCE7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccessTime,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "आज का समय",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1E293B)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${String.format(Locale.ROOT, "%.1f", todayTotalHours)} hrs",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "$totalCustomerCount कुल किसान",
                                fontSize = 12.sp,
                                color = Color(0xFF334155),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Card 2: कुल बकाया
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFFEE2E2)),
                        shadowElevation = 1.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFEE2E2)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WarningAmber,
                                        contentDescription = null,
                                        tint = Color(0xFFDC2626),
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "कुल बकाया",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFDC2626)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "₹${String.format(Locale.ROOT, "%,d", Math.round(totalOverallDue))}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFDC2626)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "$customersWithDueCount किसानों का बकाया",
                                fontSize = 12.sp,
                                color = Color(0xFF991B1B),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 3. Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.customerSearchQuery.value = it },
                    placeholder = {
                        Text(
                            "किसान का नाम या नंबर खोजें (उदा. रमेश, Ramesh)...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF475569)
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.customerSearchQuery.value = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = appTextFieldColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_search_input")
                )
            }

            // 4. Filter Chips - Evenly spaced across the full width with crisp HD styling
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 1. सभी (All)
                    val isAllSelected = currentFilter == CustomerFilter.ALL
                    Surface(
                        onClick = { viewModel.customerFilter.value = CustomerFilter.ALL },
                        color = if (isAllSelected) Color(0xFF16A34A) else Color.White,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, if (isAllSelected) Color(0xFF16A34A) else Color(0xFFCBD5E1)),
                        shadowElevation = if (isAllSelected) 2.dp else 0.dp,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tab_filter_all")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "सभी",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = if (isAllSelected) Color.White else Color(0xFF1E293B)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "($totalCustomerCount)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isAllSelected) Color(0xFFDCFCE7) else Color(0xFF64748B)
                            )
                        }
                    }

                    // 2. बकाया वाले (Due)
                    val isDueSelected = currentFilter == CustomerFilter.DUE
                    Surface(
                        onClick = { viewModel.customerFilter.value = CustomerFilter.DUE },
                        color = if (isDueSelected) Color(0xFFDC2626) else Color.White,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, if (isDueSelected) Color(0xFFDC2626) else Color(0xFFFCA5A5)),
                        shadowElevation = if (isDueSelected) 2.dp else 0.dp,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tab_filter_due")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "बकाया वाले",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = if (isDueSelected) Color.White else Color(0xFFDC2626)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "($customersWithDueCount)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isDueSelected) Color(0xFFFEE2E2) else Color(0xFFDC2626)
                            )
                        }
                    }

                    // 3. नकद वाले (Cash / Zero Due)
                    val isCashSelected = currentFilter == CustomerFilter.CASH
                    Surface(
                        onClick = { viewModel.customerFilter.value = CustomerFilter.CASH },
                        color = if (isCashSelected) Color(0xFF16A34A) else Color.White,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, if (isCashSelected) Color(0xFF16A34A) else Color(0xFF86EFAC)),
                        shadowElevation = if (isCashSelected) 2.dp else 0.dp,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tab_filter_cash")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "नकद वाले",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = if (isCashSelected) Color.White else Color(0xFF16A34A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "(${totalCustomerCount - customersWithDueCount})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isCashSelected) Color(0xFFDCFCE7) else Color(0xFF16A34A)
                            )
                        }
                    }
                }
            }

            // 5. Customer Items List
            if (customerStats.isEmpty()) {
                item {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 20.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PeopleOutline,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (searchQuery.isNotBlank()) "कोई किसान नहीं मिला" else "कोई किसान सूची में नहीं है",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF475569)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "नीचे दिए गए '+ नया किसान जोड़ें' बटन से नया खाता बनाएं",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            } else {
                items(customerStats, key = { it.customer.id }) { item ->
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectCustomerForDetail(item.customer.id)
                            }
                            .testTag("customer_card_${item.customer.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left Avatar (Colorful profile avatar based on farmer's name)
                            AvatarView(
                                name = item.customer.name,
                                bgColor = item.customer.avatarBgColor,
                                size = 46,
                                singleLetter = true
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            // Middle Info (Name, Father name, Phone)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.customer.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF0F172A),
                                    fontSize = 16.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Spacer(modifier = Modifier.height(3.dp))

                                val fatherText = if (item.customer.sO.isNotBlank()) "पिता: ${item.customer.sO}" else ""
                                val phoneText = if (item.customer.phone.isNotBlank()) "📞 ${item.customer.phone}" else ""
                                val subtitle = listOf(fatherText, phoneText).filter { it.isNotBlank() }.joinToString("  •  ")

                                Text(
                                    text = subtitle.ifBlank { "कोई विवरण नहीं" },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF1E293B),
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Right Side: Due Amount & Call Button
                            Column(
                                horizontalAlignment = Alignment.End,
                                verticalArrangement = Arrangement.Center
                            ) {
                                if (item.netDue > 0) {
                                    Text(
                                        text = "₹${String.format(Locale.ROOT, "%,d", Math.round(item.netDue))}",
                                        color = Color(0xFFDC2626),
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "बकाया",
                                        color = Color(0xFFB91C1C),
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp
                                    )
                                } else {
                                    Text(
                                        text = "₹0",
                                        color = Color(0xFF16A34A),
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "बेबाक / चुक्ता",
                                        color = Color(0xFF15803D),
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp
                                    )
                                }

                                if (item.customer.phone.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    // Quick Call Action Icon
                                    IconButton(
                                        onClick = {
                                            ShareHelper.dialPhone(context, item.customer.phone)
                                        },
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFDCFCE7))
                                            .testTag("quick_call_btn_${item.customer.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Call,
                                            contentDescription = "Call Customer",
                                            tint = Color(0xFF16A34A),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddCustomerDialog(
            viewModel = viewModel,
            onDismiss = { showAddDialog = false }
        )
    }
}
