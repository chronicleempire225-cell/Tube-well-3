package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import coil.compose.AsyncImage
import com.example.data.remoteconfig.PricingOfferConfig
import com.example.data.remoteconfig.RemoteConfigService
import kotlinx.coroutines.delay

/**
 * Top Flipkart/Amazon style Festival Flash Sale Countdown Offer Banner.
 * Shows a live tick-by-tick countdown clock (hours, mins, seconds) with festive gradient.
 */
@Composable
fun FestivalOfferCountdownBanner(
    onBannerClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()
    val pricingConfig by RemoteConfigService.pricingOffer.collectAsState()

    // Always fetch latest pricing & festival offer state from Supabase when banner mounts
    LaunchedEffect(Unit) {
        RemoteConfigService.fetchPricingOffersFromSupabase(context)
    }

    // If user already has VIP ad-free, do not show sales offer banner
    if (isAdFree) return

    // Explicitly check if home countdown banner is enabled and currently live
    if (!pricingConfig.shouldDisplayHomeBanner()) return

    var remainingSeconds by remember(pricingConfig.offerEndTimeMs) {
        mutableStateOf(pricingConfig.remainingOfferMillis() / 1000L)
    }

    // Live tick-by-tick countdown timer
    LaunchedEffect(pricingConfig.offerEndTimeMs) {
        while (true) {
            val rem = pricingConfig.remainingOfferMillis() / 1000L
            remainingSeconds = rem
            if (rem <= 0) break
            delay(1000L)
        }
    }

    if (remainingSeconds <= 0) return

    val hours = remainingSeconds / 3600L
    val minutes = (remainingSeconds % 3600L) / 60L
    val seconds = remainingSeconds % 60L

    // Pulsing glowing festive background
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    // Dynamic festive theme gradient based on bannerTheme from Supabase/Admin
    val gradientColors = when (pricingConfig.bannerTheme.uppercase()) {
        "SAFFRON", "ORANGE" -> listOf(Color(0xFFE65100), Color(0xFFF57C00), Color(0xFFFFB300))
        "GREEN", "EMERALD" -> listOf(Color(0xFF1B5E20), Color(0xFF2E7D32), Color(0xFF43A047))
        "ROYAL_BLUE", "BLUE" -> listOf(Color(0xFF0D47A1), Color(0xFF1976D2), Color(0xFF0288D1))
        "PURPLE" -> listOf(Color(0xFF4A148C), Color(0xFF7B1FA2), Color(0xFFAB47BC))
        else -> listOf(Color(0xFFB71C1C), Color(0xFFE65100), Color(0xFFF57F17)) // RED_GOLD (Default festive)
    }

    val bannerBorderColor = when (pricingConfig.bannerTheme.uppercase()) {
        "GREEN", "EMERALD" -> Color(0xFFA5D6A7)
        "ROYAL_BLUE", "BLUE" -> Color(0xFF90CAF9)
        "PURPLE" -> Color(0xFFCE93D8)
        else -> Color(0xFFFFD54F)
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 6.dp,
        border = BorderStroke(1.5.dp, bannerBorderColor),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onBannerClick() }
            .testTag("festival_offer_banner")
    ) {
        if (pricingConfig.bannerImageUrl.isNotBlank()) {
            // Mode A: Custom Poster / Banner Image uploaded via Supabase Storage / URL
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                AsyncImage(
                    model = pricingConfig.bannerImageUrl,
                    contentDescription = pricingConfig.offerTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Optional live countdown timer overlay at top-right of image
                Surface(
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(bottomStart = 10.dp),
                    border = BorderStroke(1.dp, Color(0xFFFFD54F).copy(alpha = 0.6f)),
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = "Timer",
                            tint = Color(0xFFFFD54F),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = String.format("%02d:%02d:%02d", hours, minutes, seconds),
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        } else {
            // Mode B: Elegant Dynamic Gradient Festival Banner with clean layout
            Box(
                modifier = Modifier
                    .background(Brush.horizontalGradient(colors = gradientColors))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left Icon & Festival Offer Text
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Celebration,
                                contentDescription = null,
                                tint = Color(0xFFFFEB3B),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f, fill = false)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = pricingConfig.offerTitle,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                if (pricingConfig.bannerBadgeText.isNotBlank()) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xFFFFEB3B)
                                    ) {
                                        Text(
                                            text = pricingConfig.bannerBadgeText,
                                            color = Color(0xFFB71C1C),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 10.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = if (pricingConfig.offerSubtitle.isNotBlank()) pricingConfig.offerSubtitle else "मासिक ₹${pricingConfig.monthlyPrice.toInt()} | वार्षिक ₹${pricingConfig.yearlyPrice.toInt()} • विज्ञापन मुक्त!",
                                color = Color(0xFFFFF9C4),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Right: Flipkart-style Live Countdown Box
                    Surface(
                        color = Color.Black.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFFFD54F).copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Timer",
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format("%02d:%02d:%02d", hours, minutes, seconds),
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
