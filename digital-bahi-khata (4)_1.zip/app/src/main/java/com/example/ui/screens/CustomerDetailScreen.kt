package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.CustomerEntity
import com.example.data.db.TransactionEntity
import com.example.data.db.TubewellSessionEntity
import com.example.data.pdf.PdfGenerator
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.util.AppFormatters
import com.example.data.util.ShareHelper
import com.example.ui.components.AvatarView
import com.example.ui.components.DepositPaymentDialog
import com.example.ui.components.RemoteAdBanner
import com.example.ui.components.RewardedAdUnlockDialog
import com.example.ui.components.appTextFieldColors
import com.example.ui.components.getAvatarColor
import com.example.ui.theme.*
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.TimeFilter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class TimelineEntryItem {
    abstract val timestamp: Long

    data class SessionItem(val session: TubewellSessionEntity) : TimelineEntryItem() {
        override val timestamp: Long = session.sessionDate
    }

    data class DepositItem(val txn: TransactionEntity) : TimelineEntryItem() {
        override val timestamp: Long = txn.depositDate
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
    customerId: String,
    viewModel: BahiKhataViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val allCustomers by viewModel.allCustomers.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()
    val allTxns by viewModel.allTransactions.collectAsState()
    val profile by viewModel.profile.collectAsState()

    val customer = allCustomers.firstOrNull { it.id == customerId }
    if (customer == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("किसान खाता नहीं मिला")
        }
        return
    }

    val customerSessions = allSessions.filter { it.customerId == customerId }
    val customerTxns = allTxns.filter { it.customerId == customerId }

    // Overall Lifetime Totals
    val totalHoursLifetime = customerSessions.sumOf { it.hours }
    val totalBilledLifetime = customer.initialBalance + customerSessions.sumOf { it.totalAmount }
    val totalPaidLifetime = customerSessions.sumOf { it.paidAmount } + customerTxns.sumOf { it.amountDeposited }
    val overallNetDue = (totalBilledLifetime - totalPaidLifetime).coerceAtLeast(0.0)

    var selectedFilter by remember { mutableStateOf(TimeFilter.ALL) }
    var showEditCustomerDialog by remember { mutableStateOf(false) }
    var showDepositDialog by remember { mutableStateOf(false) }
    var sessionToEdit by remember { mutableStateOf<TubewellSessionEntity?>(null) }
    var generatedPdfFile by remember { mutableStateOf<File?>(null) }
    var showPdfPeriodDialog by remember { mutableStateOf(false) }
    var pdfFilterPeriod by remember { mutableStateOf(TimeFilter.ALL) }
    var showRewardedUnlockDialog by remember { mutableStateOf(false) }
    var pendingFeatureAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    if (showRewardedUnlockDialog) {
        RewardedAdUnlockDialog(
            featureName = "WhatsApp व PDF खाता रिपोर्ट",
            onDismiss = { showRewardedUnlockDialog = false },
            onUnlockSuccess = {
                showRewardedUnlockDialog = false
                pendingFeatureAction?.invoke()
                pendingFeatureAction = null
            }
        )
    }

    // Filter sessions and transactions based on Time Filter (1 Week, 1 Month, 1 Year, 2 Years, All, Today)
    val (filteredSessions, filteredTxns) = remember(customerSessions, customerTxns, selectedFilter) {
        val minTime = when (selectedFilter) {
            TimeFilter.ALL -> 0L
            TimeFilter.TODAY -> {
                val c = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, 0)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                }
                c.timeInMillis
            }
            TimeFilter.WEEKLY -> System.currentTimeMillis() - 7 * 24 * 3600 * 1000L
            TimeFilter.MONTHLY -> System.currentTimeMillis() - 30 * 24 * 3600 * 1000L
            TimeFilter.YEARLY -> System.currentTimeMillis() - 365 * 24 * 3600 * 1000L
            TimeFilter.TWO_YEARS -> System.currentTimeMillis() - 730 * 24 * 3600 * 1000L
        }
        Pair(
            customerSessions.filter { it.sessionDate >= minTime },
            customerTxns.filter { it.depositDate >= minTime }
        )
    }

    // Filter-specific calculations for the top summary box as requested
    val filteredHours = filteredSessions.sumOf { it.hours }
    val filteredBilled = (if (selectedFilter == TimeFilter.ALL) customer.initialBalance else 0.0) + filteredSessions.sumOf { it.totalAmount }
    val filteredPaid = filteredSessions.sumOf { it.paidAmount } + filteredTxns.sumOf { it.amountDeposited }
    val filteredDue = (filteredBilled - filteredPaid).coerceAtLeast(0.0)

    // Unified timeline items
    val timelineItems = remember(filteredSessions, filteredTxns) {
        val list = mutableListOf<TimelineEntryItem>()
        filteredSessions.forEach { list.add(TimelineEntryItem.SessionItem(it)) }
        filteredTxns.forEach { list.add(TimelineEntryItem.DepositItem(it)) }
        list.sortByDescending { it.timestamp }
        list
    }

    val periodTitle = viewModel.getString(selectedFilter.titleKey)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 48.dp)
    ) {
        // 1. Top Profile Card with Single Initial & Direct Phone/WhatsApp/Deposit Actions
        item {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Large Avatar Box
                        Box(
                            modifier = Modifier
                                .clickable { showEditCustomerDialog = true }
                        ) {
                            AvatarView(
                                name = customer.name,
                                bgColor = customer.avatarBgColor,
                                size = 58,
                                singleLetter = true,
                                hasDue = overallNetDue > 0
                            )
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .background(RoyalOrange)
                                    .align(Alignment.BottomEnd),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Avatar",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = customer.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A),
                                fontSize = 18.sp
                            )
                            if (customer.sO.isNotBlank()) {
                                Text(
                                    text = "सुपुत्र: श्री ${customer.sO}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF64748B),
                                    fontSize = 13.sp
                                )
                            }
                            if (customer.phone.isNotBlank()) {
                                Text(
                                    text = "📞 ${customer.phone}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF166534),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        // Pencil Edit Button
                        IconButton(
                            onClick = { showEditCustomerDialog = true },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F9))
                                .testTag("edit_customer_info_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Customer Info",
                                tint = AgriGreenPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Direct Action Buttons (Call, Deposit, PDF Report, WhatsApp, SMS)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Call Button (Direct Phone Dial)
                        Button(
                            onClick = {
                                if (customer.phone.isNotBlank()) {
                                    ShareHelper.dialPhone(context, customer.phone)
                                } else {
                                    Toast.makeText(context, "मोबाइल नंबर दर्ज नहीं है", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier
                                .weight(1.1f)
                                .height(44.dp)
                                .testTag("detail_call_button")
                        ) {
                            Icon(imageVector = Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("कॉल करें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        // Deposit Button
                        Button(
                            onClick = { showDepositDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier
                                .weight(1.1f)
                                .height(44.dp)
                                .testTag("detail_deposit_button")
                        ) {
                            Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("जमा करें", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        // PDF Report Button
                        Button(
                            onClick = {
                                val action = {
                                    pdfFilterPeriod = selectedFilter
                                    showPdfPeriodDialog = true
                                }
                                if (RemoteConfigService.isFeaturePassActive()) {
                                    action()
                                } else {
                                    pendingFeatureAction = action
                                    showRewardedUnlockDialog = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalOrange),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier
                                .weight(1.2f)
                                .height(44.dp)
                                .testTag("detail_pdf_report_btn")
                        ) {
                            Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PDF खाता", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        // WhatsApp Share
                        IconButton(
                            onClick = {
                                val action = {
                                    val msg = ShareHelper.formatCustomerStatementMessage(
                                        profile, customer, filteredHours, filteredBilled, filteredPaid, overallNetDue
                                    )
                                    ShareHelper.shareViaWhatsApp(context, customer.phone, msg)
                                }
                                if (RemoteConfigService.isFeaturePassActive()) {
                                    action()
                                } else {
                                    pendingFeatureAction = action
                                    showRewardedUnlockDialog = true
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF25D366))
                                .testTag("detail_whatsapp_share_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Chat, contentDescription = "WhatsApp", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }

        // 2. Filter-Reflective Summary KPI Box (Top Summary reflecting the selected time filter as requested)
        item {
            Surface(
                color = Color(0xFFF0FDF4),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📊 हिसाब सारांश ($periodTitle)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF14532D),
                            fontSize = 14.sp
                        )

                        if (selectedFilter != TimeFilter.ALL) {
                            Surface(
                                color = Color(0xFFDCFCE7),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = periodTitle,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF166534),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("कुल चले घंटे", style = MaterialTheme.typography.labelSmall, color = Color(0xFF166534))
                            val hoursDisplay = if (filteredHours < 1.0) {
                                AppFormatters.formatSessionDuration(filteredHours)
                            } else {
                                "${String.format(Locale.ROOT, "%.1f", filteredHours)} hrs"
                            }
                            Text(
                                hoursDisplay,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF14532D)
                            )
                        }
                        Column {
                            Text("कुल बनी रकम", style = MaterialTheme.typography.labelSmall, color = Color(0xFF166534))
                            val billedToDisplay = AppFormatters.roundRupees(filteredBilled)
                            Text(
                                "₹${AppFormatters.formatRupees(billedToDisplay.toDouble())}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF14532D)
                            )
                        }
                        Column {
                            Text("कुल जमा", style = MaterialTheme.typography.labelSmall, color = Color(0xFF166534))
                            val paidToDisplay = AppFormatters.roundRupees(filteredPaid)
                            Text(
                                "₹${AppFormatters.formatRupees(paidToDisplay.toDouble())}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF16A34A)
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFFBBF7D0))

                    val lifetimeNetDueDisplay = (AppFormatters.roundRupees(totalBilledLifetime) - AppFormatters.roundRupees(totalPaidLifetime)).coerceAtLeast(0L)
                    val periodDueDisplay = (AppFormatters.roundRupees(filteredBilled) - AppFormatters.roundRupees(filteredPaid)).coerceAtLeast(0L)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "कुल बकाया (Net Due):",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = if (lifetimeNetDueDisplay > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                            )
                            if (selectedFilter != TimeFilter.ALL) {
                                Text(
                                    text = "इस अवधि का बकाया: ₹${AppFormatters.formatRupees(periodDueDisplay.toDouble())}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF475569)
                                )
                            }
                        }
                        Text(
                            text = "₹${AppFormatters.formatRupees(lifetimeNetDueDisplay.toDouble())}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Black,
                            color = if (lifetimeNetDueDisplay > 0) Color(0xFFDC2626) else Color(0xFF16A34A)
                        )
                    }
                }
            }
        }

        // 3. Time Filter Chips (1 Week, 1 Month, 1 Year, 2 Years, All)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "सत्र एवं लेनदेन इतिहास",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A),
                        fontSize = 16.sp
                    )

                    Text(
                        text = "${timelineItems.size} एंट्री",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Bold
                    )
                }

                // Time Filter Chips (HD Crisp Styling)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(TimeFilter.values()) { filter ->
                        val isSelected = selectedFilter == filter
                        Surface(
                            onClick = { selectedFilter = filter },
                            color = if (isSelected) Color(0xFF14532D) else Color.White,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.5.dp, if (isSelected) Color(0xFF14532D) else Color(0xFF94A3B8)),
                            shadowElevation = if (isSelected) 2.dp else 0.dp,
                            modifier = Modifier.testTag("detail_filter_${filter.name.lowercase()}")
                        ) {
                            Text(
                                text = viewModel.getString(filter.titleKey),
                                fontWeight = FontWeight.Black,
                                color = if (isSelected) Color.White else Color(0xFF0F172A),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // 4. Detailed History Timeline (Sessions & Deposits)
        if (timelineItems.isEmpty()) {
            item {
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier.padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "चयनित अवधि ($periodTitle) में कोई सत्र या जमा दर्ज नहीं है",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        } else {
            items(timelineItems, key = {
                when (it) {
                    is TimelineEntryItem.SessionItem -> "s_${it.session.id}"
                    is TimelineEntryItem.DepositItem -> "d_${it.txn.id}"
                }
            }) { entry ->
                val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

                when (entry) {
                    is TimelineEntryItem.SessionItem -> {
                        val session = entry.session
                        val isEditable = viewModel.isSessionEditable(session)

                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFDCFCE7)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.WaterDrop,
                                                contentDescription = null,
                                                tint = Color(0xFF16A34A),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = sdf.format(Date(session.sessionDate)),
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A)
                                        )
                                    }

                                    // Correction Policy Badge
                                    if (isEditable) {
                                        Surface(
                                            color = Color(0xFFFFF7ED),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, Color(0xFFFFEDD5)),
                                            modifier = Modifier.clickable { sessionToEdit = session }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = RoyalOrange, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("सुधारें", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = RoyalOrange)
                                            }
                                        }
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFF1F5F9))

                                val sessionTotalDisplay = AppFormatters.roundRupees(session.totalAmount)
                                val sessionPaidDisplay = AppFormatters.roundRupees(session.paidAmount)
                                val sessionDueDisplay = (sessionTotalDisplay - sessionPaidDisplay).coerceAtLeast(0L)
                                val sessionDurationText = AppFormatters.formatSessionDuration(session.hours)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        "$sessionDurationText @ ₹${session.rate.toInt()}/घंटा",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF334155)
                                    )
                                    Text(
                                        "कुल: ₹${AppFormatters.formatRupees(sessionTotalDisplay.toDouble())}",
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF14532D)
                                    )
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        "जमा: ₹${AppFormatters.formatRupees(sessionPaidDisplay.toDouble())}",
                                        color = Color(0xFF16A34A),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (sessionDueDisplay > 0) {
                                        Text(
                                            "बाकी: ₹${AppFormatters.formatRupees(sessionDueDisplay.toDouble())}",
                                            color = Color(0xFFDC2626),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        Text(
                                            "चुक्ता ✅",
                                            color = Color(0xFF16A34A),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                if (session.note.isNotBlank()) {
                                    Text(
                                        text = "📝 ${session.note}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF64748B),
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    is TimelineEntryItem.DepositItem -> {
                        val txn = entry.txn
                        Surface(
                            color = Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFDCFCE7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalanceWallet,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "सीधी राशि जमा (${txn.paymentMode})",
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF14532D),
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = sdf.format(Date(txn.depositDate)),
                                        fontSize = 12.sp,
                                        color = Color(0xFF166534)
                                    )
                                    if (txn.note.isNotBlank()) {
                                        Text(
                                            text = "रसीद: ${txn.note}",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }

                                Text(
                                    text = "+ ₹${txn.amountDeposited.toInt()}",
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF16A34A),
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // PDF Ready Dialog
    generatedPdfFile?.let { pdfFile ->
        AlertDialog(
            onDismissRequest = { generatedPdfFile = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            icon = {
                Icon(
                    imageVector = Icons.Default.PictureAsPdf,
                    contentDescription = null,
                    tint = RoyalOrange,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "किसान खाता रिपोर्ट PDF तैयार है!",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = Color(0xFF0F172A)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "किसान: ${customer.name}",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B),
                        fontSize = 14.sp
                    )
                    Text(
                        text = "अवधि: $periodTitle | प्रविष्टियाँ: ${filteredSessions.size + filteredTxns.size}",
                        color = Color(0xFF64748B),
                        fontSize = 13.sp
                    )
                    val overallDueToDisplay = (AppFormatters.roundRupees(totalBilledLifetime) - AppFormatters.roundRupees(totalPaidLifetime)).coerceAtLeast(0L)
                    Text(
                        text = "कुल बाकी: ₹${AppFormatters.formatRupees(overallDueToDisplay.toDouble())}",
                        fontWeight = FontWeight.Black,
                        color = if (overallDueToDisplay > 0) Color(0xFFDC2626) else Color(0xFF16A34A),
                        fontSize = 14.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        ShareHelper.sharePdfFile(context, pdfFile, "${customer.name} खाता रिपोर्ट")
                        generatedPdfFile = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp / शेयर करें", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        ShareHelper.openPdfFile(context, pdfFile)
                        generatedPdfFile = null
                    }
                ) {
                    Text("PDF खोलें", color = AgriGreenPrimary, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Edit Customer Modal Dialog
    if (showEditCustomerDialog) {
        var editName by remember { mutableStateOf(customer.name) }
        var editFather by remember { mutableStateOf(customer.sO) }
        var editPhone by remember { mutableStateOf(customer.phone) }
        var editError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showEditCustomerDialog = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = AgriGreenPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("किसान विवरण संशोधित करें", fontWeight = FontWeight.Black, color = Color(0xFF0F172A), fontSize = 18.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(
                        color = Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AvatarView(
                                name = if (editName.isNotBlank()) editName else customer.name,
                                size = 46,
                                singleLetter = true,
                                shape = CircleShape
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (editName.isNotBlank()) editName else customer.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editName,
                        onValueChange = { 
                            editName = it
                            editError = null
                        },
                        label = { Text("किसान का नाम *", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                        textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0F172A)),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editFather,
                        onValueChange = { editFather = it },
                        label = { Text("पिताजी का नाम (S/O)", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                        textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0F172A)),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Phone strictly 10 digits
                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { input ->
                            val digits = input.filter { it.isDigit() }.take(10)
                            editPhone = digits
                            editError = null
                        },
                        label = { Text("मोबाइल नंबर (10 अंक)", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                        supportingText = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (editPhone.isNotEmpty() && editPhone.length < 10) "10 अंक अनिवार्य हैं" else "केवल संख्यात्मक अंक (0-9)",
                                    color = if (editPhone.isNotEmpty() && editPhone.length < 10) Color(0xFFDC2626) else Color(0xFF64748B),
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "${editPhone.length}/10",
                                    color = if (editPhone.length == 10) Color(0xFF16A34A) else Color(0xFF64748B),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        },
                        isError = editPhone.isNotEmpty() && editPhone.length != 10,
                        textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0F172A)),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (editError != null) {
                        Text(
                            text = editError!!,
                            color = Color(0xFFDC2626),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isBlank()) {
                            editError = "कृपया किसान का नाम दर्ज करें!"
                            return@Button
                        }
                        if (editPhone.isNotBlank() && editPhone.length != 10) {
                            editError = "मोबाइल नंबर ठीक 10 अंकों का होना चाहिए!"
                            return@Button
                        }
                        val colorVal = getAvatarColor(editName).value.toLong()
                        val updated = customer.copy(
                            name = editName.trim(),
                            sO = editFather.trim(),
                            phone = editPhone.trim(),
                            avatarBgColor = colorVal
                        )
                        viewModel.updateCustomer(updated)
                        showEditCustomerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("अपडेट करें", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditCustomerDialog = false }) {
                    Text("रद्द करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Deposit Payment Dialog
    if (showDepositDialog) {
        DepositPaymentDialog(
            customer = customer,
            currentDue = overallNetDue,
            viewModel = viewModel,
            onDismiss = { showDepositDialog = false }
        )
    }

    // Edit Session Modal Dialog (Correction Policy for < 48 hrs)
    sessionToEdit?.let { s ->
        var editHours by remember { mutableStateOf(s.hours.toString()) }
        var editRate by remember { mutableStateOf(s.rate.toString()) }
        var editPaid by remember { mutableStateOf(s.paidAmount.toString()) }
        var editNote by remember { mutableStateOf(s.note) }

        AlertDialog(
            onDismissRequest = { sessionToEdit = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = RoyalOrange, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("सत्र में सुधार करें (Edit Session)", fontWeight = FontWeight.Black, color = Color(0xFF0F172A), fontSize = 18.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = editHours,
                        onValueChange = { editHours = it },
                        label = { Text("चले घंटे", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                        textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0F172A)),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editRate,
                        onValueChange = { editRate = it },
                        label = { Text("दर (₹/घंटा)", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                        textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0F172A)),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editPaid,
                        onValueChange = { editPaid = it },
                        label = { Text("जमा की गई राशि (₹)", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                        textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0F172A)),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = appTextFieldColors(containerColor = Color.White, focusedBorderColor = PaidGreen, focusedLabelColor = PaidGreen),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editNote,
                        onValueChange = { editNote = it },
                        label = { Text("विवरण / नोट", fontWeight = FontWeight.Bold, color = Color(0xFF334155)) },
                        textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0F172A)),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = appTextFieldColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val h = editHours.toDoubleOrNull() ?: s.hours
                        val r = editRate.toDoubleOrNull() ?: s.rate
                        val tot = Math.round(h * r).toDouble()
                        val p = editPaid.toDoubleOrNull() ?: s.paidAmount
                        val d = (tot - p).coerceAtLeast(0.0)

                        val updated = s.copy(
                            hours = h,
                            rate = r,
                            totalAmount = tot,
                            paidAmount = p,
                            dueAmount = d,
                            note = editNote.trim()
                        )
                        viewModel.updateSession(updated)
                        sessionToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary)
                ) {
                    Text("बदलाव सुरक्षित करें", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionToEdit = null }) {
                    Text("रद्द करें", color = TextSecondary)
                }
            }
        )
    }

    // PDF Period Selection & Action Dialog (Select Range: Today, 1 Week, 1 Month, 1 Year, 2 Years, All)
    if (showPdfPeriodDialog) {
        val (pdfSessions, pdfTxns) = remember(customerSessions, customerTxns, pdfFilterPeriod) {
            val minTime = when (pdfFilterPeriod) {
                TimeFilter.ALL -> 0L
                TimeFilter.TODAY -> {
                    val c = java.util.Calendar.getInstance().apply {
                        set(java.util.Calendar.HOUR_OF_DAY, 0)
                        set(java.util.Calendar.MINUTE, 0)
                        set(java.util.Calendar.SECOND, 0)
                        set(java.util.Calendar.MILLISECOND, 0)
                    }
                    c.timeInMillis
                }
                TimeFilter.WEEKLY -> System.currentTimeMillis() - 7 * 24 * 3600 * 1000L
                TimeFilter.MONTHLY -> System.currentTimeMillis() - 30 * 24 * 3600 * 1000L
                TimeFilter.YEARLY -> System.currentTimeMillis() - 365 * 24 * 3600 * 1000L
                TimeFilter.TWO_YEARS -> System.currentTimeMillis() - 730 * 24 * 3600 * 1000L
            }
            Pair(
                customerSessions.filter { it.sessionDate >= minTime },
                customerTxns.filter { it.depositDate >= minTime }
            )
        }
        val pdfHours = pdfSessions.sumOf { it.hours }
        val pdfBilled = (if (pdfFilterPeriod == TimeFilter.ALL) customer.initialBalance else 0.0) + pdfSessions.sumOf { it.totalAmount }
        val pdfPaid = pdfSessions.sumOf { it.paidAmount } + pdfTxns.sumOf { it.amountDeposited }
        val pdfDue = (pdfBilled - pdfPaid).coerceAtLeast(0.0)
        val pdfPeriodTitle = viewModel.getString(pdfFilterPeriod.titleKey)

        AlertDialog(
            onDismissRequest = { showPdfPeriodDialog = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = RoyalOrange,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "📄 किसान खाता PDF",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A),
                            fontSize = 18.sp
                        )
                        Text(
                            text = "${customer.name} • अवधि चुनें",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "अवधि चुनें (Select Period):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A),
                        fontSize = 13.sp
                    )

                    // Period Selector Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(TimeFilter.values()) { filter ->
                            val isSelected = pdfFilterPeriod == filter
                            Surface(
                                onClick = { pdfFilterPeriod = filter },
                                color = if (isSelected) Color(0xFF14532D) else Color.White,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.5.dp, if (isSelected) Color(0xFF14532D) else Color(0xFF94A3B8))
                            ) {
                                Text(
                                    text = viewModel.getString(filter.titleKey),
                                    fontWeight = FontWeight.Black,
                                    color = if (isSelected) Color.White else Color(0xFF0F172A),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Live Period Summary Box
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("चयनित अवधि:", style = MaterialTheme.typography.labelSmall, color = Color(0xFF166534), fontWeight = FontWeight.Bold)
                                Text(pdfPeriodTitle, style = MaterialTheme.typography.labelSmall, color = Color(0xFF14532D), fontWeight = FontWeight.Black)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("सत्र: ${pdfSessions.size} • ${String.format(Locale.ROOT, "%.1f", pdfHours)} hrs", fontSize = 11.sp, color = Color(0xFF1E293B), fontWeight = FontWeight.Bold)
                                Text("बकाया: ₹${pdfDue.toInt()}", fontSize = 11.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val pdf = PdfGenerator.generateCustomerReportPdf(
                                context = context,
                                profile = profile,
                                customer = customer,
                                sessions = pdfSessions,
                                transactions = pdfTxns,
                                periodTitle = pdfPeriodTitle,
                                filteredHours = pdfHours,
                                filteredBilled = pdfBilled,
                                filteredPaid = pdfPaid,
                                filteredDue = pdfDue,
                                overallNetDue = overallNetDue
                            )
                            if (pdf != null) {
                                ShareHelper.openPdfFile(context, pdf)
                                showPdfPeriodDialog = false
                            } else {
                                Toast.makeText(context, "PDF निर्माण विफल", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, AgriGreenPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = null, tint = AgriGreenPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF खोलें", color = AgriGreenPrimary, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val pdf = PdfGenerator.generateCustomerReportPdf(
                                context = context,
                                profile = profile,
                                customer = customer,
                                sessions = pdfSessions,
                                transactions = pdfTxns,
                                periodTitle = pdfPeriodTitle,
                                filteredHours = pdfHours,
                                filteredBilled = pdfBilled,
                                filteredPaid = pdfPaid,
                                filteredDue = pdfDue,
                                overallNetDue = overallNetDue
                            )
                            if (pdf != null) {
                                ShareHelper.sharePdfFile(context, pdf, "${customer.name} का खाता ($pdfPeriodTitle)")
                                showPdfPeriodDialog = false
                            } else {
                                Toast.makeText(context, "PDF निर्माण विफल", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("शेयर करें", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showPdfPeriodDialog = false }) {
                    Text("रद्द करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // PDF View & Share Dialog (Fallback if direct file exists)
    generatedPdfFile?.let { pdfFile ->
        AlertDialog(
            onDismissRequest = { generatedPdfFile = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = RoyalOrange,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PDF खाता तैयार है",
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A),
                        fontSize = 18.sp
                    )
                }
            },
            text = {
                Text(
                    text = "${customer.name} का खाता ($periodTitle) PDF में सफलतापूर्वक तैयार हो गया है। आप इसे खोलकर देख सकते हैं या साझा कर सकते हैं।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF334155),
                    fontWeight = FontWeight.Medium
                )
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            ShareHelper.openPdfFile(context, pdfFile)
                            generatedPdfFile = null
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, AgriGreenPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = null, tint = AgriGreenPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF खोलें", color = AgriGreenPrimary, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = {
                            ShareHelper.sharePdfFile(context, pdfFile)
                            generatedPdfFile = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AgriGreenPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("शेयर करें", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { generatedPdfFile = null }) {
                    Text("बंद करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
