package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.util.AppFormatters
import com.example.data.util.ShareHelper
import com.example.ui.components.AvatarView
import com.example.ui.components.RemoteAdBanner
import com.example.ui.components.RewardedAdUnlockDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.TimeFilter
import java.util.Locale

@Composable
fun ReportsScreen(
    viewModel: BahiKhataViewModel
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsState()
    val currentFilter by viewModel.reportTimeFilter.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val reportRows = remember(currentFilter, viewModel.allCustomers.collectAsState().value, viewModel.allSessions.collectAsState().value, viewModel.allTransactions.collectAsState().value) {
        viewModel.getFilteredReportRows(currentFilter)
    }

    var showMasterPdfPeriodDialog by remember { mutableStateOf(false) }
    var pdfFilterPeriod by remember { mutableStateOf(currentFilter) }
    var showRewardedUnlockDialog by remember { mutableStateOf(false) }
    var pendingPdfAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    if (showRewardedUnlockDialog) {
        RewardedAdUnlockDialog(
            featureName = "मास्टर PDF खाता रिपोर्ट",
            onDismiss = { showRewardedUnlockDialog = false },
            onUnlockSuccess = {
                showRewardedUnlockDialog = false
                pendingPdfAction?.invoke()
                pendingPdfAction = null
            }
        )
    }

    val totalIncomeRounded = reportRows.sumOf { AppFormatters.roundRupees(it.totalAmount) }
    val totalPaidRounded = reportRows.sumOf { AppFormatters.roundRupees(it.totalPaid) }
    val totalDueRounded = reportRows.sumOf { (AppFormatters.roundRupees(it.totalAmount) - AppFormatters.roundRupees(it.totalPaid)).coerceAtLeast(0L) }
    val totalHours = reportRows.sumOf { it.totalHours }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 88.dp)
    ) {
        // 1. Top Green Header Banner (Matching Provided Theme)
        item {
            Surface(
                color = Color(0xFF14532D), // Deep Agriculture Green
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Icon Circle
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Assessment,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Title & Subtitle
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "रिपोर्ट एवं बही-खाता / Reports",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        val agencyName = profile?.agencyName?.takeIf { it.isNotBlank() } ?: "Kisan Tubewell & Sinchai Seva"
                        val rate = profile?.ratePerHour?.toInt() ?: 160
                        Text(
                            text = "📍 $agencyName • ₹$rate/hr",
                            color = Color(0xFFBBF7D0),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Right Profile Badge (KR / Avatar)
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE65100)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = profile?.name?.take(2)?.uppercase() ?: "KR",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 2. Master PDF Download, View & Share Banner Card
        item {
            Surface(
                color = Color(0xFFFFF7ED), // Soft warm orange container
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, Color(0xFFFDBA74)),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        pdfFilterPeriod = currentFilter
                        showMasterPdfPeriodDialog = true
                    }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFEDD5)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = Color(0xFFEA580C),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "📄 मास्टर PDF रिपोर्ट (PDF खाता)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF9A3412),
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "अवधि चुनकर सभी किसानों का समेकित PDF बनाएं, देखें व शेयर करें",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF9A3412),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Button 1: अवधि चुनें व PDF खोलें
                        Button(
                            onClick = {
                                pdfFilterPeriod = currentFilter
                                showMasterPdfPeriodDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF14532D)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_view_pdf_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "अवधि चुनें / PDF खोलें",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }

                        // Button 2: PDF शेयर करें (Share PDF)
                        Button(
                            onClick = {
                                pdfFilterPeriod = currentFilter
                                showMasterPdfPeriodDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("download_share_pdf_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PDF शेयर करें",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // 3. Time Filter Chips (HD Crisp Styling)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "समय अवधि (Time Range):",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF0F172A),
                    fontSize = 14.sp
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(TimeFilter.values()) { filter ->
                        val isSelected = currentFilter == filter
                        Surface(
                            onClick = { viewModel.reportTimeFilter.value = filter },
                            color = if (isSelected) Color(0xFF14532D) else Color.White,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.5.dp, if (isSelected) Color(0xFF14532D) else Color(0xFF94A3B8)),
                            shadowElevation = if (isSelected) 2.dp else 0.dp,
                            modifier = Modifier.testTag("report_filter_${filter.name.lowercase()}")
                        ) {
                            Text(
                                text = viewModel.getString(filter.titleKey),
                                fontWeight = FontWeight.Black,
                                color = if (isSelected) Color.White else Color(0xFF1E293B),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // 4. 4 KPI Summary Cards in a 2x2 Grid (Large Bold HD Text)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Total Hours
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFDCFCE7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccessTime,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "कुल चले घंटे",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1E293B)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            val hoursDisplay = if (totalHours < 1.0) {
                                AppFormatters.formatSessionDuration(totalHours)
                            } else {
                                "${String.format(Locale.ROOT, "%.1f", totalHours)} hrs"
                            }
                            Text(
                                text = hoursDisplay,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "कुल सिंचाई समय",
                                fontSize = 12.sp,
                                color = Color(0xFF334155),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Total Billed Income
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        shadowElevation = 1.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFEF3C7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CurrencyRupee,
                                        contentDescription = null,
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "कुल बनी रकम",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1E293B)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "₹${AppFormatters.formatRupees(totalIncomeRounded.toDouble())}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "कुल बिल राशि",
                                fontSize = 12.sp,
                                color = Color(0xFF334155),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Total Cash Received
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFDCFCE7)),
                        shadowElevation = 1.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFDCFCE7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "कुल जमा राशि",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF15803D)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "₹${AppFormatters.formatRupees(totalPaidRounded.toDouble())}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF16A34A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "नकद / प्राप्त राशि",
                                fontSize = 12.sp,
                                color = Color(0xFF166534),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Total Outstanding Balance
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFFEE2E2)),
                        shadowElevation = 1.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFEE2E2)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WarningAmber,
                                        contentDescription = null,
                                        tint = Color(0xFFDC2626),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "कुल बकाया",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFDC2626)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "₹${AppFormatters.formatRupees(totalDueRounded.toDouble())}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFDC2626)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "किसानों से लेना शेष",
                                fontSize = 12.sp,
                                color = Color(0xFF991B1B),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 5. Customer-wise Breakdown Section Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "किसान अनुसार हिसाब (${reportRows.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF0F172A),
                    fontSize = 16.sp
                )

                Text(
                    text = "अवधि: ${viewModel.getString(currentFilter.titleKey)}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF1E293B),
                    fontSize = 13.sp
                )
            }
        }

        // 6. Customer Breakdown List
        if (reportRows.isEmpty()) {
            item {
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "इस अवधि के लिए कोई डाटा उपलब्ध नहीं है",
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        } else {
            items(reportRows) { row ->
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectCustomerForDetail(row.customer.id) }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            AvatarView(
                                name = row.customer.name,
                                bgColor = row.customer.avatarBgColor,
                                size = 44,
                                singleLetter = true
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = row.customer.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF0F172A),
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (row.customer.sO.isNotBlank() || row.customer.phone.isNotBlank()) {
                                    val fText = if (row.customer.sO.isNotBlank()) "पिता: ${row.customer.sO}" else ""
                                    val pText = if (row.customer.phone.isNotBlank()) "📞 ${row.customer.phone}" else ""
                                    val sub = listOf(fText, pText).filter { it.isNotBlank() }.joinToString("  •  ")
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = sub,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF1E293B),
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                val rowTotal = AppFormatters.roundRupees(row.totalAmount)
                                val rowPaid = AppFormatters.roundRupees(row.totalPaid)
                                val rowDue = (rowTotal - rowPaid).coerceAtLeast(0L)
                                val rowHoursText = if (row.totalHours < 1.0) {
                                    AppFormatters.formatSessionDuration(row.totalHours)
                                } else {
                                    "${String.format(Locale.ROOT, "%.1f", row.totalHours)} hrs"
                                }

                                if (rowDue > 0) {
                                    Text(
                                        text = "बकाया ₹${AppFormatters.formatRupees(rowDue.toDouble())}",
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFFDC2626),
                                        fontSize = 15.sp
                                    )
                                } else {
                                    Text(
                                        text = "चुक्ता ✅",
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF16A34A),
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${row.sessionCount} सत्र • $rowHoursText",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF1E293B),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Divider(
                            modifier = Modifier.padding(vertical = 10.dp),
                            color = Color(0xFFE2E8F0)
                        )

                        val rowTotalBottom = AppFormatters.roundRupees(row.totalAmount)
                        val rowPaidBottom = AppFormatters.roundRupees(row.totalPaid)
                        val rowDueBottom = (rowTotalBottom - rowPaidBottom).coerceAtLeast(0L)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "बनी रकम: ₹${AppFormatters.formatRupees(rowTotalBottom.toDouble())}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF0F172A),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "जमा: ₹${AppFormatters.formatRupees(rowPaidBottom.toDouble())}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                            if (rowDueBottom > 0) {
                                Text(
                                    text = "शेष बकाया: ₹${AppFormatters.formatRupees(rowDueBottom.toDouble())}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFDC2626),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Master PDF Period Selection & Action Dialog (Select Range: Today, 1 Week, 1 Month, 1 Year, 2 Years, All)
    if (showMasterPdfPeriodDialog) {
        val pdfReportRows = remember(pdfFilterPeriod, viewModel.allCustomers.collectAsState().value, viewModel.allSessions.collectAsState().value, viewModel.allTransactions.collectAsState().value) {
            viewModel.getFilteredReportRows(pdfFilterPeriod)
        }
        val pdfTotalIncome = pdfReportRows.sumOf { it.totalAmount }
        val pdfTotalPaid = pdfReportRows.sumOf { it.totalPaid }
        val pdfTotalDue = pdfReportRows.sumOf { it.totalDue }
        val pdfTotalHours = pdfReportRows.sumOf { it.totalHours }
        val pdfPeriodTitle = viewModel.getString(pdfFilterPeriod.titleKey)

        AlertDialog(
            onDismissRequest = { showMasterPdfPeriodDialog = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = Color(0xFFEA580C),
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "📄 मास्टर बही-खाता PDF",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A),
                            fontSize = 18.sp
                        )
                        Text(
                            text = "सभी किसानों का समेकित खाता • अवधि चुनें",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "अवधि चुनें (Select Period):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A),
                        fontSize = 13.sp
                    )

                    // Period Selector Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(TimeFilter.values()) { filter ->
                            val isSelected = pdfFilterPeriod == filter
                            Surface(
                                onClick = { pdfFilterPeriod = filter },
                                color = if (isSelected) Color(0xFF14532D) else Color.White,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.5.dp, if (isSelected) Color(0xFF14532D) else Color(0xFF94A3B8))
                            ) {
                                Text(
                                    text = viewModel.getString(filter.titleKey),
                                    fontWeight = FontWeight.Black,
                                    color = if (isSelected) Color.White else Color(0xFF0F172A),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Live Period Summary Box
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("चयनित अवधि:", style = MaterialTheme.typography.labelSmall, color = Color(0xFF166534), fontWeight = FontWeight.Bold)
                                Text(pdfPeriodTitle, style = MaterialTheme.typography.labelSmall, color = Color(0xFF14532D), fontWeight = FontWeight.Black)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("कुल किसान: ${pdfReportRows.size}", fontSize = 12.sp, color = Color(0xFF1E293B), fontWeight = FontWeight.Bold)
                                Text("कुल घंटे: ${String.format(Locale.ROOT, "%.1f", pdfTotalHours)} hrs", fontSize = 12.sp, color = Color(0xFF1E293B), fontWeight = FontWeight.Bold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("कुल बनी रकम: ₹${pdfTotalIncome.toInt()}", fontSize = 12.sp, color = Color(0xFF1E293B), fontWeight = FontWeight.Bold)
                                Text("कुल जमा: ₹${pdfTotalPaid.toInt()}", fontSize = 12.sp, color = Color(0xFF15803D), fontWeight = FontWeight.Black)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("कुल शुद्ध बाकी (बकाया):", fontSize = 12.sp, color = Color(0xFF991B1B), fontWeight = FontWeight.Bold)
                                Text("₹${pdfTotalDue.toInt()}", fontSize = 14.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val action = {
                                val pdfFile = viewModel.generateMasterPdf(context, pdfFilterPeriod)
                                if (pdfFile != null) {
                                    ShareHelper.openPdfFile(context, pdfFile)
                                    showMasterPdfPeriodDialog = false
                                } else {
                                    Toast.makeText(context, "PDF तैयार करने के लिए कोई डाटा नहीं है", Toast.LENGTH_SHORT).show()
                                }
                            }
                            if (RemoteConfigService.isFeaturePassActive()) {
                                action()
                            } else {
                                pendingPdfAction = action
                                showRewardedUnlockDialog = true
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, Color(0xFF14532D))
                    ) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = null, tint = Color(0xFF14532D), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF खोलें", color = Color(0xFF14532D), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val action = {
                                val pdfFile = viewModel.generateMasterPdf(context, pdfFilterPeriod)
                                if (pdfFile != null) {
                                    val title = "मास्टर बही-खाता PDF ($pdfPeriodTitle)"
                                    ShareHelper.sharePdfFile(context, pdfFile, title)
                                    showMasterPdfPeriodDialog = false
                                } else {
                                    Toast.makeText(context, "PDF तैयार करने के लिए कोई डाटा नहीं है", Toast.LENGTH_SHORT).show()
                                }
                            }
                            if (RemoteConfigService.isFeaturePassActive()) {
                                action()
                            } else {
                                pendingPdfAction = action
                                showRewardedUnlockDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF14532D)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("शेयर करें", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showMasterPdfPeriodDialog = false }) {
                    Text("रद्द करें", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
