package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.ui.viewmodel.BahiKhataViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(
    viewModel: BahiKhataViewModel
) {
    val progress = remember { Animatable(0f) }
    var secondsLeft by remember { mutableStateOf(4) }

    LaunchedEffect(Unit) {
        val animationJob = launch {
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 4000, easing = LinearEasing)
            )
        }
        val countdownJob = launch {
            for (i in 4 downTo 1) {
                secondsLeft = i
                delay(1000)
            }
        }
        animationJob.join()
        countdownJob.join()
        viewModel.onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0D3B13),
                        AgriGreenPrimary,
                        Color(0xFF134E17),
                        Color(0xFFF1F8E9)
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Slogan Banner at the top
            Surface(
                color = RoyalOrange,
                shape = RoundedCornerShape(24.dp),
                shadowElevation = 6.dp,
                modifier = Modifier
                    .padding(bottom = 18.dp)
                    .testTag("splash_banner_tag")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "🌾  जय जवान, जय किसान  🌾",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        fontSize = 17.sp
                    )
                }
            }

            // Illustration of Tubewell & Farmer
            Surface(
                modifier = Modifier
                    .size(240.dp)
                    .shadow(12.dp, CircleShape)
                    .clip(CircleShape),
                color = Color.White
            ) {
                Image(
                    painter = painterResource(id = R.drawable.tubewell_splash_art),
                    contentDescription = "Tubewell water flowing to farmer",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // App Main Title
            Text(
                text = "डिजिटल बही-खाता",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Black,
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Tubewell & Irrigation Rental App",
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFFC8E6C9),
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Farmer Speech / Core Slogan Card
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "💧 \"अब हिसाब करना हुआ आसान!\"",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AgriGreenPrimary,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ट्यूबवेल के घंटे, नकद व बाकी का 100% सटीक हिसाब",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // 4-Second Linear Progress Bar
            LinearProgressIndicator(
                progress = { progress.value },
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = RoyalOrange,
                trackColor = Color(0x44FFFFFF)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Skip Button
            OutlinedButton(
                onClick = { viewModel.onSplashFinished() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("splash_skip_button")
            ) {
                Text(
                    text = "आगे बढ़ें (${secondsLeft}s) →",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
