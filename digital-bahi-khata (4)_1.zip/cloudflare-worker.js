/**
 * Cloudflare Worker for Bahi Khata 'Munshi AI' (Gemini Failover & Security Proxy)
 */

const MUNSHI_APP_SECRET = "munshi_tubewell_secure_2026";
const ACTIVE_MODELS = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-3.5-flash"];

export default {
async fetch(request, env) {
const cors = {
"Access-Control-Allow-Origin": "*",
"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
"Access-Control-Allow-Headers": "Content-Type, x-munshi-secret, x-goog-api-key"
};

if (request.method === "OPTIONS") {
return new Response(null, { headers: cors });
}

// 1. Read all API Keys (Checks GEMINI_API_KEYS, GEMINI_API_KEY, GEMINI_API_KEY_1, etc.)
const keys = [];
if (env.GEMINI_API_KEYS) {
env.GEMINI_API_KEYS.split(/[\n,]+/).forEach(k => {
const trimmed = k.trim();
if (trimmed && !keys.includes(trimmed)) keys.push(trimmed);
});
}
if (env.GEMINI_API_KEY) {
const trimmed = env.GEMINI_API_KEY.trim();
if (trimmed && !keys.includes(trimmed)) keys.push(trimmed);
}
if (env.GEMINI_API_KEY_1) {
const trimmed = env.GEMINI_API_KEY_1.trim();
if (trimmed && !keys.includes(trimmed)) keys.push(trimmed);
}
if (env.GEMINI_API_KEY_2) {
const trimmed = env.GEMINI_API_KEY_2.trim();
if (trimmed && !keys.includes(trimmed)) keys.push(trimmed);
}

// GET status check
if (request.method === "GET") {
return new Response(JSON.stringify({
status: keys.length > 0 ? "ONLINE" : "NO_KEYS_FOUND",
message: keys.length > 0 ? "मुंशी जी AI सक्रिय और चालू है" : "कृपया Cloudflare में GEMINI_API_KEYS सेट करें",
keysFound: keys.length,
models: ACTIVE_MODELS
}), { headers: { ...cors, "Content-Type": "application/json; charset=UTF-8" } });
}

// 2. Security Check: Block scrapers if APP_SECRET is defined in Cloudflare
const clientSecret = request.headers.get("x-munshi-secret");
if (env.APP_SECRET && clientSecret !== env.APP_SECRET) {
return new Response(JSON.stringify({ error: "Unauthorized access blocked" }), {
status: 401,
headers: { ...cors, "Content-Type": "application/json" }
});
}

if (keys.length === 0) {
return new Response(JSON.stringify({
error: "NO_KEYS",
message: "Cloudflare में GEMINI_API_KEYS खाली है"
}), {
status: 500,
headers: { ...cors, "Content-Type": "application/json" }
});
}

const reqBody = await request.text();

// 3. Call active modern Gemini model (gemini-2.5-flash) with failover
for (const key of keys) {
for (const model of ACTIVE_MODELS) {
try {
const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
const res = await fetch(url, {
method: "POST",
headers: { "Content-Type": "application/json; charset=UTF-8" },
body: reqBody
});
if (res.ok) {
return new Response(await res.text(), {
status: 200,
headers: { ...cors, "Content-Type": "application/json; charset=UTF-8" }
});
}
if (res.status === 429) break; // Next key
} catch (err) {}
}
}

return new Response(JSON.stringify({ error: "All keys or models exhausted" }), {
status: 502,
headers: { ...cors, "Content-Type": "application/json" }
});
}
};

