-- ==============================================================================
-- 🌾 KISAN TUBEWELL BAHI KHATA - SUPABASE MUNSHI & REMOTE CONFIG MASTER SCRIPT
-- ==============================================================================
-- यह SQL स्क्रिप्ट:
-- 1. app_remote_config टेबल बनाती है (या यदि पहले से है तो मिसिंग कॉलम्स जोड़ती है)
-- 2. column "required_seconds" एरर को ठीक करने के लिए ALTER TABLE चलाती है
-- 3. Row Level Security (RLS) और Policies को सही से सेट करती है
-- 4. मुंशी जी (Gemini AI) को 24-घंटे फीचर पास / VIP पास और 5 API लिमिट से जोड़ती है
-- ==============================================================================

-- 1. टेबल बनाएं (यदि पहले से नहीं बनी है)
CREATE TABLE IF NOT EXISTS public.app_remote_config (
    screen_name TEXT PRIMARY KEY,
    is_enabled BOOLEAN DEFAULT true,
    position TEXT DEFAULT 'TIED_TO_PASS',
    ad_size TEXT DEFAULT 'GEMINI_AI',
    ad_unit_id TEXT DEFAULT '5',
    required_seconds INTEGER DEFAULT 5,
    required_watch_seconds INTEGER DEFAULT 5,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. यदि टेबल पहले से मौजूद थी तो सभी ज़रूरी कॉलम सुरक्षित रूप से जोड़ें
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS is_enabled BOOLEAN DEFAULT true;
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS position TEXT DEFAULT 'TIED_TO_PASS';
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS ad_size TEXT DEFAULT 'GEMINI_AI';
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS ad_unit_id TEXT DEFAULT '5';
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS required_seconds INTEGER DEFAULT 5;
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS required_watch_seconds INTEGER DEFAULT 5;
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE public.app_remote_config ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 3. Row Level Security (RLS) सक्रिय करें
ALTER TABLE public.app_remote_config ENABLE ROW LEVEL SECURITY;

-- 4. पुरानी नीतियां हटाएं और सुरक्षित नई नीतियां (RLS Policies) बनाएं
DROP POLICY IF EXISTS "Public read app_remote_config" ON public.app_remote_config;
DROP POLICY IF EXISTS "Public read config" ON public.app_remote_config;
DROP POLICY IF EXISTS "Admin manage config" ON public.app_remote_config;
DROP POLICY IF EXISTS "Allow all app_remote_config" ON public.app_remote_config;

-- सार्वजनिक पठन नीति (App यूज़र्स बिना लॉगिन और लॉगिन दोनों में पढ़ सकते हैं)
CREATE POLICY "Public read app_remote_config" ON public.app_remote_config
    FOR SELECT TO anon, authenticated USING (true);

-- प्रबंधन नीति (अपडेट/इन्सर्ट की अनुमति)
CREATE POLICY "Allow all app_remote_config" ON public.app_remote_config
    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- ग्रांट परमिशन्स
GRANT ALL ON TABLE public.app_remote_config TO anon, authenticated, service_role;

-- 5. मुंशी जी कॉन्फ़िगरेशन दर्ज/अपडेट करें (पास आवश्यक + 5 API सवाल/दिन)
INSERT INTO public.app_remote_config (
    screen_name,
    is_enabled,
    position,
    ad_size,
    ad_unit_id,
    required_seconds,
    required_watch_seconds,
    updated_at
)
VALUES (
    'MUNSHI_PASS_CONFIG',
    true,            -- true = मुंशी जी 24h पास या VIP पास से चलेगा
    'TIED_TO_PASS',
    'GEMINI_AI',
    '5',             -- प्रतिदिन 5 Gemini AI सवाल
    5,               -- 5 API सवाल प्रति अकाउंट
    5,
    NOW()
)
ON CONFLICT (screen_name) 
DO UPDATE SET 
    is_enabled = EXCLUDED.is_enabled,
    ad_unit_id = EXCLUDED.ad_unit_id,
    required_seconds = EXCLUDED.required_seconds,
    required_watch_seconds = EXCLUDED.required_watch_seconds,
    updated_at = NOW();

-- ==============================================================================
-- भविष्य में कभी भी नियंत्रण करने के लिए 1-लाइन कमांड्स:
-- ==============================================================================
-- मुंशी को पास से अलग करने के लिए (सबके लिए खुला):
-- UPDATE public.app_remote_config SET is_enabled = false, updated_at = NOW() WHERE screen_name = 'MUNSHI_PASS_CONFIG';

-- मुंशी को वापस 24h पास और VIP पास से जोड़ने के लिए:
-- UPDATE public.app_remote_config SET is_enabled = true, updated_at = NOW() WHERE screen_name = 'MUNSHI_PASS_CONFIG';
