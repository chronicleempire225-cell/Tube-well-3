// ==============================================================================
// 🚀 SUPABASE EDGE FUNCTION: send-email-verify
// किसान ट्यूबवेल बही खाता - ईमेल सत्यापन व पासवर्ड रीसेट सर्विस
// ==============================================================================
// यह Edge Function ईमेल पर सीधा 'Confirm' लिंक और 6-अंकों का OTP भेजता है।
// जब यूजर ईमेल में लिंक पर क्लिक करता है, तो confirm-email फंक्शन डेटाबेस 
// में तुरंत स्टेटस कन्फर्म कर देता है और ऐप में अपने आप आगे बढ़ने का ऑप्शन चालू हो जाता है।
// ==============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  // Handle CORS Preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { email, name = "किसान भाई", type = "VERIFY_EMAIL", newPin = "" } = await req.json();

    if (!email || !email.includes("@")) {
      return new Response(
        JSON.stringify({ success: false, message: "कृपया सही ईमेल पता दर्ज करें!" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const cleanEmail = email.trim().toLowerCase();
    
    // 6-अंकों का सुरक्षित OTP और यूनीक कन्फर्मेशन टोकन
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const token = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 मिनट की वैधता

    // 1. डेटाबेस में टोकन व स्टेटस 'PENDING' सेव करें
    const { error: dbError } = await supabase
      .from("email_verifications")
      .insert({
        email: cleanEmail,
        token: token,
        otp: otp,
        purpose: type,
        new_pin: newPin,
        status: "PENDING",
        expires_at: expiresAt,
      });

    if (dbError) {
      console.error("DB Insert Error:", dbError);
    }

    // 2. सीधा कन्फर्मेशन लिंक तैयार करें
    const confirmUrl = `${supabaseUrl}/functions/v1/confirm-email?token=${token}`;

    // 3. ईमेल का विषय व संदेश तैयार करें
    const isPasswordReset = type === "RESET_PASSWORD";
    const subject = isPasswordReset 
      ? "🔑 पासवर्ड/पिन बदलने की पुष्टि करें - किसान ट्यूबवेल बही खाता"
      : "🌾 ईमेल सत्यापित करें - किसान ट्यूबवेल बही खाता";

    const emailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 550px; margin: auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 12px; background: #ffffff;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: #1b5e20; margin: 0;">🌾 किसान ट्यूबवेल बही खाता</h2>
          <p style="color: #64748b; font-size: 14px; margin-top: 4px;">आसान, सुरक्षित व डिजिटल हिसाब-किताब</p>
        </div>
        <hr style="border: none; border-top: 1px solid #f1f5f9; margin: 15px 0;">
        <p style="font-size: 16px; color: #1e293b;">नमस्ते <b>${name}</b>,</p>
        <p style="font-size: 14px; color: #475569; line-height: 1.6;">
          ${isPasswordReset 
            ? "आपके खाते के लिए नया सुरक्षा पासवर्ड/पिन सेट करने का अनुरोध प्राप्त हुआ है। पुष्टि करने के लिए नीचे दिए गए हरे बटन पर क्लिक करें:" 
            : "अपने खाते में इस ईमेल को सत्यापित व सुरक्षित जोड़ने के लिए नीचे दिए गए हरे बटन पर क्लिक करें:"}
        </p>

        <!-- सीधा क्लिक करने वाला बटन -->
        <div style="text-align: center; margin: 30px 0;">
          <a href="${confirmUrl}" target="_blank" style="background-color: #16a34a; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px; display: inline-block; box-shadow: 0 4px 6px rgba(22, 163, 74, 0.2);">
            ${isPasswordReset ? "✓ नया पासवर्ड कन्फर्म करें" : "✓ ईमेल तुरंत कन्फर्म करें"}
          </a>
        </div>

        <p style="text-align: center; font-size: 13px; color: #94a3b8;">
          (क्लिक करते ही आपके ऐप में आगे बढ़ने का विकल्प अपने आप चालू हो जाएगा)
        </p>

        <div style="background: #f8fafc; border-radius: 8px; padding: 15px; text-align: center; margin-top: 25px;">
          <p style="margin: 0; font-size: 13px; color: #64748b;">यदि बटन काम न करे, तो ऐप में यह 6-अंकों का ओटीपी दर्ज करें:</p>
          <h3 style="margin: 8px 0 0 0; color: #0f172a; font-size: 26px; letter-spacing: 4px; font-family: monospace;">${otp}</h3>
        </div>

        <p style="font-size: 12px; color: #94a3b8; margin-top: 20px; text-align: center;">
          ⚠️ यह लिंक व कोड अगले 15 मिनट तक मान्य है। यदि आपने यह अनुरोध नहीं किया था, तो इस ईमेल को अनदेखा करें।
        </p>
      </div>
    `;

    // 4. Resend API (या SMTP) से ईमेल भेजें (यदि RESEND_API_KEY सेट है)
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (resendApiKey) {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${resendApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: "किसान बही खाता <onboarding@resend.dev>",
          to: [cleanEmail],
          subject: subject,
          html: emailHtml,
        }),
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        token: token,
        otp: otp,
        confirmUrl: confirmUrl,
        message: "आपके ईमेल पर कन्फर्मेशन लिंक भेज दिया गया है। ईमेल में जाकर 'Confirm' पर क्लिक करें!",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: (error as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
