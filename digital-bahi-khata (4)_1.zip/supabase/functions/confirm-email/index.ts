// ==============================================================================
// 🚀 SUPABASE EDGE FUNCTION: confirm-email
// किसान ट्यूबवेल बही खाता - ईमेल सत्यापन व पासवर्ड कन्फर्मेशन हैंडलर
// ==============================================================================
// जब किसान ईमेल में 'Confirm' बटन पर क्लिक करता है, तो यह वेबपेज खुलता है।
// यह डेटाबेस में स्थिति को 'CONFIRMED' कर देता है, जिससे किसान के मोबाइल ऐप 
// में अपने आप आगे बढ़ने का ऑप्शन चालू हो जाता है।
// ==============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.0";

serve(async (req: Request) => {
  const url = new URL(req.url);
  const token = url.searchParams.get("token");

  if (!token) {
    return new Response(
      `<html><body style="font-family:sans-serif; text-align:center; padding:50px;">
        <h2 style="color:#dc2626;">⚠️ अवैध या अमान्य टोकन</h2>
        <p>यह लिंक सही नहीं है या समाप्त हो चुका है।</p>
      </body></html>`,
      { status: 400, headers: { "Content-Type": "text/html; charset=utf-8" } }
    );
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY") ?? "";
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  // 1. टोकन की जांच करें
  const { data: record, error } = await supabase
    .from("email_verifications")
    .select("*")
    .eq("token", token)
    .single();

  if (error || !record) {
    return new Response(
      `<html><body style="font-family:sans-serif; text-align:center; padding:50px;">
        <h2 style="color:#dc2626;">⚠️ लिंक नहीं मिला या समाप्त हो चुका है</h2>
        <p>कृपया ऐप में जाकर नया लिंक भेजें।</p>
      </body></html>`,
      { status: 404, headers: { "Content-Type": "text/html; charset=utf-8" } }
    );
  }

  // 2. क्या एक्सपायर हो चुका है?
  if (new Date(record.expires_at) < new Date()) {
    return new Response(
      `<html><body style="font-family:sans-serif; text-align:center; padding:50px;">
        <h2 style="color:#ea580c;">⏳ लिंक की समय सीमा समाप्त हो गई है</h2>
        <p>यह लिंक 15 मिनट से पुराना है। कृपया ऐप में जाकर नया लिंक मंगाएं।</p>
      </body></html>`,
      { status: 400, headers: { "Content-Type": "text/html; charset=utf-8" } }
    );
  }

  // 3. डेटाबेस में स्टेटस 'CONFIRMED' करें
  await supabase
    .from("email_verifications")
    .update({ status: "CONFIRMED", is_used: true, updated_at: new Date().toISOString() })
    .eq("token", token);

  // 4. अगर यह ईमेल वेरिफिकेशन था, तो प्रोफाइल में ईमेल व verified मार्क करें
  if (record.purpose === "VERIFY_EMAIL") {
    await supabase
      .from("profiles")
      .update({ is_email_verified: true, email: record.email })
      .ilike("email", record.email);
  }

  // 5. अगर यह पासवर्ड रीसेट था और नया पिन मौजूद है, तो पिन अपडेट करें
  if (record.purpose === "RESET_PASSWORD" && record.new_pin) {
    await supabase
      .from("profiles")
      .update({ pin_hash: record.new_pin })
      .ilike("email", record.email);
  }

  const isPassword = record.purpose === "RESET_PASSWORD";

  // 6. सुंदर सफलता पृष्ठ (Success HTML Page)
  const html = `
    <!DOCTYPE html>
    <html lang="hi">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>सत्यापन सफल - किसान ट्यूबवेल बही खाता</title>
      <style>
        body { font-family: 'Segoe UI', Roboto, sans-serif; background: #f0fdf4; margin: 0; padding: 30px 15px; display: flex; align-items: center; justify-content: center; min-height: 80vh; }
        .card { background: white; max-width: 450px; width: 100%; border-radius: 20px; box-shadow: 0 10px 25px rgba(22, 163, 74, 0.15); border: 2px solid #86efac; padding: 35px 25px; text-align: center; }
        .icon { width: 70px; height: 70px; background: #dcfce7; color: #16a34a; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 36px; margin-bottom: 20px; }
        h1 { color: #15803d; font-size: 24px; margin: 0 0 10px 0; }
        p { color: #475569; font-size: 15px; line-height: 1.6; margin: 8px 0; }
        .badge { display: inline-block; background: #f1f5f9; padding: 6px 14px; border-radius: 20px; font-weight: bold; color: #0f172a; margin: 15px 0; font-size: 13px; }
        .footer-note { background: #f8fafc; border-radius: 12px; padding: 15px; margin-top: 25px; border-left: 4px solid #16a34a; font-size: 13px; color: #1e293b; }
      </style>
    </head>
    <body>
      <div class="card">
        <div class="icon">✓</div>
        <h1>${isPassword ? "पासवर्ड सफलतापूर्वक सेट हो गया!" : "ईमेल सफलतापूर्वक सत्यापित हुआ!"}</h1>
        <div class="badge">ईमेल: ${record.email}</div>
        <p>
          ${isPassword 
            ? "आपके किसान खाते का नया पासवर्ड/पिन सुरक्षित रूप से अपडेट कर दिया गया है।" 
            : "आपका ईमेल किसान ट्यूबवेल बही खाता खाते से सफलता पूर्वक जुड़ गया है।"}
        </p>
        <div class="footer-note">
          📱 <b>अब आप इस पेज को बंद करके अपने मोबाइल ऐप में वापस जा सकते हैं।</b><br>
          वहाँ आगे बढ़ने का विकल्प अपने आप चालू हो गया है।
        </div>
      </div>
    </body>
    </html>
  `;

  return new Response(html, {
    status: 200,
    headers: { "Content-Type": "text/html; charset=utf-8" },
  });
});
